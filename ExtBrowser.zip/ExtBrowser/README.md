# ExtBrowser

Trình duyệt iOS (WKWebView) có quản lý extension kiểu Chrome. Dùng cá nhân, cài bằng chứng chỉ.

## Build

**Cách 1 – có Mac:**
```
brew install xcodegen
xcodegen generate
open ExtBrowser.xcodeproj
```
Chọn Team/chứng chỉ của bạn, đổi `PRODUCT_BUNDLE_IDENTIFIER` trong `project.yml` nếu cần, rồi Run.

**Cách 2 – không có Mac:** đẩy thư mục này lên GitHub, vào tab Actions, chạy workflow **Build IPA**.
Tải `ExtBrowser.ipa` (chưa ký) ở mục Artifacts, rồi ký/cài bằng chứng chỉ của bạn.

## Cách dùng

- Mở trang extension trên **Chrome Web Store** hoặc **addons.mozilla.org** → bấm nút **Thêm vào app** ở dưới màn hình.
- Nút puzzle ở thanh dưới → dán link (store, `.user.js`, `.zip`) hoặc chọn file `.zip / .crx / .xpi / .js`.
- Bấm link `.user.js` (Greasy Fork...) trong trang web → app tự cài userscript.
- Bật/tắt bằng công tắc, xóa bằng cách vuốt trái. Extension có popup/options sẽ có nút mở.

## Hỗ trợ (bản 2)

- Content script (`matches`, `exclude_matches`, `js`, `css`, `run_at`, `all_frames`, `world: "MAIN"`)
- **Background page / service worker** (trang nền ẩn): `runtime.sendMessage / onMessage / connect`, `tabs.sendMessage`, `runtime.onInstalled`, `alarms`
- `chrome.storage.local/sync/session` + `onChanged`
- **declarativeNetRequest** (luật tĩnh + động) đổi sang bộ chặn của WebKit: chạy được kiểu uBlock Lite / AdGuard MV3
- `chrome.scripting.executeScript / insertCSS`, `tabs.executeScript`, `tabs.query/get/update/create/captureVisibleTab`
- `chrome.cookies`, `chrome.downloads` (lưu vào thư mục Documents của app), `webNavigation`, `tabs.onUpdated`
- `fetch` trong trang nền/popup đi qua mạng native nên không bị CORS (giống host_permissions)
- Popup, trang options, `runtime.openOptionsPage`
- Userscript: `GM_*` (get/set/delete/list/addStyle/xmlhttpRequest/openInTab/setClipboard/download), script không khai `@grant` chạy ở world của trang
- Nút **doc** cạnh extension (có trang nền) để xem log lỗi của trang nền

## Không hỗ trợ

- `webRequest` chặn động (uBlock Origin đầy đủ), `redirect`/`modifyHeaders` của declarativeNetRequest
- Native messaging, `identity`, `proxy`, `sidePanel`, `offscreen` (các hàm này trả về rỗng, không báo lỗi)
- Nhiều tab: app chỉ có 1 tab nên `tabId` luôn là 1
- Chèn thẻ `<script src="ext://...">` vào trang https có thể bị chặn
- Cập nhật tự động extension (muốn cập nhật thì bấm "Thêm vào app" lại)
