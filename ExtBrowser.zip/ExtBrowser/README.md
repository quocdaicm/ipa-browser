# CM Browser

Trình duyệt iOS (WKWebView) có quản lý extension kiểu Chrome. Dùng cá nhân, cài bằng chứng chỉ.

## Build

**Cách 1 – có Mac:**
```
brew install xcodegen
xcodegen generate
open ExtBrowser.xcodeproj
```
Chọn Team/chứng chỉ của bạn, đổi `PRODUCT_BUNDLE_IDENTIFIER` trong `project.yml` nếu cần, rồi Run.

**Cách 2 – không có Mac:** đẩy thư mục này lên GitHub, vào tab Actions, chạy workflow **Build IPA**.
Tải `CM-Browser.ipa` (chưa ký) ở mục Artifacts, rồi ký/cài bằng chứng chỉ của bạn.

## Cách dùng

- Mở trang extension trên **Chrome Web Store** hoặc **addons.mozilla.org** → bấm nút **Thêm vào app** ở dưới màn hình.
- Nút puzzle ở thanh dưới → dán link (store, `.user.js`, `.zip`) hoặc chọn file `.zip / .crx / .xpi / .js`.
- Bấm link `.user.js` (Greasy Fork...) trong trang web → app tự cài userscript.
- Bật/tắt bằng công tắc, xóa bằng cách vuốt trái. Extension có popup/options sẽ có nút mở.

## Hỗ trợ (bản 2)

- Content script (`matches`, `exclude_matches`, `js`, `css`, `run_at`, `all_frames`, `world: "MAIN"`)
- **Background page / service worker** (trang nền ẩn): `runtime.sendMessage / onMessage / connect`, `tabs.sendMessage`, `runtime.onInstalled`, `alarms`
- `chrome.storage.local/sync/session` + `onChanged`
- **declarativeNetRequest** (luật tĩnh + động) đổi sang bộ chặn của WebKit: chạy được kiểu uBlock Lite / AdGuard MV3
- `chrome.scripting.executeScript / insertCSS`, `tabs.executeScript`, `tabs.query/get/update/create/captureVisibleTab`
- `chrome.cookies`, `chrome.downloads` (lưu vào thư mục Documents của app), `webNavigation`, `tabs.onUpdated`
- `fetch` trong trang nền/popup đi qua mạng native nên không bị CORS (giống host_permissions)
- Popup, trang options, `runtime.openOptionsPage`
- Userscript: `GM_*` (get/set/delete/list/addStyle/xmlhttpRequest/openInTab/setClipboard/download), script không khai `@grant` chạy ở world của trang
- Nút **doc** cạnh extension (có trang nền) để xem log lỗi của trang nền

## Không hỗ trợ

- `webRequest` chặn động (uBlock Origin đầy đủ), `redirect`/`modifyHeaders` của declarativeNetRequest
- Native messaging, `identity`, `proxy`, `sidePanel`, `offscreen` (các hàm này trả về rỗng, không báo lỗi)
- Nhiều tab: app chỉ có 1 tab nên `tabId` luôn là 1
- Chèn thẻ `<script src="ext://...">` vào trang https có thể bị chặn
- Cập nhật tự động extension (muốn cập nhật thì bấm "Thêm vào app" lại)

## Bản 3: chặn quảng cáo, popup, video mạng yếu

Nút khiên ở thanh dưới mở menu 3 công tắc:
- **Chặn quảng cáo**: luật WebKit dựng sẵn (chặn các máy chủ quảng cáo phổ biến + ẩn khung quảng cáo).
- **Chặn popup / tự mở tab**: `window.open` chỉ chạy khi vừa có thao tác thật; tab mới chỉ mở khi bấm link; chặn nhảy sang scheme lạ.
- **Tiết kiệm dữ liệu (mạng yếu)**: tự bật khi iOS ở Chế độ dữ liệu thấp. Video tải `metadata` trước, không tự phát khi chưa chạm, ảnh tải lười, video bị đứng lâu sẽ tự nạp lại và phát tiếp đúng vị trí (chỉ với video thường, không áp dụng cho player MSE/blob như YouTube).

## Tải file

Link tải (Content-Disposition: attachment, file trình duyệt không mở được, thuộc tính `download`) được tải bằng WKDownload vào `Documents/Downloads` (xem trong app Tệp). Menu khiên → **Tải xuống**: xem tiến độ, chia sẻ/lưu vào Tệp, vuốt trái để xoá; file `.crx .xpi .zip .js` có nút **Cài** để cài làm extension.

## Dấu trang & lịch sử

Menu khiên → **Thêm dấu trang** (bấm lại để bỏ) và **Dấu trang & Lịch sử** (tìm kiếm, vuốt trái để xoá, “Xoá hết” cho lịch sử). Dữ liệu lưu ở `Application Support/library.json`, giữ tối đa 2000 mục lịch sử.

## Thanh địa chỉ

Khi không nhập chỉ hiện ổ khoá + tên miền (`exclamationmark` màu cam nếu trang HTTP không mã hoá). Bấm vào ô: xoá URL cũ, hiện gợi ý từ dấu trang và lịch sử (kèm dòng “Tìm …”), có nút ✕ để xoá nhanh chữ đang gõ.

## Tìm trong trang & chia sẻ

Menu khiên → **Tìm trong trang** (thanh tìm của iOS, có nút lên/xuống giữa các kết quả) và **Chia sẻ** (gửi link trang đang xem).

## Xem bản máy tính

Menu khiên → công tắc **Xem bản máy tính**: áp dụng riêng cho tab đang xem và tải lại trang. Tab mới mặc định là bản điện thoại.

## Tab riêng tư

Trong màn Tab, bấm **+** → **Tab riêng tư**. Tab riêng tư dùng kho dữ liệu tạm (cookie, cache không ghi xuống máy), không ghi lịch sử; đóng hết tab riêng tư thì dữ liệu bị bỏ. Ô địa chỉ và số tab chuyển sang màu bạc, nền đen có hình SVG (bg_private) khi đang ở tab riêng tư. Link mở từ tab riêng tư cũng ra tab riêng tư. Lưu ý: file đã tải và dấu trang vẫn được giữ.

## Sửa lỗi nhỏ

- Hộp nhập `prompt()` của JavaScript hoạt động (trước đây trả về rỗng).
- Camera / micro / vị trí: trang web xin quyền thì iOS hiện hộp hỏi (đã khai báo trong `project.yml`).
- Trang HTTP không mã hoá: hỏi xác nhận một lần cho mỗi tên miền trong phiên (bỏ qua localhost và mạng nội bộ).

## Cài đặt, kéo để tải lại, tự ẩn thanh

- Menu khiên → **Cài đặt**: chọn công cụ tìm kiếm (Google / DuckDuckGo / Bing), trang chủ, xoá lịch sử, xoá cookie và bộ nhớ đệm.
- Kéo trang xuống để tải lại.
- Cuộn xuống thì thanh địa chỉ và thanh công cụ tự ẩn, cuộn lên (hoặc về đầu trang, hoặc bấm vào ô địa chỉ) thì hiện lại.

## Toàn màn hình (chơi web game)

- Nút **⤢** ở thanh dưới (hoặc menu khiên → **Toàn màn hình (chơi game)**): ẩn thanh địa chỉ + thanh công cụ + thanh trạng thái + thanh home, tự xoay ngang.
- Khi toàn màn hình có **nút nổi mờ** ở mép trái: chạm để hiện **Thoát / Tải lại**, kéo để dời chỗ (tránh che HUD của game).
- Tắt vuốt cạnh quay lại, kéo tải lại, nảy trang và pinch để không vướng thao tác game.
- Script hỗ trợ game dựng sẵn (Cài đặt → **Chơi game**): thêm Fullscreen API (game gọi `requestFullscreen()` sẽ tự vào chế độ này), chặn zoom/chạm đúp, chọn chữ, menu giữ lâu, kéo trang; tự bắn sự kiện `resize` để canvas co giãn lại.
- **Làm nét game** (Cài đặt → Chơi game): *Nét pixel* tắt làm mịn khi canvas bị phóng to (hết nhoè, chữ sắc cạnh); *Nét tối đa* ép thêm `devicePixelRatio = 3` cho game có tính theo DPR (nặng máy hơn, cần tải lại trang). Chỉ áp dụng khi đang toàn màn hình.

## Giao diện

Ô địa chỉ dạng viên thuốc có viền sáng khi nhập, thanh tiến trình mảnh theo màu chủ đạo (bạc ở tab riêng tư), thanh công cụ kính mờ có đường kẻ trên, biểu tượng khiên xanh khi chặn quảng cáo, số tab có nền nhạt, danh sách tab dạng thẻ có chữ cái đầu của trang, thông báo nổi có bóng.

## Phát nền (nhạc, video)

- `UIBackgroundModes: audio` + `AVAudioSession` category `playback`: nhạc/âm thanh video vẫn phát khi khoá màn hình hoặc sang app khác, có điều khiển ở màn hình khoá.
- Script dựng sẵn giữ `document.hidden = false` và chặn `visibilitychange` để site không tự dừng; khi app vào nền, media đang phát mà bị hệ thống tạm dừng sẽ được bật lại.
- Video: iOS dừng phần hình khi ở nền (âm thanh vẫn chạy); muốn giữ hình hãy dùng Hình trong hình (PiP) của trình phát.
- Bật/tắt tại Cài đặt → **Phát nền**.

## Giao diện mới (v4)

- Biểu tượng vẽ bằng **SVG** (23 file trong `Assets.xcassets/ic_*.imageset`, nét 2px bo tròn, tô màu theo chủ đề). Muốn đổi icon chỉ cần thay file `.svg` cùng tên.
- Màu chủ đạo xanh ngọc → lục (`Theme.swift`), nút có hiệu ứng nhún khi bấm.
- Ô địa chỉ dạng viên thuốc nổi: ổ khoá/cảnh báo, nút tải lại/dừng ngay trong ô, thanh tiến trình mảnh.
- Thanh công cụ dạng viên thuốc nổi kính mờ: Lùi, Tiến, Tab, Toàn màn hình, Extension, Menu.
- **Menu** là bảng lưới ô biểu tượng (kéo lên để mở rộng): ô bật/tắt (chặn QC, popup, tiết kiệm dữ liệu, bản máy tính) sáng màu gradient khi đang bật; các ô công cụ gồm toàn màn hình, tìm trong trang, chia sẻ, dấu trang, lịch sử, tải xuống, tab riêng tư, cài đặt.

## Kiểm tra extension trước khi cài

Mỗi extension (store, link, file) được kiểm tra bằng `ExtCompat.swift` **trước khi ghi xuống máy**:

- **Không cài được** (báo "Không cài được: tên: lý do", không ghi gì): theme / từ điển / gói ngôn ngữ; `manifest_version` sai; chỉ có side panel, devtools, thay tab mới; chỉ có luật redirect/modifyHeaders; cần native messaging, proxy/VPN, `webRequestBlocking` mà không có content script hay luật chặn DNR; chỉ chạy nền dựa vào `webRequest`; không có thành phần nào chạy được.
- **Cài được nhưng chạy một phần**: thông báo "Đã cài: … Chưa chạy được: …" và dòng cam trong danh sách extension (webRequest, identity, offscreen, bookmarks/history, menu chuột phải, thông báo, luật DNR bị bỏ qua, file bị thiếu...).
- **Chạy tốt**: có content script, luật chặn (block/allow), trang nền hoặc popup/options và không phụ thuộc API chưa hỗ trợ.

## Thanh bên (side panel)

- Extension khai `side_panel.default_path` (Chrome) hoặc `sidebar_action.default_panel` (Firefox) được cài bình thường; trong danh sách extension có nút **thanh bên** (biểu tượng ▯|) để mở trang đó dạng bảng trượt (kéo lên để mở rộng).
- `chrome.sidePanel.open()` và `browser.sidebarAction.open/toggle()` mở bảng này; `setOptions` / `setPanelBehavior` được nhận nhưng không làm gì.
- Trang thanh bên dùng được `tabs.query`, `tabs.sendMessage`, `storage`, `runtime.sendMessage` như popup. Tab hiện tại là trang đang mở lúc bấm.

## Cửa hàng & cài nhiều extension

Nút ghép hình → mục **Cửa hàng**:
- **Mở Chrome Web Store / Firefox Add-ons**: mở thẳng trong app; vào trang extension thì bấm **Thêm vào app**.
- **Dán nhiều link → chọn để cài**: dán một đoạn văn bản chứa nhiều link store, `.user.js`, `.zip/.crx/.xpi` hoặc ID Chrome (32 ký tự) → app tách thành danh sách có tên extension, chạm để chọn rồi bấm **Cài … đã chọn**; mỗi dòng báo cài xong hay lý do không cài được.
- **Gợi ý nhanh**: vài extension phổ biến, chạm là cài.

## Chọn chất lượng video

- Khi phát video HLS (.m3u8) có nhiều mức trong trình phát toàn màn hình sẽ có nút chất lượng ở mép trái (Auto / 360p / 720p / 1080p / 2K / 4K…), mờ dần sau vài giây và sáng lại khi chạm màn hình.
- Chọn một mức = giới hạn **tối đa** mức đó; trình phát vẫn tự hạ xuống nếu mạng yếu. Lựa chọn được nhớ cho lần sau.
- **Auto**: Wi-Fi không giới hạn, mạng di động (kể cả điểm phát sóng) tối đa 720p, chế độ dữ liệu thấp của iOS hoặc nút Tiết kiệm dữ liệu tối đa 360p. Đổi mạng giữa chừng sẽ tự điều chỉnh.
- Mặc định đặt trong Cài đặt → Plugin Xem video → Chất lượng tối đa.
- Video MP4 trực tiếp chỉ có một mức nên không có nút này.

## Giao diện (thiết kế lại)

- Menu: lưới 4 cột, mọi ô cao bằng nhau (nhãn cố định 2 dòng, căn trên) nên các hàng luôn thẳng hàng; toàn bộ biểu tượng là SVG nét mảnh cùng cỡ (thêm `ic_video`).
- Độ nét: viền thẻ/ô/ô nhập dùng nét mảnh tròn pixel (1 px màn 2x, 2 px màn 3x), thẻ đậm hơn và viền rõ hơn, bóng nhẹ hơn; biểu tượng giữ vector.
- Nhãn nhóm dùng chung một kiểu chữ (`Theme.sectionFont`).

## Phát video đã tải

Menu → Tải xuống: video MP4/M4V/MOV đã tải xong hiện ảnh xem trước có biểu tượng phát. Bấm vào ảnh, nút ▶ hoặc cả hàng để phát ngay bằng trình phát toàn màn hình (nhớ vị trí xem, có PiP). WEBM/MKV iOS không phát được nên vẫn chỉ chia sẻ/xoá.

## Khoá dấu trang & lịch sử

Cài đặt → **Khoá dấu trang & lịch sử**: đặt mật khẩu riêng 6 ký tự (độc lập với khoá ứng dụng), tuỳ chọn mở khoá bằng Face ID / Touch ID.
- Khi bật: xem **Dấu trang & Lịch sử** và bấm **Dấu trang** trong menu đều hiện màn nhập mật khẩu; gợi ý dấu trang/lịch sử trên thanh địa chỉ bị ẩn.
- Tự khoá lại khi đóng bảng hoặc thoát app. Sai 5 lần thì tạm khoá nhập, thời gian tăng dần.
- Mật khẩu chỉ lưu dạng băm có muối trong Keychain; quên mật khẩu thì không khôi phục được.
- Lịch sử vẫn được ghi bình thường khi đang khoá; “Xoá lịch sử” trong Cài đặt không cần mật khẩu.

## Tính năng kiểu Cốc Cốc (v5)

Menu → mục **Trang đang xem** có 4 ô: Chế độ đọc, Dịch trang, Lưu thành PDF, Nền tối.

- **Chế độ đọc**: tách phần bài viết chính, bỏ quảng cáo / menu / bình luận / khối bài liên quan, hiện lại với bố cục gọn (ảnh, tiêu đề, danh sách, trích dẫn, bảng được giữ). Có nút **A− / A+** (cỡ chữ), **Nền** (sáng / sepia / tối), **✕ Thoát**. Cũng bật được bằng biểu tượng quyển sách trong ô địa chỉ. Cỡ chữ và giao diện được nhớ. Trang không có bài viết (trang chủ, danh sách…) sẽ báo không dùng được.
- **Lưu thành PDF**: tạo PDF nhiều trang A4 bằng bộ in của iOS (nếu lỗi thì chụp cả trang thành 1 trang dài), lưu vào `Documents/Downloads` (hiện trong Tải xuống và app Tệp) rồi mở bảng chia sẻ. Bật chế độ đọc trước khi lưu sẽ ra PDF gọn hơn.
- **Nền tối cho mọi trang**: đảo màu trang sáng, giữ nguyên ảnh / video, bỏ qua trang vốn đã tối. Bật ở Menu hoặc Cài đặt → Hiển thị trang. Chỉ đảo ở khung chính của trang.
- **Menu giữ lâu trên liên kết**: Mở · Mở trong thẻ mới · Mở ở thẻ nền · Mở trong thẻ riêng tư · Sao chép liên kết · Chia sẻ · Tải liên kết về. Với ảnh / chữ vẫn là menu mặc định của iOS.
- **Nhóm tab**: Màn Thẻ có thanh nhóm (Tất cả / từng nhóm / + Nhóm mới). Giữ lâu một thẻ → *Thêm vào nhóm*; giữ lâu tên nhóm → đổi tên, giải tán, đóng cả nhóm. Thẻ trong nhóm có viền màu nhóm; bấm + khi đang xem một nhóm sẽ mở thẻ mới vào nhóm đó; link mở từ một thẻ kế thừa nhóm của thẻ đó. Tab riêng tư không có nhóm. Nhóm chỉ lưu trong phiên (app chưa lưu lại các tab khi thoát).
- **Dịch trang**: dùng Google Dịch, dịch ngay trong trang đang xem (giữ phiên đăng nhập). Nếu trang chặn script ngoài thì tự chuyển sang `translate.goog`. Bấm lại để về bản gốc. Chọn ngôn ngữ đích và bật / tắt gợi ý dịch (hiện khi ngôn ngữ trang khác ngôn ngữ đích, mỗi tên miền hỏi một lần) tại Cài đặt → Dịch trang. Nội dung trang được gửi tới Google khi dịch.

## Chép văn bản tự do & chụp cả trang

- **Chép tự do** (Menu → *Chép tự do*, hoặc Cài đặt → Hiển thị trang; mặc định bật): ép mọi chữ chọn được (`user-select`), chặn các trình xử lý `copy / cut / selectstart / contextmenu / dragstart` của trang để trang không cấm chọn, không chèn thêm chữ vào clipboard. Tự tắt khi chơi game toàn màn hình. Không vượt được trang phủ lớp trong suốt lên chữ hoặc chữ vẽ bằng ảnh/canvas.
- **Chụp cả trang** (Menu → *Chụp cả trang*): tự cuộn qua trang để ảnh tải lười được nạp, chụp toàn bộ chiều dài thành ảnh PNG, lưu vào Tải xuống rồi mở bảng chia sẻ (có *Lưu hình ảnh* vào Ảnh). Trang quá dài sẽ được giảm độ phân giải (cạnh dài tối đa 16000 px).

## Quét video chuẩn hơn (học theo cách Cốc Cốc)

Cốc Cốc không đoán link từ HTML mà bắt đúng yêu cầu mạng của trình phát, chỉ hiện nút khi trình phát thật sự tải video, và lọc bỏ đoạn nhỏ/quảng cáo. App làm tương tự:

- **Bỏ đoạn rác của luồng**: `.ts`, `.m4s`, `seg-12.mp4`, `init.mp4`, `video/mp2t`, `video/iso.segment`, âm thanh thuần… không còn bị liệt kê như một "video".
- **Nhận link không có đuôi**: dựa vào `Content-Type`, tham số `mime=video/mp4`, và `initiatorType = video` của PerformanceObserver.
- **Playlist HLS ẩn**: nếu phản hồi là `text/plain`/`octet-stream` nhưng nội dung bắt đầu bằng `#EXTM3U` vẫn nhận (cả fetch lẫn XHR).
- **Chống trùng**: bỏ tham số `range`/`bytestart`/`byteend`; master HLS gộp các mức chất lượng con thành một mục.
- **Lọc mẩu nhỏ**: file dưới ~100 KB hoặc phản hồi dưới ~150 KB không phải playlist bị bỏ; HLS toàn âm thanh bị bỏ.
- **Thông tin trên thẻ**: hiện độ phân giải, dung lượng (đọc từ `Content-Range`) và thời lượng (cộng `#EXTINF` với video đã kết thúc).
- **Shadow DOM & iframe**: quét cả trình phát dựng bằng web component; tên video lấy tiêu đề trang chính khi video nằm trong iframe.

## Chọn chất lượng khi tải (HLS)

Bấm **Tải về** trên video HLS nhiều mức → hiện hộp chọn 1080p / 720p / 480p… (mỗi chiều cao một mục, lấy bitrate cao nhất). Video chỉ có một mức hoặc MP4 trực tiếp thì tải ngay. Tên file ghi kèm chất lượng đã chọn.

## Sửa lỗi Menu cuộn lâu bị khựng

Nguyên nhân: nền Cà Mau vẽ hiệu ứng động 30 khung/giây (đom đóm / lá rơi) liên tục phía sau, trong khi 6 thẻ kính mờ + bóng lớn cuộn đè lên và tranh SVG đáy (vector) bị vẽ lại + che mờ mỗi khung hình → GPU quá tải, máy nóng dần rồi giật. Đã sửa: Menu không chạy hiệu ứng động, thẻ dùng nền đặc nhẹ + bóng nhỏ trong Menu, phần nền tĩnh được vẽ sẵn thành ảnh (`drawingGroup`), hiệu ứng nền ở nơi khác giảm còn 20 khung/giây và tự tắt khi app ra nền hoặc máy nóng.

## Sửa giao diện đêm của trang chủ

Khi chọn giao diện Tối trong app, khung app tối nhưng trang chủ Cà Mau (và mọi trang web) vẫn báo chế độ sáng nên hiện tranh ban ngày, thẻ trắng, chữ đen. Nguyên nhân: WKWebView không tự theo `preferredColorScheme` của SwiftUI. Đã đặt `overrideUserInterfaceStyle` cho từng webview theo Cài đặt (Sáng / Tối / Tự động) và tab riêng tư (luôn tối), cập nhật ngay khi đổi cài đặt.

## Menu: ô "Giao diện" thay cho "Nền tối"

Đã bỏ ô **Nền tối** khỏi Menu (đổi Sáng/Tối đã tự đảo nền trang, nên ô riêng này thừa). Thay bằng ô **Giao diện** (biểu tượng đổi theo chế độ hiện tại) mở bảng chọn Tự động / Sáng / Tối và chủ đề màu Lagoon / Cà Mau. Tuỳ chọn "Nền tối cho mọi trang" vẫn còn trong Cài đặt.
