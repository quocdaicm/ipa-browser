# ExtBrowser

Trình duyệt iOS (WKWebView) có quản lý extension kiểu Chrome. Dùng cá nhân, cài bằng chứng chỉ.

## Build

**Cách 1 – có Mac:**
```
brew install xcodegen
xcodegen generate
open ExtBrowser.xcodeproj
```
Chọn Team/chứng chỉ của bạn, đổi `PRODUCT_BUNDLE_IDENTIFIER` trong `project.yml` nếu cần, rồi Run.

**Cách 2 – không có Mac:** đẩy thư mục này lên GitHub, vào tab Actions, chạy workflow **Build IPA**.
Tải `ExtBrowser.ipa` (chưa ký) ở mục Artifacts, rồi ký/cài bằng chứng chỉ của bạn.

## Cách dùng

- Mở trang extension trên **Chrome Web Store** hoặc **addons.mozilla.org** → bấm nút **Thêm vào app** ở dưới màn hình.
- Nút puzzle ở thanh dưới → dán link (store, `.user.js`, `.zip`) hoặc chọn file `.zip / .crx / .xpi / .js`.
- Bấm link `.user.js` (Greasy Fork...) trong trang web → app tự cài userscript.
- Bật/tắt bằng công tắc, xóa bằng cách vuốt trái. Extension có popup/options sẽ có nút mở.

## Hỗ trợ (bản 2)

- Content script (`matches`, `exclude_matches`, `js`, `css`, `run_at`, `all_frames`, `world: "MAIN"`)
- **Background page / service worker** (trang nền ẩn): `runtime.sendMessage / onMessage / connect`, `tabs.sendMessage`, `runtime.onInstalled`, `alarms`
- `chrome.storage.local/sync/session` + `onChanged`
- **declarativeNetRequest** (luật tĩnh + động) đổi sang bộ chặn của WebKit: chạy được kiểu uBlock Lite / AdGuard MV3
- `chrome.scripting.executeScript / insertCSS`, `tabs.executeScript`, `tabs.query/get/update/create/captureVisibleTab`
- `chrome.cookies`, `chrome.downloads` (lưu vào thư mục Documents của app), `webNavigation`, `tabs.onUpdated`
- `fetch` trong trang nền/popup đi qua mạng native nên không bị CORS (giống host_permissions)
- Popup, trang options, `runtime.openOptionsPage`
- Userscript: `GM_*` (get/set/delete/list/addStyle/xmlhttpRequest/openInTab/setClipboard/download), script không khai `@grant` chạy ở world của trang
- Nút **doc** cạnh extension (có trang nền) để xem log lỗi của trang nền

## Không hỗ trợ

- `webRequest` chặn động (uBlock Origin đầy đủ), `redirect`/`modifyHeaders` của declarativeNetRequest
- Native messaging, `identity`, `proxy`, `sidePanel`, `offscreen` (các hàm này trả về rỗng, không báo lỗi)
- Nhiều tab: app chỉ có 1 tab nên `tabId` luôn là 1
- Chèn thẻ `<script src="ext://...">` vào trang https có thể bị chặn
- Cập nhật tự động extension (muốn cập nhật thì bấm "Thêm vào app" lại)

## Bản 3: chặn quảng cáo, popup, video mạng yếu

Nút khiên ở thanh dưới mở menu 3 công tắc:
- **Chặn quảng cáo**: luật WebKit dựng sẵn (chặn các máy chủ quảng cáo phổ biến + ẩn khung quảng cáo).
- **Chặn popup / tự mở tab**: `window.open` chỉ chạy khi vừa có thao tác thật; tab mới chỉ mở khi bấm link; chặn nhảy sang scheme lạ.
- **Tiết kiệm dữ liệu (mạng yếu)**: tự bật khi iOS ở Chế độ dữ liệu thấp. Video tải `metadata` trước, không tự phát khi chưa chạm, ảnh tải lười, video bị đứng lâu sẽ tự nạp lại và phát tiếp đúng vị trí (chỉ với video thường, không áp dụng cho player MSE/blob như YouTube).

## Tải file

Link tải (Content-Disposition: attachment, file trình duyệt không mở được, thuộc tính `download`) được tải bằng WKDownload vào `Documents/Downloads` (xem trong app Tệp). Menu khiên → **Tải xuống**: xem tiến độ, chia sẻ/lưu vào Tệp, vuốt trái để xoá; file `.crx .xpi .zip .js` có nút **Cài** để cài làm extension.

## Dấu trang & lịch sử

Menu khiên → **Thêm dấu trang** (bấm lại để bỏ) và **Dấu trang & Lịch sử** (tìm kiếm, vuốt trái để xoá, “Xoá hết” cho lịch sử). Dữ liệu lưu ở `Application Support/library.json`, giữ tối đa 2000 mục lịch sử.

## Thanh địa chỉ

Khi không nhập chỉ hiện ổ khoá + tên miền (`exclamationmark` màu cam nếu trang HTTP không mã hoá). Bấm vào ô: xoá URL cũ, hiện gợi ý từ dấu trang và lịch sử (kèm dòng “Tìm …”), có nút ✕ để xoá nhanh chữ đang gõ.

## Tìm trong trang & chia sẻ

Menu khiên → **Tìm trong trang** (thanh tìm của iOS, có nút lên/xuống giữa các kết quả) và **Chia sẻ** (gửi link trang đang xem).

## Xem bản máy tính

Menu khiên → công tắc **Xem bản máy tính**: áp dụng riêng cho tab đang xem và tải lại trang. Tab mới mặc định là bản điện thoại.

## Tab riêng tư

Trong màn Tab, bấm **+** → **Tab riêng tư**. Tab riêng tư dùng kho dữ liệu tạm (cookie, cache không ghi xuống máy), không ghi lịch sử; đóng hết tab riêng tư thì dữ liệu bị bỏ. Ô địa chỉ và số tab chuyển sang màu tím khi đang ở tab riêng tư. Link mở từ tab riêng tư cũng ra tab riêng tư. Lưu ý: file đã tải và dấu trang vẫn được giữ.

## Sửa lỗi nhỏ

- Hộp nhập `prompt()` của JavaScript hoạt động (trước đây trả về rỗng).
- Camera / micro / vị trí: trang web xin quyền thì iOS hiện hộp hỏi (đã khai báo trong `project.yml`).
- Trang HTTP không mã hoá: hỏi xác nhận một lần cho mỗi tên miền trong phiên (bỏ qua localhost và mạng nội bộ).

## Cài đặt, kéo để tải lại, tự ẩn thanh

- Menu khiên → **Cài đặt**: chọn công cụ tìm kiếm (Google / DuckDuckGo / Bing), trang chủ, xoá lịch sử, xoá cookie và bộ nhớ đệm.
- Kéo trang xuống để tải lại.
- Cuộn xuống thì thanh địa chỉ và thanh công cụ tự ẩn, cuộn lên (hoặc về đầu trang, hoặc bấm vào ô địa chỉ) thì hiện lại.
