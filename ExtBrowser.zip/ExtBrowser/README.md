# ExtBrowser

Trình duyệt iOS (WKWebView) có quản lý extension kiểu Chrome. Dùng cá nhân, cài bằng chứng chỉ.

## Build

**Cách 1 – có Mac:**
```
brew install xcodegen
xcodegen generate
open ExtBrowser.xcodeproj
```
Chọn Team/chứng chỉ của bạn, đổi `PRODUCT_BUNDLE_IDENTIFIER` trong `project.yml` nếu cần, rồi Run.

**Cách 2 – không có Mac:** đẩy thư mục này lên GitHub, vào tab Actions, chạy workflow **Build IPA**.
Tải `ExtBrowser.ipa` (chưa ký) ở mục Artifacts, rồi ký/cài bằng chứng chỉ của bạn.

## Cách dùng

- Mở trang extension trên **Chrome Web Store** hoặc **addons.mozilla.org** → bấm nút **Thêm vào app** ở dưới màn hình.
- Nút puzzle ở thanh dưới → dán link (store, `.user.js`, `.zip`) hoặc chọn file `.zip / .crx / .xpi / .js`.
- Bấm link `.user.js` (Greasy Fork...) trong trang web → app tự cài userscript.
- Bật/tắt bằng công tắc, xóa bằng cách vuốt trái. Extension có popup/options sẽ có nút mở.

## Hỗ trợ (bản 2)

- Content script (`matches`, `exclude_matches`, `js`, `css`, `run_at`, `all_frames`, `world: "MAIN"`)
- **Background page / service worker** (trang nền ẩn): `runtime.sendMessage / onMessage / connect`, `tabs.sendMessage`, `runtime.onInstalled`, `alarms`
- `chrome.storage.local/sync/session` + `onChanged`
- **declarativeNetRequest** (luật tĩnh + động) đổi sang bộ chặn của WebKit: chạy được kiểu uBlock Lite / AdGuard MV3
- `chrome.scripting.executeScript / insertCSS`, `tabs.executeScript`, `tabs.query/get/update/create/captureVisibleTab`
- `chrome.cookies`, `chrome.downloads` (lưu vào thư mục Documents của app), `webNavigation`, `tabs.onUpdated`
- `fetch` trong trang nền/popup đi qua mạng native nên không bị CORS (giống host_permissions)
- Popup, trang options, `runtime.openOptionsPage`
- Userscript: `GM_*` (get/set/delete/list/addStyle/xmlhttpRequest/openInTab/setClipboard/download), script không khai `@grant` chạy ở world của trang
- Nút **doc** cạnh extension (có trang nền) để xem log lỗi của trang nền

## Không hỗ trợ

- `webRequest` chặn động (uBlock Origin đầy đủ), `redirect`/`modifyHeaders` của declarativeNetRequest
- Native messaging, `identity`, `proxy`, `sidePanel`, `offscreen` (các hàm này trả về rỗng, không báo lỗi)
- Nhiều tab: app chỉ có 1 tab nên `tabId` luôn là 1
- Chèn thẻ `<script src="ext://...">` vào trang https có thể bị chặn
- Cập nhật tự động extension (muốn cập nhật thì bấm "Thêm vào app" lại)

## Bản 3: chặn quảng cáo, popup, video mạng yếu

Nút khiên ở thanh dưới mở menu 3 công tắc:
- **Chặn quảng cáo**: luật WebKit dựng sẵn (chặn các máy chủ quảng cáo phổ biến + ẩn khung quảng cáo).
- **Chặn popup / tự mở tab**: `window.open` chỉ chạy khi vừa có thao tác thật; tab mới chỉ mở khi bấm link; chặn nhảy sang scheme lạ.
- **Tiết kiệm dữ liệu (mạng yếu)**: tự bật khi iOS ở Chế độ dữ liệu thấp. Video tải `metadata` trước, không tự phát khi chưa chạm, ảnh tải lười, video bị đứng lâu sẽ tự nạp lại và phát tiếp đúng vị trí (chỉ với video thường, không áp dụng cho player MSE/blob như YouTube).

## Tải file

Link tải (Content-Disposition: attachment, file trình duyệt không mở được, thuộc tính `download`) được tải bằng WKDownload vào `Documents/Downloads` (xem trong app Tệp). Menu khiên → **Tải xuống**: xem tiến độ, chia sẻ/lưu vào Tệp, vuốt trái để xoá; file `.crx .xpi .zip .js` có nút **Cài** để cài làm extension.

## Dấu trang & lịch sử

Menu khiên → **Thêm dấu trang** (bấm lại để bỏ) và **Dấu trang & Lịch sử** (tìm kiếm, vuốt trái để xoá, “Xoá hết” cho lịch sử). Dữ liệu lưu ở `Application Support/library.json`, giữ tối đa 2000 mục lịch sử.

## Thanh địa chỉ

Khi không nhập chỉ hiện ổ khoá + tên miền (`exclamationmark` màu cam nếu trang HTTP không mã hoá). Bấm vào ô: xoá URL cũ, hiện gợi ý từ dấu trang và lịch sử (kèm dòng “Tìm …”), có nút ✕ để xoá nhanh chữ đang gõ.

## Tìm trong trang & chia sẻ

Menu khiên → **Tìm trong trang** (thanh tìm của iOS, có nút lên/xuống giữa các kết quả) và **Chia sẻ** (gửi link trang đang xem).

## Xem bản máy tính

Menu khiên → công tắc **Xem bản máy tính**: áp dụng riêng cho tab đang xem và tải lại trang. Tab mới mặc định là bản điện thoại.

## Tab riêng tư

Trong màn Tab, bấm **+** → **Tab riêng tư**. Tab riêng tư dùng kho dữ liệu tạm (cookie, cache không ghi xuống máy), không ghi lịch sử; đóng hết tab riêng tư thì dữ liệu bị bỏ. Ô địa chỉ và số tab chuyển sang màu bạc, nền đen có hình SVG (bg_private) khi đang ở tab riêng tư. Link mở từ tab riêng tư cũng ra tab riêng tư. Lưu ý: file đã tải và dấu trang vẫn được giữ.

## Sửa lỗi nhỏ

- Hộp nhập `prompt()` của JavaScript hoạt động (trước đây trả về rỗng).
- Camera / micro / vị trí: trang web xin quyền thì iOS hiện hộp hỏi (đã khai báo trong `project.yml`).
- Trang HTTP không mã hoá: hỏi xác nhận một lần cho mỗi tên miền trong phiên (bỏ qua localhost và mạng nội bộ).

## Cài đặt, kéo để tải lại, tự ẩn thanh

- Menu khiên → **Cài đặt**: chọn công cụ tìm kiếm (Google / DuckDuckGo / Bing), trang chủ, xoá lịch sử, xoá cookie và bộ nhớ đệm.
- Kéo trang xuống để tải lại.
- Cuộn xuống thì thanh địa chỉ và thanh công cụ tự ẩn, cuộn lên (hoặc về đầu trang, hoặc bấm vào ô địa chỉ) thì hiện lại.

## Toàn màn hình (chơi web game)

- Nút **⤢** ở thanh dưới (hoặc menu khiên → **Toàn màn hình (chơi game)**): ẩn thanh địa chỉ + thanh công cụ + thanh trạng thái + thanh home, tự xoay ngang.
- Khi toàn màn hình có **nút nổi mờ** ở mép trái: chạm để hiện **Thoát / Tải lại**, kéo để dời chỗ (tránh che HUD của game).
- Tắt vuốt cạnh quay lại, kéo tải lại, nảy trang và pinch để không vướng thao tác game.
- Script hỗ trợ game dựng sẵn (Cài đặt → **Chơi game**): thêm Fullscreen API (game gọi `requestFullscreen()` sẽ tự vào chế độ này), chặn zoom/chạm đúp, chọn chữ, menu giữ lâu, kéo trang; tự bắn sự kiện `resize` để canvas co giãn lại.
- **Làm nét game** (Cài đặt → Chơi game): *Nét pixel* tắt làm mịn khi canvas bị phóng to (hết nhoè, chữ sắc cạnh); *Nét tối đa* ép thêm `devicePixelRatio = 3` cho game có tính theo DPR (nặng máy hơn, cần tải lại trang). Chỉ áp dụng khi đang toàn màn hình.

## Giao diện

Ô địa chỉ dạng viên thuốc có viền sáng khi nhập, thanh tiến trình mảnh theo màu chủ đạo (bạc ở tab riêng tư), thanh công cụ kính mờ có đường kẻ trên, biểu tượng khiên xanh khi chặn quảng cáo, số tab có nền nhạt, danh sách tab dạng thẻ có chữ cái đầu của trang, thông báo nổi có bóng.

## Phát nền (nhạc, video)

- `UIBackgroundModes: audio` + `AVAudioSession` category `playback`: nhạc/âm thanh video vẫn phát khi khoá màn hình hoặc sang app khác, có điều khiển ở màn hình khoá.
- Script dựng sẵn giữ `document.hidden = false` và chặn `visibilitychange` để site không tự dừng; khi app vào nền, media đang phát mà bị hệ thống tạm dừng sẽ được bật lại.
- Video: iOS dừng phần hình khi ở nền (âm thanh vẫn chạy); muốn giữ hình hãy dùng Hình trong hình (PiP) của trình phát.
- Bật/tắt tại Cài đặt → **Phát nền**.

## Giao diện mới (v4)

- Biểu tượng vẽ bằng **SVG** (23 file trong `Assets.xcassets/ic_*.imageset`, nét 2px bo tròn, tô màu theo chủ đề). Muốn đổi icon chỉ cần thay file `.svg` cùng tên.
- Màu chủ đạo xanh ngọc → lục (`Theme.swift`), nút có hiệu ứng nhún khi bấm.
- Ô địa chỉ dạng viên thuốc nổi: ổ khoá/cảnh báo, nút tải lại/dừng ngay trong ô, thanh tiến trình mảnh.
- Thanh công cụ dạng viên thuốc nổi kính mờ: Lùi, Tiến, Tab, Toàn màn hình, Extension, Menu.
- **Menu** là bảng lưới ô biểu tượng (kéo lên để mở rộng): ô bật/tắt (chặn QC, popup, tiết kiệm dữ liệu, bản máy tính) sáng màu gradient khi đang bật; các ô công cụ gồm toàn màn hình, tìm trong trang, chia sẻ, dấu trang, lịch sử, tải xuống, tab riêng tư, cài đặt.

## Kiểm tra extension trước khi cài

Mỗi extension (store, link, file) được kiểm tra bằng `ExtCompat.swift` **trước khi ghi xuống máy**:

- **Không cài được** (báo "Không cài được: tên: lý do", không ghi gì): theme / từ điển / gói ngôn ngữ; `manifest_version` sai; chỉ có side panel, devtools, thay tab mới; chỉ có luật redirect/modifyHeaders; cần native messaging, proxy/VPN, `webRequestBlocking` mà không có content script hay luật chặn DNR; chỉ chạy nền dựa vào `webRequest`; không có thành phần nào chạy được.
- **Cài được nhưng chạy một phần**: thông báo "Đã cài: … Chưa chạy được: …" và dòng cam trong danh sách extension (webRequest, identity, offscreen, bookmarks/history, menu chuột phải, thông báo, luật DNR bị bỏ qua, file bị thiếu...).
- **Chạy tốt**: có content script, luật chặn (block/allow), trang nền hoặc popup/options và không phụ thuộc API chưa hỗ trợ.

## Thanh bên (side panel)

- Extension khai `side_panel.default_path` (Chrome) hoặc `sidebar_action.default_panel` (Firefox) được cài bình thường; trong danh sách extension có nút **thanh bên** (biểu tượng ▯|) để mở trang đó dạng bảng trượt (kéo lên để mở rộng).
- `chrome.sidePanel.open()` và `browser.sidebarAction.open/toggle()` mở bảng này; `setOptions` / `setPanelBehavior` được nhận nhưng không làm gì.
- Trang thanh bên dùng được `tabs.query`, `tabs.sendMessage`, `storage`, `runtime.sendMessage` như popup. Tab hiện tại là trang đang mở lúc bấm.

## Cửa hàng & cài nhiều extension

Nút ghép hình → mục **Cửa hàng**:
- **Mở Chrome Web Store / Firefox Add-ons**: mở thẳng trong app; vào trang extension thì bấm **Thêm vào app**.
- **Dán nhiều link → chọn để cài**: dán một đoạn văn bản chứa nhiều link store, `.user.js`, `.zip/.crx/.xpi` hoặc ID Chrome (32 ký tự) → app tách thành danh sách có tên extension, chạm để chọn rồi bấm **Cài … đã chọn**; mỗi dòng báo cài xong hay lý do không cài được.
- **Gợi ý nhanh**: vài extension phổ biến, chạm là cài.
