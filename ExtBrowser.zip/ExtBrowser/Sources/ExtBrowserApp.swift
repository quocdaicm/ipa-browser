import SwiftUI

@main
struct ExtBrowserApp: App {
    @StateObject private var manager = ExtensionManager()
    @StateObject private var browser = BrowserModel()
    @ObservedObject private var lock = AppLock.shared
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            BrowserView()
                .tint(Theme.accent)
                .environmentObject(manager)
                .environmentObject(browser)
                // Che ngay từ khung hình đầu tiên khi đang khoá (cửa sổ khoá sẽ phủ lên ngay sau đó).
                .overlay { if lock.isLocked || lock.covered { Color.black.ignoresSafeArea() } }
                .onAppear { AppLock.shared.attach() }
                .onChange(of: scenePhase) { AppLock.shared.scenePhaseChanged($0) }
        }
    }
}
