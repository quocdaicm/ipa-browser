import SwiftUI

@main
struct ExtBrowserApp: App {
    @StateObject private var manager = ExtensionManager()
    @StateObject private var browser = BrowserModel()

    var body: some Scene {
        WindowGroup {
            BrowserView()
                .environmentObject(manager)
                .environmentObject(browser)
        }
    }
}
