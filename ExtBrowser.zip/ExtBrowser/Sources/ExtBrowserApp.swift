import SwiftUI

@main
struct ExtBrowserApp: App {
    @StateObject private var manager = ExtensionManager()
    @StateObject private var browser = BrowserModel()
    @ObservedObject private var lock = AppLock.shared
    @ObservedObject private var settings = BrowserSettings.shared
    @Environment(\.scenePhase) private var scenePhase

    init() { AppAppearance.install() }

    var body: some Scene {
        WindowGroup {
            BrowserView()
                .tint(browser.isPrivate ? Theme.privateAccent : Theme.accent)
                .environment(\.privateMode, browser.isPrivate)
                .preferredColorScheme(browser.isPrivate ? .dark : settings.colorScheme)
                .id(settings.palette)
                .environmentObject(manager)
                .environmentObject(browser)
                // Che ngay từ khung hình đầu tiên khi đang khoá (cửa sổ khoá sẽ phủ lên ngay sau đó).
                .overlay { if lock.isLocked || lock.covered { Color.black.ignoresSafeArea() } }
                .onAppear { AppLock.shared.attach() }
                .onChange(of: scenePhase) {
                    AppLock.shared.scenePhaseChanged($0)
                    LibraryLock.shared.scenePhaseChanged($0)
                }
        }
    }
}
