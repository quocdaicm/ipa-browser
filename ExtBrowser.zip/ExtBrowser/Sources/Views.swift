import SwiftUI
import WebKit
import UniformTypeIdentifiers

// MARK: - Browser

struct BrowserView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @State private var address = ""
    @State private var showExt = false
    @State private var showTabs = false
    @State private var showDownloads = false
    @State private var showLibrary = false
    @State private var showSettings = false
    @State private var showMenu = false
    @ObservedObject private var library = LibraryStore.shared
    @State private var directPage: ExtPage?
    @ObservedObject private var settings = BrowserSettings.shared
    @FocusState private var focused: Bool

    /// Ổ khoá + tên miền hiện khi không nhập; nil nếu không phải trang web.
    private var siteLabel: (icon: String, text: String, secure: Bool)? {
        guard let u = browser.currentURL else { return nil }
        let scheme = (u.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https", var h = u.host else { return nil }
        if h.hasPrefix("www.") { h.removeFirst(4) }
        let secure = scheme == "https"
        return (secure ? "lock.fill" : "exclamationmark.triangle.fill", h, secure)
    }

    private var suggestions: [SavedPage] {
        let q = address.trimmingCharacters(in: .whitespacesAndNewlines)
        var seen = Set<String>()
        var out: [SavedPage] = []
        if q.isEmpty {
            for p in Array(library.bookmarks.prefix(4)) + Array(library.history.prefix(6)) {
                if seen.insert(p.url).inserted { out.append(p) }
            }
            return out
        }
        for p in library.bookmarks + library.history {
            guard p.title.localizedCaseInsensitiveContains(q) ||
                  p.url.localizedCaseInsensitiveContains(q) else { continue }
            if seen.insert(p.url).inserted {
                out.append(p)
                if out.count >= 8 { break }
            }
        }
        return out
    }

    private var suggestionList: some View {
        let q = address.trimmingCharacters(in: .whitespacesAndNewlines)
        return List {
            if !q.isEmpty {
                Button {
                    browser.go(q)
                    focused = false
                } label: {
                    Label("Tìm “\(q)”", systemImage: "magnifyingglass")
                }
            }
            ForEach(suggestions) { p in
                Button {
                    browser.go(p.url)
                    focused = false
                } label: {
                    HStack {
                        Image(systemName: library.isBookmarked(p.url) ? "star.fill" : "clock")
                            .foregroundStyle(.secondary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(p.title).lineLimit(1)
                            Text(p.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .listStyle(.insetGrouped)
        .scrollDismissesKeyboard(.immediately)
    }

    var body: some View {
        VStack(spacing: 0) {
            if !browser.fullscreen && !(browser.chromeHidden && !focused) {
                addressBar
                    .transition(.move(edge: .top).combined(with: .opacity))
            }

            ZStack(alignment: .bottom) {
                WebViewContainer(webView: browser.webView)
                    .id(browser.activeID)
                if let t = ExtensionManager.storeTarget(for: browser.currentURL) {
                    Button {
                        Task { await manager.installFromStore(t) }
                    } label: {
                        Label(manager.busy ? "Đang cài…" : "Thêm vào app",
                              systemImage: "plus.circle.fill")
                            .font(.headline)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(manager.busy)
                    .padding(.bottom, 16)
                }
                if focused {
                    suggestionList
                }
            }
            .ignoresSafeArea(.container, edges: browser.fullscreen ? .vertical : [])

            if !browser.fullscreen && !(browser.chromeHidden && !focused) {
            toolbar
                .sheet(item: $directPage) { p in
                    NavigationStack {
                        ExtPageView(page: p)
                            .navigationTitle(p.title)
                            .navigationBarTitleDisplayMode(.inline)
                    }
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
                }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: browser.chromeHidden)
        .background {
            if browser.fullscreen { Color.black.ignoresSafeArea() }
        }
        .statusBarHidden(browser.fullscreen)
        .persistentSystemOverlays(browser.fullscreen ? .hidden : .automatic)
        .overlay(alignment: .leading) {
            if browser.fullscreen {
                FullscreenFab().padding(.leading, 8)
            }
        }
        .overlay(alignment: .top) {
            if let n = manager.notice {
                Text(n)
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(.regularMaterial, in: Capsule())
                    .overlay(Capsule().strokeBorder(Color.primary.opacity(0.08)))
                    .shadow(color: .black.opacity(0.15), radius: 8, y: 3)
                    .padding(.top, 50)
                    .padding(.horizontal, 20)
                    .transition(.opacity)
            }
        }
        .animation(.default, value: manager.notice)
        .onChange(of: focused) { f in
            // Bấm vào ô địa chỉ: xoá URL cũ ngay; thoát mà không nhập thì khôi phục lại
            address = f ? "" : (browser.currentURL?.absoluteString ?? "")
        }
        .onReceive(browser.$currentURL) { u in
            if !focused { address = u?.absoluteString ?? "" }
        }
        .onReceive(manager.$items) { browser.applyExtensions($0) }
        .onAppear {
            browser.onInstallLink = { u in
                Task { await manager.installFromLink(u.absoluteString) }
            }
            DownloadManager.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.onOpenPage = { p in
                Task { @MainActor in directPage = p }
            }
        }
        .sheet(isPresented: $showMenu) {
            MenuSheet { handle($0) }
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showExt) { ExtensionsView() }
        .sheet(isPresented: $showTabs) { TabsView() }
        .sheet(isPresented: $showDownloads) { DownloadsView() }
        .sheet(isPresented: $showLibrary) { LibraryView() }
        .sheet(isPresented: $showSettings) { SettingsView() }
    }

    private var progressLine: some View {
        GeometryReader { g in
            Capsule()
                .fill(browser.isPrivate ? Color.purple : Theme.accent)
                .frame(width: g.size.width * CGFloat(browser.progress), height: 3)
        }
        .frame(height: 3)
        .padding(.horizontal, 22)
        .padding(.bottom, 1)
        .opacity(browser.isLoading ? 1 : 0)
        .animation(.easeOut(duration: 0.25), value: browser.progress)
    }

    private var addressBar: some View {
        HStack(spacing: 10) {
            Group {
                if focused || siteLabel == nil {
                    SVGIcon(name: "ic_search", size: 18).foregroundStyle(.secondary)
                } else if let l = siteLabel {
                    SVGIcon(name: l.secure ? "ic_lock" : "ic_warning", size: 17)
                        .foregroundStyle(l.secure ? Color.green : Color.orange)
                }
            }
            TextField("Tìm kiếm hoặc nhập địa chỉ", text: $address)
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.go)
                .focused($focused)
                .onSubmit {
                    browser.go(address)
                    focused = false
                }
                .foregroundStyle(focused || siteLabel == nil ? Color.primary : Color.clear)
                .overlay(alignment: .leading) {
                    if !focused, let l = siteLabel {
                        Text(l.text).lineLimit(1).allowsHitTesting(false)
                    }
                }
            if focused {
                if !address.isEmpty {
                    Button { address = "" } label: {
                        SVGIcon(name: "ic_close", size: 16).foregroundStyle(.secondary)
                    }
                    .buttonStyle(PressStyle())
                }
            } else {
                Button {
                    if browser.isLoading { browser.webView.stopLoading() } else { browser.webView.reload() }
                } label: {
                    SVGIcon(name: browser.isLoading ? "ic_close" : "ic_reload", size: 18)
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(PressStyle())
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 46)
        .background(browser.isPrivate ? Color.purple.opacity(0.14) : Color(.secondarySystemBackground), in: Capsule())
        .overlay(
            Capsule().strokeBorder(focused ? Theme.accent : Color.primary.opacity(0.07),
                                   lineWidth: focused ? 1.5 : 1)
        )
        .overlay(alignment: .bottom) { progressLine }
        .shadow(color: .black.opacity(0.06), radius: 8, y: 3)
        .padding(.horizontal, 14)
        .padding(.vertical, 6)
        .animation(.easeOut(duration: 0.15), value: focused)
    }

    private var toolbar: some View {
        HStack(spacing: 0) {
            IconButton(icon: "ic_back") { browser.webView.goBack() }
                .disabled(!browser.canGoBack)
            IconButton(icon: "ic_forward") { browser.webView.goForward() }
                .disabled(!browser.canGoForward)
            Button { showTabs = true } label: {
                Text("\(browser.tabs.count)")
                    .font(.caption.bold())
                    .frame(minWidth: 24, minHeight: 24)
                    .background(Theme.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous).stroke(lineWidth: 1.8))
                    .foregroundStyle(browser.isPrivate ? Color.purple : Theme.accent)
                    .frame(maxWidth: .infinity, minHeight: 48)
                    .contentShape(Rectangle())
            }
            .buttonStyle(PressStyle())
            IconButton(icon: "ic_fullscreen") { browser.setFullscreen(true) }
            IconButton(icon: "ic_puzzle") { showExt = true }
            IconButton(icon: "ic_grid", tint: settings.adBlock ? Theme.accent : Color.primary) { showMenu = true }
        }
        .padding(.horizontal, 8)
        .background(.regularMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(Color.primary.opacity(0.07)))
        .shadow(color: .black.opacity(0.10), radius: 12, y: 4)
        .padding(.horizontal, 16)
        .padding(.top, 4)
        .padding(.bottom, 6)
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }

    private func handle(_ a: MenuAction) {
        showMenu = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            switch a {
            case .fullscreen: browser.setFullscreen(true)
            case .find: browser.findInPage()
            case .library: showLibrary = true
            case .settings: showSettings = true
            case .downloads: showDownloads = true
            case .newPrivate: browser.newPrivateTab()
            }
        }
    }
}

/// Nút nổi khi toàn màn hình: chạm để mở menu nhỏ (Thoát / Tải lại), kéo để dời chỗ.
struct FullscreenFab: View {
    @EnvironmentObject var browser: BrowserModel
    @State private var open = false
    @State private var base = CGSize.zero
    @State private var drag = CGSize.zero

    private func clamp(_ s: CGSize) -> CGSize {
        let b = UIScreen.main.bounds
        let maxX = max(0, max(b.width, b.height) - 60)
        let maxY = min(b.width, b.height) / 2 - 24
        return CGSize(width: min(max(s.width, 0), maxX), height: min(max(s.height, -maxY), maxY))
    }

    private func chip(_ icon: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            SVGIcon(name: icon, size: 18)
                .frame(width: 36, height: 36)
                .background(.black.opacity(0.6), in: Circle())
                .foregroundStyle(.white)
        }
    }

    var body: some View {
        HStack(spacing: 8) {
            SVGIcon(name: open ? "ic_close" : "ic_exit_fullscreen", size: 18)
                .font(.system(size: 15, weight: .semibold))
                .frame(width: 36, height: 36)
                .background(.black.opacity(0.45), in: Circle())
                .foregroundStyle(.white)
                .onTapGesture { withAnimation { open.toggle() } }
            if open {
                chip("ic_exit_fullscreen") { browser.setFullscreen(false) }
                chip("ic_reload") { browser.webView.reload(); open = false }
            }
        }
        .opacity(open ? 1 : 0.4)
        .offset(clamp(CGSize(width: base.width + drag.width, height: base.height + drag.height)))
        .gesture(
            DragGesture(minimumDistance: 6)
                .onChanged { drag = $0.translation }
                .onEnded { v in
                    base = clamp(CGSize(width: base.width + v.translation.width,
                                        height: base.height + v.translation.height))
                    drag = .zero
                }
        )
    }
}

struct WebViewContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Cài đặt

struct SettingsView: View {
    @ObservedObject private var settings = BrowserSettings.shared
    @Environment(\.dismiss) private var dismiss
    @State private var message = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Tìm kiếm") {
                    Picker("Công cụ tìm kiếm", selection: $settings.searchEngine) {
                        Text("Google").tag("google")
                        Text("DuckDuckGo").tag("duckduckgo")
                        Text("Bing").tag("bing")
                    }
                }
                Section("Trang chủ") {
                    TextField("https://www.google.com", text: $settings.homepage)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section {
                    Toggle("Tiếp tục phát khi thoát app / khoá màn hình", isOn: $settings.bgPlay)
                } header: {
                    Text("Phát nền")
                } footer: {
                    Text("Nhạc và âm thanh video vẫn phát khi tắt màn hình hoặc sang app khác, có nút điều khiển ở màn hình khoá. Muốn giữ hình video khi ra ngoài, dùng nút Hình trong hình (PiP) của trình phát. Phần hình có thể dừng ở nền, âm thanh vẫn chạy.")
                }
                Section {
                    Toggle("Hỗ trợ game khi toàn màn hình", isOn: $settings.gameHelper)
                    Toggle("Tự xoay ngang khi toàn màn hình", isOn: $settings.fsLandscape)
                    Picker("Làm nét game", selection: $settings.sharp) {
                        Text("Tắt").tag(0)
                        Text("Nét pixel").tag(1)
                        Text("Nét tối đa (nặng hơn)").tag(2)
                    }
                } header: {
                    Text("Chơi game")
                } footer: {
                    Text("Hỗ trợ game: chặn phóng to bằng 2 ngón / chạm đúp, chặn chọn chữ, menu giữ lâu và kéo trang; thêm Fullscreen API cho game gọi requestFullscreen().")
                }
                Section("Dữ liệu duyệt web") {
                    Button("Xoá lịch sử", role: .destructive) {
                        LibraryStore.shared.clearHistory()
                        message = "Đã xoá lịch sử"
                    }
                    Button("Xoá cookie và bộ nhớ đệm", role: .destructive) {
                        Task {
                            await WKWebsiteDataStore.default().removeData(
                                ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                                modifiedSince: .distantPast)
                            message = "Đã xoá cookie và bộ nhớ đệm (bạn sẽ bị đăng xuất khỏi các trang)"
                        }
                    }
                    if !message.isEmpty {
                        Text(message).font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Dấu trang & Lịch sử

struct LibraryView: View {
    @ObservedObject private var lib = LibraryStore.shared
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var tab = 0
    @State private var query = ""
    @State private var confirmClear = false

    private var shown: [SavedPage] {
        let src = tab == 0 ? lib.bookmarks : lib.history
        if query.isEmpty { return src }
        return src.filter {
            $0.title.localizedCaseInsensitiveContains(query) ||
            $0.url.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("", selection: $tab) {
                    Text("Dấu trang").tag(0)
                    Text("Lịch sử").tag(1)
                }
                .pickerStyle(.segmented)
                .padding()

                List {
                    if shown.isEmpty {
                        Text(tab == 0 ? "Chưa có dấu trang" : "Chưa có lịch sử")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(shown) { p in
                        Button {
                            browser.go(p.url)
                            dismiss()
                        } label: {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(p.title).font(.headline).lineLimit(1)
                                Text(p.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                if tab == 1 {
                                    Text(p.date.formatted(date: .abbreviated, time: .shortened))
                                        .font(.caption2)
                                        .foregroundStyle(.tertiary)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                    .onDelete { offsets in
                        let ids = offsets.map { shown[$0].id }
                        for id in ids {
                            if tab == 0 { lib.removeBookmark(id) } else { lib.removeHistory(id) }
                        }
                    }
                }
            }
            .searchable(text: $query)
            .navigationTitle(tab == 0 ? "Dấu trang" : "Lịch sử")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    if tab == 1 && !lib.history.isEmpty {
                        Button("Xoá hết", role: .destructive) { confirmClear = true }
                    }
                }
            }
            .confirmationDialog("Xoá toàn bộ lịch sử?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Xoá hết", role: .destructive) { lib.clearHistory() }
            }
        }
    }
}

// MARK: - Tải xuống

struct DownloadsView: View {
    @ObservedObject private var dl = DownloadManager.shared
    @EnvironmentObject var manager: ExtensionManager
    @Environment(\.dismiss) private var dismiss

    private func installable(_ u: URL) -> Bool {
        ["crx", "xpi", "zip", "js"].contains(u.pathExtension.lowercased())
    }

    private func sizeText(_ u: URL?) -> String {
        guard let u = u,
              let n = (try? u.resourceValues(forKeys: [.fileSizeKey]))?.fileSize else { return "" }
        return ByteCountFormatter.string(fromByteCount: Int64(n), countStyle: .file)
    }

    var body: some View {
        NavigationStack {
            List {
                if dl.items.isEmpty {
                    Text("Chưa có file nào").foregroundStyle(.secondary)
                }
                ForEach(dl.items) { item in
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.name).font(.headline).lineLimit(2)
                            if item.state == .running {
                                ProgressView(value: item.progress)
                            } else if item.state == .failed {
                                Text("Tải thất bại").font(.caption).foregroundStyle(.red)
                            } else {
                                Text(sizeText(item.fileURL)).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        if item.state == .done, let u = item.fileURL {
                            if installable(u) {
                                Button("Cài") { manager.importFile(u) }
                                    .buttonStyle(.borderless)
                            }
                            ShareLink(item: u) { Image(systemName: "square.and.arrow.up") }
                                .buttonStyle(.borderless)
                        }
                    }
                }
                .onDelete { offsets in
                    let ids = offsets.map { dl.items[$0].id }
                    ids.forEach { dl.remove($0) }
                }
            }
            .navigationTitle("Tải xuống")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Danh sách tab

struct TabsView: View {
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                ForEach(browser.tabs) { tab in
                    TabRow(tab: tab,
                           active: tab.id == browser.activeID,
                           select: { browser.select(tab.id); dismiss() },
                           close: { browser.close(tab.id) })
                }
            }
            .navigationTitle("Tab (\(browser.tabs.count))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        Button { browser.newTab(); dismiss() } label: {
                            Label("Tab mới", systemImage: "plus")
                        }
                        Button { browser.newPrivateTab(); dismiss() } label: {
                            Label("Tab riêng tư", systemImage: "eyeglasses")
                        }
                    } label: { Image(systemName: "plus") }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }
}

struct TabRow: View {
    @ObservedObject var tab: Tab
    let active: Bool
    let select: () -> Void
    let close: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Text(String((tab.url?.host ?? "•").replacingOccurrences(of: "www.", with: "").prefix(1)).uppercased())
                .font(.subheadline.bold())
                .foregroundStyle(.white)
                .frame(width: 32, height: 32)
                .background(tab.isPrivate ? Color.purple : Theme.accent, in: Circle())
            Button(action: select) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(tab.title.isEmpty ? (tab.url?.host ?? "Tab mới") : tab.title)
                        .font(.headline)
                        .lineLimit(1)
                    Text(tab.url?.host ?? "")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            .buttonStyle(.plain)
            Spacer()
            if tab.isPrivate { Image(systemName: "eyeglasses").foregroundStyle(.purple) }
            if active { Image(systemName: "checkmark").foregroundStyle(.tint) }
            Button(action: close) {
                Image(systemName: "xmark")
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
                    .frame(width: 26, height: 26)
                    .background(Color(.tertiarySystemFill), in: Circle())
            }
            .buttonStyle(.borderless)
        }
        .padding(.vertical, 6)
        .listRowBackground(
            RoundedRectangle(cornerRadius: 12)
                .fill(active ? Theme.accent.opacity(0.12) : Color(.secondarySystemGroupedBackground))
                .padding(.vertical, 2)
                .padding(.horizontal, 4)
        )
    }
}

// MARK: - Extension list

struct ExtPage: Identifiable {
    let id = UUID()
    let extId: String
    let path: String
    let tabURL: String
    let title: String
}

struct ExtensionsView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var link = ""
    @State private var importing = false
    @State private var page: ExtPage?
    @State private var logFor: InstalledExtension?
    @State private var showLinks = false

    private func openStore(_ url: String) {
        browser.go(url)
        dismiss()
    }

    var body: some View {
        NavigationStack {
            List {
                Section("Cửa hàng") {
                    Button { openStore("https://chromewebstore.google.com") } label: {
                        Label("Mở Chrome Web Store", systemImage: "bag")
                    }
                    Button { openStore("https://addons.mozilla.org/vi/firefox/extensions/") } label: {
                        Label("Mở Firefox Add-ons", systemImage: "flame")
                    }
                    Button { showLinks = true } label: {
                        Label("Dán nhiều link → chọn để cài", systemImage: "list.bullet.rectangle")
                    }
                }

                Section("Gợi ý nhanh") {
                    ForEach(Suggested.all) { s in
                        Button {
                            Task { await manager.installFromLink(s.url) }
                        } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(s.name).font(.subheadline.weight(.semibold))
                                    Text(s.note).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "arrow.down.circle.fill").foregroundStyle(Theme.accent)
                            }
                        }
                        .disabled(manager.busy)
                    }
                }

                Section("Thêm extension") {
                    HStack {
                        TextField("Dán link store, .user.js hoặc .zip", text: $link)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .keyboardType(.URL)
                        Button("Cài") {
                            let l = link
                            link = ""
                            Task { await manager.installFromLink(l) }
                        }
                        .buttonStyle(.borderless)
                        .disabled(link.isEmpty || manager.busy)
                    }
                    Button("Chọn file (.zip .crx .xpi .js)") { importing = true }
                    Text("Hoặc mở trang extension trên Chrome Web Store / Firefox Add-ons rồi bấm nút “Thêm vào app”.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Đã cài (\(manager.items.count))") {
                    if manager.items.isEmpty {
                        Text("Chưa có extension nào").foregroundStyle(.secondary)
                    }
                    ForEach(manager.items) { item in
                        row(item)
                    }
                    .onDelete { offsets in
                        let ids = offsets.map { manager.items[$0].id }
                        ids.forEach { manager.remove($0) }
                    }
                }
            }
            .navigationTitle("Extension")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.item]) { result in
                if case .success(let u) = result { manager.importFile(u) }
            }
            .sheet(isPresented: $showLinks) { LinkImportView() }
            .sheet(item: $logFor) { it in
                ExtLogView(extId: it.id, title: it.name)
            }
            .sheet(item: $page) { p in
                NavigationStack {
                    ExtPageView(page: p)
                        .navigationTitle(p.title)
                        .navigationBarTitleDisplayMode(.inline)
                }
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
            }
        }
    }

    @ViewBuilder
    private func row(_ item: InstalledExtension) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name).font(.headline)
                Text("v\(item.version) · \(item.source)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                if let n = item.notes, !n.isEmpty {
                    Label("Chưa chạy: " + n.joined(separator: ", "), systemImage: "exclamationmark.triangle.fill")
                        .font(.caption2)
                        .foregroundStyle(.orange)
                }
            }
            Spacer()
            if manager.store.backgroundEntry(id: item.id) != nil {
                Button {
                    logFor = item
                } label: {
                    Image(systemName: "doc.text")
                }
                .buttonStyle(.borderless)
            }
            if let p = manager.store.popupPath(id: item.id) {
                Button {
                    page = ExtPage(extId: item.id, path: p,
                                   tabURL: browser.currentURL?.absoluteString ?? "",
                                   title: item.name)
                } label: {
                    Image(systemName: "rectangle.on.rectangle")
                }
                .buttonStyle(.borderless)
            }
            if let sp = manager.store.sidePanelPath(id: item.id) {
                Button {
                    page = ExtPage(extId: item.id, path: sp,
                                   tabURL: browser.currentURL?.absoluteString ?? "",
                                   title: item.name)
                } label: {
                    Image(systemName: "sidebar.right")
                }
                .buttonStyle(.borderless)
            }
            if let o = manager.store.optionsPath(id: item.id) {
                Button {
                    page = ExtPage(extId: item.id, path: o,
                                   tabURL: browser.currentURL?.absoluteString ?? "",
                                   title: item.name)
                } label: {
                    Image(systemName: "gearshape")
                }
                .buttonStyle(.borderless)
            }
            Toggle("", isOn: Binding(
                get: { item.enabled },
                set: { manager.setEnabled(item.id, $0) }
            ))
            .labelsHidden()
        }
    }
}

// MARK: - Popup / options page of an extension

struct ExtPageView: UIViewRepresentable {
    let page: ExtPage

    final class Coordinator {
        let scheme = ExtSchemeHandler(store: ExtStore.shared)
        let bridge = ExtBridge(store: ExtStore.shared)
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(context.coordinator.scheme, forURLScheme: "ext")
        cfg.userContentController.addScriptMessageHandler(context.coordinator.bridge,
                                                          contentWorld: .page,
                                                          name: "extBridge")
        let src = ScriptBuilder.context(id: page.extId, store: ExtStore.shared, tabURL: page.tabURL, role: "page")
        cfg.userContentController.addUserScript(
            WKUserScript(source: src, injectionTime: .atDocumentStart,
                         forMainFrameOnly: true, in: .page))
        let w = WKWebView(frame: .zero, configuration: cfg)
        if let u = URL(string: "ext://\(page.extId)/\(page.path)") {
            w.load(URLRequest(url: u))
        }
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Nhật ký của trang nền

struct ExtLogView: View {
    let extId: String
    let title: String
    @State private var text = ""

    var body: some View {
        NavigationStack {
            ScrollView {
                Text(text.isEmpty ? "Chưa có log" : text)
                    .font(.system(size: 11, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .textSelection(.enabled)
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Làm mới") { text = ExtRuntime.shared.logText(extId) }
                }
            }
            .onAppear { text = ExtRuntime.shared.logText(extId) }
        }
    }
}
