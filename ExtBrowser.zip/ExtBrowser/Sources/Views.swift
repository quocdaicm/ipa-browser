import SwiftUI
import WebKit
import UniformTypeIdentifiers

// MARK: - Browser

struct BrowserView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @State private var address = ""
    @State private var showExt = false
    @State private var directPage: ExtPage?
    @FocusState private var focused: Bool

    var body: some View {
        VStack(spacing: 0) {
            TextField("Tìm kiếm hoặc nhập địa chỉ", text: $address)
                .textFieldStyle(.roundedBorder)
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.go)
                .focused($focused)
                .onSubmit {
                    browser.go(address)
                    focused = false
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)

            ProgressView(value: browser.progress)
                .opacity(browser.isLoading ? 1 : 0)

            ZStack(alignment: .bottom) {
                WebViewContainer(webView: browser.webView)
                if let t = ExtensionManager.storeTarget(for: browser.currentURL) {
                    Button {
                        Task { await manager.installFromStore(t) }
                    } label: {
                        Label(manager.busy ? "Đang cài…" : "Thêm vào app",
                              systemImage: "plus.circle.fill")
                            .font(.headline)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(manager.busy)
                    .padding(.bottom, 16)
                }
            }

            toolbar
                .sheet(item: $directPage) { p in
                    NavigationStack {
                        ExtPageView(page: p)
                            .navigationTitle(p.title)
                            .navigationBarTitleDisplayMode(.inline)
                    }
                }
        }
        .overlay(alignment: .top) {
            if let n = manager.notice {
                Text(n)
                    .font(.subheadline)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(.thinMaterial, in: Capsule())
                    .padding(.top, 50)
                    .transition(.opacity)
            }
        }
        .animation(.default, value: manager.notice)
        .onReceive(browser.$currentURL) { u in
            if !focused { address = u?.absoluteString ?? "" }
        }
        .onReceive(manager.$items) { browser.applyExtensions($0) }
        .onAppear {
            browser.onInstallLink = { u in
                Task { await manager.installFromLink(u.absoluteString) }
            }
            ExtRuntime.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.onOpenPage = { p in
                Task { @MainActor in directPage = p }
            }
        }
        .sheet(isPresented: $showExt) { ExtensionsView() }
    }

    private var toolbar: some View {
        HStack {
            Button { browser.webView.goBack() } label: { Image(systemName: "chevron.left") }
                .disabled(!browser.canGoBack)
            Spacer()
            Button { browser.webView.goForward() } label: { Image(systemName: "chevron.right") }
                .disabled(!browser.canGoForward)
            Spacer()
            Button {
                if browser.isLoading { browser.webView.stopLoading() } else { browser.webView.reload() }
            } label: {
                Image(systemName: browser.isLoading ? "xmark" : "arrow.clockwise")
            }
            Spacer()
            Button { showExt = true } label: { Image(systemName: "puzzlepiece.extension") }
        }
        .font(.title3)
        .padding(.horizontal, 24)
        .padding(.vertical, 10)
        .background(.bar)
    }
}

struct WebViewContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Extension list

struct ExtPage: Identifiable {
    let id = UUID()
    let extId: String
    let path: String
    let tabURL: String
    let title: String
}

struct ExtensionsView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var link = ""
    @State private var importing = false
    @State private var page: ExtPage?
    @State private var logFor: InstalledExtension?

    var body: some View {
        NavigationStack {
            List {
                Section("Thêm extension") {
                    HStack {
                        TextField("Dán link store, .user.js hoặc .zip", text: $link)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .keyboardType(.URL)
                        Button("Cài") {
                            let l = link
                            link = ""
                            Task { await manager.installFromLink(l) }
                        }
                        .buttonStyle(.borderless)
                        .disabled(link.isEmpty || manager.busy)
                    }
                    Button("Chọn file (.zip .crx .xpi .js)") { importing = true }
                    Text("Hoặc mở trang extension trên Chrome Web Store / Firefox Add-ons rồi bấm nút “Thêm vào app”.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Đã cài (\(manager.items.count))") {
                    if manager.items.isEmpty {
                        Text("Chưa có extension nào").foregroundStyle(.secondary)
                    }
                    ForEach(manager.items) { item in
                        row(item)
                    }
                    .onDelete { offsets in
                        let ids = offsets.map { manager.items[$0].id }
                        ids.forEach { manager.remove($0) }
                    }
                }
            }
            .navigationTitle("Extension")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.item]) { result in
                if case .success(let u) = result { manager.importFile(u) }
            }
            .sheet(item: $logFor) { it in
                ExtLogView(extId: it.id, title: it.name)
            }
            .sheet(item: $page) { p in
                NavigationStack {
                    ExtPageView(page: p)
                        .navigationTitle(p.title)
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }

    @ViewBuilder
    private func row(_ item: InstalledExtension) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name).font(.headline)
                Text("v\(item.version) · \(item.source)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if manager.store.backgroundEntry(id: item.id) != nil {
                Button {
                    logFor = item
                } label: {
                    Image(systemName: "doc.text")
                }
                .buttonStyle(.borderless)
            }
            if let p = manager.store.popupPath(id: item.id) {
                Button {
                    page = ExtPage(extId: item.id, path: p,
                                   tabURL: browser.currentURL?.absoluteString ?? "",
                                   title: item.name)
                } label: {
                    Image(systemName: "rectangle.on.rectangle")
                }
                .buttonStyle(.borderless)
            }
            if let o = manager.store.optionsPath(id: item.id) {
                Button {
                    page = ExtPage(extId: item.id, path: o,
                                   tabURL: browser.currentURL?.absoluteString ?? "",
                                   title: item.name)
                } label: {
                    Image(systemName: "gearshape")
                }
                .buttonStyle(.borderless)
            }
            Toggle("", isOn: Binding(
                get: { item.enabled },
                set: { manager.setEnabled(item.id, $0) }
            ))
            .labelsHidden()
        }
    }
}

// MARK: - Popup / options page of an extension

struct ExtPageView: UIViewRepresentable {
    let page: ExtPage

    final class Coordinator {
        let scheme = ExtSchemeHandler(store: ExtStore.shared)
        let bridge = ExtBridge(store: ExtStore.shared)
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(context.coordinator.scheme, forURLScheme: "ext")
        cfg.userContentController.addScriptMessageHandler(context.coordinator.bridge,
                                                          contentWorld: .page,
                                                          name: "extBridge")
        let src = ScriptBuilder.context(id: page.extId, store: ExtStore.shared, tabURL: page.tabURL, role: "page")
        cfg.userContentController.addUserScript(
            WKUserScript(source: src, injectionTime: .atDocumentStart,
                         forMainFrameOnly: true, in: .page))
        let w = WKWebView(frame: .zero, configuration: cfg)
        if let u = URL(string: "ext://\(page.extId)/\(page.path)") {
            w.load(URLRequest(url: u))
        }
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Nhật ký của trang nền

struct ExtLogView: View {
    let extId: String
    let title: String
    @State private var text = ""

    var body: some View {
        NavigationStack {
            ScrollView {
                Text(text.isEmpty ? "Chưa có log" : text)
                    .font(.system(size: 11, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .textSelection(.enabled)
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Làm mới") { text = ExtRuntime.shared.logText(extId) }
                }
            }
            .onAppear { text = ExtRuntime.shared.logText(extId) }
        }
    }
}
