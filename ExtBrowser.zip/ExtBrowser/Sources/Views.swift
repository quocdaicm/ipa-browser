import SwiftUI
import WebKit
import UniformTypeIdentifiers

// MARK: - Browser

struct BrowserView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @State private var address = ""
    @State private var showExt = false
    @State private var showTabs = false
    @State private var showDownloads = false
    @State private var showLibrary = false
    @State private var showSettings = false
    @State private var showMenu = false
    @State private var showAdMenu = false
    @State private var showVideos = false
    @State private var shareFile: ShareFile?
    @State private var hiddenFab: Set<UUID> = []
    @ObservedObject private var library = LibraryStore.shared
    @ObservedObject private var libLock = LibraryLock.shared
    @State private var directPage: ExtPage?
    @ObservedObject private var settings = BrowserSettings.shared
    @FocusState private var focused: Bool

    /// Ổ khoá + tên miền hiện khi không nhập; nil nếu không phải trang web.
    private var siteLabel: (icon: String, text: String, secure: Bool)? {
        guard let u = browser.currentURL else { return nil }
        let scheme = (u.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https", var h = u.host else { return nil }
        if h.hasPrefix("www.") { h.removeFirst(4) }
        let secure = scheme == "https"
        return (secure ? "lock.fill" : "exclamationmark.triangle.fill", h, secure)
    }

    private var suggestions: [SavedPage] {
        // Có đặt mật khẩu dấu trang/lịch sử thì không gợi ý từ hai nguồn này
        if libLock.enabled { return [] }
        let q = address.trimmingCharacters(in: .whitespacesAndNewlines)
        var seen = Set<String>()
        var out: [SavedPage] = []
        if q.isEmpty {
            for p in Array(library.bookmarks.prefix(4)) + Array(library.history.prefix(6)) {
                if seen.insert(p.url).inserted { out.append(p) }
            }
            return out
        }
        for p in library.bookmarks + library.history {
            guard p.title.localizedCaseInsensitiveContains(q) ||
                  p.url.localizedCaseInsensitiveContains(q) else { continue }
            if seen.insert(p.url).inserted {
                out.append(p)
                if out.count >= 8 { break }
            }
        }
        return out
    }

    private var suggestionList: some View {
        let q = address.trimmingCharacters(in: .whitespacesAndNewlines)
        return ZStack {
            ScreenBackground()
            ScrollView {
                LazyVStack(spacing: 10) {
                    if !q.isEmpty {
                        Button {
                            browser.go(q)
                            focused = false
                        } label: {
                            HStack(spacing: 12) {
                                IconChip(asset: "ic_search", color: Theme.accent, size: 38)
                                Text("Tìm “\(q)”")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                Spacer(minLength: 0)
                                Chevron()
                            }
                            .padding(12)
                            .card(radius: 18)
                        }
                        .buttonStyle(PressStyle())
                    }
                    if q.isEmpty && !suggestions.isEmpty {
                        Text("GẦN ĐÂY").font(Theme.sectionFont).tracking(0.8)
                            .foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 6).padding(.top, 4)
                    }
                    ForEach(suggestions) { p in
                        HStack(spacing: 10) {
                            Button {
                                browser.go(p.url)
                                focused = false
                            } label: {
                                HStack(spacing: 12) {
                                    IconChip(sf: library.isBookmarked(p.url) ? "star.fill" : "clock.fill",
                                             color: library.isBookmarked(p.url) ? Theme.warn : Theme.accent2,
                                             size: 38, filled: false)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(p.title.isEmpty ? p.url : p.title)
                                            .font(.subheadline.weight(.semibold))
                                            .foregroundStyle(.primary).lineLimit(1)
                                        Text(p.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(minLength: 0)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            Button { address = p.url } label: {
                                Image(systemName: "arrow.up.left")
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundStyle(.secondary)
                                    .frame(width: 32, height: 32)
                                    .background(Theme.chip, in: Circle())
                            }
                            .buttonStyle(PressStyle())
                        }
                        .padding(10)
                        .card(radius: 18)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
            }
            .scrollDismissesKeyboard(.immediately)
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            if !browser.fullscreen && !(browser.chromeHidden && !focused) {
                addressBar
                    .transition(.move(edge: .top).combined(with: .opacity))
            }

            ZStack(alignment: .bottom) {
                WebViewContainer(webView: browser.webView)
                    .id(browser.activeID)
                if settings.videoTool && settings.videoFab && !browser.fullscreen && !hiddenFab.contains(browser.activeID ?? UUID()) {
                    VideoFab(tab: browser.activeTab, action: { showVideos = true },
                             onHideTab: { if let id = browser.activeID { hiddenFab.insert(id) } },
                             onHideAlways: { settings.videoFab = false })
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                        .padding(.trailing, 16)
                        .padding(.bottom, 14)
                        .animation(.spring(response: 0.4, dampingFraction: 0.65), value: browser.activeTab.videos.count)
                }
                if browser.translateOffer != nil && !focused {
                    HStack(spacing: 10) {
                        SVGIcon(name: "ic_translate", size: 18).foregroundStyle(Theme.accent)
                        Text("Dịch sang \(PageTranslate.name(settings.translateLang))?")
                            .font(.system(.subheadline, design: .rounded).weight(.semibold))
                            .lineLimit(1)
                        Button("Dịch") { browser.translatePage() }
                            .buttonStyle(.borderedProminent)
                            .controlSize(.small)
                        Button { browser.translateOffer = nil } label: {
                            SVGIcon(name: "ic_close", size: 12)
                                .foregroundStyle(.secondary)
                                .frame(width: 26, height: 26)
                                .background(Theme.chip, in: Circle())
                        }
                        .buttonStyle(PressStyle())
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background(.regularMaterial, in: Capsule())
                    .overlay(Capsule().strokeBorder(Theme.cardStroke))
                    .shadow(color: .black.opacity(0.18), radius: 12, y: 5)
                    .padding(.bottom, 14)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }
                if let t = ExtensionManager.storeTarget(for: browser.currentURL) {
                    Button {
                        Task { await manager.installFromStore(t) }
                    } label: {
                        Label(manager.busy ? "Đang cài…" : "Thêm vào app",
                              systemImage: "plus.circle.fill")
                            .font(.headline)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(manager.busy)
                    .padding(.bottom, 16)
                }
                if focused {
                    suggestionList
                }
            }
            // Khi các thanh tự ẩn lúc cuộn xuống: trang phủ kín cả dải trên (giờ/pin) và dải dưới (vạch home)
            .ignoresSafeArea(.container, edges: (browser.fullscreen || (browser.chromeHidden && !focused)) ? .vertical : [])

            if !browser.fullscreen && !(browser.chromeHidden && !focused) {
            toolbar
                .sheet(item: $directPage) { p in
                    NavigationStack {
                        ExtPageView(page: p)
                            .navigationTitle(p.title)
                            .navigationBarTitleDisplayMode(.inline)
                    }
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
                }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: browser.chromeHidden)
        .background {
            if browser.fullscreen || (browser.chromeHidden && !focused) { Color.black.ignoresSafeArea() } else { ScreenBackground() }
        }
        .statusBarHidden(browser.fullscreen)
        .persistentSystemOverlays(browser.fullscreen ? .hidden : .automatic)
        .overlay(alignment: .leading) {
            if browser.fullscreen {
                FullscreenFab().padding(.leading, 8)
            }
        }
        .overlay(alignment: .top) {
            if let n = manager.notice {
                HStack(spacing: 8) {
                    Circle().fill(Theme.gradient).frame(width: 8, height: 8)
                    Text(n)
                        .font(.system(.subheadline, design: .rounded).weight(.medium))
                        .multilineTextAlignment(.leading)
                }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(.regularMaterial, in: Capsule())
                    .overlay(Capsule().strokeBorder(Theme.cardStroke))
                    .shadow(color: .black.opacity(0.18), radius: 12, y: 5)
                    .padding(.top, 50)
                    .padding(.horizontal, 20)
                    .transition(.opacity)
            }
        }
        .animation(.default, value: manager.notice)
        .onChange(of: focused) { f in
            // Bấm vào ô địa chỉ: xoá URL cũ ngay; thoát mà không nhập thì khôi phục lại
            address = f ? "" : (browser.currentURL?.absoluteString ?? "")
        }
        .onReceive(browser.$currentURL) { u in
            if !focused { address = u?.absoluteString ?? "" }
        }
        .onReceive(manager.$items) { browser.applyExtensions($0) }
        .onAppear {
            browser.onInstallLink = { u in
                Task { await manager.installFromLink(u.absoluteString) }
            }
            DownloadManager.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            browser.onNotice = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.onOpenPage = { p in
                Task { @MainActor in directPage = p }
            }
        }
        .sheet(isPresented: $showMenu) {
            MenuSheet { handle($0) }
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showAdMenu) {
            AdBlockSheet()
                .presentationDetents([.height(400)])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showExt) { ExtensionsView() }
        .fullScreenCover(isPresented: $showTabs) { TabsView() }
        .sheet(isPresented: $showVideos) { VideoSheet(tab: browser.activeTab) }
        .fullScreenCover(item: $browser.nativePlay) { p in
            NativePlayerCover(item: p) { browser.nativePlay = nil }
        }
        .sheet(isPresented: $showDownloads) { DownloadsView() }
        .sheet(isPresented: $showLibrary) { LibraryView() }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(item: $shareFile) { f in
            ShareSheet(items: [f.url])
                .presentationDetents([.medium, .large])
        }
    }

    private var progressLine: some View {
        GeometryReader { g in
            Capsule()
                .fill(browser.isPrivate ? AnyShapeStyle(Theme.privateAccent) : AnyShapeStyle(Theme.gradient))
                .frame(width: g.size.width * CGFloat(browser.progress), height: 3)
        }
        .frame(height: 3)
        .padding(.horizontal, 24)
        .padding(.bottom, 1)
        .opacity(browser.isLoading ? 1 : 0)
        .animation(.easeOut(duration: 0.25), value: browser.progress)
    }

    private var addressBar: some View {
        HStack(spacing: 10) {
            if !focused {
                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    showAdMenu = true
                } label: {
                    let on = settings.adBlockActive(for: browser.currentURL?.host)
                    SVGIcon(name: on ? "ic_shield" : "ic_shield_off", size: 16)
                        .foregroundStyle(on ? Theme.success : Color.secondary)
                        .frame(width: 30, height: 30)
                        .background(on ? Theme.success.opacity(0.15) : Theme.chip, in: Circle())
                }
                .buttonStyle(PressStyle())
            }
            Group {
                if focused || siteLabel == nil {
                    SVGIcon(name: "ic_search", size: 16).foregroundStyle(Theme.accent)
                } else if let l = siteLabel {
                    SVGIcon(name: l.secure ? "ic_lock" : "ic_warning", size: 15)
                        .foregroundStyle(l.secure ? Theme.success : Theme.warn)
                }
            }
            .frame(width: 30, height: 30)
            .background(Theme.chip, in: Circle())

            TextField("Tìm kiếm hoặc nhập địa chỉ", text: $address)
                .font(.system(.body, design: .rounded))
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.go)
                .focused($focused)
                .onSubmit {
                    browser.go(address)
                    focused = false
                }
                .foregroundStyle(focused || siteLabel == nil ? Color.primary : Color.clear)
                .overlay(alignment: .leading) {
                    if !focused, let l = siteLabel {
                        Text(l.text)
                            .font(.system(.body, design: .rounded).weight(.medium))
                            .lineLimit(1).allowsHitTesting(false)
                    }
                }
            if focused {
                if !address.isEmpty {
                    Button { address = "" } label: {
                        SVGIcon(name: "ic_close", size: 12)
                            .foregroundStyle(.secondary)
                            .frame(width: 28, height: 28)
                            .background(Theme.chip, in: Circle())
                    }
                    .buttonStyle(PressStyle())
                }
            } else {
                if browser.isPrivate {
                    SVGIcon(name: "ic_private", size: 16).foregroundStyle(Theme.privateAccent)
                }
                // Nút Tải xuống (thay cho nút Chế độ đọc; chế độ đọc vẫn ở Menu).
                DownloadBarButton { showDownloads = true }
                // Đang ở chế độ đọc thì vẫn hiện nút để thoát nhanh.
                if browser.readerOn {
                    Button {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        browser.toggleReader()
                    } label: {
                        SVGIcon(name: "ic_reader", size: 15)
                            .foregroundStyle(Color.white)
                            .frame(width: 30, height: 30)
                            .background(Theme.gradient, in: Circle())
                    }
                    .buttonStyle(PressStyle())
                }
                Button {
                    if browser.isLoading { browser.webView.stopLoading() } else { browser.webView.reload() }
                } label: {
                    SVGIcon(name: browser.isLoading ? "ic_close" : "ic_reload", size: 15)
                        .foregroundStyle(.secondary)
                        .frame(width: 30, height: 30)
                        .background(Theme.chip, in: Circle())
                }
                .buttonStyle(PressStyle())
            }
        }
        .padding(.horizontal, 9)
        .frame(height: 50)
        .background(.ultraThinMaterial, in: Capsule())
        .background(browser.isPrivate ? Theme.privateAccent.opacity(0.14) : Theme.field, in: Capsule())
        .overlay(
            Capsule().strokeBorder(focused ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Theme.cardStroke),
                                   lineWidth: focused ? 1.8 : 1)
        )
        .overlay(alignment: .bottom) { progressLine }
        .shadow(color: focused ? Theme.accent.opacity(0.30) : .black.opacity(0.08),
                radius: focused ? 14 : 9, y: 4)
        .padding(.horizontal, 14)
        .padding(.vertical, 6)
        .animation(.easeOut(duration: 0.15), value: focused)
    }

    private var toolbar: some View {
        HStack(spacing: 0) {
            IconButton(icon: "ic_back") { browser.webView.goBack() }
                .disabled(!browser.canGoBack)
            IconButton(icon: "ic_forward") { browser.webView.goForward() }
                .disabled(!browser.canGoForward)
            Button { browser.captureActiveThumb { showTabs = true } } label: {
                Text("\(browser.tabs.count)")
                    .font(.system(.caption, design: .rounded).weight(.heavy))
                    .frame(minWidth: 26, minHeight: 26)
                    .padding(.horizontal, 2)
                    .background(Theme.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(lineWidth: 1.8))
                    .foregroundStyle(browser.isPrivate ? Theme.privateAccent : Theme.accent)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .contentShape(Rectangle())
            }
            .buttonStyle(PressStyle())
            Button { browser.newTab() } label: {
                SVGIcon(name: "ic_plus", size: 19)
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(Theme.gradient, in: Circle())
                    .overlay(Circle().strokeBorder(.white.opacity(0.30), lineWidth: 1))
                    .shadow(color: Theme.accent.opacity(0.5), radius: 9, y: 4)
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(PressStyle())
            IconButton(icon: browser.isLoading ? "ic_close" : "ic_reload") {
                if browser.isLoading { browser.webView.stopLoading() } else { browser.webView.reload() }
            }
            IconButton(icon: "ic_grid", tint: settings.adBlock ? Theme.accent : Color.primary,
                       badge: settings.adBlock) { showMenu = true }
        }
        .padding(.horizontal, 6)
        .frame(height: 62)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(Theme.cardStroke, lineWidth: 1))
        .overlay(
            Capsule().strokeBorder(LinearGradient(colors: [.white.opacity(0.35), .clear],
                                                  startPoint: .top, endPoint: .bottom), lineWidth: 0.8)
        )
        .shadow(color: .black.opacity(0.16), radius: 18, y: 8)
        .padding(.horizontal, 16)
        .padding(.top, 4)
        .padding(.bottom, 6)
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }

    private func handle(_ a: MenuAction) {
        showMenu = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            switch a {
            case .fullscreen: browser.setFullscreen(true)
            case .find: browser.findInPage()
            case .library: showLibrary = true
            case .settings: showSettings = true
            case .downloads: showDownloads = true
            case .newPrivate: browser.newPrivateTab()
            case .videos: showVideos = true
            case .extensions: showExt = true
            case .reader: browser.toggleReader()
            case .translate: browser.translatePage()
            case .shot:
                Task {
                    if let u = await browser.saveFullScreenshot() { shareFile = ShareFile(url: u) }
                }
            case .pdf:
                Task {
                    if let u = await browser.savePDF() { shareFile = ShareFile(url: u) }
                }
            }
        }
    }
}

/// Nút nổi khi toàn màn hình: chạm để mở menu nhỏ (Thoát / Tải lại), kéo để dời chỗ.
struct FullscreenFab: View {
    @EnvironmentObject var browser: BrowserModel
    @State private var open = false
    @State private var base = CGSize.zero
    @State private var drag = CGSize.zero

    private func clamp(_ s: CGSize) -> CGSize {
        let b = UIScreen.main.bounds
        let maxX = max(0, max(b.width, b.height) - 60)
        let maxY = min(b.width, b.height) / 2 - 24
        return CGSize(width: min(max(s.width, 0), maxX), height: min(max(s.height, -maxY), maxY))
    }

    private func chip(_ icon: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            SVGIcon(name: icon, size: 18)
                .frame(width: 36, height: 36)
                .background(.ultraThinMaterial, in: Circle())
                .background(Color.black.opacity(0.35), in: Circle())
                .overlay(Circle().strokeBorder(.white.opacity(0.25), lineWidth: 1))
                .foregroundStyle(.white)
        }
        .buttonStyle(PressStyle())
    }

    var body: some View {
        HStack(spacing: 8) {
            SVGIcon(name: open ? "ic_close" : "ic_exit_fullscreen", size: 18)
                .font(.system(size: 15, weight: .semibold))
                .frame(width: 36, height: 36)
                .background(.ultraThinMaterial, in: Circle())
                .background(Theme.accent.opacity(0.45), in: Circle())
                .overlay(Circle().strokeBorder(.white.opacity(0.3), lineWidth: 1))
                .foregroundStyle(.white)
                .onTapGesture { withAnimation { open.toggle() } }
            if open {
                chip("ic_exit_fullscreen") { browser.setFullscreen(false) }
                chip("ic_reload") { browser.webView.reload(); open = false }
            }
        }
        .opacity(open ? 1 : 0.4)
        .offset(clamp(CGSize(width: base.width + drag.width, height: base.height + drag.height)))
        .gesture(
            DragGesture(minimumDistance: 6)
                .onChanged { drag = $0.translation }
                .onEnded { v in
                    base = clamp(CGSize(width: base.width + v.translation.width,
                                        height: base.height + v.translation.height))
                    drag = .zero
                }
        )
    }
}

struct WebViewContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Cài đặt

// MARK: - Dấu trang & Lịch sử

// MARK: - Tải xuống

// MARK: - Danh sách tab

struct TabsView: View {
    @EnvironmentObject var browser: BrowserModel
    @ObservedObject private var settings = BrowserSettings.shared
    @Environment(\.dismiss) private var dismiss
    @State private var showPrivate = false
    /// nil = tất cả thẻ; khác nil = chỉ thẻ trong nhóm này.
    @State private var filterGroup: UUID?

    private var shown: [Tab] {
        browser.tabs.filter {
            $0.isPrivate == showPrivate && (showPrivate || filterGroup == nil || $0.groupID == filterGroup)
        }
    }
    private let cols = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    private func count(_ g: TabGroup) -> Int {
        browser.tabs.filter { !$0.isPrivate && $0.groupID == g.id }.count
    }

    private func newGroup(for tabID: UUID?) {
        browser.askText(title: "Nhóm mới", message: "Đặt tên cho nhóm thẻ",
                        placeholder: "Ví dụ: Công việc", initial: "", ok: "Tạo") { name in
            let g = browser.createGroup(name: name)
            if let id = tabID { browser.setGroup(g.id, for: id) }
            filterGroup = g.id
        }
    }

    private func rename(_ g: TabGroup) {
        browser.askText(title: "Đổi tên nhóm", message: nil,
                        placeholder: "Tên nhóm", initial: g.name) { name in
            browser.renameGroup(g.id, to: name)
        }
    }

    private func chip(_ title: String, color: Color?, selected: Bool) -> some View {
        HStack(spacing: 6) {
            if let c = color { Circle().fill(c).frame(width: 9, height: 9) }
            Text(title)
                .font(Theme.rounded(.footnote, .semibold))
                .lineLimit(1)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .foregroundStyle(.primary)
        .background((selected ? (color ?? Theme.accent).opacity(0.24) : Theme.chip), in: Capsule())
        .overlay(Capsule().strokeBorder(selected ? (color ?? Theme.accent) : Color.clear, lineWidth: 1.5))
    }

    private var groupBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                Button { filterGroup = nil } label: { chip("Tất cả", color: nil, selected: filterGroup == nil) }
                    .buttonStyle(PressStyle())
                ForEach(browser.groups) { g in
                    Button { filterGroup = g.id } label: {
                        chip("\(g.name) · \(count(g))", color: GroupPalette.color(g.colorIndex),
                             selected: filterGroup == g.id)
                    }
                    .buttonStyle(PressStyle())
                    .contextMenu {
                        Button { rename(g) } label: { Label("Đổi tên", systemImage: "pencil") }
                        Button {
                            if filterGroup == g.id { filterGroup = nil }
                            browser.deleteGroup(g.id)
                        } label: { Label("Giải tán nhóm", systemImage: "rectangle.stack.badge.minus") }
                        Button(role: .destructive) {
                            if filterGroup == g.id { filterGroup = nil }
                            withAnimation { browser.closeGroup(g.id) }
                        } label: { Label("Đóng cả nhóm", systemImage: "xmark.circle") }
                    }
                }
                Button { newGroup(for: nil) } label: {
                    chip("+ Nhóm mới", color: nil, selected: false)
                }
                .buttonStyle(PressStyle())
            }
            .padding(.horizontal, 20)
        }
        .padding(.top, 10)
    }

    var body: some View {
        ZStack {
            ScreenBackground()

            VStack(spacing: 0) {
                SegmentedPill(titles: ["Thường", "Riêng tư"], icons: ["ic_grid", "ic_private"],
                              selection: Binding(get: { showPrivate ? 1 : 0 },
                                                 set: { showPrivate = ($0 == 1) }))
                    .padding(.horizontal, 20)
                    .padding(.top, 12)

                if !showPrivate { groupBar }

                ScrollView {
                    if shown.isEmpty {
                        EmptyState(asset: showPrivate ? "ic_private" : "ic_grid",
                                   title: showPrivate ? "Chưa có thẻ riêng tư" : "Chưa có thẻ nào",
                                   message: "Bấm nút + để mở thẻ mới.")
                            .padding(.top, 60)
                    } else {
                        LazyVGrid(columns: cols, spacing: 18) {
                            ForEach(shown) { tab in
                                TabCard(tab: tab,
                                        active: tab.id == browser.activeID,
                                        select: { browser.select(tab.id); dismiss() },
                                        close: { withAnimation(.easeOut(duration: 0.2)) { browser.close(tab.id) } },
                                        groupColor: browser.group(of: tab).map { GroupPalette.color($0.colorIndex) })
                                    .contextMenu {
                                        if !showPrivate {
                                            Menu {
                                                ForEach(browser.groups) { g in
                                                    Button {
                                                        browser.setGroup(g.id, for: tab.id)
                                                    } label: {
                                                        Label(g.name, systemImage: tab.groupID == g.id ? "checkmark" : "folder")
                                                    }
                                                }
                                                Button { newGroup(for: tab.id) } label: {
                                                    Label("Nhóm mới…", systemImage: "plus")
                                                }
                                            } label: {
                                                Label("Thêm vào nhóm", systemImage: "folder.badge.plus")
                                            }
                                            if tab.groupID != nil {
                                                Button { browser.setGroup(nil, for: tab.id) } label: {
                                                    Label("Bỏ khỏi nhóm", systemImage: "folder.badge.minus")
                                                }
                                            }
                                        }
                                        Button(role: .destructive) {
                                            withAnimation { browser.close(tab.id) }
                                        } label: { Label("Đóng thẻ", systemImage: "xmark") }
                                    }
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 16)
                        .padding(.bottom, 120)
                    }
                }
            }

            VStack {
                Spacer()
                HStack {
                    Text("\(shown.count) thẻ")
                        .font(Theme.rounded(.footnote, .semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Button {
                        browser.addTab(request: nil, isPrivate: showPrivate,
                                       group: showPrivate ? nil : filterGroup)
                        dismiss()
                    } label: {
                        SVGIcon(name: "ic_plus", size: 24)
                            .foregroundStyle(.white)
                            .frame(width: 60, height: 60)
                            .background(Theme.gradient, in: Circle())
                            .overlay(Circle().strokeBorder(.white.opacity(0.3), lineWidth: 1))
                            .shadow(color: Theme.accent.opacity(0.55), radius: 14, y: 6)
                    }
                    .buttonStyle(PressStyle())
                    Button("Xong") { dismiss() }
                        .buttonStyle(SoftButtonStyle())
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .background(.ultraThinMaterial)
            }
        }
        .onAppear { showPrivate = browser.isPrivate; filterGroup = nil }
        .environment(\.privateMode, showPrivate)
        .preferredColorScheme(showPrivate ? .dark : settings.colorScheme)
    }
}

/// Thẻ tab dạng lưới có ảnh xem trước.
struct TabCard: View {
    @ObservedObject var tab: Tab
    let active: Bool
    let select: () -> Void
    let close: () -> Void
    var groupColor: Color? = nil

    private var stroke: AnyShapeStyle {
        if active { return AnyShapeStyle(Theme.gradient) }
        if let c = groupColor { return AnyShapeStyle(c) }
        return AnyShapeStyle(Theme.cardStroke)
    }
    private var strokeWidth: CGFloat { active ? 3 : (groupColor != nil ? 2.5 : 1) }

    private var title: String {
        tab.title.isEmpty ? (tab.url?.host?.replacingOccurrences(of: "www.", with: "") ?? "Thẻ mới") : tab.title
    }

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 6) {
                Text(String((tab.url?.host ?? "•").replacingOccurrences(of: "www.", with: "").prefix(1)).uppercased())
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(width: 20, height: 20)
                    .background(tab.isPrivate ? AnyShapeStyle(Theme.privateAccent) : AnyShapeStyle(Theme.gradient), in: Circle())
                    .overlay(Circle().strokeBorder(groupColor ?? Color.clear, lineWidth: 2.5).padding(-3))
                Text(title)
                    .font(Theme.rounded(.footnote, .semibold))
                    .lineLimit(1)
                Spacer(minLength: 0)
                Button(action: close) {
                    SVGIcon(name: "ic_close", size: 11)
                        .foregroundStyle(.secondary)
                        .frame(width: 24, height: 24)
                        .background(Theme.chip, in: Circle())
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 4)

            Button(action: select) {
                ZStack(alignment: .top) {
                    Rectangle().fill(Theme.card)
                    if let img = tab.thumb {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                    } else {
                        VStack(spacing: 8) {
                            SVGIcon(name: "ic_search", size: 24).foregroundStyle(Theme.accent)
                            Text(tab.url?.host ?? "Trang mới").font(.caption).foregroundStyle(.secondary)
                        }
                        .frame(maxHeight: .infinity)
                    }
                }
                .aspectRatio(0.72, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .strokeBorder(stroke, lineWidth: strokeWidth)
                )
                .shadow(color: active ? Theme.accent.opacity(0.45) : .black.opacity(0.18),
                        radius: active ? 12 : 8, y: 4)
            }
            .buttonStyle(PressStyle())
        }
    }
}

// MARK: - Extension list

struct ExtPage: Identifiable {
    let id = UUID()
    let extId: String
    let path: String
    let tabURL: String
    let title: String
}

// MARK: - Popup / options page of an extension

struct ExtPageView: UIViewRepresentable {
    let page: ExtPage

    final class Coordinator {
        let scheme = ExtSchemeHandler(store: ExtStore.shared)
        let bridge = ExtBridge(store: ExtStore.shared)
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(context.coordinator.scheme, forURLScheme: "ext")
        cfg.userContentController.addScriptMessageHandler(context.coordinator.bridge,
                                                          contentWorld: .page,
                                                          name: "extBridge")
        let src = ScriptBuilder.context(id: page.extId, store: ExtStore.shared, tabURL: page.tabURL, role: "page")
        cfg.userContentController.addUserScript(
            WKUserScript(source: src, injectionTime: .atDocumentStart,
                         forMainFrameOnly: true, in: .page))
        let w = WKWebView(frame: .zero, configuration: cfg)
        if let u = URL(string: "ext://\(page.extId)/\(page.path)") {
            w.load(URLRequest(url: u))
        }
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Nhật ký của trang nền

struct ExtLogView: View {
    let extId: String
    let title: String
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""

    var body: some View {
        SheetScaffold(title: title, subtitle: "Nhật ký trang nền", onClose: { dismiss() },
                      trailing: {
            Button("Làm mới") { text = ExtRuntime.shared.logText(extId) }
                .buttonStyle(SoftButtonStyle())
        }, content: {
            ScrollView {
                Text(text.isEmpty ? "Chưa có log" : text)
                    .font(.system(size: 11, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14)
                    .textSelection(.enabled)
                    .card(radius: 18)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 30)
            }
        })
        .onAppear { text = ExtRuntime.shared.logText(extId) }
    }
}


// MARK: - Menu nút khiên trên thanh địa chỉ

struct AdBlockSheet: View {
    @EnvironmentObject var browser: BrowserModel
    @ObservedObject private var settings = BrowserSettings.shared
    @Environment(\.dismiss) private var dismiss

    private enum Mode { case all, siteOff, off }

    private var host: String? { browser.currentURL?.host }
    private var site: String { BrowserModel.siteKey(host) }

    private var mode: Mode {
        if !settings.adBlock { return .off }
        return settings.adBlockActive(for: host) ? .all : .siteOff
    }

    private func reloadSoon() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { browser.webView.reload() }
    }

    private func choose(_ m: Mode) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        switch m {
        case .all:
            settings.setAdBlock(allowedOn: host, false)
            settings.adBlock = true
        case .siteOff:
            guard !site.isEmpty else { return }
            settings.adBlock = true
            settings.setAdBlock(allowedOn: host, true)
        case .off:
            settings.adBlock = false
        }
        reloadSoon()
    }

    private func row(_ title: String, _ sub: String?, selected: Bool, enabled: Bool = true,
                     action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 21))
                    .foregroundStyle(selected ? Theme.success : Color.secondary.opacity(0.6))
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(Theme.rounded(.subheadline, .semibold)).foregroundStyle(.primary)
                    if let sub = sub {
                        Text(sub).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(.vertical, 10)
            .contentShape(Rectangle())
        }
        .buttonStyle(PressStyle())
        .disabled(!enabled)
        .opacity(enabled ? 1 : 0.45)
    }

    var body: some View {
        ZStack {
            ScreenBackground()
            VStack(spacing: 14) {
                HStack(spacing: 12) {
                    SVGIcon(name: mode == .all ? "ic_shield" : "ic_shield_off", size: 22)
                        .foregroundStyle(mode == .all ? Theme.success : Color.secondary)
                        .frame(width: 44, height: 44)
                        .background(mode == .all ? Theme.success.opacity(0.15) : Theme.chip, in: Circle())
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Chặn quảng cáo").font(Theme.rounded(.headline, .bold))
                        Text(site.isEmpty ? "Chưa mở trang nào" : site)
                            .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .padding(.top, 18)

                VStack(spacing: 0) {
                    Toggle(isOn: $settings.popupBlock) {
                        HStack(spacing: 10) {
                            SVGIcon(name: "ic_popup", size: 18).foregroundStyle(.secondary)
                            Text("Chặn mở tab mới").font(Theme.rounded(.subheadline, .semibold))
                        }
                    }
                    .tint(Theme.success)
                    .padding(.vertical, 6)
                }
                .padding(.horizontal, 16)
                .card()

                VStack(spacing: 0) {
                    row("Chặn quảng cáo", "Áp dụng cho mọi trang", selected: mode == .all) { choose(.all) }
                    Divider()
                    row("Tắt chặn trên trang này", site.isEmpty ? nil : site,
                        selected: mode == .siteOff, enabled: !site.isEmpty) { choose(.siteOff) }
                    Divider()
                    row("Tắt chặn quảng cáo", "Tắt cho tất cả trang", selected: mode == .off) { choose(.off) }
                }
                .padding(.horizontal, 16)
                .card()

                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
        }
    }
}
