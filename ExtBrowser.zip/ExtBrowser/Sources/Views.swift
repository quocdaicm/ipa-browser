import SwiftUI
import WebKit
import UniformTypeIdentifiers

// MARK: - Browser

struct BrowserView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @State private var address = ""
    @State private var showExt = false
    @State private var showTabs = false
    @State private var showDownloads = false
    @State private var showLibrary = false
    @State private var showSettings = false
    @State private var showMenu = false
    @State private var showVideos = false
    @ObservedObject private var library = LibraryStore.shared
    @State private var directPage: ExtPage?
    @ObservedObject private var settings = BrowserSettings.shared
    @FocusState private var focused: Bool

    /// Ổ khoá + tên miền hiện khi không nhập; nil nếu không phải trang web.
    private var siteLabel: (icon: String, text: String, secure: Bool)? {
        guard let u = browser.currentURL else { return nil }
        let scheme = (u.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https", var h = u.host else { return nil }
        if h.hasPrefix("www.") { h.removeFirst(4) }
        let secure = scheme == "https"
        return (secure ? "lock.fill" : "exclamationmark.triangle.fill", h, secure)
    }

    private var suggestions: [SavedPage] {
        let q = address.trimmingCharacters(in: .whitespacesAndNewlines)
        var seen = Set<String>()
        var out: [SavedPage] = []
        if q.isEmpty {
            for p in Array(library.bookmarks.prefix(4)) + Array(library.history.prefix(6)) {
                if seen.insert(p.url).inserted { out.append(p) }
            }
            return out
        }
        for p in library.bookmarks + library.history {
            guard p.title.localizedCaseInsensitiveContains(q) ||
                  p.url.localizedCaseInsensitiveContains(q) else { continue }
            if seen.insert(p.url).inserted {
                out.append(p)
                if out.count >= 8 { break }
            }
        }
        return out
    }

    private var suggestionList: some View {
        let q = address.trimmingCharacters(in: .whitespacesAndNewlines)
        return ZStack {
            ScreenBackground()
            ScrollView {
                LazyVStack(spacing: 10) {
                    if !q.isEmpty {
                        Button {
                            browser.go(q)
                            focused = false
                        } label: {
                            HStack(spacing: 12) {
                                IconChip(asset: "ic_search", color: Theme.accent, size: 38)
                                Text("Tìm “\(q)”")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                Spacer(minLength: 0)
                                Chevron()
                            }
                            .padding(12)
                            .card(radius: 18)
                        }
                        .buttonStyle(PressStyle())
                    }
                    if q.isEmpty && !suggestions.isEmpty {
                        Text("GẦN ĐÂY").font(.caption.weight(.bold)).tracking(0.8)
                            .foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 6).padding(.top, 4)
                    }
                    ForEach(suggestions) { p in
                        HStack(spacing: 10) {
                            Button {
                                browser.go(p.url)
                                focused = false
                            } label: {
                                HStack(spacing: 12) {
                                    IconChip(sf: library.isBookmarked(p.url) ? "star.fill" : "clock.fill",
                                             color: library.isBookmarked(p.url) ? Theme.warn : Theme.accent2,
                                             size: 38, filled: false)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(p.title.isEmpty ? p.url : p.title)
                                            .font(.subheadline.weight(.semibold))
                                            .foregroundStyle(.primary).lineLimit(1)
                                        Text(p.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(minLength: 0)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            Button { address = p.url } label: {
                                Image(systemName: "arrow.up.left")
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundStyle(.secondary)
                                    .frame(width: 32, height: 32)
                                    .background(Theme.chip, in: Circle())
                            }
                            .buttonStyle(PressStyle())
                        }
                        .padding(10)
                        .card(radius: 18)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
            }
            .scrollDismissesKeyboard(.immediately)
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            if !browser.fullscreen && !(browser.chromeHidden && !focused) {
                addressBar
                    .transition(.move(edge: .top).combined(with: .opacity))
            }

            ZStack(alignment: .bottom) {
                WebViewContainer(webView: browser.webView)
                    .id(browser.activeID)
                if settings.videoTool && !browser.fullscreen {
                    VideoFab(tab: browser.activeTab) { showVideos = true }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                        .padding(.trailing, 16)
                        .padding(.bottom, 14)
                        .animation(.spring(response: 0.4, dampingFraction: 0.65), value: browser.activeTab.videos.count)
                }
                if let t = ExtensionManager.storeTarget(for: browser.currentURL) {
                    Button {
                        Task { await manager.installFromStore(t) }
                    } label: {
                        Label(manager.busy ? "Đang cài…" : "Thêm vào app",
                              systemImage: "plus.circle.fill")
                            .font(.headline)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(manager.busy)
                    .padding(.bottom, 16)
                }
                if focused {
                    suggestionList
                }
            }
            .ignoresSafeArea(.container, edges: browser.fullscreen ? .vertical : [])

            if !browser.fullscreen && !(browser.chromeHidden && !focused) {
            toolbar
                .sheet(item: $directPage) { p in
                    NavigationStack {
                        ExtPageView(page: p)
                            .navigationTitle(p.title)
                            .navigationBarTitleDisplayMode(.inline)
                    }
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
                }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: browser.chromeHidden)
        .background {
            if browser.fullscreen { Color.black.ignoresSafeArea() } else { ScreenBackground() }
        }
        .statusBarHidden(browser.fullscreen)
        .persistentSystemOverlays(browser.fullscreen ? .hidden : .automatic)
        .overlay(alignment: .leading) {
            if browser.fullscreen {
                FullscreenFab().padding(.leading, 8)
            }
        }
        .overlay(alignment: .top) {
            if let n = manager.notice {
                HStack(spacing: 8) {
                    Circle().fill(Theme.gradient).frame(width: 8, height: 8)
                    Text(n)
                        .font(.system(.subheadline, design: .rounded).weight(.medium))
                        .multilineTextAlignment(.leading)
                }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(.regularMaterial, in: Capsule())
                    .overlay(Capsule().strokeBorder(Theme.cardStroke))
                    .shadow(color: .black.opacity(0.18), radius: 12, y: 5)
                    .padding(.top, 50)
                    .padding(.horizontal, 20)
                    .transition(.opacity)
            }
        }
        .animation(.default, value: manager.notice)
        .onChange(of: focused) { f in
            // Bấm vào ô địa chỉ: xoá URL cũ ngay; thoát mà không nhập thì khôi phục lại
            address = f ? "" : (browser.currentURL?.absoluteString ?? "")
        }
        .onReceive(browser.$currentURL) { u in
            if !focused { address = u?.absoluteString ?? "" }
        }
        .onReceive(manager.$items) { browser.applyExtensions($0) }
        .onAppear {
            browser.onInstallLink = { u in
                Task { await manager.installFromLink(u.absoluteString) }
            }
            DownloadManager.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.onOpenPage = { p in
                Task { @MainActor in directPage = p }
            }
        }
        .sheet(isPresented: $showMenu) {
            MenuSheet { handle($0) }
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showExt) { ExtensionsView() }
        .fullScreenCover(isPresented: $showTabs) { TabsView() }
        .sheet(isPresented: $showVideos) { VideoSheet(tab: browser.activeTab) }
        .sheet(isPresented: $showDownloads) { DownloadsView() }
        .sheet(isPresented: $showLibrary) { LibraryView() }
        .sheet(isPresented: $showSettings) { SettingsView() }
    }

    private var progressLine: some View {
        GeometryReader { g in
            Capsule()
                .fill(browser.isPrivate ? AnyShapeStyle(Color.purple) : AnyShapeStyle(Theme.gradient))
                .frame(width: g.size.width * CGFloat(browser.progress), height: 3)
        }
        .frame(height: 3)
        .padding(.horizontal, 24)
        .padding(.bottom, 1)
        .opacity(browser.isLoading ? 1 : 0)
        .animation(.easeOut(duration: 0.25), value: browser.progress)
    }

    private var addressBar: some View {
        HStack(spacing: 10) {
            Group {
                if focused || siteLabel == nil {
                    SVGIcon(name: "ic_search", size: 16).foregroundStyle(Theme.accent)
                } else if let l = siteLabel {
                    SVGIcon(name: l.secure ? "ic_lock" : "ic_warning", size: 15)
                        .foregroundStyle(l.secure ? Theme.success : Theme.warn)
                }
            }
            .frame(width: 30, height: 30)
            .background(Theme.chip, in: Circle())

            TextField("Tìm kiếm hoặc nhập địa chỉ", text: $address)
                .font(.system(.body, design: .rounded))
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.go)
                .focused($focused)
                .onSubmit {
                    browser.go(address)
                    focused = false
                }
                .foregroundStyle(focused || siteLabel == nil ? Color.primary : Color.clear)
                .overlay(alignment: .leading) {
                    if !focused, let l = siteLabel {
                        Text(l.text)
                            .font(.system(.body, design: .rounded).weight(.medium))
                            .lineLimit(1).allowsHitTesting(false)
                    }
                }
            if focused {
                if !address.isEmpty {
                    Button { address = "" } label: {
                        SVGIcon(name: "ic_close", size: 12)
                            .foregroundStyle(.secondary)
                            .frame(width: 28, height: 28)
                            .background(Theme.chip, in: Circle())
                    }
                    .buttonStyle(PressStyle())
                }
            } else {
                if browser.isPrivate {
                    SVGIcon(name: "ic_private", size: 16).foregroundStyle(Color.purple)
                }
                Button {
                    if browser.isLoading { browser.webView.stopLoading() } else { browser.webView.reload() }
                } label: {
                    SVGIcon(name: browser.isLoading ? "ic_close" : "ic_reload", size: 15)
                        .foregroundStyle(.secondary)
                        .frame(width: 30, height: 30)
                        .background(Theme.chip, in: Circle())
                }
                .buttonStyle(PressStyle())
            }
        }
        .padding(.horizontal, 9)
        .frame(height: 50)
        .background(.ultraThinMaterial, in: Capsule())
        .background(browser.isPrivate ? Color.purple.opacity(0.14) : Theme.field, in: Capsule())
        .overlay(
            Capsule().strokeBorder(focused ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Theme.cardStroke),
                                   lineWidth: focused ? 1.8 : 1)
        )
        .overlay(alignment: .bottom) { progressLine }
        .shadow(color: focused ? Theme.accent.opacity(0.30) : .black.opacity(0.08),
                radius: focused ? 14 : 9, y: 4)
        .padding(.horizontal, 14)
        .padding(.vertical, 6)
        .animation(.easeOut(duration: 0.15), value: focused)
    }

    private var toolbar: some View {
        HStack(spacing: 0) {
            IconButton(icon: "ic_back") { browser.webView.goBack() }
                .disabled(!browser.canGoBack)
            IconButton(icon: "ic_forward") { browser.webView.goForward() }
                .disabled(!browser.canGoForward)
            Button { browser.captureActiveThumb { showTabs = true } } label: {
                Text("\(browser.tabs.count)")
                    .font(.system(.caption, design: .rounded).weight(.heavy))
                    .frame(minWidth: 26, minHeight: 26)
                    .padding(.horizontal, 2)
                    .background(Theme.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(lineWidth: 1.8))
                    .foregroundStyle(browser.isPrivate ? Color.purple : Theme.accent)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .contentShape(Rectangle())
            }
            .buttonStyle(PressStyle())
            Button { browser.newTab() } label: {
                SVGIcon(name: "ic_plus", size: 19)
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(Theme.gradient, in: Circle())
                    .overlay(Circle().strokeBorder(.white.opacity(0.30), lineWidth: 1))
                    .shadow(color: Theme.accent.opacity(0.5), radius: 9, y: 4)
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(PressStyle())
            IconButton(icon: "ic_puzzle") { showExt = true }
            IconButton(icon: "ic_grid", tint: settings.adBlock ? Theme.accent : Color.primary,
                       badge: settings.adBlock) { showMenu = true }
        }
        .padding(.horizontal, 6)
        .frame(height: 62)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(Theme.cardStroke, lineWidth: 1))
        .overlay(
            Capsule().strokeBorder(LinearGradient(colors: [.white.opacity(0.35), .clear],
                                                  startPoint: .top, endPoint: .bottom), lineWidth: 0.8)
        )
        .shadow(color: .black.opacity(0.16), radius: 18, y: 8)
        .padding(.horizontal, 16)
        .padding(.top, 4)
        .padding(.bottom, 6)
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }

    private func handle(_ a: MenuAction) {
        showMenu = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            switch a {
            case .fullscreen: browser.setFullscreen(true)
            case .find: browser.findInPage()
            case .library: showLibrary = true
            case .settings: showSettings = true
            case .downloads: showDownloads = true
            case .newPrivate: browser.newPrivateTab()
            case .videos: showVideos = true
            }
        }
    }
}

/// Nút nổi khi toàn màn hình: chạm để mở menu nhỏ (Thoát / Tải lại), kéo để dời chỗ.
struct FullscreenFab: View {
    @EnvironmentObject var browser: BrowserModel
    @State private var open = false
    @State private var base = CGSize.zero
    @State private var drag = CGSize.zero

    private func clamp(_ s: CGSize) -> CGSize {
        let b = UIScreen.main.bounds
        let maxX = max(0, max(b.width, b.height) - 60)
        let maxY = min(b.width, b.height) / 2 - 24
        return CGSize(width: min(max(s.width, 0), maxX), height: min(max(s.height, -maxY), maxY))
    }

    private func chip(_ icon: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            SVGIcon(name: icon, size: 18)
                .frame(width: 36, height: 36)
                .background(.ultraThinMaterial, in: Circle())
                .background(Color.black.opacity(0.35), in: Circle())
                .overlay(Circle().strokeBorder(.white.opacity(0.25), lineWidth: 1))
                .foregroundStyle(.white)
        }
        .buttonStyle(PressStyle())
    }

    var body: some View {
        HStack(spacing: 8) {
            SVGIcon(name: open ? "ic_close" : "ic_exit_fullscreen", size: 18)
                .font(.system(size: 15, weight: .semibold))
                .frame(width: 36, height: 36)
                .background(.ultraThinMaterial, in: Circle())
                .background(Theme.accent.opacity(0.45), in: Circle())
                .overlay(Circle().strokeBorder(.white.opacity(0.3), lineWidth: 1))
                .foregroundStyle(.white)
                .onTapGesture { withAnimation { open.toggle() } }
            if open {
                chip("ic_exit_fullscreen") { browser.setFullscreen(false) }
                chip("ic_reload") { browser.webView.reload(); open = false }
            }
        }
        .opacity(open ? 1 : 0.4)
        .offset(clamp(CGSize(width: base.width + drag.width, height: base.height + drag.height)))
        .gesture(
            DragGesture(minimumDistance: 6)
                .onChanged { drag = $0.translation }
                .onEnded { v in
                    base = clamp(CGSize(width: base.width + v.translation.width,
                                        height: base.height + v.translation.height))
                    drag = .zero
                }
        )
    }
}

struct WebViewContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Cài đặt

// MARK: - Dấu trang & Lịch sử

// MARK: - Tải xuống

// MARK: - Danh sách tab

struct TabsView: View {
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var showPrivate = false

    private var shown: [Tab] { browser.tabs.filter { $0.isPrivate == showPrivate } }
    private let cols = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        ZStack {
            ScreenBackground()

            VStack(spacing: 0) {
                SegmentedPill(titles: ["Thường", "Riêng tư"], icons: ["ic_grid", "ic_private"],
                              selection: Binding(get: { showPrivate ? 1 : 0 },
                                                 set: { showPrivate = ($0 == 1) }))
                    .padding(.horizontal, 20)
                    .padding(.top, 12)

                ScrollView {
                    if shown.isEmpty {
                        EmptyState(asset: showPrivate ? "ic_private" : "ic_grid",
                                   title: showPrivate ? "Chưa có thẻ riêng tư" : "Chưa có thẻ nào",
                                   message: "Bấm nút + để mở thẻ mới.")
                            .padding(.top, 60)
                    } else {
                        LazyVGrid(columns: cols, spacing: 18) {
                            ForEach(shown) { tab in
                                TabCard(tab: tab,
                                        active: tab.id == browser.activeID,
                                        select: { browser.select(tab.id); dismiss() },
                                        close: { withAnimation(.easeOut(duration: 0.2)) { browser.close(tab.id) } })
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 16)
                        .padding(.bottom, 120)
                    }
                }
            }

            VStack {
                Spacer()
                HStack {
                    Text("\(shown.count) thẻ")
                        .font(Theme.rounded(.footnote, .semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Button {
                        if showPrivate { browser.newPrivateTab() } else { browser.newTab() }
                        dismiss()
                    } label: {
                        SVGIcon(name: "ic_plus", size: 24)
                            .foregroundStyle(.white)
                            .frame(width: 60, height: 60)
                            .background(Theme.gradient, in: Circle())
                            .overlay(Circle().strokeBorder(.white.opacity(0.3), lineWidth: 1))
                            .shadow(color: Theme.accent.opacity(0.55), radius: 14, y: 6)
                    }
                    .buttonStyle(PressStyle())
                    Button("Xong") { dismiss() }
                        .buttonStyle(SoftButtonStyle())
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .background(.ultraThinMaterial)
            }
        }
        .onAppear { showPrivate = browser.isPrivate }
    }
}

/// Thẻ tab dạng lưới có ảnh xem trước.
struct TabCard: View {
    @ObservedObject var tab: Tab
    let active: Bool
    let select: () -> Void
    let close: () -> Void

    private var title: String {
        tab.title.isEmpty ? (tab.url?.host?.replacingOccurrences(of: "www.", with: "") ?? "Thẻ mới") : tab.title
    }

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 6) {
                Text(String((tab.url?.host ?? "•").replacingOccurrences(of: "www.", with: "").prefix(1)).uppercased())
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(width: 20, height: 20)
                    .background(tab.isPrivate ? AnyShapeStyle(Color.purple) : AnyShapeStyle(Theme.gradient), in: Circle())
                Text(title)
                    .font(Theme.rounded(.footnote, .semibold))
                    .lineLimit(1)
                Spacer(minLength: 0)
                Button(action: close) {
                    SVGIcon(name: "ic_close", size: 11)
                        .foregroundStyle(.secondary)
                        .frame(width: 24, height: 24)
                        .background(Theme.chip, in: Circle())
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 4)

            Button(action: select) {
                ZStack(alignment: .top) {
                    Rectangle().fill(Theme.card)
                    if let img = tab.thumb {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                    } else {
                        VStack(spacing: 8) {
                            SVGIcon(name: "ic_search", size: 24).foregroundStyle(Theme.accent)
                            Text(tab.url?.host ?? "Trang mới").font(.caption).foregroundStyle(.secondary)
                        }
                        .frame(maxHeight: .infinity)
                    }
                }
                .aspectRatio(0.72, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .strokeBorder(active ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Theme.cardStroke),
                                      lineWidth: active ? 3 : 1)
                )
                .shadow(color: active ? Theme.accent.opacity(0.45) : .black.opacity(0.18),
                        radius: active ? 12 : 8, y: 4)
            }
            .buttonStyle(PressStyle())
        }
    }
}

// MARK: - Extension list

struct ExtPage: Identifiable {
    let id = UUID()
    let extId: String
    let path: String
    let tabURL: String
    let title: String
}

// MARK: - Popup / options page of an extension

struct ExtPageView: UIViewRepresentable {
    let page: ExtPage

    final class Coordinator {
        let scheme = ExtSchemeHandler(store: ExtStore.shared)
        let bridge = ExtBridge(store: ExtStore.shared)
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(context.coordinator.scheme, forURLScheme: "ext")
        cfg.userContentController.addScriptMessageHandler(context.coordinator.bridge,
                                                          contentWorld: .page,
                                                          name: "extBridge")
        let src = ScriptBuilder.context(id: page.extId, store: ExtStore.shared, tabURL: page.tabURL, role: "page")
        cfg.userContentController.addUserScript(
            WKUserScript(source: src, injectionTime: .atDocumentStart,
                         forMainFrameOnly: true, in: .page))
        let w = WKWebView(frame: .zero, configuration: cfg)
        if let u = URL(string: "ext://\(page.extId)/\(page.path)") {
            w.load(URLRequest(url: u))
        }
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Nhật ký của trang nền

struct ExtLogView: View {
    let extId: String
    let title: String
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""

    var body: some View {
        SheetScaffold(title: title, subtitle: "Nhật ký trang nền", onClose: { dismiss() },
                      trailing: {
            Button("Làm mới") { text = ExtRuntime.shared.logText(extId) }
                .buttonStyle(SoftButtonStyle())
        }, content: {
            ScrollView {
                Text(text.isEmpty ? "Chưa có log" : text)
                    .font(.system(size: 11, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14)
                    .textSelection(.enabled)
                    .card(radius: 18)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 30)
            }
        })
        .onAppear { text = ExtRuntime.shared.logText(extId) }
    }
}
