import SwiftUI
import WebKit
import UniformTypeIdentifiers

// MARK: - Browser

struct BrowserView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @State private var address = ""
    @State private var showExt = false
    @State private var showTabs = false
    @State private var showDownloads = false
    @State private var showLibrary = false
    @State private var showSettings = false
    @ObservedObject private var library = LibraryStore.shared
    @State private var directPage: ExtPage?
    @ObservedObject private var settings = BrowserSettings.shared
    @FocusState private var focused: Bool

    /// Ổ khoá + tên miền hiện khi không nhập; nil nếu không phải trang web.
    private var siteLabel: (icon: String, text: String, secure: Bool)? {
        guard let u = browser.currentURL else { return nil }
        let scheme = (u.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https", var h = u.host else { return nil }
        if h.hasPrefix("www.") { h.removeFirst(4) }
        let secure = scheme == "https"
        return (secure ? "lock.fill" : "exclamationmark.triangle.fill", h, secure)
    }

    private var suggestions: [SavedPage] {
        let q = address.trimmingCharacters(in: .whitespacesAndNewlines)
        var seen = Set<String>()
        var out: [SavedPage] = []
        if q.isEmpty {
            for p in Array(library.bookmarks.prefix(4)) + Array(library.history.prefix(6)) {
                if seen.insert(p.url).inserted { out.append(p) }
            }
            return out
        }
        for p in library.bookmarks + library.history {
            guard p.title.localizedCaseInsensitiveContains(q) ||
                  p.url.localizedCaseInsensitiveContains(q) else { continue }
            if seen.insert(p.url).inserted {
                out.append(p)
                if out.count >= 8 { break }
            }
        }
        return out
    }

    private var suggestionList: some View {
        let q = address.trimmingCharacters(in: .whitespacesAndNewlines)
        return List {
            if !q.isEmpty {
                Button {
                    browser.go(q)
                    focused = false
                } label: {
                    Label("Tìm “\(q)”", systemImage: "magnifyingglass")
                }
            }
            ForEach(suggestions) { p in
                Button {
                    browser.go(p.url)
                    focused = false
                } label: {
                    HStack {
                        Image(systemName: library.isBookmarked(p.url) ? "star.fill" : "clock")
                            .foregroundStyle(.secondary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(p.title).lineLimit(1)
                            Text(p.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .listStyle(.plain)
        .scrollDismissesKeyboard(.immediately)
    }

    var body: some View {
        VStack(spacing: 0) {
            if !(browser.chromeHidden && !focused) {
            TextField("Tìm kiếm hoặc nhập địa chỉ", text: $address)
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.go)
                .focused($focused)
                .onSubmit {
                    browser.go(address)
                    focused = false
                }
                .foregroundStyle(focused || siteLabel == nil ? Color.primary : Color.clear)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(browser.isPrivate ? Color.purple.opacity(0.18) : Color(.secondarySystemBackground),
                            in: RoundedRectangle(cornerRadius: 12))
                .overlay {
                    if !focused, let l = siteLabel {
                        HStack(spacing: 6) {
                            Image(systemName: l.icon)
                                .font(.caption)
                                .foregroundStyle(l.secure ? Color.secondary : Color.orange)
                            Text(l.text).lineLimit(1)
                        }
                        .allowsHitTesting(false)
                    }
                }
                .overlay(alignment: .trailing) {
                    if focused && !address.isEmpty {
                        Button { address = "" } label: {
                            Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary)
                        }
                        .padding(.trailing, 8)
                    }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)

            ProgressView(value: browser.progress)
                .opacity(browser.isLoading ? 1 : 0)
            }

            ZStack(alignment: .bottom) {
                WebViewContainer(webView: browser.webView)
                    .id(browser.activeID)
                if let t = ExtensionManager.storeTarget(for: browser.currentURL) {
                    Button {
                        Task { await manager.installFromStore(t) }
                    } label: {
                        Label(manager.busy ? "Đang cài…" : "Thêm vào app",
                              systemImage: "plus.circle.fill")
                            .font(.headline)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(manager.busy)
                    .padding(.bottom, 16)
                }
                if focused {
                    suggestionList
                }
            }

            if !(browser.chromeHidden && !focused) {
            toolbar
                .sheet(item: $directPage) { p in
                    NavigationStack {
                        ExtPageView(page: p)
                            .navigationTitle(p.title)
                            .navigationBarTitleDisplayMode(.inline)
                    }
                }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: browser.chromeHidden)
        .overlay(alignment: .top) {
            if let n = manager.notice {
                Text(n)
                    .font(.subheadline)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(.thinMaterial, in: Capsule())
                    .padding(.top, 50)
                    .transition(.opacity)
            }
        }
        .animation(.default, value: manager.notice)
        .onChange(of: focused) { f in
            // Bấm vào ô địa chỉ: xoá URL cũ ngay; thoát mà không nhập thì khôi phục lại
            address = f ? "" : (browser.currentURL?.absoluteString ?? "")
        }
        .onReceive(browser.$currentURL) { u in
            if !focused { address = u?.absoluteString ?? "" }
        }
        .onReceive(manager.$items) { browser.applyExtensions($0) }
        .onAppear {
            browser.onInstallLink = { u in
                Task { await manager.installFromLink(u.absoluteString) }
            }
            DownloadManager.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.notify = { s in
                Task { @MainActor in manager.flash(s) }
            }
            ExtRuntime.shared.onOpenPage = { p in
                Task { @MainActor in directPage = p }
            }
        }
        .sheet(isPresented: $showExt) { ExtensionsView() }
        .sheet(isPresented: $showTabs) { TabsView() }
        .sheet(isPresented: $showDownloads) { DownloadsView() }
        .sheet(isPresented: $showLibrary) { LibraryView() }
        .sheet(isPresented: $showSettings) { SettingsView() }
    }

    private var toolbar: some View {
        HStack {
            Button { browser.webView.goBack() } label: { Image(systemName: "chevron.left") }
                .disabled(!browser.canGoBack)
            Spacer()
            Button { browser.webView.goForward() } label: { Image(systemName: "chevron.right") }
                .disabled(!browser.canGoForward)
            Spacer()
            Button {
                if browser.isLoading { browser.webView.stopLoading() } else { browser.webView.reload() }
            } label: {
                Image(systemName: browser.isLoading ? "xmark" : "arrow.clockwise")
            }
            Spacer()
            Button { showTabs = true } label: {
                Text("\(browser.tabs.count)")
                    .font(.caption.bold())
                    .frame(minWidth: 22, minHeight: 22)
                    .overlay(RoundedRectangle(cornerRadius: 6).stroke(lineWidth: 2))
                    .foregroundStyle(browser.isPrivate ? Color.purple : Color.accentColor)
            }
            Spacer()
            Menu {
                Toggle("Chặn quảng cáo", isOn: $settings.adBlock)
                Toggle("Chặn popup / tự mở tab", isOn: $settings.popupBlock)
                Toggle("Tiết kiệm dữ liệu (mạng yếu)", isOn: $settings.dataSaver)
                Toggle("Xem bản máy tính", isOn: Binding(
                    get: { browser.desktopMode },
                    set: { _ in browser.toggleDesktop() }
                ))
                Divider()
                Button { browser.findInPage() } label: {
                    Label("Tìm trong trang", systemImage: "text.magnifyingglass")
                }
                if let u = browser.currentURL {
                    ShareLink(item: u) {
                        Label("Chia sẻ", systemImage: "square.and.arrow.up")
                    }
                }
                Button {
                    if let u = browser.currentURL { library.toggleBookmark(url: u, title: browser.pageTitle) }
                } label: {
                    let marked = browser.currentURL.map { library.isBookmarked($0.absoluteString) } ?? false
                    Label(marked ? "Bỏ dấu trang" : "Thêm dấu trang",
                          systemImage: marked ? "star.slash" : "star")
                }
                .disabled(browser.currentURL == nil)
                Button { showLibrary = true } label: {
                    Label("Dấu trang & Lịch sử", systemImage: "book")
                }
                Button { showSettings = true } label: {
                    Label("Cài đặt", systemImage: "gearshape")
                }
                Button { showDownloads = true } label: {
                    Label("Tải xuống", systemImage: "arrow.down.circle")
                }
            } label: {
                Image(systemName: settings.adBlock ? "shield.lefthalf.filled" : "shield.slash")
            }
            Spacer()
            Button { showExt = true } label: { Image(systemName: "puzzlepiece.extension") }
        }
        .font(.title3)
        .padding(.horizontal, 24)
        .padding(.vertical, 10)
        .background(.bar)
    }
}

struct WebViewContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Cài đặt

struct SettingsView: View {
    @ObservedObject private var settings = BrowserSettings.shared
    @Environment(\.dismiss) private var dismiss
    @State private var message = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Tìm kiếm") {
                    Picker("Công cụ tìm kiếm", selection: $settings.searchEngine) {
                        Text("Google").tag("google")
                        Text("DuckDuckGo").tag("duckduckgo")
                        Text("Bing").tag("bing")
                    }
                }
                Section("Trang chủ") {
                    TextField("https://www.google.com", text: $settings.homepage)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section("Dữ liệu duyệt web") {
                    Button("Xoá lịch sử", role: .destructive) {
                        LibraryStore.shared.clearHistory()
                        message = "Đã xoá lịch sử"
                    }
                    Button("Xoá cookie và bộ nhớ đệm", role: .destructive) {
                        Task {
                            await WKWebsiteDataStore.default().removeData(
                                ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                                modifiedSince: .distantPast)
                            message = "Đã xoá cookie và bộ nhớ đệm (bạn sẽ bị đăng xuất khỏi các trang)"
                        }
                    }
                    if !message.isEmpty {
                        Text(message).font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Dấu trang & Lịch sử

struct LibraryView: View {
    @ObservedObject private var lib = LibraryStore.shared
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var tab = 0
    @State private var query = ""
    @State private var confirmClear = false

    private var shown: [SavedPage] {
        let src = tab == 0 ? lib.bookmarks : lib.history
        if query.isEmpty { return src }
        return src.filter {
            $0.title.localizedCaseInsensitiveContains(query) ||
            $0.url.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("", selection: $tab) {
                    Text("Dấu trang").tag(0)
                    Text("Lịch sử").tag(1)
                }
                .pickerStyle(.segmented)
                .padding()

                List {
                    if shown.isEmpty {
                        Text(tab == 0 ? "Chưa có dấu trang" : "Chưa có lịch sử")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(shown) { p in
                        Button {
                            browser.go(p.url)
                            dismiss()
                        } label: {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(p.title).font(.headline).lineLimit(1)
                                Text(p.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                if tab == 1 {
                                    Text(p.date.formatted(date: .abbreviated, time: .shortened))
                                        .font(.caption2)
                                        .foregroundStyle(.tertiary)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                    .onDelete { offsets in
                        let ids = offsets.map { shown[$0].id }
                        for id in ids {
                            if tab == 0 { lib.removeBookmark(id) } else { lib.removeHistory(id) }
                        }
                    }
                }
            }
            .searchable(text: $query)
            .navigationTitle(tab == 0 ? "Dấu trang" : "Lịch sử")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    if tab == 1 && !lib.history.isEmpty {
                        Button("Xoá hết", role: .destructive) { confirmClear = true }
                    }
                }
            }
            .confirmationDialog("Xoá toàn bộ lịch sử?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Xoá hết", role: .destructive) { lib.clearHistory() }
            }
        }
    }
}

// MARK: - Tải xuống

struct DownloadsView: View {
    @ObservedObject private var dl = DownloadManager.shared
    @EnvironmentObject var manager: ExtensionManager
    @Environment(\.dismiss) private var dismiss

    private func installable(_ u: URL) -> Bool {
        ["crx", "xpi", "zip", "js"].contains(u.pathExtension.lowercased())
    }

    private func sizeText(_ u: URL?) -> String {
        guard let u = u,
              let n = (try? u.resourceValues(forKeys: [.fileSizeKey]))?.fileSize else { return "" }
        return ByteCountFormatter.string(fromByteCount: Int64(n), countStyle: .file)
    }

    var body: some View {
        NavigationStack {
            List {
                if dl.items.isEmpty {
                    Text("Chưa có file nào").foregroundStyle(.secondary)
                }
                ForEach(dl.items) { item in
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.name).font(.headline).lineLimit(2)
                            if item.state == .running {
                                ProgressView(value: item.progress)
                            } else if item.state == .failed {
                                Text("Tải thất bại").font(.caption).foregroundStyle(.red)
                            } else {
                                Text(sizeText(item.fileURL)).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        if item.state == .done, let u = item.fileURL {
                            if installable(u) {
                                Button("Cài") { manager.importFile(u) }
                                    .buttonStyle(.borderless)
                            }
                            ShareLink(item: u) { Image(systemName: "square.and.arrow.up") }
                                .buttonStyle(.borderless)
                        }
                    }
                }
                .onDelete { offsets in
                    let ids = offsets.map { dl.items[$0].id }
                    ids.forEach { dl.remove($0) }
                }
            }
            .navigationTitle("Tải xuống")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Danh sách tab

struct TabsView: View {
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                ForEach(browser.tabs) { tab in
                    TabRow(tab: tab,
                           active: tab.id == browser.activeID,
                           select: { browser.select(tab.id); dismiss() },
                           close: { browser.close(tab.id) })
                }
            }
            .navigationTitle("Tab (\(browser.tabs.count))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        Button { browser.newTab(); dismiss() } label: {
                            Label("Tab mới", systemImage: "plus")
                        }
                        Button { browser.newPrivateTab(); dismiss() } label: {
                            Label("Tab riêng tư", systemImage: "eyeglasses")
                        }
                    } label: { Image(systemName: "plus") }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }
}

struct TabRow: View {
    @ObservedObject var tab: Tab
    let active: Bool
    let select: () -> Void
    let close: () -> Void

    var body: some View {
        HStack {
            Button(action: select) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(tab.title.isEmpty ? (tab.url?.host ?? "Tab mới") : tab.title)
                        .font(.headline)
                        .lineLimit(1)
                    Text(tab.url?.host ?? "")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            .buttonStyle(.plain)
            Spacer()
            if tab.isPrivate { Image(systemName: "eyeglasses").foregroundStyle(.purple) }
            if active { Image(systemName: "checkmark").foregroundStyle(.tint) }
            Button(action: close) { Image(systemName: "xmark") }
                .buttonStyle(.borderless)
        }
    }
}

// MARK: - Extension list

struct ExtPage: Identifiable {
    let id = UUID()
    let extId: String
    let path: String
    let tabURL: String
    let title: String
}

struct ExtensionsView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var link = ""
    @State private var importing = false
    @State private var page: ExtPage?
    @State private var logFor: InstalledExtension?

    var body: some View {
        NavigationStack {
            List {
                Section("Thêm extension") {
                    HStack {
                        TextField("Dán link store, .user.js hoặc .zip", text: $link)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .keyboardType(.URL)
                        Button("Cài") {
                            let l = link
                            link = ""
                            Task { await manager.installFromLink(l) }
                        }
                        .buttonStyle(.borderless)
                        .disabled(link.isEmpty || manager.busy)
                    }
                    Button("Chọn file (.zip .crx .xpi .js)") { importing = true }
                    Text("Hoặc mở trang extension trên Chrome Web Store / Firefox Add-ons rồi bấm nút “Thêm vào app”.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Đã cài (\(manager.items.count))") {
                    if manager.items.isEmpty {
                        Text("Chưa có extension nào").foregroundStyle(.secondary)
                    }
                    ForEach(manager.items) { item in
                        row(item)
                    }
                    .onDelete { offsets in
                        let ids = offsets.map { manager.items[$0].id }
                        ids.forEach { manager.remove($0) }
                    }
                }
            }
            .navigationTitle("Extension")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.item]) { result in
                if case .success(let u) = result { manager.importFile(u) }
            }
            .sheet(item: $logFor) { it in
                ExtLogView(extId: it.id, title: it.name)
            }
            .sheet(item: $page) { p in
                NavigationStack {
                    ExtPageView(page: p)
                        .navigationTitle(p.title)
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }

    @ViewBuilder
    private func row(_ item: InstalledExtension) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name).font(.headline)
                Text("v\(item.version) · \(item.source)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if manager.store.backgroundEntry(id: item.id) != nil {
                Button {
                    logFor = item
                } label: {
                    Image(systemName: "doc.text")
                }
                .buttonStyle(.borderless)
            }
            if let p = manager.store.popupPath(id: item.id) {
                Button {
                    page = ExtPage(extId: item.id, path: p,
                                   tabURL: browser.currentURL?.absoluteString ?? "",
                                   title: item.name)
                } label: {
                    Image(systemName: "rectangle.on.rectangle")
                }
                .buttonStyle(.borderless)
            }
            if let o = manager.store.optionsPath(id: item.id) {
                Button {
                    page = ExtPage(extId: item.id, path: o,
                                   tabURL: browser.currentURL?.absoluteString ?? "",
                                   title: item.name)
                } label: {
                    Image(systemName: "gearshape")
                }
                .buttonStyle(.borderless)
            }
            Toggle("", isOn: Binding(
                get: { item.enabled },
                set: { manager.setEnabled(item.id, $0) }
            ))
            .labelsHidden()
        }
    }
}

// MARK: - Popup / options page of an extension

struct ExtPageView: UIViewRepresentable {
    let page: ExtPage

    final class Coordinator {
        let scheme = ExtSchemeHandler(store: ExtStore.shared)
        let bridge = ExtBridge(store: ExtStore.shared)
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(context.coordinator.scheme, forURLScheme: "ext")
        cfg.userContentController.addScriptMessageHandler(context.coordinator.bridge,
                                                          contentWorld: .page,
                                                          name: "extBridge")
        let src = ScriptBuilder.context(id: page.extId, store: ExtStore.shared, tabURL: page.tabURL, role: "page")
        cfg.userContentController.addUserScript(
            WKUserScript(source: src, injectionTime: .atDocumentStart,
                         forMainFrameOnly: true, in: .page))
        let w = WKWebView(frame: .zero, configuration: cfg)
        if let u = URL(string: "ext://\(page.extId)/\(page.path)") {
            w.load(URLRequest(url: u))
        }
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Nhật ký của trang nền

struct ExtLogView: View {
    let extId: String
    let title: String
    @State private var text = ""

    var body: some View {
        NavigationStack {
            ScrollView {
                Text(text.isEmpty ? "Chưa có log" : text)
                    .font(.system(size: 11, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .textSelection(.enabled)
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Làm mới") { text = ExtRuntime.shared.logText(extId) }
                }
            }
            .onAppear { text = ExtRuntime.shared.logText(extId) }
        }
    }
}
