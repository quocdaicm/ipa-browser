import SwiftUI
import WebKit

// MARK: - Trang nền (background) ẩn của từng extension

@MainActor
final class BackgroundHost: NSObject, WKNavigationDelegate {
    let extId: String
    let webView: WKWebView
    private let scheme: ExtSchemeHandler
    private let bridge: ExtBridge
    private(set) var loaded = false
    private var attachTries = 0

    init(extId: String, entry: String) {
        self.extId = extId
        let store = ExtStore.shared
        let sch = ExtSchemeHandler(store: store)
        let br = ExtBridge(store: store)
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(sch, forURLScheme: "ext")
        let ucc = cfg.userContentController
        ucc.addScriptMessageHandler(br, contentWorld: .page, name: "extBridge")
        let src = ScriptBuilder.context(id: extId, store: store, tabURL: nil, role: "background")
        ucc.addUserScript(WKUserScript(source: src, injectionTime: .atDocumentStart,
                                       forMainFrameOnly: true, in: .page))
        self.scheme = sch
        self.bridge = br
        self.webView = WKWebView(frame: CGRect(x: 0, y: 0, width: 2, height: 2), configuration: cfg)
        super.init()
        webView.navigationDelegate = self
        if let u = URL(string: "ext://\(extId)/\(entry)") {
            webView.load(URLRequest(url: u))
        }
        attach()
    }

    /// Gắn WebView vào cửa sổ (ẩn) để iOS không làm chậm timer của nó.
    func attach() {
        guard webView.superview == nil, attachTries < 20 else { return }
        attachTries += 1
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        if let win = scene?.windows.first(where: { $0.isKeyWindow }) ?? scene?.windows.first {
            webView.alpha = 0.01
            webView.isUserInteractionEnabled = false
            win.insertSubview(webView, at: 0)
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
                self?.attach()
            }
        }
    }

    func teardown() {
        webView.stopLoading()
        webView.configuration.userContentController.removeAllUserScripts()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "extBridge", contentWorld: .page)
        webView.removeFromSuperview()
    }

    func waitLoaded() async {
        var n = 0
        while !loaded && n < 80 {
            try? await Task.sleep(nanoseconds: 100_000_000)
            n += 1
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        loaded = true
        Task { @MainActor in await ExtRuntime.shared.backgroundReady(extId) }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        loaded = true
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        loaded = true
        ExtRuntime.shared.appendLog(extId, "Không tải được trang nền: \(error.localizedDescription)")
    }
}

// MARK: - Điều phối chung

@MainActor
final class ExtRuntime {
    static let shared = ExtRuntime()

    weak var browser: BrowserModel?
    var notify: ((String) -> Void)?
    var onOpenPage: ((ExtPage) -> Void)?

    private let store = ExtStore.shared
    private var hosts: [String: BackgroundHost] = [:]
    private var revs: [String: Int] = [:]
    private var logs: [String: [String]] = [:]
    private var downloadCounter = 0

    private init() {}

    // MARK: Logs

    func appendLog(_ id: String, _ line: String) {
        var l = logs[id] ?? []
        l.append(line)
        if l.count > 200 { l.removeFirst(l.count - 200) }
        logs[id] = l
    }

    func logText(_ id: String) -> String {
        (logs[id] ?? []).joined(separator: "\n")
    }

    // MARK: Background hosts

    func sync(_ items: [InstalledExtension]) {
        var wanted: [String: InstalledExtension] = [:]
        for i in items where i.enabled && store.backgroundEntry(id: i.id) != nil {
            wanted[i.id] = i
        }
        for id in Array(hosts.keys) {
            if let w = wanted[id], revs[id] == (w.rev ?? 0) { continue }
            hosts[id]?.teardown()
            hosts[id] = nil
            revs[id] = nil
        }
        for (id, item) in wanted where hosts[id] == nil {
            guard let entry = store.backgroundEntry(id: id) else { continue }
            hosts[id] = BackgroundHost(extId: id, entry: entry)
            revs[id] = item.rev ?? 0
        }
    }

    func backgroundReady(_ id: String) async {
        let first = store.consumeFirstRun(id)
        if first {
            _ = await toBackground(id, kind: "installed", payload: ["reason": "install"])
        }
        _ = await toBackground(id, kind: "startup", payload: [:])
    }

    // MARK: Gửi sự kiện vào JS

    private static let recvBody = "return await window.__extRecv(k, JSON.parse(j));"

    private func jsonString(_ o: Any) -> String {
        guard JSONSerialization.isValidJSONObject(o),
              let d = try? JSONSerialization.data(withJSONObject: o),
              let s = String(data: d, encoding: .utf8) else { return "{}" }
        return s
    }

    private func evalJSON(_ web: WKWebView, body: String, args: [String: Any], world: WKContentWorld) async -> Any? {
        await withCheckedContinuation { (c: CheckedContinuation<Any?, Never>) in
            web.callAsyncJavaScript(body, arguments: args, in: nil, in: world) { result in
                switch result {
                case .success(let v):
                    if let s = v as? String,
                       let d = s.data(using: .utf8),
                       let o = try? JSONSerialization.jsonObject(with: d, options: [.fragmentsAllowed]) {
                        c.resume(returning: o)
                    } else {
                        c.resume(returning: nil)
                    }
                case .failure:
                    c.resume(returning: nil)
                }
            }
        }
    }

    func toBackground(_ id: String, kind: String, payload: [String: Any]) async -> Any? {
        guard let h = hosts[id] else { return nil }
        await h.waitLoaded()
        return await evalJSON(h.webView, body: Self.recvBody,
                              args: ["k": kind, "j": jsonString(payload)], world: .page)
    }

    func toContent(_ id: String, kind: String, payload: [String: Any]) async -> Any? {
        guard let b = browser else { return nil }
        return await evalJSON(b.webView, body: Self.recvBody,
                              args: ["k": kind, "j": jsonString(payload)],
                              world: WKContentWorld.world(name: id))
    }

    /// Sự kiện tải trang -> tabs.onUpdated / webNavigation cho mọi background.
    func pageEvent(status: String, url: URL?) {
        guard !hosts.isEmpty else { return }
        let u = url?.absoluteString ?? ""
        var tab = tabDict()
        tab["status"] = status
        tab["url"] = u
        let change: [String: Any] = ["status": status, "url": u]
        let nav: [String: Any] = ["tabId": 1, "frameId": 0, "url": u, "timeStamp": Date().timeIntervalSince1970 * 1000]
        for id in Array(hosts.keys) {
            Task {
                _ = await self.toBackground(id, kind: "tabUpdated", payload: ["tabId": 1, "changeInfo": change, "tab": tab])
                if status == "loading" {
                    _ = await self.toBackground(id, kind: "navBefore", payload: nav)
                } else {
                    _ = await self.toBackground(id, kind: "navCommitted", payload: nav)
                    _ = await self.toBackground(id, kind: "navDOM", payload: nav)
                    _ = await self.toBackground(id, kind: "navCompleted", payload: nav)
                }
            }
        }
    }

    private func notifyStorage(_ id: String, _ area: String, _ ch: [String: [String: Any]]) {
        guard !ch.isEmpty, ["local", "sync", "session", "managed"].contains(area) else { return }
        let pl: [String: Any] = ["area": area, "changes": ch]
        Task { _ = await self.toBackground(id, kind: "storageChanged", payload: pl) }
        Task { _ = await self.toContent(id, kind: "storageChanged", payload: pl) }
    }

    // MARK: Tab giả lập (trình duyệt chỉ có 1 tab)

    func tabDict() -> [String: Any] {
        var d: [String: Any] = [
            "id": 1, "index": 0, "windowId": 1, "active": true, "highlighted": true,
            "pinned": false, "incognito": false, "audible": false, "discarded": false,
            "autoDiscardable": true, "favIconUrl": ""
        ]
        d["status"] = (browser?.isLoading ?? false) ? "loading" : "complete"
        d["url"] = browser?.currentURL?.absoluteString ?? ""
        d["title"] = browser?.pageTitle ?? ""
        return d
    }

    // MARK: Xử lý message từ JS

    func handle(extId: String, type: String, payload p: [String: Any], role: String) async -> Any? {
        let area = p["area"] as? String ?? "local"
        switch type {

        // ---- storage
        case "storage.get":
            return store.storageGet(id: extId, area: area, keys: p["keys"])
        case "storage.set":
            let ch = store.storageSet(id: extId, area: area, items: p["items"] as? [String: Any] ?? [:])
            notifyStorage(extId, area, ch)
            return ch
        case "storage.remove":
            let ch = store.storageRemove(id: extId, area: area, keys: p["keys"] as? [String] ?? [])
            notifyStorage(extId, area, ch)
            return ch
        case "storage.clear":
            let ch = store.storageClear(id: extId, area: area)
            notifyStorage(extId, area, ch)
            return ch

        // ---- nhắn tin
        case "runtime.sendMessage":
            if role == "background" { return ["ok": false] }
            let pl: [String: Any] = ["message": p["message"] ?? NSNull(), "sender": p["sender"] ?? [String: Any]()]
            return await toBackground(extId, kind: "message", payload: pl)
        case "tabs.sendMessage":
            let sender: [String: Any] = ["id": extId, "url": "ext://\(extId)/"]
            let pl: [String: Any] = ["message": p["message"] ?? NSNull(), "sender": sender]
            return await toContent(extId, kind: "message", payload: pl)
        case "port.connect", "port.post", "port.disconnect":
            let kinds = ["port.connect": "portConnect", "port.post": "portMessage", "port.disconnect": "portDisconnect"]
            let kind = kinds[type] ?? "portMessage"
            if (p["to"] as? String) == "tab" {
                _ = await toContent(extId, kind: kind, payload: p)
            } else {
                _ = await toBackground(extId, kind: kind, payload: p)
            }
            return nil

        // ---- tabs / windows
        case "tabs.query":
            if let a = p["active"] as? Bool, !a { return [[String: Any]]() }
            if let pat = p["url"] {
                let pats = (pat as? [String]) ?? ((pat as? String).map { [$0] } ?? [])
                let cur = browser?.currentURL?.absoluteString ?? ""
                let ok = pats.compactMap { MatchPattern.regexSource($0) }.contains {
                    (try? NSRegularExpression(pattern: $0))?.firstMatch(in: cur, range: NSRange(cur.startIndex..., in: cur)) != nil
                }
                if !pats.isEmpty && !ok { return [[String: Any]]() }
            }
            return [tabDict()]
        case "tabs.get":
            return tabDict()
        case "tabs.create", "tabs.update":
            if let u = p["url"] as? String { browser?.go(u) }
            return tabDict()
        case "tabs.reload":
            browser?.webView.reload()
            return nil
        case "tabs.goBack":
            browser?.webView.goBack()
            return nil
        case "tabs.goForward":
            browser?.webView.goForward()
            return nil
        case "tabs.capture":
            guard let w = browser?.webView else { return nil }
            return await withCheckedContinuation { (k: CheckedContinuation<Any?, Never>) in
                w.takeSnapshot(with: nil) { img, _ in
                    if let d = img?.jpegData(compressionQuality: 0.8) {
                        k.resume(returning: "data:image/jpeg;base64," + d.base64EncodedString())
                    } else {
                        k.resume(returning: nil)
                    }
                }
            }
        case "openOptions":
            if let path = store.optionsPath(id: extId) {
                onOpenPage?(ExtPage(extId: extId, path: path,
                                    tabURL: browser?.currentURL?.absoluteString ?? "",
                                    title: store.manifest(id: extId)["name"] as? String ?? extId))
            }
            return nil

        // ---- chèn script / css vào trang
        case "exec":
            return await execScript(extId, p)
        case "css":
            return await insertCSS(extId, p)

        // ---- mạng
        case "fetch":
            return await nativeFetch(p)

        // ---- cookies
        case "cookies.getAll":
            return (await matchingCookies(p)).map { cookieDict($0) }
        case "cookies.get":
            if let c = (await matchingCookies(p)).first { return cookieDict(c) }
            return nil
        case "cookies.set":
            return await setCookie(p)
        case "cookies.remove":
            for c in await matchingCookies(p) { await deleteCookie(c) }
            return nil

        // ---- downloads
        case "downloads.download":
            return await download(p)

        // ---- declarativeNetRequest
        case "dnr.update":
            let key = p["key"] as? String ?? "dynamic"
            let remove = (p["remove"] as? [Any] ?? []).compactMap { ($0 as? NSNumber)?.intValue }
            let add = p["add"] as? [[String: Any]] ?? []
            let addIds = add.compactMap { ($0["id"] as? NSNumber)?.intValue }
            var rules = store.dnrRules(extId, key: key).filter {
                guard let rid = ($0["id"] as? NSNumber)?.intValue else { return true }
                return !remove.contains(rid) && !addIds.contains(rid)
            }
            rules += add
            store.dnrSetRules(extId, key: key, rules: rules)
            await browser?.rebuildRules()
            return nil
        case "dnr.get":
            return store.dnrRules(extId, key: p["key"] as? String ?? "dynamic")
        case "dnr.rulesets":
            var cur = enabledRulesets(extId)
            for d in p["disable"] as? [String] ?? [] { cur.removeAll { $0 == d } }
            for e in p["enable"] as? [String] ?? [] where !cur.contains(e) { cur.append(e) }
            store.dnrSetEnabled(extId, cur)
            await browser?.rebuildRules()
            return nil
        case "dnr.enabled":
            return enabledRulesets(extId)

        // ---- log
        case "log":
            let lv = p["level"] as? String ?? "log"
            appendLog(extId, "[\(lv)] " + (p["text"] as? String ?? ""))
            return nil

        default:
            return nil
        }
    }

    private func enabledRulesets(_ id: String) -> [String] {
        if let o = store.dnrEnabledOverride(id) { return o }
        let dnr = store.manifest(id: id)["declarative_net_request"] as? [String: Any]
        let res = dnr?["rule_resources"] as? [[String: Any]] ?? []
        return res.compactMap { r in
            ((r["enabled"] as? Bool) ?? false) ? (r["id"] as? String) : nil
        }
    }

    // MARK: exec / css

    private func world(for extId: String, _ p: [String: Any]) -> WKContentWorld {
        ((p["world"] as? String) ?? "").uppercased() == "MAIN" ? .page : WKContentWorld.world(name: extId)
    }

    private func execScript(_ extId: String, _ p: [String: Any]) async -> Any? {
        guard let web = browser?.webView else { return [[String: Any]]() }
        let w = world(for: extId, p)
        if let call = p["call"] as? String {
            let body = "var __r = await (\(call)); return JSON.stringify({r: __r === undefined ? null : __r});"
            let r = await evalJSON(web, body: body, args: [:], world: w)
            guard let o = r as? [String: Any] else { return [[String: Any]]() }
            let item: [String: Any] = ["frameId": 0, "result": o["r"] ?? NSNull()]
            return [item]
        }
        var sources: [String] = []
        if let s = p["source"] as? String { sources.append(s) }
        for f in p["files"] as? [String] ?? [] {
            if let t = store.readText(id: extId, path: f) { sources.append(t) }
        }
        var last: Any = NSNull()
        for src in sources {
            let v: Any? = await withCheckedContinuation { (c: CheckedContinuation<Any?, Never>) in
                web.evaluateJavaScript(src, in: nil, in: w) { result in
                    if case .success(let v) = result { c.resume(returning: v) } else { c.resume(returning: nil) }
                }
            }
            if let v = v, JSONSerialization.isValidJSONObject([v]) { last = v }
        }
        let item: [String: Any] = ["frameId": 0, "result": last]
        return [item]
    }

    private func insertCSS(_ extId: String, _ p: [String: Any]) async -> Any? {
        guard let web = browser?.webView else { return nil }
        var css = p["css"] as? String ?? ""
        for f in p["files"] as? [String] ?? [] {
            if let t = store.readText(id: extId, path: f) { css += "\n" + t }
        }
        if css.isEmpty { return nil }
        let src = "(function(t){var s=document.createElement('style');s.textContent=t;(document.head||document.documentElement).appendChild(s);})(\(ScriptBuilder.js(css)));"
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            web.evaluateJavaScript(src, in: nil, in: WKContentWorld.world(name: extId)) { _ in c.resume() }
        }
        return nil
    }

    // MARK: Mạng

    private func nativeFetch(_ p: [String: Any]) async -> [String: Any] {
        guard let s = p["url"] as? String, let url = URL(string: s) else { return ["error": "bad url"] }
        var req = URLRequest(url: url)
        req.httpMethod = (p["method"] as? String) ?? "GET"
        for (k, v) in (p["headers"] as? [String: Any] ?? [:]) { req.setValue("\(v)", forHTTPHeaderField: k) }
        if let b = p["body"] as? String { req.httpBody = Data(b.utf8) }
        req.httpShouldHandleCookies = false
        if req.value(forHTTPHeaderField: "Cookie") == nil {
            let mine = (await allCookies()).filter { cookieMatches($0, url: url) }
            if !mine.isEmpty {
                req.setValue(mine.map { "\($0.name)=\($0.value)" }.joined(separator: "; "), forHTTPHeaderField: "Cookie")
            }
        }
        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            let h = resp as? HTTPURLResponse
            var headers: [String: String] = [:]
            for (k, v) in h?.allHeaderFields ?? [:] { headers["\(k)"] = "\(v)" }
            return [
                "status": h?.statusCode ?? 200,
                "statusText": "",
                "headers": headers,
                "b64": data.base64EncodedString(),
                "url": resp.url?.absoluteString ?? s
            ]
        } catch {
            return ["error": error.localizedDescription]
        }
    }

    // MARK: Cookies

    private func allCookies() async -> [HTTPCookie] {
        await withCheckedContinuation { (c: CheckedContinuation<[HTTPCookie], Never>) in
            WKWebsiteDataStore.default().httpCookieStore.getAllCookies { c.resume(returning: $0) }
        }
    }

    private func cookieMatches(_ ck: HTTPCookie, url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        var d = ck.domain.lowercased()
        if d.hasPrefix(".") {
            d.removeFirst()
            if !(host == d || host.hasSuffix("." + d)) { return false }
        } else if host != d {
            return false
        }
        let path = url.path.isEmpty ? "/" : url.path
        if !path.hasPrefix(ck.path) { return false }
        if ck.isSecure && url.scheme != "https" { return false }
        return true
    }

    private func matchingCookies(_ p: [String: Any]) async -> [HTTPCookie] {
        var list = await allCookies()
        if let s = p["url"] as? String, let u = URL(string: s) {
            list = list.filter { cookieMatches($0, url: u) }
        }
        if let n = p["name"] as? String { list = list.filter { $0.name == n } }
        if let pa = p["path"] as? String { list = list.filter { $0.path == pa } }
        if let sec = p["secure"] as? Bool { list = list.filter { $0.isSecure == sec } }
        if let ses = p["session"] as? Bool { list = list.filter { $0.isSessionOnly == ses } }
        if let dom = p["domain"] as? String {
            let d = dom.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
            list = list.filter { c in
                let cd = c.domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
                return cd == d || cd.hasSuffix("." + d)
            }
        }
        return list
    }

    private func cookieDict(_ c: HTTPCookie) -> [String: Any] {
        var d: [String: Any] = [
            "name": c.name, "value": c.value, "domain": c.domain,
            "hostOnly": !c.domain.hasPrefix("."), "path": c.path,
            "secure": c.isSecure, "httpOnly": c.isHTTPOnly,
            "sameSite": "unspecified", "session": c.isSessionOnly, "storeId": "0"
        ]
        if let e = c.expiresDate { d["expirationDate"] = e.timeIntervalSince1970 }
        return d
    }

    private func setCookie(_ p: [String: Any]) async -> Any? {
        guard let s = p["url"] as? String, let u = URL(string: s), let name = p["name"] as? String else { return nil }
        var props: [HTTPCookiePropertyKey: Any] = [
            .name: name,
            .value: (p["value"] as? String) ?? "",
            .path: (p["path"] as? String) ?? "/",
            .domain: (p["domain"] as? String) ?? (u.host ?? "")
        ]
        if (p["secure"] as? Bool) == true { props[.secure] = "TRUE" }
        if (p["httpOnly"] as? Bool) == true { props[HTTPCookiePropertyKey(rawValue: "HttpOnly")] = "TRUE" }
        if let e = p["expirationDate"] as? Double { props[.expires] = Date(timeIntervalSince1970: e) }
        guard let ck = HTTPCookie(properties: props) else { return nil }
        await withCheckedContinuation { (k: CheckedContinuation<Void, Never>) in
            WKWebsiteDataStore.default().httpCookieStore.setCookie(ck) { k.resume() }
        }
        return cookieDict(ck)
    }

    private func deleteCookie(_ c: HTTPCookie) async {
        await withCheckedContinuation { (k: CheckedContinuation<Void, Never>) in
            WKWebsiteDataStore.default().httpCookieStore.delete(c) { k.resume() }
        }
    }

    // MARK: Downloads

    private func download(_ p: [String: Any]) async -> Any? {
        guard let s = p["url"] as? String, let u = URL(string: s) else { return nil }
        do {
            let (tmp, resp) = try await URLSession.shared.download(from: u)
            let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            var name = (p["filename"] as? String).map { ($0 as NSString).lastPathComponent }
                ?? resp.suggestedFilename ?? u.lastPathComponent
            if name.isEmpty { name = "download" }
            var dest = docs.appendingPathComponent(name)
            var n = 1
            while FileManager.default.fileExists(atPath: dest.path) {
                dest = docs.appendingPathComponent("\(n)-" + name)
                n += 1
            }
            try FileManager.default.moveItem(at: tmp, to: dest)
            downloadCounter += 1
            notify?("Đã tải: \(dest.lastPathComponent)")
            return downloadCounter
        } catch {
            notify?("Tải lỗi: \(error.localizedDescription)")
            return nil
        }
    }
}
