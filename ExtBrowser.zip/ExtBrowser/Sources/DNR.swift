import Foundation
import WebKit

/// Đổi luật declarativeNetRequest của Chrome sang WKContentRuleList (chặn quảng cáo kiểu uBlock Lite).
/// Hỗ trợ: block / allow / upgradeScheme / redirect->https. Chưa hỗ trợ: redirect khác, modifyHeaders.
enum DNR {
    struct Box: @unchecked Sendable {
        let v: [[String: Any]]
    }

    // MARK: Đọc + đổi luật

    static func contentBlockerRules(extId: String, store: ExtStore) -> [[String: Any]] {
        var raw: [[String: Any]] = []
        let m = store.manifest(id: extId)
        let dnr = m["declarative_net_request"] as? [String: Any]
        let resources = dnr?["rule_resources"] as? [[String: Any]] ?? []
        let ovr = store.dnrEnabledOverride(extId)
        for r in resources {
            guard let rid = r["id"] as? String, let path = r["path"] as? String else { continue }
            let on: Bool
            if let o = ovr { on = o.contains(rid) } else { on = (r["enabled"] as? Bool) ?? false }
            guard on,
                  let d = store.readFile(id: extId, path: path),
                  let arr = (try? JSONSerialization.jsonObject(with: d)) as? [[String: Any]] else { continue }
            raw += arr
        }
        raw += store.dnrRules(extId, key: "dynamic")
        raw += store.dnrRules(extId, key: "session")
        return convert(raw)
    }

    private static func priority(_ r: [String: Any]) -> Int {
        (r["priority"] as? NSNumber)?.intValue ?? 1
    }

    private static func rank(_ r: [String: Any]) -> Int {
        let t = (r["action"] as? [String: Any])?["type"] as? String
        return (t == "allow" || t == "allowAllRequests") ? 1 : 0
    }

    static func convert(_ rules: [[String: Any]]) -> [[String: Any]] {
        let sorted = rules.sorted { a, b in
            let pa = priority(a), pb = priority(b)
            if pa != pb { return pa < pb }
            return rank(a) < rank(b)
        }
        var out: [[String: Any]] = []
        out.reserveCapacity(sorted.count)
        for r in sorted { out += convertOne(r) }
        return out
    }

    private static let allTypes = ["sub_frame", "stylesheet", "script", "image", "font", "object",
                                   "xmlhttprequest", "ping", "media", "websocket", "other"]

    private static func convertOne(_ r: [String: Any]) -> [[String: Any]] {
        guard let action = r["action"] as? [String: Any],
              let type = action["type"] as? String,
              let cond = r["condition"] as? [String: Any] else { return [] }

        let wkAction: [String: Any]
        var anyType = false
        switch type {
        case "block":
            wkAction = ["type": "block"]
        case "allow", "allowAllRequests":
            wkAction = ["type": "ignore-previous-rules"]
        case "upgradeScheme":
            wkAction = ["type": "make-https"]
            anyType = true
        case "redirect":
            guard let red = action["redirect"] as? [String: Any],
                  let tr = red["transform"] as? [String: Any],
                  (tr["scheme"] as? String) == "https", tr.count == 1 else { return [] }
            wkAction = ["type": "make-https"]
            anyType = true
        default:
            return []
        }

        // url-filter
        var filters: [String] = []
        if let f = cond["urlFilter"] as? String, !f.isEmpty {
            filters = [urlFilterRegex(f)]
        } else if let rx = cond["regexFilter"] as? String, !rx.isEmpty {
            if let x = regexFilter(rx) { filters = [x] } else { return [] }
        } else if let hosts = cond["requestDomains"] as? [String], !hosts.isEmpty {
            filters = hosts.map { "^[a-z][a-z0-9+.-]*://([^/?#]*\\.)?" + escapeRegex($0.lowercased()) + "[/:?]" }
        } else {
            filters = [".*"]
        }
        filters = filters.filter { $0.allSatisfy { $0.isASCII } }
        if filters.isEmpty { return [] }

        var base: [String: Any] = [:]
        if (cond["isUrlFilterCaseSensitive"] as? Bool) == true { base["url-filter-is-case-sensitive"] = true }

        let inc = ((cond["initiatorDomains"] ?? cond["domains"]) as? [String]) ?? []
        let exc = ((cond["excludedInitiatorDomains"] ?? cond["excludedDomains"]) as? [String]) ?? []
        if !inc.isEmpty {
            base["if-domain"] = inc.map { "*" + $0.lowercased() }
        } else if !exc.isEmpty {
            base["unless-domain"] = exc.map { "*" + $0.lowercased() }
        }
        if let dt = cond["domainType"] as? String {
            base["load-type"] = [dt == "thirdParty" ? "third-party" : "first-party"]
        }

        // resource-type
        var variants: [[String: Any]] = []
        let hasTypes = cond["resourceTypes"] != nil || cond["excludedResourceTypes"] != nil
        if anyType && !hasTypes {
            variants = [base]
        } else {
            var types: Set<String>
            if let t = cond["resourceTypes"] as? [String] { types = Set(t) } else { types = Set(allTypes) }
            for e in (cond["excludedResourceTypes"] as? [String]) ?? [] { types.remove(e) }
            if types.isEmpty { return [] }

            var plain = Set<String>()
            var top = false, child = false
            for t in types {
                switch t {
                case "main_frame": top = true
                case "sub_frame": child = true
                case "stylesheet": plain.insert("style-sheet")
                case "script": plain.insert("script")
                case "image": plain.insert("image")
                case "font": plain.insert("font")
                case "object", "media": plain.insert("media")
                case "xmlhttprequest": plain.insert("fetch"); plain.insert("raw")
                case "ping": plain.insert("ping")
                case "websocket": plain.insert("websocket")
                case "other": plain.insert("other")
                default: break
                }
            }
            if !plain.isEmpty {
                var v = base
                v["resource-type"] = plain.sorted()
                variants.append(v)
            }
            if top && child {
                var v = base
                v["resource-type"] = ["document"]
                variants.append(v)
            } else if top {
                var v = base
                v["resource-type"] = ["document"]
                v["load-context"] = ["top-frame"]
                variants.append(v)
            } else if child {
                var v = base
                v["resource-type"] = ["document"]
                v["load-context"] = ["child-frame"]
                variants.append(v)
            }
        }

        var out: [[String: Any]] = []
        for f in filters {
            for v in variants {
                var trig = v
                trig["url-filter"] = f
                out.append(["trigger": trig, "action": wkAction])
            }
        }
        return out
    }

    // MARK: Regex helpers

    private static func escapeRegex(_ s: String) -> String {
        var o = ""
        for c in s {
            if ".+?()[]{}\\|$^*".contains(c) { o.append("\\") }
            o.append(c)
        }
        return o
    }

    /// Cú pháp urlFilter của DNR (*, ^, |, ||) -> regex của WebKit.
    static func urlFilterRegex(_ f: String) -> String {
        var s = f
        var out = ""
        if s.hasPrefix("||") {
            s.removeFirst(2)
            out = "^[a-z][a-z0-9+.-]*://([^/?#]*\\.)?"
        } else if s.hasPrefix("|") {
            s.removeFirst()
            out = "^"
        }
        var endAnchor = false
        if s.hasSuffix("|") {
            s.removeLast()
            endAnchor = true
        }
        let chars = Array(s)
        for (i, c) in chars.enumerated() {
            switch c {
            case "*":
                out += ".*"
            case "^":
                out += (i == chars.count - 1) ? "[/:?]" : "[/:?&=;,#]"
            case ".", "+", "?", "(", ")", "[", "]", "{", "}", "\\", "|", "$":
                out += "\\" + String(c)
            default:
                out.append(c)
            }
        }
        if endAnchor { out += "$" }
        return out.isEmpty ? ".*" : out
    }

    private static func regexFilter(_ rx: String) -> String? {
        var s = rx
        s = s.replacingOccurrences(of: "\\d", with: "[0-9]")
        s = s.replacingOccurrences(of: "\\w", with: "[a-zA-Z0-9_]")
        s = s.replacingOccurrences(of: "(?:", with: "(")
        if s.contains("|") || s.contains("{") || s.contains("(?") || s.contains("\\b") { return nil }
        return s
    }

    // MARK: Biên dịch WKContentRuleList

    @MainActor
    static func lists(for items: [InstalledExtension], store: ExtStore) async -> [WKContentRuleList] {
        var out: [WKContentRuleList] = []
        var keep = Set<String>()
        for item in items where item.enabled && store.hasDNR(item.id) {
            let key = "ext-\(item.id)-\(item.rev ?? 0)-\(store.dnrVersion(item.id))"
            let defaultsKey = "dnr.\(key)"
            if let ids = UserDefaults.standard.stringArray(forKey: defaultsKey),
               let found = await lookup(ids) {
                out += found
                ids.forEach { keep.insert($0) }
                continue
            }
            let id = item.id
            let box = await Task.detached(priority: .userInitiated) {
                Box(v: DNR.contentBlockerRules(extId: id, store: store))
            }.value
            var ids: [String] = []
            var start = 0
            var chunk = 0
            while start < box.v.count {
                let end = min(start + 100_000, box.v.count)
                let part = Array(box.v[start..<end])
                let compiled = await compileRobust(base: "\(key)-c\(chunk)", rules: part)
                for (cid, l) in compiled {
                    ids.append(cid)
                    out.append(l)
                }
                start = end
                chunk += 1
            }
            UserDefaults.standard.set(ids, forKey: defaultsKey)
            ids.forEach { keep.insert($0) }
        }
        cleanup(keep: keep)
        return out
    }

    @MainActor
    private static func lookup(_ ids: [String]) async -> [WKContentRuleList]? {
        var out: [WKContentRuleList] = []
        for id in ids {
            let l: WKContentRuleList? = await withCheckedContinuation { (c: CheckedContinuation<WKContentRuleList?, Never>) in
                guard let store = WKContentRuleListStore.default() else { c.resume(returning: nil); return }
                store.lookUpContentRuleList(forIdentifier: id) { list, _ in
                    c.resume(returning: list)
                }
            }
            guard let l = l else { return nil }
            out.append(l)
        }
        return out
    }

    @MainActor
    private static func compile(id: String, rules: [[String: Any]]) async -> WKContentRuleList? {
        guard !rules.isEmpty,
              JSONSerialization.isValidJSONObject(rules),
              let data = try? JSONSerialization.data(withJSONObject: rules),
              let json = String(data: data, encoding: .utf8) else { return nil }
        return await withCheckedContinuation { (c: CheckedContinuation<WKContentRuleList?, Never>) in
            guard let store = WKContentRuleListStore.default() else { c.resume(returning: nil); return }
            store.compileContentRuleList(forIdentifier: id, encodedContentRuleList: json) { list, _ in
                c.resume(returning: list)
            }
        }
    }

    /// Nếu cả danh sách lỗi (do 1 luật không hợp lệ) thì chia đôi để loại luật lỗi.
    @MainActor
    private static func compileRobust(base: String, rules: [[String: Any]]) async -> [(String, WKContentRuleList)] {
        if rules.isEmpty { return [] }
        if let l = await compile(id: base, rules: rules) { return [(base, l)] }
        if rules.count == 1 { return [] }
        let mid = rules.count / 2
        let a = await compileRobust(base: base + "a", rules: Array(rules[..<mid]))
        let b = await compileRobust(base: base + "b", rules: Array(rules[mid...]))
        return a + b
    }

    @MainActor
    private static func cleanup(keep: Set<String>) {
        guard let s = WKContentRuleListStore.default() else { return }
        s.getAvailableContentRuleListIdentifiers { ids in
            for id in ids ?? [] where id.hasPrefix("ext-") && !keep.contains(id) {
                s.removeContentRuleList(forIdentifier: id) { _ in }
            }
        }
    }
}
