import AVFoundation
import Foundation
import SwiftUI
import WebKit
import Network

// MARK: - Cài đặt trình duyệt

@MainActor
final class BrowserSettings: ObservableObject {
    static let shared = BrowserSettings()

    @Published var adBlock: Bool { didSet { UserDefaults.standard.set(adBlock, forKey: "set.adblock") } }
    @Published var popupBlock: Bool { didSet { UserDefaults.standard.set(popupBlock, forKey: "set.popup") } }
    /// Các trang được tắt chặn quảng cáo riêng (lưu theo tên miền gốc).
    @Published var adAllowSites: Set<String> { didSet { UserDefaults.standard.set(Array(adAllowSites).sorted(), forKey: "set.adallow") } }
    @Published var dataSaver: Bool { didSet { UserDefaults.standard.set(dataSaver, forKey: "set.saver") } }
    /// Máy đang bật Chế độ dữ liệu thấp (Low Data Mode) hoặc mạng bị hạn chế.
    @Published var searchEngine: String { didSet { UserDefaults.standard.set(searchEngine, forKey: "set.engine") } }
    /// Dùng trang chủ Cà Mau dựng sẵn (tắt thì dùng địa chỉ trang chủ bên dưới).
    @Published var caMauHome: Bool { didSet { UserDefaults.standard.set(caMauHome, forKey: "set.camauhome") } }
    @Published var homepage: String { didSet { UserDefaults.standard.set(homepage, forKey: "set.home") } }
    /// Hỗ trợ game khi toàn màn hình (chặn zoom, chọn chữ, kéo trang...).
    @Published var gameHelper: Bool { didSet { UserDefaults.standard.set(gameHelper, forKey: "set.game") } }
    /// Tự xoay ngang khi vào toàn màn hình.
    /// Làm nét game: 0 tắt, 1 tắt làm mịn khi phóng canvas, 2 thêm ép devicePixelRatio = 3.
    @Published var sharp: Int { didSet { UserDefaults.standard.set(sharp, forKey: "set.sharp") } }
    /// Tiếp tục phát nhạc/video khi thoát app hoặc khoá màn hình.
    @Published var bgPlay: Bool { didSet { UserDefaults.standard.set(bgPlay, forKey: "set.bgplay"); applyAudioSession() } }
    /// Plugin “Xem video”: dò video trong trang và hiện nút tải.
    @Published var videoTool: Bool { didSet { UserDefaults.standard.set(videoTool, forKey: "set.video") } }
    /// Hiện nút tải nổi ở góc màn hình (tắt thì vẫn xem video qua Menu → Xem video).
    /// Chất lượng video tối đa khi phát HLS: 0 = tự động theo mạng, còn lại là chiều ngắn (360, 480, 720, 1080, 1440, 2160).
    @Published var videoQuality: Int { didSet { UserDefaults.standard.set(videoQuality, forKey: "set.vquality") } }
    @Published var videoFab: Bool { didSet { UserDefaults.standard.set(videoFab, forKey: "set.videofab") } }
    /// Nền tối cho mọi trang (đảo màu trang sáng).
    @Published var darkPages: Bool { didSet { UserDefaults.standard.set(darkPages, forKey: "set.dark") } }
    /// Giao diện app: 0 = theo hệ thống, 1 = sáng, 2 = tối. Chọn sáng/tối cũng đặt luôn nền web tương ứng.
    @Published var appearance: Int {
        didSet {
            UserDefaults.standard.set(appearance, forKey: "set.appearance")
            if appearance == 2, !darkPages { darkPages = true }
            if appearance == 1, darkPages { darkPages = false }
        }
    }
    /// Chủ đề màu: 0 = Lagoon, 1 = Cà Mau.
    @Published var palette: Int {
        didSet {
            UserDefaults.standard.set(palette, forKey: "set.palette")
            ThemePalette.current = palette
            AppAppearance.install()
        }
    }
    var colorScheme: ColorScheme? { appearance == 1 ? .light : appearance == 2 ? .dark : nil }
    /// Ngôn ngữ đích khi dịch trang.
    @Published var translateLang: String { didSet { UserDefaults.standard.set(translateLang, forKey: "set.tlang") } }
    /// Gợi ý dịch khi trang khác ngôn ngữ đích.
    @Published var translateOffer: Bool { didSet { UserDefaults.standard.set(translateOffer, forKey: "set.toffer") } }
    // Chế độ đọc: không dùng @Published để đổi cỡ chữ không làm dựng lại luật chặn.
    var readerSize: Int {
        get { UserDefaults.standard.object(forKey: "set.rsize") as? Int ?? 18 }
        set { UserDefaults.standard.set(newValue, forKey: "set.rsize") }
    }
    var readerTheme: String {
        get { UserDefaults.standard.string(forKey: "set.rtheme") ?? "light" }
        set { UserDefaults.standard.set(newValue, forKey: "set.rtheme") }
    }
    /// Cho phép chọn / sao chép chữ ở mọi trang (bỏ chặn của trang web).
    @Published var freeCopy: Bool { didSet { UserDefaults.standard.set(freeCopy, forKey: "set.freecopy") } }
    @Published var fsLandscape: Bool { didSet { UserDefaults.standard.set(fsLandscape, forKey: "set.fsland") } }
    /// Máy đang bật Chế độ dữ liệu thấp (Low Data Mode) hoặc mạng bị hạn chế.
    @Published private(set) var lowData = false

    var searchBase: String {
        switch searchEngine {
        case "duckduckgo": return "https://duckduckgo.com/"
        case "bing": return "https://www.bing.com/search"
        default: return "https://www.google.com/search"
        }
    }

    /// Địa chỉ trang chủ đã chuẩn hoá (rỗng -> Google).
    var homeURLString: String {
        let t = homepage.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return "https://www.google.com" }
        return t.contains("://") ? t : "https://" + t
    }

    var saverActive: Bool { dataSaver || lowData }

    /// Chặn quảng cáo có đang hoạt động trên trang (host) này không.
    func adBlockActive(for host: String?) -> Bool {
        guard adBlock else { return false }
        let key = BrowserModel.siteKey(host)
        return key.isEmpty || !adAllowSites.contains(key)
    }

    func setAdBlock(allowedOn host: String?, _ allowed: Bool) {
        let key = BrowserModel.siteKey(host)
        guard !key.isEmpty else { return }
        if allowed { adAllowSites.insert(key) } else { adAllowSites.remove(key) }
    }

    private let monitor = NWPathMonitor()

    private init() {
        let d = UserDefaults.standard
        adBlock = d.object(forKey: "set.adblock") as? Bool ?? true
        popupBlock = d.object(forKey: "set.popup") as? Bool ?? true
        adAllowSites = Set(d.stringArray(forKey: "set.adallow") ?? [])
        dataSaver = d.object(forKey: "set.saver") as? Bool ?? false
        searchEngine = d.string(forKey: "set.engine") ?? "google"
        homepage = d.string(forKey: "set.home") ?? "https://www.google.com"
        gameHelper = d.object(forKey: "set.game") as? Bool ?? true
        fsLandscape = d.object(forKey: "set.fsland") as? Bool ?? true
        sharp = d.object(forKey: "set.sharp") as? Int ?? 1
        bgPlay = d.object(forKey: "set.bgplay") as? Bool ?? true
        videoTool = d.object(forKey: "set.video") as? Bool ?? true
        videoFab = d.object(forKey: "set.videofab") as? Bool ?? true
        videoQuality = d.object(forKey: "set.vquality") as? Int ?? 0
        darkPages = d.object(forKey: "set.dark") as? Bool ?? false
        appearance = d.object(forKey: "set.appearance") as? Int ?? 0
        // Cà Mau là chủ đề mặc định; một lần duy nhất chuyển cả máy đã lưu Lagoon sang Cà Mau (vẫn đổi lại được trong Cài đặt).
        if !d.bool(forKey: "set.palette.camauDefault") {
            d.set(1, forKey: "set.palette")
            d.set(true, forKey: "set.palette.camauDefault")
        }
        let pal = d.object(forKey: "set.palette") as? Int ?? 1
        palette = pal
        ThemePalette.current = pal
        freeCopy = d.object(forKey: "set.freecopy") as? Bool ?? true
        caMauHome = d.object(forKey: "set.camauhome") as? Bool ?? true
        translateLang = d.string(forKey: "set.tlang") ?? "vi"
        translateOffer = d.object(forKey: "set.toffer") as? Bool ?? true
        monitor.pathUpdateHandler = { [weak self] p in
            let c = p.isConstrained
            Task { @MainActor in
                if let self = self, self.lowData != c { self.lowData = c }
            }
        }
        monitor.start(queue: DispatchQueue(label: "extbrowser.netmonitor"))
        applyAudioSession()
    }

    /// Category `playback` để âm thanh vẫn phát khi tắt màn hình / sang app khác (cần UIBackgroundModes = audio).
    func applyAudioSession() {
        let s = AVAudioSession.sharedInstance()
        if bgPlay {
            try? s.setCategory(.playback, mode: .moviePlayback, options: [])
        } else {
            try? s.setCategory(.soloAmbient, mode: .default, options: [])
        }
    }
}

// MARK: - Chặn quảng cáo

enum AdBlock {
    static let hosts: [String] = [
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "googletagservices.com",
        "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com",
        "popads.net", "popcash.net", "propellerads.com", "onclickads.net", "onclkds.com",
        "exoclick.com", "juicyads.com", "trafficjunky.com", "adsterra.com", "hilltopads.net",
        "clickadu.com", "mgid.com", "revcontent.com", "criteo.com", "criteo.net",
        "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
        "amazon-adsystem.com", "moatads.com", "adform.net", "smartadserver.com",
        "advertising.com", "yieldmo.com", "33across.com", "bidswitch.net", "contextweb.com",
        "lijit.com", "sharethrough.com", "teads.tv", "tapad.com", "adcolony.com",
        "admaven.com", "ad-maven.com", "a-ads.com", "adskeeper.com", "bidvertiser.com",
        "zedo.com", "cpmstar.com", "tsyndicate.com", "monetag.com", "adtima.vn",
        "eclick.vn", "adsplay.net", "scorecardresearch.com", "adsafeprotected.com",
        "serving-sys.com", "2mdn.net", "pagead2.googlesyndication.com",
        "adcash.com", "profitablegatecpm.com", "effectivegatecpm.com", "highperformanceformat.com",
        "highrevenuegate.com", "profitablecpmrate.com", "exosrv.com", "exdynsrv.com", "realsrv.com",
        "magsrv.com", "trafficstars.com", "ero-advertising.com", "adspyglass.com", "propellerclick.com",
        "inmobi.com", "applovin.com", "vungle.com", "chartboost.com", "supersonicads.com",
        "unityads.unity3d.com", "mopub.com", "smaato.net", "lentainform.com", "richaudience.com",
        "triplelift.com", "indexww.com", "gumgum.com", "spotxchange.com", "springserve.com",
        "adroll.com", "quantserve.com", "media.net", "zemanta.com", "adtechus.com", "247realmedia.com",
        "admicro.vn", "ambientplatform.vn", "plugrush.com", "clickadilla.com"
    ]

    /// Mẫu đường dẫn script/ảnh quảng cáo (mỗi mẫu một luật riêng, không dùng ký tự | vì WebKit không hỗ trợ).
    static let urlPatterns = [
        "popunder", "pop-under", "pop_under", "adsbygoogle", "show_ads", "adserver", "ad-server",
        "/pagead/", "/ads\\.js", "/ad\\.js", "/adv\\.js", "/popads"
    ]

    static let hideSelectors = [
        "ins.adsbygoogle", ".adsbygoogle", "[id^='google_ads_']", "[id^='div-gpt-ad']",
        "iframe[src*='doubleclick.net']", "iframe[src*='googlesyndication.com']",
        "[class*='ad-banner']", "[class*='ads-banner']", "[class*='popup-ad']",
        "[id*='ad-container']", "[class*='adsbox']", "a[href*='doubleclick.net']",
        "[id*='google_ads']", "[class*='ad-slot']", "[class*='adslot']", "[data-ad-slot]",
        "[data-ad-client]", ".ad-unit", ".ad-wrapper", "[id*='taboola']", "[class*='taboola']",
        "[id*='outbrain']", ".OUTBRAIN", "iframe[id^='aswift']", "[class*='sponsored-ad']"
    ]

    static func isAdHost(_ host: String?) -> Bool {
        guard let h = host?.lowercased(), !h.isEmpty else { return false }
        for a in hosts where h == a || h.hasSuffix("." + a) { return true }
        return false
    }

    static func rules(patterns: Bool = true, allow: [String] = []) -> [[String: Any]] {
        var out: [[String: Any]] = []
        for h in hosts {
            let esc = h.replacingOccurrences(of: ".", with: "\\.")
            out.append([
                "trigger": ["url-filter": "^https?://([^/:]*\\.)?\(esc)[/:]"],
                "action": ["type": "block"]
            ])
        }
        if patterns {
            for p in urlPatterns {
                out.append([
                    "trigger": ["url-filter": p,
                                "resource-type": ["script", "image", "raw", "media", "style-sheet", "popup"]],
                    "action": ["type": "block"]
                ])
            }
        }
        out.append([
            "trigger": ["url-filter": ".*"],
            "action": ["type": "css-display-none", "selector": hideSelectors.joined(separator: ", ")]
        ])
        // Trang được tắt chặn: luật cuối cùng huỷ mọi luật trước đó (kể cả tên miền con)
        if !allow.isEmpty {
            out.append([
                "trigger": ["url-filter": ".*", "if-domain": allow.map { "*" + $0 }],
                "action": ["type": "ignore-previous-rules"]
            ])
        }
        return out
    }

    /// Danh sách luật dựng sẵn; được cache theo identifier (có kèm danh sách trang được tắt chặn).
    @MainActor
    static func list(allow: Set<String> = []) async -> WKContentRuleList? {
        let store: WKContentRuleListStore? = WKContentRuleListStore.default()
        guard let store = store else { return nil }
        let sites = allow.sorted()
        var h: UInt64 = 5381
        for b in sites.joined(separator: ",").utf8 { h = (h &* 33) &+ UInt64(b) }
        let id = sites.isEmpty ? "builtin-ads-v3" : "builtin-ads-v3-" + String(h, radix: 16)

        // Dọn các bản cũ (bản v1/v2 và danh sách của bộ trang cũ)
        let ids: [String] = await withCheckedContinuation { (c: CheckedContinuation<[String], Never>) in
            store.getAvailableContentRuleListIdentifiers { c.resume(returning: $0 ?? []) }
        }
        for old in ids where old.hasPrefix("builtin-ads") && old != id {
            store.removeContentRuleList(forIdentifier: old) { _ in }
        }

        let found: WKContentRuleList? = await withCheckedContinuation { (c: CheckedContinuation<WKContentRuleList?, Never>) in
            store.lookUpContentRuleList(forIdentifier: id) { l, _ in c.resume(returning: l) }
        }
        if let f = found { return f }
        // Nếu bộ luật đầy đủ lỗi thì rơi về bộ luật chỉ chặn theo tên miền
        if let l = await compile(store, id, rules(patterns: true, allow: sites)) { return l }
        return await compile(store, id, rules(patterns: false, allow: sites))
    }

    @MainActor
    private static func compile(_ store: WKContentRuleListStore, _ id: String, _ r: [[String: Any]]) async -> WKContentRuleList? {
        guard JSONSerialization.isValidJSONObject(r),
              let data = try? JSONSerialization.data(withJSONObject: r),
              let json = String(data: data, encoding: .utf8) else { return nil }
        return await withCheckedContinuation { (c: CheckedContinuation<WKContentRuleList?, Never>) in
            store.compileContentRuleList(forIdentifier: id, encodedContentRuleList: json) { l, _ in
                c.resume(returning: l)
            }
        }
    }
}

// MARK: - Script dựng sẵn (chặn popup + video mạng yếu)

enum BuiltinScript {
    @MainActor
    static func source(_ s: BrowserSettings) -> String {
        let flags = "window.__xb={saver:\(s.saverActive),popup:\(s.popupBlock),game:\(s.gameHelper),sharp:\(s.sharp),bg:\(s.bgPlay),dark:\(s.darkPages),copy:\(s.freeCopy)};"
        return flags + body + "\n;" + DarkScript.body + "\n;" + CopyScript.body
    }

    /// Cập nhật cờ ở trang đang mở (không cần tải lại).
    @MainActor
    static func flagsJS(_ s: BrowserSettings) -> String {
        "window.__xb={saver:\(s.saverActive),popup:\(s.popupBlock),game:\(s.gameHelper),sharp:\(s.sharp),bg:\(s.bgPlay),dark:\(s.darkPages),copy:\(s.freeCopy)};" + "window.__xbDarkApply&&window.__xbDarkApply();window.__xbCopyApply&&window.__xbCopyApply();"
    }

    private static let body = #"""
(function(){
  if (window.__xbInit) return; window.__xbInit = true;
  var X = function(){ return window.__xb || {}; };
  var last = 0, seen = false, used = false;
  ['touchstart','pointerdown','mousedown','click','keydown'].forEach(function(e){
    addEventListener(e, function(ev){
      if (!ev.isTrusted) return;
      var n = Date.now();
      if (n - last > 700) used = false;   // bắt đầu một thao tác mới
      last = n; seen = true;
    }, true);
  });
  var recent = function(){ return Date.now() - last < 1500; };
  // Mỗi thao tác thật chỉ được mở tối đa 1 tab/link
  var allow = function(){
    if (!recent() || used) return false;
    used = true; return true;
  };

  var SLD = {co:1, com:1, net:1, org:1, gov:1, edu:1, ac:1};
  function siteOf(u){
    try {
      var h = new URL(u, location.href).hostname.toLowerCase();
      var p = h.split('.');
      if (p.length <= 2) return h;
      if (SLD[p[p.length-2]] && p[p.length-1].length === 2) return p.slice(-3).join('.');
      return p.slice(-2).join('.');
    } catch(e){ return ''; }
  }
  var mySite = siteOf(location.href);

  // ---- Chặn popup / tự mở tab / click-hijack
  function stub(){
    var noop = function(){};
    return { closed:false, opener:null, focus:noop, blur:noop, close:noop, postMessage:noop,
             location:{ href:'', assign:noop, replace:noop, reload:noop },
             document:{ write:noop, writeln:noop, open:noop, close:noop } };
  }
  var wo = window.open;
  window.open = function(){
    if (!X().popup) return wo.apply(window, arguments);
    var r = allow() ? wo.apply(window, arguments) : null;
    return r || stub();   // trả cửa sổ giả để script không chuyển hướng ngay trong tab hiện tại
  };

  // Link do script bấm hộ (thẻ <a> tạo ra rồi .click()) là mánh phổ biến của popunder
  function badAnchor(a){
    try {
      if (!a || a.tagName !== 'A' || a.hasAttribute('download')) return false;
      var h = a.href || '';
      if (!h || /^(blob|data|javascript|mailto|tel|sms):/i.test(h)) return false;
      var cross = siteOf(h) !== mySite;
      var blank = String(a.target || '').toLowerCase() === '_blank';
      if (cross && (blank || !a.isConnected)) return true;
      if (!allow()) return blank || cross;
      return false;
    } catch(e){ return false; }
  }
  var ac = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){
    if (X().popup && badAnchor(this)) return;
    return ac.apply(this, arguments);
  };
  var de = EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent = function(ev){
    try {
      if (X().popup && ev && ev.type === 'click' && !ev.isTrusted &&
          this instanceof HTMLAnchorElement && badAnchor(this)) return false;
    } catch(e){}
    return de.apply(this, arguments);
  };
  var fsub = HTMLFormElement.prototype.submit;
  HTMLFormElement.prototype.submit = function(){
    if (X().popup && String(this.target || '').toLowerCase() === '_blank' && !allow()) return;
    return fsub.apply(this, arguments);
  };

  // ---- Gỡ lớp phủ trong suốt phủ kín màn hình (chạm đâu cũng ra quảng cáo)
  var MAXZ = 2000000000;
  function isOverlay(el){
    try {
      if (!el || el.nodeType !== 1 || el.__xbO) return false;
      var tg = el.tagName;
      if (tg !== 'A' && tg !== 'DIV' && tg !== 'IFRAME' && tg !== 'SPAN') return false;
      if (el.classList.contains('__xbfs-el')) return false;
      var cs = getComputedStyle(el);
      if (cs.position !== 'fixed' && cs.position !== 'absolute') return false;
      var r = el.getBoundingClientRect();
      if (r.width < innerWidth * 0.8 || r.height < innerHeight * 0.8) return false;
      if (el.querySelector('img,video,canvas,input,button,textarea,select,svg,audio')) return false;
      if (tg !== 'IFRAME' && (el.textContent || '').trim()) return false;
      var z = parseInt(cs.zIndex, 10) || 0;
      var op = parseFloat(cs.opacity);
      var bg = cs.backgroundColor;
      var clear = op < 0.05 || bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent';
      if (!clear) return false;
      if (tg === 'A') return siteOf(el.href || '') !== mySite;
      if (tg === 'IFRAME') return (op < 0.05 || z >= MAXZ) && siteOf(el.src || '') !== mySite;
      return z >= MAXZ;
    } catch(e){ return false; }
  }
  function sweep(n){
    if (!X().popup || !n || n.nodeType !== 1) return;
    if (isOverlay(n)) { n.__xbO = 1; try { n.remove(); } catch(e){} }
  }
  function sweepAll(){
    [document.body, document.documentElement].forEach(function(p){
      if (!p) return;
      var ch = p.children;
      for (var i = ch.length - 1; i >= 0; i--) sweep(ch[i]);
    });
  }

  // ---- Video khi mạng yếu
  var tries = new WeakMap();
  function isBlob(v){ var s = v.currentSrc || v.src || ''; return !s || s.indexOf('blob:') === 0; }

  function prep(v){
    if (v.__xbP) return; v.__xbP = true;
    v.addEventListener('play', function(){
      if (X().saver && !seen && v.muted) { try { v.pause(); } catch(e){} }
    });
    var timer = null;
    function arm(){
      if (timer || isBlob(v)) return;
      var n0 = tries.get(v) || 0;
      timer = setTimeout(function(){
        timer = null;
        if (v.paused || v.ended || v.readyState >= 3) return;
        var n = tries.get(v) || 0;
        if (n >= 6) return;
        tries.set(v, n + 1);
        var t = v.currentTime;
        var onMeta = function(){
          v.removeEventListener('loadedmetadata', onMeta);
          try { v.currentTime = t; } catch(e){}
          var p = v.play(); if (p && p.catch) p.catch(function(){});
        };
        v.addEventListener('loadedmetadata', onMeta);
        v.load();
      }, 10000 + n0 * 4000);
    }
    ['stalled','waiting','error'].forEach(function(e){ v.addEventListener(e, arm); });
    ['playing','canplaythrough'].forEach(function(e){
      v.addEventListener(e, function(){
        if (timer) { clearTimeout(timer); timer = null; }
        if (e === 'playing') tries.set(v, 0);
      });
    });
  }

  function tune(v){
    if (!X().saver) return;
    try {
      if (v.paused) { v.preload = 'metadata'; if (!seen) v.removeAttribute('autoplay'); }
    } catch(e){}
  }

  function scan(){
    var vs = document.querySelectorAll('video');
    for (var i = 0; i < vs.length; i++) { prep(vs[i]); tune(vs[i]); }
    if (X().saver) {
      var im = document.querySelectorAll('img:not([loading])');
      for (var j = 0; j < im.length; j++) { im[j].loading = 'lazy'; im[j].decoding = 'async'; }
    }
  }

  var pending = false;
  function schedule(){
    if (pending) return; pending = true;
    setTimeout(function(){ pending = false; scan(); }, 500);
  }
  function go(){
    scan();
    sweepAll();
    [1000, 3000, 6000].forEach(function(t){ setTimeout(sweepAll, t); });
    try { new MutationObserver(schedule).observe(document.documentElement, {childList:true, subtree:true}); } catch(e){}
    // Lớp phủ quảng cáo thường được chèn thẳng vào <body>
    try {
      new MutationObserver(function(recs){
        for (var i = 0; i < recs.length; i++) {
          var ad = recs[i].addedNodes;
          for (var j = 0; j < ad.length; j++) {
            var n = ad[j];
            if (n.parentNode === document.body || n.parentNode === document.documentElement) sweep(n);
          }
        }
      }).observe(document.documentElement, {childList:true, subtree:true});
    } catch(e){}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();


  // ---- Phát nền: giữ trang "đang hiện" để site không tự dừng, và bật lại media nếu hệ thống tạm dừng
  (function(){
    function vd(name, hiddenValue){
      var d = Object.getOwnPropertyDescriptor(Document.prototype, name);
      if (!d || !d.get) return;
      try {
        Object.defineProperty(document, name, {
          configurable: true,
          get: function(){ return X().bg ? hiddenValue : d.get.call(document); }
        });
      } catch(e){}
    }
    vd('hidden', false); vd('webkitHidden', false);
    vd('visibilityState', 'visible'); vd('webkitVisibilityState', 'visible');
    ['visibilitychange','webkitvisibilitychange'].forEach(function(n){
      document.addEventListener(n, function(e){ if (X().bg) e.stopImmediatePropagation(); }, true);
    });
    var list = null, timers = [];
    function resume(){
      if (!list) return;
      list.forEach(function(v){
        if (v.paused && !v.ended) { try { var p = v.play(); if (p && p.catch) p.catch(function(){}); } catch(e){} }
      });
    }
    window.__xbBG = function(on){
      timers.forEach(clearTimeout); timers = [];
      if (!on) { list = null; return; }
      if (!X().bg) return;
      if (!list) {
        list = [];
        var ms = document.querySelectorAll('video,audio');
        for (var i = 0; i < ms.length; i++) { if (!ms[i].paused && !ms[i].ended) list.push(ms[i]); }
        if (!list.length) list = null;
      }
      [200, 700, 1500, 3000].forEach(function(t){ timers.push(setTimeout(resume, t)); });
    };
  })();

  // ---- Toàn màn hình: polyfill Fullscreen API + hỗ trợ game
  var fsOn = false, fsEl = null, fsStyle = null, fsByPage = false;
  function postFS(on){ try { window.webkit.messageHandlers.xbFS.postMessage(!!on); } catch(e){} }
  function fireFS(){
    ['fullscreenchange','webkitfullscreenchange'].forEach(function(n){
      try { if (fsEl) fsEl.dispatchEvent(new Event(n, {bubbles:true})); document.dispatchEvent(new Event(n)); } catch(e){}
    });
  }
  if (!(Element.prototype.requestFullscreen || Element.prototype.webkitRequestFullscreen)) {
    // Trình phát web thường gọi requestFullscreen() trên khung chứa (div), không phải thẻ <video>.
    // Tìm thẻ video bên trong để mở trình phát gốc của iOS (tự xoay ngang), thay vì chỉ xoay trang.
    var pickVideo = function(el){
      if (el.tagName === 'VIDEO') return el;
      if (!el.querySelectorAll) return null;
      if (el.querySelector('canvas')) return null;           // game: giữ kiểu toàn màn hình trang
      var vs = el.querySelectorAll('video'), best = null, area = 0;
      for (var i = 0; i < vs.length; i++) {
        var r = vs[i].getBoundingClientRect(), a = r.width * r.height;
        if (a > area && (vs[i].src || vs[i].currentSrc || vs[i].srcObject || vs[i].readyState > 0)) { best = vs[i]; area = a; }
      }
      return area > 4000 ? best : null;
    };
    var nativeFS = function(v){
      try {
        if (v.webkitEnterFullscreen) { v.webkitEnterFullscreen(); return true; }
      } catch(e){}
      return false;
    };
    // Video có link trực tiếp (mp4 / m3u8): nhờ app mở trình phát gốc (AVPlayer) — mượt, tự xoay ngang, có PiP.
    var playInApp = function(v){
      try {
        var u = v.currentSrc || v.src || '';
        if (!/^https?:/i.test(u)) return false;
        var page = (window.top === window) ? location.href : (document.referrer || location.href);
        var o = {url:u, kind:(/\.m3u8(\?|#|$)/i.test(u) ? 'hls' : 'file'), title:document.title || '', page:page,
                 w:v.videoWidth || 0, h:v.videoHeight || 0, d:(isFinite(v.duration) ? v.duration : 0),
                 play:true, t:v.currentTime || 0};
        window.webkit.messageHandlers.xbVideo.postMessage(o);
        try { v.pause(); } catch(e){}
        return true;
      } catch(e){ return false; }
    };
    var reqFS = function(){
      var v = pickVideo(this);
      if (v && playInApp(v)) return Promise.resolve();
      if (v && nativeFS(v)) return Promise.resolve();
      fsEl = this; fsByPage = true; postFS(true);
      return Promise.resolve();
    };
    var exitFS = function(){ fsByPage = false; postFS(false); return Promise.resolve(); };
    var defFS = function(n, g){ try { Object.defineProperty(Document.prototype, n, {get:g, configurable:true}); } catch(e){} };
    try {
      Element.prototype.requestFullscreen = reqFS;
      Element.prototype.webkitRequestFullscreen = reqFS;
      document.exitFullscreen = exitFS;
      document.webkitExitFullscreen = exitFS;
      defFS('fullscreenElement', function(){ return fsOn ? fsEl : null; });
      defFS('webkitFullscreenElement', function(){ return fsOn ? fsEl : null; });
      defFS('webkitCurrentFullScreenElement', function(){ return fsOn ? fsEl : null; });
      defFS('fullscreenEnabled', function(){ return true; });
      defFS('webkitFullscreenEnabled', function(){ return true; });
      defFS('webkitIsFullScreen', function(){ return fsOn; });
    } catch(e){}
  }

  var SHARP_CSS = 'canvas{image-rendering:-webkit-optimize-contrast;image-rendering:pixelated}';
  if (X().sharp === 2) {
    try { Object.defineProperty(window, 'devicePixelRatio', {get:function(){ return 3; }, configurable:true}); } catch(e){}
  }
  var GAME_CSS = 'html,body{overscroll-behavior:none!important;-webkit-user-select:none;user-select:none;' +
    '-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent;touch-action:manipulation}' +
    'input,textarea,[contenteditable]{-webkit-user-select:text;user-select:text}';
  // Chỉ chặn vuốt khi là game: trang tự gọi requestFullscreen(), hoặc trang không có gì để cuộn.
  // Nếu người dùng bấm "Toàn màn hình" ở menu trên trang dài thì vẫn cho cuộn bình thường.
  function pageScrollable(){
    var de = document.documentElement, b = document.body;
    var h = Math.max(de ? de.scrollHeight : 0, b ? b.scrollHeight : 0);
    return h > innerHeight + 24;
  }
  function gameOn(){ return fsOn && X().game && (fsByPage || !pageScrollable()); }
  function scrollableUp(el){
    while (el && el !== document.documentElement) {
      if (el.nodeType === 1) {
        var cs = getComputedStyle(el);
        if (/(auto|scroll)/.test(cs.overflowY + cs.overflowX) &&
            (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1)) return true;
      }
      el = el.parentNode;
    }
    return false;
  }
  addEventListener('touchmove', function(e){
    if (!gameOn()) return;
    var t = e.target;
    if (t && t.closest && t.closest('input,textarea,select,[contenteditable]')) return;
    if (scrollableUp(t)) return;
    if (e.cancelable) e.preventDefault();
  }, {capture:true, passive:false});
  ['gesturestart','gesturechange'].forEach(function(n){
    addEventListener(n, function(e){ if (gameOn() && e.cancelable) e.preventDefault(); }, {capture:true, passive:false});
  });
  addEventListener('contextmenu', function(e){ if (gameOn()) e.preventDefault(); }, true);

  // Khung phát (div chứa <video>) được trang yêu cầu toàn màn hình: cho phủ kín viewport,
  // gỡ các thuộc tính của tổ tiên làm "position:fixed" bị kẹt hoặc bị cắt.
  var FILL_CSS = '.__xbfs-el{position:fixed!important;left:0!important;top:0!important;right:0!important;bottom:0!important;' +
    'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;' +
    'z-index:2147483647!important;background:#000!important;transform:none!important}' +
    '.__xbfs-el video{width:100%!important;height:100%!important;object-fit:contain!important;background:#000}' +
    '.__xbfs-anc{transform:none!important;filter:none!important;perspective:none!important;contain:none!important;' +
    'overflow:visible!important;will-change:auto!important;clip-path:none!important}' +
    'html.__xbfs-on,html.__xbfs-on body{overflow:hidden!important}';
  var fsFillStyle = null, fsAnc = [], fsFilled = null;
  function fillOn(el){
    try {
      if (!el || el === document.documentElement || el === document.body) return;
      if (!fsFillStyle) { fsFillStyle = document.createElement('style'); fsFillStyle.textContent = FILL_CSS; }
      (document.head || document.documentElement).appendChild(fsFillStyle);
      document.documentElement.classList.add('__xbfs-on');
      el.classList.add('__xbfs-el'); fsFilled = el;
      var n = el.parentElement;
      while (n && n !== document.documentElement) { n.classList.add('__xbfs-anc'); fsAnc.push(n); n = n.parentElement; }
      try { window.scrollTo(0, 0); } catch(e){}
    } catch(e){}
  }
  function fillOff(){
    try {
      if (fsFilled) { fsFilled.classList.remove('__xbfs-el'); fsFilled = null; }
      fsAnc.forEach(function(n){ n.classList.remove('__xbfs-anc'); }); fsAnc = [];
      document.documentElement.classList.remove('__xbfs-on');
      if (fsFillStyle && fsFillStyle.parentNode) fsFillStyle.parentNode.removeChild(fsFillStyle);
    } catch(e){}
  }

  function applyFS(on){
    on = !!on;
    if (on === fsOn) return;
    fsOn = on; window.__xbFSOn = on;
    try { window.__xbCopyApply && window.__xbCopyApply(); } catch(e){}
    if (on && !fsEl) fsEl = document.documentElement;
    if (on) fillOn(fsEl); else fillOff();
    try {
      if (on && (X().game || X().sharp)) {
        if (!fsStyle) fsStyle = document.createElement('style');
        fsStyle.textContent = (X().game ? GAME_CSS : '') + (X().sharp ? SHARP_CSS : '');
        (document.head || document.documentElement).appendChild(fsStyle);
      } else if (fsStyle && fsStyle.parentNode) {
        fsStyle.parentNode.removeChild(fsStyle);
      }
    } catch(e){}
    fireFS();
    if (!on) { fsEl = null; fsByPage = false; }
    var fr = document.querySelectorAll('iframe');
    for (var i = 0; i < fr.length; i++) { try { fr[i].contentWindow.postMessage({__xbFS: on}, '*'); } catch(e){} }
    [120, 400, 900].forEach(function(ms){ setTimeout(function(){ try { dispatchEvent(new Event('resize')); } catch(e){} }, ms); });
  }
  window.__xbFSState = applyFS;
  addEventListener('message', function(e){
    var d = e.data;
    if (d && typeof d === 'object' && '__xbFS' in d) applyFS(d.__xbFS);
  });
})();
"""#
}
