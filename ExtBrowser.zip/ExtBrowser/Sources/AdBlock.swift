import Foundation
import WebKit
import Network

// MARK: - Cài đặt trình duyệt

@MainActor
final class BrowserSettings: ObservableObject {
    static let shared = BrowserSettings()

    @Published var adBlock: Bool { didSet { UserDefaults.standard.set(adBlock, forKey: "set.adblock") } }
    @Published var popupBlock: Bool { didSet { UserDefaults.standard.set(popupBlock, forKey: "set.popup") } }
    @Published var dataSaver: Bool { didSet { UserDefaults.standard.set(dataSaver, forKey: "set.saver") } }
    /// Máy đang bật Chế độ dữ liệu thấp (Low Data Mode) hoặc mạng bị hạn chế.
    @Published var searchEngine: String { didSet { UserDefaults.standard.set(searchEngine, forKey: "set.engine") } }
    @Published var homepage: String { didSet { UserDefaults.standard.set(homepage, forKey: "set.home") } }
    /// Máy đang bật Chế độ dữ liệu thấp (Low Data Mode) hoặc mạng bị hạn chế.
    @Published private(set) var lowData = false

    var searchBase: String {
        switch searchEngine {
        case "duckduckgo": return "https://duckduckgo.com/"
        case "bing": return "https://www.bing.com/search"
        default: return "https://www.google.com/search"
        }
    }

    /// Địa chỉ trang chủ đã chuẩn hoá (rỗng -> Google).
    var homeURLString: String {
        let t = homepage.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return "https://www.google.com" }
        return t.contains("://") ? t : "https://" + t
    }

    var saverActive: Bool { dataSaver || lowData }

    private let monitor = NWPathMonitor()

    private init() {
        let d = UserDefaults.standard
        adBlock = d.object(forKey: "set.adblock") as? Bool ?? true
        popupBlock = d.object(forKey: "set.popup") as? Bool ?? true
        dataSaver = d.object(forKey: "set.saver") as? Bool ?? false
        searchEngine = d.string(forKey: "set.engine") ?? "google"
        homepage = d.string(forKey: "set.home") ?? "https://www.google.com"
        monitor.pathUpdateHandler = { [weak self] p in
            let c = p.isConstrained
            Task { @MainActor in
                if let self = self, self.lowData != c { self.lowData = c }
            }
        }
        monitor.start(queue: DispatchQueue(label: "extbrowser.netmonitor"))
    }
}

// MARK: - Chặn quảng cáo

enum AdBlock {
    static let hosts: [String] = [
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "googletagservices.com",
        "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com",
        "popads.net", "popcash.net", "propellerads.com", "onclickads.net", "onclkds.com",
        "exoclick.com", "juicyads.com", "trafficjunky.com", "adsterra.com", "hilltopads.net",
        "clickadu.com", "mgid.com", "revcontent.com", "criteo.com", "criteo.net",
        "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
        "amazon-adsystem.com", "moatads.com", "adform.net", "smartadserver.com",
        "advertising.com", "yieldmo.com", "33across.com", "bidswitch.net", "contextweb.com",
        "lijit.com", "sharethrough.com", "teads.tv", "tapad.com", "adcolony.com",
        "admaven.com", "ad-maven.com", "a-ads.com", "adskeeper.com", "bidvertiser.com",
        "zedo.com", "cpmstar.com", "tsyndicate.com", "monetag.com", "adtima.vn",
        "eclick.vn", "adsplay.net", "scorecardresearch.com", "adsafeprotected.com",
        "serving-sys.com", "2mdn.net", "pagead2.googlesyndication.com"
    ]

    static let hideSelectors = [
        "ins.adsbygoogle", ".adsbygoogle", "[id^='google_ads_']", "[id^='div-gpt-ad']",
        "iframe[src*='doubleclick.net']", "iframe[src*='googlesyndication.com']",
        "[class*='ad-banner']", "[class*='ads-banner']", "[class*='popup-ad']",
        "[id*='ad-container']", "[class*='adsbox']", "a[href*='doubleclick.net']"
    ]

    static func isAdHost(_ host: String?) -> Bool {
        guard let h = host?.lowercased(), !h.isEmpty else { return false }
        for a in hosts where h == a || h.hasSuffix("." + a) { return true }
        return false
    }

    static func rules() -> [[String: Any]] {
        var out: [[String: Any]] = []
        for h in hosts {
            let esc = h.replacingOccurrences(of: ".", with: "\\.")
            out.append([
                "trigger": ["url-filter": "^https?://([^/:]*\\.)?\(esc)[/:]"],
                "action": ["type": "block"]
            ])
        }
        out.append([
            "trigger": ["url-filter": ".*"],
            "action": ["type": "css-display-none", "selector": hideSelectors.joined(separator: ", ")]
        ])
        return out
    }

    /// Danh sách luật dựng sẵn; được cache theo identifier. Đổi số version khi sửa luật.
    @MainActor
    static func list() async -> WKContentRuleList? {
        let store: WKContentRuleListStore? = WKContentRuleListStore.default()
        guard let store = store else { return nil }
        let id = "builtin-ads-v1"

        let found: WKContentRuleList? = await withCheckedContinuation { (c: CheckedContinuation<WKContentRuleList?, Never>) in
            store.lookUpContentRuleList(forIdentifier: id) { l, _ in c.resume(returning: l) }
        }
        if let f = found { return f }

        let r = rules()
        guard JSONSerialization.isValidJSONObject(r),
              let data = try? JSONSerialization.data(withJSONObject: r),
              let json = String(data: data, encoding: .utf8) else { return nil }
        return await withCheckedContinuation { (c: CheckedContinuation<WKContentRuleList?, Never>) in
            store.compileContentRuleList(forIdentifier: id, encodedContentRuleList: json) { l, _ in
                c.resume(returning: l)
            }
        }
    }
}

// MARK: - Script dựng sẵn (chặn popup + video mạng yếu)

enum BuiltinScript {
    @MainActor
    static func source(_ s: BrowserSettings) -> String {
        let flags = "window.__xb={saver:\(s.saverActive),popup:\(s.popupBlock)};"
        return flags + body
    }

    /// Cập nhật cờ ở trang đang mở (không cần tải lại).
    @MainActor
    static func flagsJS(_ s: BrowserSettings) -> String {
        "window.__xb={saver:\(s.saverActive),popup:\(s.popupBlock)};"
    }

    private static let body = #"""
(function(){
  if (window.__xbInit) return; window.__xbInit = true;
  var X = function(){ return window.__xb || {}; };
  var last = 0, seen = false;
  ['touchstart','pointerdown','mousedown','click','keydown'].forEach(function(e){
    addEventListener(e, function(ev){ if (ev.isTrusted) { last = Date.now(); seen = true; } }, true);
  });
  var recent = function(){ return Date.now() - last < 1500; };

  // ---- Chặn popup / tự mở tab: chỉ cho mở khi vừa có thao tác thật của người dùng
  var wo = window.open;
  window.open = function(){
    if (X().popup && !recent()) return null;
    return wo.apply(window, arguments);
  };
  var ac = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){
    if (X().popup && !recent() && this.target === '_blank') return;
    return ac.apply(this, arguments);
  };

  // ---- Video khi mạng yếu
  var tries = new WeakMap();
  function isBlob(v){ var s = v.currentSrc || v.src || ''; return !s || s.indexOf('blob:') === 0; }

  function prep(v){
    if (v.__xbP) return; v.__xbP = true;
    v.addEventListener('play', function(){
      if (X().saver && !seen && v.muted) { try { v.pause(); } catch(e){} }
    });
    var timer = null;
    function arm(){
      if (timer || isBlob(v)) return;
      var n0 = tries.get(v) || 0;
      timer = setTimeout(function(){
        timer = null;
        if (v.paused || v.ended || v.readyState >= 3) return;
        var n = tries.get(v) || 0;
        if (n >= 6) return;
        tries.set(v, n + 1);
        var t = v.currentTime;
        var onMeta = function(){
          v.removeEventListener('loadedmetadata', onMeta);
          try { v.currentTime = t; } catch(e){}
          var p = v.play(); if (p && p.catch) p.catch(function(){});
        };
        v.addEventListener('loadedmetadata', onMeta);
        v.load();
      }, 10000 + n0 * 4000);
    }
    ['stalled','waiting','error'].forEach(function(e){ v.addEventListener(e, arm); });
    ['playing','canplaythrough'].forEach(function(e){
      v.addEventListener(e, function(){
        if (timer) { clearTimeout(timer); timer = null; }
        if (e === 'playing') tries.set(v, 0);
      });
    });
  }

  function tune(v){
    if (!X().saver) return;
    try {
      if (v.paused) { v.preload = 'metadata'; if (!seen) v.removeAttribute('autoplay'); }
    } catch(e){}
  }

  function scan(){
    var vs = document.querySelectorAll('video');
    for (var i = 0; i < vs.length; i++) { prep(vs[i]); tune(vs[i]); }
    if (X().saver) {
      var im = document.querySelectorAll('img:not([loading])');
      for (var j = 0; j < im.length; j++) { im[j].loading = 'lazy'; im[j].decoding = 'async'; }
    }
  }

  var pending = false;
  function schedule(){
    if (pending) return; pending = true;
    setTimeout(function(){ pending = false; scan(); }, 500);
  }
  function go(){
    scan();
    try { new MutationObserver(schedule).observe(document.documentElement, {childList:true, subtree:true}); } catch(e){}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
})();
"""#
}
