import AVFoundation
import Foundation
import WebKit
import Network

// MARK: - Cài đặt trình duyệt

@MainActor
final class BrowserSettings: ObservableObject {
    static let shared = BrowserSettings()

    @Published var adBlock: Bool { didSet { UserDefaults.standard.set(adBlock, forKey: "set.adblock") } }
    @Published var popupBlock: Bool { didSet { UserDefaults.standard.set(popupBlock, forKey: "set.popup") } }
    @Published var dataSaver: Bool { didSet { UserDefaults.standard.set(dataSaver, forKey: "set.saver") } }
    /// Máy đang bật Chế độ dữ liệu thấp (Low Data Mode) hoặc mạng bị hạn chế.
    @Published var searchEngine: String { didSet { UserDefaults.standard.set(searchEngine, forKey: "set.engine") } }
    @Published var homepage: String { didSet { UserDefaults.standard.set(homepage, forKey: "set.home") } }
    /// Hỗ trợ game khi toàn màn hình (chặn zoom, chọn chữ, kéo trang...).
    @Published var gameHelper: Bool { didSet { UserDefaults.standard.set(gameHelper, forKey: "set.game") } }
    /// Tự xoay ngang khi vào toàn màn hình.
    /// Làm nét game: 0 tắt, 1 tắt làm mịn khi phóng canvas, 2 thêm ép devicePixelRatio = 3.
    @Published var sharp: Int { didSet { UserDefaults.standard.set(sharp, forKey: "set.sharp") } }
    /// Tiếp tục phát nhạc/video khi thoát app hoặc khoá màn hình.
    @Published var bgPlay: Bool { didSet { UserDefaults.standard.set(bgPlay, forKey: "set.bgplay"); applyAudioSession() } }
    /// Plugin “Xem video”: dò video trong trang và hiện nút tải.
    @Published var videoTool: Bool { didSet { UserDefaults.standard.set(videoTool, forKey: "set.video") } }
    @Published var fsLandscape: Bool { didSet { UserDefaults.standard.set(fsLandscape, forKey: "set.fsland") } }
    /// Máy đang bật Chế độ dữ liệu thấp (Low Data Mode) hoặc mạng bị hạn chế.
    @Published private(set) var lowData = false

    var searchBase: String {
        switch searchEngine {
        case "duckduckgo": return "https://duckduckgo.com/"
        case "bing": return "https://www.bing.com/search"
        default: return "https://www.google.com/search"
        }
    }

    /// Địa chỉ trang chủ đã chuẩn hoá (rỗng -> Google).
    var homeURLString: String {
        let t = homepage.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return "https://www.google.com" }
        return t.contains("://") ? t : "https://" + t
    }

    var saverActive: Bool { dataSaver || lowData }

    private let monitor = NWPathMonitor()

    private init() {
        let d = UserDefaults.standard
        adBlock = d.object(forKey: "set.adblock") as? Bool ?? true
        popupBlock = d.object(forKey: "set.popup") as? Bool ?? true
        dataSaver = d.object(forKey: "set.saver") as? Bool ?? false
        searchEngine = d.string(forKey: "set.engine") ?? "google"
        homepage = d.string(forKey: "set.home") ?? "https://www.google.com"
        gameHelper = d.object(forKey: "set.game") as? Bool ?? true
        fsLandscape = d.object(forKey: "set.fsland") as? Bool ?? true
        sharp = d.object(forKey: "set.sharp") as? Int ?? 1
        bgPlay = d.object(forKey: "set.bgplay") as? Bool ?? true
        videoTool = d.object(forKey: "set.video") as? Bool ?? true
        monitor.pathUpdateHandler = { [weak self] p in
            let c = p.isConstrained
            Task { @MainActor in
                if let self = self, self.lowData != c { self.lowData = c }
            }
        }
        monitor.start(queue: DispatchQueue(label: "extbrowser.netmonitor"))
        applyAudioSession()
    }

    /// Category `playback` để âm thanh vẫn phát khi tắt màn hình / sang app khác (cần UIBackgroundModes = audio).
    func applyAudioSession() {
        let s = AVAudioSession.sharedInstance()
        if bgPlay {
            try? s.setCategory(.playback, mode: .moviePlayback, options: [])
        } else {
            try? s.setCategory(.soloAmbient, mode: .default, options: [])
        }
    }
}

// MARK: - Chặn quảng cáo

enum AdBlock {
    static let hosts: [String] = [
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "googletagservices.com",
        "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com",
        "popads.net", "popcash.net", "propellerads.com", "onclickads.net", "onclkds.com",
        "exoclick.com", "juicyads.com", "trafficjunky.com", "adsterra.com", "hilltopads.net",
        "clickadu.com", "mgid.com", "revcontent.com", "criteo.com", "criteo.net",
        "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
        "amazon-adsystem.com", "moatads.com", "adform.net", "smartadserver.com",
        "advertising.com", "yieldmo.com", "33across.com", "bidswitch.net", "contextweb.com",
        "lijit.com", "sharethrough.com", "teads.tv", "tapad.com", "adcolony.com",
        "admaven.com", "ad-maven.com", "a-ads.com", "adskeeper.com", "bidvertiser.com",
        "zedo.com", "cpmstar.com", "tsyndicate.com", "monetag.com", "adtima.vn",
        "eclick.vn", "adsplay.net", "scorecardresearch.com", "adsafeprotected.com",
        "serving-sys.com", "2mdn.net", "pagead2.googlesyndication.com"
    ]

    static let hideSelectors = [
        "ins.adsbygoogle", ".adsbygoogle", "[id^='google_ads_']", "[id^='div-gpt-ad']",
        "iframe[src*='doubleclick.net']", "iframe[src*='googlesyndication.com']",
        "[class*='ad-banner']", "[class*='ads-banner']", "[class*='popup-ad']",
        "[id*='ad-container']", "[class*='adsbox']", "a[href*='doubleclick.net']"
    ]

    static func isAdHost(_ host: String?) -> Bool {
        guard let h = host?.lowercased(), !h.isEmpty else { return false }
        for a in hosts where h == a || h.hasSuffix("." + a) { return true }
        return false
    }

    static func rules() -> [[String: Any]] {
        var out: [[String: Any]] = []
        for h in hosts {
            let esc = h.replacingOccurrences(of: ".", with: "\\.")
            out.append([
                "trigger": ["url-filter": "^https?://([^/:]*\\.)?\(esc)[/:]"],
                "action": ["type": "block"]
            ])
        }
        out.append([
            "trigger": ["url-filter": ".*"],
            "action": ["type": "css-display-none", "selector": hideSelectors.joined(separator: ", ")]
        ])
        return out
    }

    /// Danh sách luật dựng sẵn; được cache theo identifier. Đổi số version khi sửa luật.
    @MainActor
    static func list() async -> WKContentRuleList? {
        let store: WKContentRuleListStore? = WKContentRuleListStore.default()
        guard let store = store else { return nil }
        let id = "builtin-ads-v1"

        let found: WKContentRuleList? = await withCheckedContinuation { (c: CheckedContinuation<WKContentRuleList?, Never>) in
            store.lookUpContentRuleList(forIdentifier: id) { l, _ in c.resume(returning: l) }
        }
        if let f = found { return f }

        let r = rules()
        guard JSONSerialization.isValidJSONObject(r),
              let data = try? JSONSerialization.data(withJSONObject: r),
              let json = String(data: data, encoding: .utf8) else { return nil }
        return await withCheckedContinuation { (c: CheckedContinuation<WKContentRuleList?, Never>) in
            store.compileContentRuleList(forIdentifier: id, encodedContentRuleList: json) { l, _ in
                c.resume(returning: l)
            }
        }
    }
}

// MARK: - Script dựng sẵn (chặn popup + video mạng yếu)

enum BuiltinScript {
    @MainActor
    static func source(_ s: BrowserSettings) -> String {
        let flags = "window.__xb={saver:\(s.saverActive),popup:\(s.popupBlock),game:\(s.gameHelper),sharp:\(s.sharp),bg:\(s.bgPlay)};"
        return flags + body
    }

    /// Cập nhật cờ ở trang đang mở (không cần tải lại).
    @MainActor
    static func flagsJS(_ s: BrowserSettings) -> String {
        "window.__xb={saver:\(s.saverActive),popup:\(s.popupBlock),game:\(s.gameHelper),sharp:\(s.sharp),bg:\(s.bgPlay)};"
    }

    private static let body = #"""
(function(){
  if (window.__xbInit) return; window.__xbInit = true;
  var X = function(){ return window.__xb || {}; };
  var last = 0, seen = false;
  ['touchstart','pointerdown','mousedown','click','keydown'].forEach(function(e){
    addEventListener(e, function(ev){ if (ev.isTrusted) { last = Date.now(); seen = true; } }, true);
  });
  var recent = function(){ return Date.now() - last < 1500; };

  // ---- Chặn popup / tự mở tab: chỉ cho mở khi vừa có thao tác thật của người dùng
  var wo = window.open;
  window.open = function(){
    if (X().popup && !recent()) return null;
    return wo.apply(window, arguments);
  };
  var ac = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){
    if (X().popup && !recent() && this.target === '_blank') return;
    return ac.apply(this, arguments);
  };

  // ---- Video khi mạng yếu
  var tries = new WeakMap();
  function isBlob(v){ var s = v.currentSrc || v.src || ''; return !s || s.indexOf('blob:') === 0; }

  function prep(v){
    if (v.__xbP) return; v.__xbP = true;
    v.addEventListener('play', function(){
      if (X().saver && !seen && v.muted) { try { v.pause(); } catch(e){} }
    });
    var timer = null;
    function arm(){
      if (timer || isBlob(v)) return;
      var n0 = tries.get(v) || 0;
      timer = setTimeout(function(){
        timer = null;
        if (v.paused || v.ended || v.readyState >= 3) return;
        var n = tries.get(v) || 0;
        if (n >= 6) return;
        tries.set(v, n + 1);
        var t = v.currentTime;
        var onMeta = function(){
          v.removeEventListener('loadedmetadata', onMeta);
          try { v.currentTime = t; } catch(e){}
          var p = v.play(); if (p && p.catch) p.catch(function(){});
        };
        v.addEventListener('loadedmetadata', onMeta);
        v.load();
      }, 10000 + n0 * 4000);
    }
    ['stalled','waiting','error'].forEach(function(e){ v.addEventListener(e, arm); });
    ['playing','canplaythrough'].forEach(function(e){
      v.addEventListener(e, function(){
        if (timer) { clearTimeout(timer); timer = null; }
        if (e === 'playing') tries.set(v, 0);
      });
    });
  }

  function tune(v){
    if (!X().saver) return;
    try {
      if (v.paused) { v.preload = 'metadata'; if (!seen) v.removeAttribute('autoplay'); }
    } catch(e){}
  }

  function scan(){
    var vs = document.querySelectorAll('video');
    for (var i = 0; i < vs.length; i++) { prep(vs[i]); tune(vs[i]); }
    if (X().saver) {
      var im = document.querySelectorAll('img:not([loading])');
      for (var j = 0; j < im.length; j++) { im[j].loading = 'lazy'; im[j].decoding = 'async'; }
    }
  }

  var pending = false;
  function schedule(){
    if (pending) return; pending = true;
    setTimeout(function(){ pending = false; scan(); }, 500);
  }
  function go(){
    scan();
    try { new MutationObserver(schedule).observe(document.documentElement, {childList:true, subtree:true}); } catch(e){}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();


  // ---- Phát nền: giữ trang "đang hiện" để site không tự dừng, và bật lại media nếu hệ thống tạm dừng
  (function(){
    function vd(name, hiddenValue){
      var d = Object.getOwnPropertyDescriptor(Document.prototype, name);
      if (!d || !d.get) return;
      try {
        Object.defineProperty(document, name, {
          configurable: true,
          get: function(){ return X().bg ? hiddenValue : d.get.call(document); }
        });
      } catch(e){}
    }
    vd('hidden', false); vd('webkitHidden', false);
    vd('visibilityState', 'visible'); vd('webkitVisibilityState', 'visible');
    ['visibilitychange','webkitvisibilitychange'].forEach(function(n){
      document.addEventListener(n, function(e){ if (X().bg) e.stopImmediatePropagation(); }, true);
    });
    var list = null, timers = [];
    function resume(){
      if (!list) return;
      list.forEach(function(v){
        if (v.paused && !v.ended) { try { var p = v.play(); if (p && p.catch) p.catch(function(){}); } catch(e){} }
      });
    }
    window.__xbBG = function(on){
      timers.forEach(clearTimeout); timers = [];
      if (!on) { list = null; return; }
      if (!X().bg) return;
      if (!list) {
        list = [];
        var ms = document.querySelectorAll('video,audio');
        for (var i = 0; i < ms.length; i++) { if (!ms[i].paused && !ms[i].ended) list.push(ms[i]); }
        if (!list.length) list = null;
      }
      [200, 700, 1500, 3000].forEach(function(t){ timers.push(setTimeout(resume, t)); });
    };
  })();

  // ---- Toàn màn hình: polyfill Fullscreen API + hỗ trợ game
  var fsOn = false, fsEl = null, fsStyle = null, fsByPage = false;
  function postFS(on){ try { window.webkit.messageHandlers.xbFS.postMessage(!!on); } catch(e){} }
  function fireFS(){
    ['fullscreenchange','webkitfullscreenchange'].forEach(function(n){
      try { if (fsEl) fsEl.dispatchEvent(new Event(n, {bubbles:true})); document.dispatchEvent(new Event(n)); } catch(e){}
    });
  }
  if (!(Element.prototype.requestFullscreen || Element.prototype.webkitRequestFullscreen)) {
    var reqFS = function(){
      if (this.tagName === 'VIDEO' && this.webkitEnterFullscreen) {
        try { this.webkitEnterFullscreen(); } catch(e){}
        return Promise.resolve();
      }
      fsEl = this; fsByPage = true; postFS(true);
      return Promise.resolve();
    };
    var exitFS = function(){ fsByPage = false; postFS(false); return Promise.resolve(); };
    var defFS = function(n, g){ try { Object.defineProperty(Document.prototype, n, {get:g, configurable:true}); } catch(e){} };
    try {
      Element.prototype.requestFullscreen = reqFS;
      Element.prototype.webkitRequestFullscreen = reqFS;
      document.exitFullscreen = exitFS;
      document.webkitExitFullscreen = exitFS;
      defFS('fullscreenElement', function(){ return fsOn ? fsEl : null; });
      defFS('webkitFullscreenElement', function(){ return fsOn ? fsEl : null; });
      defFS('webkitCurrentFullScreenElement', function(){ return fsOn ? fsEl : null; });
      defFS('fullscreenEnabled', function(){ return true; });
      defFS('webkitFullscreenEnabled', function(){ return true; });
      defFS('webkitIsFullScreen', function(){ return fsOn; });
    } catch(e){}
  }

  var SHARP_CSS = 'canvas{image-rendering:-webkit-optimize-contrast;image-rendering:pixelated}';
  if (X().sharp === 2) {
    try { Object.defineProperty(window, 'devicePixelRatio', {get:function(){ return 3; }, configurable:true}); } catch(e){}
  }
  var GAME_CSS = 'html,body{overscroll-behavior:none!important;-webkit-user-select:none;user-select:none;' +
    '-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent;touch-action:manipulation}' +
    'input,textarea,[contenteditable]{-webkit-user-select:text;user-select:text}';
  // Chỉ chặn vuốt khi là game: trang tự gọi requestFullscreen(), hoặc trang không có gì để cuộn.
  // Nếu người dùng bấm "Toàn màn hình" ở menu trên trang dài thì vẫn cho cuộn bình thường.
  function pageScrollable(){
    var de = document.documentElement, b = document.body;
    var h = Math.max(de ? de.scrollHeight : 0, b ? b.scrollHeight : 0);
    return h > innerHeight + 24;
  }
  function gameOn(){ return fsOn && X().game && (fsByPage || !pageScrollable()); }
  function scrollableUp(el){
    while (el && el !== document.documentElement) {
      if (el.nodeType === 1) {
        var cs = getComputedStyle(el);
        if (/(auto|scroll)/.test(cs.overflowY + cs.overflowX) &&
            (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1)) return true;
      }
      el = el.parentNode;
    }
    return false;
  }
  addEventListener('touchmove', function(e){
    if (!gameOn()) return;
    var t = e.target;
    if (t && t.closest && t.closest('input,textarea,select,[contenteditable]')) return;
    if (scrollableUp(t)) return;
    if (e.cancelable) e.preventDefault();
  }, {capture:true, passive:false});
  ['gesturestart','gesturechange'].forEach(function(n){
    addEventListener(n, function(e){ if (gameOn() && e.cancelable) e.preventDefault(); }, {capture:true, passive:false});
  });
  addEventListener('contextmenu', function(e){ if (gameOn()) e.preventDefault(); }, true);

  // Khung phát (div chứa <video>) được trang yêu cầu toàn màn hình: cho phủ kín viewport,
  // gỡ các thuộc tính của tổ tiên làm "position:fixed" bị kẹt hoặc bị cắt.
  var FILL_CSS = '.__xbfs-el{position:fixed!important;left:0!important;top:0!important;right:0!important;bottom:0!important;' +
    'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;' +
    'z-index:2147483647!important;background:#000!important;transform:none!important}' +
    '.__xbfs-el video{width:100%!important;height:100%!important;object-fit:contain!important;background:#000}' +
    '.__xbfs-anc{transform:none!important;filter:none!important;perspective:none!important;contain:none!important;' +
    'overflow:visible!important;will-change:auto!important;clip-path:none!important}' +
    'html.__xbfs-on,html.__xbfs-on body{overflow:hidden!important}';
  var fsFillStyle = null, fsAnc = [], fsFilled = null;
  function fillOn(el){
    try {
      if (!el || el === document.documentElement || el === document.body) return;
      if (!fsFillStyle) { fsFillStyle = document.createElement('style'); fsFillStyle.textContent = FILL_CSS; }
      (document.head || document.documentElement).appendChild(fsFillStyle);
      document.documentElement.classList.add('__xbfs-on');
      el.classList.add('__xbfs-el'); fsFilled = el;
      var n = el.parentElement;
      while (n && n !== document.documentElement) { n.classList.add('__xbfs-anc'); fsAnc.push(n); n = n.parentElement; }
      try { window.scrollTo(0, 0); } catch(e){}
    } catch(e){}
  }
  function fillOff(){
    try {
      if (fsFilled) { fsFilled.classList.remove('__xbfs-el'); fsFilled = null; }
      fsAnc.forEach(function(n){ n.classList.remove('__xbfs-anc'); }); fsAnc = [];
      document.documentElement.classList.remove('__xbfs-on');
      if (fsFillStyle && fsFillStyle.parentNode) fsFillStyle.parentNode.removeChild(fsFillStyle);
    } catch(e){}
  }

  function applyFS(on){
    on = !!on;
    if (on === fsOn) return;
    fsOn = on;
    if (on && !fsEl) fsEl = document.documentElement;
    if (on) fillOn(fsEl); else fillOff();
    try {
      if (on && (X().game || X().sharp)) {
        if (!fsStyle) fsStyle = document.createElement('style');
        fsStyle.textContent = (X().game ? GAME_CSS : '') + (X().sharp ? SHARP_CSS : '');
        (document.head || document.documentElement).appendChild(fsStyle);
      } else if (fsStyle && fsStyle.parentNode) {
        fsStyle.parentNode.removeChild(fsStyle);
      }
    } catch(e){}
    fireFS();
    if (!on) { fsEl = null; fsByPage = false; }
    var fr = document.querySelectorAll('iframe');
    for (var i = 0; i < fr.length; i++) { try { fr[i].contentWindow.postMessage({__xbFS: on}, '*'); } catch(e){} }
    [120, 400, 900].forEach(function(ms){ setTimeout(function(){ try { dispatchEvent(new Event('resize')); } catch(e){} }, ms); });
  }
  window.__xbFSState = applyFS;
  addEventListener('message', function(e){
    var d = e.data;
    if (d && typeof d === 'object' && '__xbFS' in d) applyFS(d.__xbFS);
  });
})();
"""#
}
