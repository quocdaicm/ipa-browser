import SwiftUI

// MARK: - Trang chủ Cà Mau (thuần SwiftUI)
//
// Trang chủ là một màn hình SwiftUI phủ lên WKWebView khi tab đang ở trang trống (about:blank),
// không còn là HTML nhúng. Tranh rừng đước lấy từ Assets (camau_banner, tự đổi sáng/tối theo
// giao diện app), nên màu luôn khớp lựa chọn Tự động / Sáng / Tối mà không cần nạp lại gì cả.

/// Lớp phủ trang chủ cho một tab. Quan sát trực tiếp `Tab.isHome` để hiện/ẩn ngay khi tab đổi trang.
/// Trang chủ đang hiện hay không — BrowserView đọc để bỏ dải rừng đước ở nền (trang chủ tự vẽ dải riêng).
struct HomeShownKey: PreferenceKey {
    static var defaultValue = false
    static func reduce(value: inout Bool, nextValue: () -> Bool) { value = value || nextValue() }
}

struct HomeOverlay: View {
    @ObservedObject var tab: Tab

    var body: some View {
        ZStack {
            if tab.showsHome {
                CaMauHomeView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .transition(.opacity)
            }
        }
        .animation(.easeOut(duration: 0.15), value: tab.showsHome)
        .preference(key: HomeShownKey.self, value: tab.showsHome)
    }
}

/// Webview của tab. Ở trang chủ thì ẩn đi (và không nhận chạm) để nền chung của app hiện xuyên qua lớp phủ trang chủ.
struct WebHost: View {
    @ObservedObject var tab: Tab

    var body: some View {
        WebViewContainer(webView: tab.webView)
            .opacity(tab.showsHome ? 0 : 1)
            .allowsHitTesting(!tab.showsHome)
            .animation(.easeOut(duration: 0.15), value: tab.showsHome)
    }
}

private enum Glyph {
    case sf(String)
    case asset(String)
}

private struct HomeLink: Identifiable {
    let id = UUID()
    let title: String
    var subtitle: String = ""
    let url: String
    let glyph: Glyph
    let c1: UInt32
    let c2: UInt32
}

private struct BottomRound: Shape {
    var radius: CGFloat
    func path(in rect: CGRect) -> Path {
        Path(UIBezierPath(roundedRect: rect,
                          byRoundingCorners: [.bottomLeft, .bottomRight],
                          cornerRadii: CGSize(width: radius, height: radius)).cgPath)
    }
}

struct CaMauHomeView: View {
    @EnvironmentObject private var browser: BrowserModel
    @ObservedObject private var library = LibraryStore.shared
    @ObservedObject private var libLock = LibraryLock.shared
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var query = ""
    @State private var typed = ""
    @State private var factIndex = 0
    @FocusState private var searchFocused: Bool

    private let welcome = "Cà Mau Browser xin chào!"

    private let quick: [HomeLink] = [
        HomeLink(title: "Google", url: "https://www.google.com", glyph: .sf("magnifyingglass"), c1: 0x4285F4, c2: 0x1A5FD0),
        HomeLink(title: "YouTube", url: "https://m.youtube.com", glyph: .sf("play.rectangle.fill"), c1: 0xFF4B4B, c2: 0xC4161C),
        HomeLink(title: "Facebook", url: "https://m.facebook.com", glyph: .sf("person.2.fill"), c1: 0x3B82F6, c2: 0x1D4ED8),
        HomeLink(title: "Báo Cà Mau", url: "https://baocamau.vn", glyph: .sf("newspaper.fill"), c1: 0x16A34A, c2: 0x0B6B34),
        HomeLink(title: "Về Cà Mau", url: "https://vi.wikipedia.org/wiki/C%C3%A0_Mau", glyph: .sf("book.fill"), c1: 0xD9A21F, c2: 0xA8700B),
        HomeLink(title: "Thời tiết", url: "https://www.google.com/search?q=th%E1%BB%9Di+ti%E1%BA%BFt+C%C3%A0+Mau", glyph: .sf("cloud.sun.fill"), c1: 0x0EA5C6, c2: 0x0A6E8A)
    ]

    private let discover: [HomeLink] = [
        HomeLink(title: "Mũi Cà Mau", subtitle: "Điểm cực Nam Tổ quốc",
                 url: "https://www.google.com/search?q=M%C5%A9i%20C%C3%A0%20Mau", glyph: .sf("mappin.circle.fill"), c1: 0x0F8A4F, c2: 0xC8941F),
        HomeLink(title: "U Minh Hạ", subtitle: "Rừng tràm, rừng đước",
                 url: "https://www.google.com/search?q=r%E1%BB%ABng%20U%20Minh%20H%E1%BA%A1%20C%C3%A0%20Mau", glyph: .asset("ic_leaf"), c1: 0x14703F, c2: 0x0B4A5E),
        HomeLink(title: "Cua & tôm", subtitle: "Đặc sản đất Mũi",
                 url: "https://www.google.com/search?q=%C4%91%E1%BA%B7c%20s%E1%BA%A3n%20cua%20t%C3%B4m%20C%C3%A0%20Mau", glyph: .asset("ic_shrimp"), c1: 0xE2672A, c2: 0xA23A12),
        HomeLink(title: "Hòn Đá Bạc", subtitle: "Biển Tây Cà Mau",
                 url: "https://www.google.com/search?q=H%C3%B2n%20%C4%90%C3%A1%20B%E1%BA%A1c%20C%C3%A0%20Mau", glyph: .asset("ic_drop"), c1: 0x0EA5C6, c2: 0x14537A)
    ]

    private let facts = [
        "**Mũi Cà Mau** là điểm cực Nam trên đất liền của Tổ quốc.",
        "Rừng đước, mắm, vẹt tạo nên một trong những vùng **rừng ngập mặn** lớn nhất cả nước.",
        "Đêm xuống, **đom đóm** lấp lánh trên những tán cây ven sông.",
        "**Xuồng ba lá** và nón lá – hình ảnh quen thuộc của miền sông nước.",
        "Mật ong rừng **U Minh** là đặc sản nổi tiếng của vùng đất này."
    ]

    /// Tối đa 3 trang vừa xem (mỗi trang web một ô). Ẩn khi khoá thư viện hoặc đang ở tab riêng tư.
    private var recents: [(String, String)] {
        guard !libLock.enabled, !browser.isPrivate else { return [] }
        let saved = Set(marks.map { $0.url })
        var hosts = Set<String>()
        var out: [(String, String)] = []
        for p in library.history {
            guard !saved.contains(p.url), let u = URL(string: p.url), let h = u.host, hosts.insert(h).inserted else { continue }
            out.append((p.title.isEmpty ? h.replacingOccurrences(of: "www.", with: "") : p.title, p.url))
            if out.count == 3 { break }
        }
        return out
    }

    private var marks: [SavedPage] {
        libLock.enabled ? [] : Array(library.bookmarks.prefix(6))
    }

    var body: some View {
        // Không vẽ nền ở đây: BrowserView đã có ScreenBackground toàn màn hình (gradient, đom đóm,
        // tranh rừng đước ở đáy). Vẽ thêm một lớp nữa sẽ làm hai tranh đáy chồng lên nhau.
        ZStack {
            // Dải sông cuối trang (rừng đước + cá, tôm, cua): nằm ngay trên thanh công cụ, cuộn hết trang là thấy rõ.
            if ThemePalette.current == 1 {
                ZStack(alignment: .bottom) {
                    CaMauFooterArt()
                    CaMauCritters()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                .allowsHitTesting(false)
            }
            ScrollView {
                VStack(spacing: 0) {
                    hero
                    VStack(alignment: .leading, spacing: 0) {
                        searchBar
                            .padding(.top, -28)
                            .padding(.bottom, 22)
                        header("TRUY CẬP NHANH")
                        grid(quick.map { ($0.title, $0.url, $0.glyph, $0.c1, $0.c2) })
                        if !marks.isEmpty {
                            header("DẤU TRANG CỦA BẠN").padding(.top, 20)
                            grid(marks.map { m in
                                (m.title.isEmpty ? (URL(string: m.url)?.host ?? m.url) : m.title,
                                 m.url, Glyph.sf("bookmark.fill"), UInt32(0xD9A21F), UInt32(0xA8700B))
                            })
                        }
                        if !recents.isEmpty {
                            header("GẦN ĐÂY").padding(.top, 20)
                            grid(recents.map { ($0.0, $0.1, Glyph.sf("clock.fill"), UInt32(0x6B7A99), UInt32(0x44506B)) })
                        }
                        header("KHÁM PHÁ CÀ MAU").padding(.top, 20)
                        rail
                        fact
                    }
                    .padding(.horizontal, 16)
                    Spacer(minLength: 110)
                }
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .task { await typeWelcome() }
        .onReceive(Timer.publish(every: 7, on: .main, in: .common).autoconnect()) { _ in
            withAnimation(.easeInOut(duration: 0.5)) { factIndex = (factIndex + 1) % facts.count }
        }
    }

    // MARK: Ảnh bìa

    private var hero: some View {
        ZStack(alignment: .topLeading) {
            // Khung quyết định kích thước; ảnh chỉ được vẽ tràn trong overlay để scaledToFill
            // không làm rộng cả cột nội dung (ảnh 360x170 phóng theo chiều cao sẽ rộng ~550pt).
            Color.clear
                .frame(maxWidth: .infinity)
                .frame(height: 260)
                .overlay {
                    Image("camau_banner")
                        .resizable()
                        .interpolation(.high)
                        .scaledToFill()
                }
                .clipped()
            LinearGradient(colors: [Color.black.opacity(0.46), .clear, .clear, Color.black.opacity(0.30)],
                           startPoint: .top, endPoint: .bottom)
            CaMauAmbient()
            HeroBirds()
            VStack(alignment: .leading, spacing: 4) {
                Text("\(greeting) 🌿")
                    .font(.system(size: 13, weight: .bold))
                HStack(spacing: 3) {
                    Text(typed.isEmpty ? " " : typed)
                        .font(.system(size: 23, weight: .heavy))
                    Caret()
                }
            }
            .foregroundStyle(.white)
            .shadow(color: .black.opacity(0.5), radius: 5, y: 2)
            .padding(.leading, 20)
            .padding(.top, 16)
            .frame(maxWidth: 260, alignment: .leading)
        }
        .frame(height: 260)
        .overlay(alignment: .topTrailing) {
            Text(dateText)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color.black.opacity(0.28), in: Capsule())
                .padding(.trailing, 16)
                .padding(.top, 14)
        }
        .clipShape(BottomRound(radius: 32))
        .shadow(color: .black.opacity(0.18), radius: 12, y: 6)
    }

    private var greeting: String {
        let h = Calendar.current.component(.hour, from: Date())
        switch h {
        case 0..<5: return "Khuya rồi, nghỉ ngơi nhé"
        case 5..<11: return "Chào buổi sáng"
        case 11..<14: return "Chào buổi trưa"
        case 14..<18: return "Chào buổi chiều"
        default: return "Chào buổi tối"
        }
    }

    private var dateText: String {
        let c = Calendar.current
        let d = Date()
        let names = ["CN", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"]
        let wd = c.component(.weekday, from: d) - 1
        return "\(names[max(0, min(6, wd))]), \(c.component(.day, from: d))/\(c.component(.month, from: d))"
    }

    @MainActor
    private func typeWelcome() async {
        if reduceMotion { typed = welcome; return }
        typed = ""
        try? await Task.sleep(nanoseconds: 500_000_000)
        for ch in welcome {
            if Task.isCancelled { return }
            typed.append(ch)
            try? await Task.sleep(nanoseconds: 62_000_000)
        }
    }

    // MARK: Ô tìm kiếm

    private var searchBar: some View {
        HStack(spacing: 8) {
            TextField("Tìm kiếm trên web", text: $query)
                .focused($searchFocused)
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)
                .onSubmit(submit)
            Button(action: submit) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(Theme.gradient, in: Circle())
            }
            .buttonStyle(PressStyle())
            .accessibilityLabel("Tìm kiếm")
        }
        .padding(.leading, 18)
        .padding(7)
        .background(Theme.card, in: Capsule())
        .overlay(Capsule().strokeBorder(Theme.cardStroke, lineWidth: 1))
        .shadow(color: .black.opacity(0.14), radius: 10, y: 4)
    }

    private func submit() {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        searchFocused = false
        query = ""
        browser.search(q)
    }

    // MARK: Lối tắt & thẻ

    private func header(_ t: String) -> some View {
        HStack(spacing: 8) {
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .fill(Theme.gradient)
                .frame(width: 4, height: 14)
            Text(t)
                .font(.system(size: 12, weight: .heavy))
                .tracking(0.9)
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 4)
        .padding(.bottom, 10)
    }

    private func glyphView(_ g: Glyph, size: CGFloat) -> some View {
        Group {
            switch g {
            case .sf(let n): Image(systemName: n).font(.system(size: size, weight: .semibold))
            case .asset(let n): SVGIcon(name: n, size: size + 2)
            }
        }
    }

    private func grid(_ items: [(String, String, Glyph, UInt32, UInt32)]) -> some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 3), spacing: 12) {
            ForEach(Array(items.enumerated()), id: \.offset) { _, it in
                Button { browser.go(it.1) } label: {
                    VStack(spacing: 9) {
                        glyphView(it.2, size: 22)
                            .foregroundStyle(.white)
                            .frame(width: 48, height: 48)
                            .background(LinearGradient(colors: [Color(hex: it.3), Color(hex: it.4)],
                                                       startPoint: .topLeading, endPoint: .bottomTrailing),
                                        in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .shadow(color: Color(hex: it.4).opacity(0.45), radius: 6, y: 3)
                        Text(it.0)
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                            .foregroundStyle(.primary)
                            .lineLimit(2)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                    }
                    .padding(.top, 15)
                    .padding(.bottom, 12)
                    .padding(.horizontal, 6)
                    .frame(maxWidth: .infinity)
                    .background(Theme.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .strokeBorder(Theme.cardStroke, lineWidth: 1))
                }
                .buttonStyle(PressStyle())
            }
        }
    }

    private var rail: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(discover) { c in
                    Button { browser.go(c.url) } label: {
                        ZStack(alignment: .bottomTrailing) {
                            glyphView(c.glyph, size: 62)
                                .foregroundStyle(.white.opacity(0.28))
                                .offset(x: 8, y: 10)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(c.title).font(.system(size: 15, weight: .heavy))
                                Text(c.subtitle).font(.system(size: 11.5, weight: .semibold)).opacity(0.92)
                            }
                            .foregroundStyle(.white)
                            .shadow(color: .black.opacity(0.35), radius: 2, y: 1)
                            .padding(13)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                        }
                        .frame(width: 158, height: 104)
                        .background(LinearGradient(colors: [Color(hex: c.c1), Color(hex: c.c2)],
                                                   startPoint: .topLeading, endPoint: .bottomTrailing))
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .shadow(color: Color(hex: c.c2).opacity(0.35), radius: 8, y: 4)
                    }
                    .buttonStyle(PressStyle())
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 2)
            .padding(.bottom, 12)
        }
        .padding(.horizontal, -16)   // cho dải cuộn tràn sát mép màn hình, thẻ đầu vẫn thẳng lề
    }

    private var fact: some View {
        Text(LocalizedStringKey(facts[factIndex]))
            .font(.system(size: 13))
            .foregroundStyle(.secondary)
            .multilineTextAlignment(.center)
            .padding(.vertical, 10)
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity, minHeight: 44)
            .background(Theme.card.opacity(0.85), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .padding(.top, 10)
            .id(factIndex)
            .transition(.opacity)
    }
}

/// Con trỏ nhấp nháy sau dòng chữ chào.
private struct Caret: View {
    @State private var on = true
    var body: some View {
        Rectangle()
            .fill(.white)
            .frame(width: 3, height: 22)
            .opacity(on ? 1 : 0)
            .onAppear {
                withAnimation(.easeInOut(duration: 0.45).repeatForever(autoreverses: true)) { on = false }
            }
    }
}

/// Đàn chim bay ngang bầu trời ban ngày (tắt khi trời tối hoặc bật "Giảm chuyển động").
private struct HeroBirds: View {
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var phase

    var body: some View {
        if scheme == .dark || reduceMotion || phase != .active {
            EmptyView()
        } else {
            TimelineView(.animation(minimumInterval: 1.0 / 24.0)) { tl in
                Canvas { ctx, size in
                    let t = tl.date.timeIntervalSinceReferenceDate
                    let span = Double(size.width) + 200
                    let x0 = (t * 14).truncatingRemainder(dividingBy: span) - 100
                    let flock: [(Double, Double, Double)] = [(0, 0, 1.0), (22, -8, 0.8), (-20, -10, 0.7), (42, 8, 0.6)]
                    for (i, b) in flock.enumerated() {
                        let flap = sin(t * 9 + Double(i))
                        let y = Double(size.height) * 0.22 + b.1 + sin(t * 0.8 + Double(i)) * 3
                        drawBird(&ctx, x: x0 + b.0, y: y, s: b.2, flap: flap)
                    }
                }
            }
            .allowsHitTesting(false)
            .accessibilityHidden(true)
        }
    }

    private func drawBird(_ ctx: inout GraphicsContext, x: Double, y: Double, s: Double, flap: Double) {
        let w = 12 * s
        let h = 5 * s * flap
        var p = Path()
        p.move(to: CGPoint(x: x - w, y: y + h * 0.3))
        p.addQuadCurve(to: CGPoint(x: x, y: y), control: CGPoint(x: x - w * 0.5, y: y - h))
        p.addQuadCurve(to: CGPoint(x: x + w, y: y + h * 0.3), control: CGPoint(x: x + w * 0.5, y: y - h))
        ctx.stroke(p, with: .color(Color.white.opacity(0.92)),
                   style: StrokeStyle(lineWidth: 1.4 * s, lineCap: .round, lineJoin: .round))
    }
}
