import Foundation

/// Trang chủ Cà Mau dựng sẵn trong app: tranh SVG động (ngày/đêm theo giao diện),
/// lời chào gõ chữ, ô tìm kiếm và lối tắt. Không cần mạng để hiển thị.
enum CaMauHome {
    /// `bookmarks`: tối đa vài dấu trang gần nhất (title, url) để hiện thành lối tắt riêng của bạn.
    static func html(searchBase: String, bookmarks: [(title: String, url: String)] = []) -> String {
        var extra = ""
        if !bookmarks.isEmpty {
            var tiles = ""
            for (i, b) in bookmarks.prefix(6).enumerated() {
                let name = b.title.isEmpty ? (URL(string: b.url)?.host ?? b.url) : b.title
                tiles += "<a class=\"tile\" style=\"--i:\(i + 6)\" href=\"\(esc(b.url))\"><span class=\"ico\">🔖</span><span class=\"nm\">\(esc(name))</span></a>\n"
            }
            extra = "<h2 style=\"margin-top:20px\">DẤU TRANG CỦA BẠN</h2><div class=\"grid\">\n" + tiles + "</div>"
        }
        return template
            .replacingOccurrences(of: "__SEARCH__", with: esc(searchBase))
            .replacingOccurrences(of: "__BOOKMARKS__", with: extra)
    }

    private static func esc(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }

    private static let template = ##"""
<!doctype html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="color-scheme" content="light dark"><title>CM Browser</title>
<style>
:root{--bg1:#F6FAF1;--bg2:#E2EEDA;--card:rgba(255,255,255,.96);--txt:#0B2A1A;--sub:#557562;--acc:#0F8A4F;--acc2:#C8941F;--stroke:rgba(15,138,79,.26);--chip:rgba(15,138,79,.13);--shadow:0 6px 18px rgba(10,60,30,.12)}
@media(prefers-color-scheme:dark){:root{--bg1:#07120C;--bg2:#0E1F15;--card:rgba(26,43,32,.82);--txt:#EAF7EE;--sub:#9DBFA9;--acc:#4ADE80;--acc2:#FBBF24;--stroke:rgba(134,239,172,.24);--chip:rgba(134,239,172,.15);--shadow:0 6px 18px rgba(0,0,0,.35)}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0}
body{min-height:100vh;background:linear-gradient(var(--bg1),var(--bg2)) fixed;font-family:-apple-system,"SF Pro Rounded",system-ui,sans-serif;color:var(--txt);padding-bottom:calc(28px + env(safe-area-inset-bottom))}
.hero{position:relative;height:250px;overflow:hidden;border-radius:0 0 28px 28px;box-shadow:var(--shadow)}
.hero svg{position:absolute;inset:0;width:100%;height:100%}
.hero .night{display:none}
@media(prefers-color-scheme:dark){.hero .day{display:none}.hero .night{display:block}}
.hero:after{content:"";position:absolute;inset:0;background:linear-gradient(to bottom,rgba(0,0,0,0) 38%,rgba(0,0,0,.58))}
.greet{position:absolute;left:20px;right:20px;bottom:44px;z-index:2;color:#fff;text-shadow:0 2px 8px rgba(0,0,0,.45)}
.greet small{display:block;font-size:13px;font-weight:600;opacity:.95;letter-spacing:.3px;margin-bottom:4px;animation:fadeUp .8s .2s both}
.greet h1{margin:0;font-size:27px;font-weight:800;letter-spacing:.2px;min-height:34px}
.caret{display:inline-block;width:3px;height:26px;margin-left:3px;background:#fff;vertical-align:-4px;animation:blink .9s steps(1) infinite}
.date{position:absolute;right:16px;top:calc(14px + env(safe-area-inset-top));z-index:2;color:#fff;font-size:12px;font-weight:700;padding:6px 11px;border-radius:99px;background:rgba(0,0,0,.28);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);animation:fadeUp .8s .5s both}
.wrap{padding:0 16px}
form{position:relative;z-index:3;margin:-26px 0 20px;display:flex;gap:8px;align-items:center;padding:7px 7px 7px 18px;background:var(--card);border:1px solid var(--stroke);border-radius:99px;box-shadow:var(--shadow);animation:fadeUp .7s .35s both}
form input{flex:1;min-width:0;border:0;outline:0;background:transparent;font-size:16px;color:var(--txt);font-family:inherit}
form input::placeholder{color:var(--sub)}
form button{border:0;border-radius:99px;width:42px;height:42px;display:grid;place-items:center;background:linear-gradient(135deg,var(--acc),var(--acc2));color:#fff;box-shadow:0 4px 10px rgba(15,138,79,.35)}
form button svg{width:20px;height:20px}
h2{font-size:12px;letter-spacing:.9px;color:var(--sub);margin:4px 4px 10px;font-weight:800;display:flex;align-items:center;gap:8px}
h2:before{content:"";width:4px;height:14px;border-radius:4px;background:linear-gradient(var(--acc),var(--acc2))}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.tile{display:flex;flex-direction:column;align-items:center;gap:8px;padding:14px 6px 12px;text-decoration:none;color:var(--txt);background:var(--card);border:1px solid var(--stroke);border-radius:20px;box-shadow:var(--shadow);font-size:13px;font-weight:700;opacity:0;animation:fadeUp .6s calc(.45s + var(--i)*.07s) both;transition:transform .15s}
.tile:active{transform:scale(.94)}
.ico{width:46px;height:46px;border-radius:15px;display:grid;place-items:center;font-size:24px;background:var(--chip)}
.nm{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-align:center;line-height:1.25;max-width:100%;word-break:break-word}
.quote{margin:22px 8px 0;text-align:center;font-size:13px;line-height:1.5;color:var(--sub);animation:fadeUp .8s 1.1s both}
.quote b{color:var(--acc);font-weight:800}
/* hoạt hoạ tranh */
.sun{transform-box:fill-box;transform-origin:center;animation:pulse 4s ease-in-out infinite}
.stars circle{animation:twinkle 3s ease-in-out infinite}.stars circle:nth-child(2n){animation-delay:1.2s}
.birds{animation:fly 16s linear infinite}
.wing{transform-box:fill-box;transform-origin:center;animation:flap .7s ease-in-out infinite alternate}
.boatwrap{animation:drift 20s ease-in-out infinite alternate}
.boat{animation:bob 3.2s ease-in-out infinite}
.lamp{animation:pulse 2.4s ease-in-out infinite;transform-box:fill-box;transform-origin:center}
.rip{animation:shimmer 3s ease-in-out infinite}.r1{animation-delay:.6s}.r2{animation-delay:1.2s}.r3{animation-delay:1.8s}.r4{animation-delay:2.4s}
.sway{transform-box:fill-box;transform-origin:50% 100%;animation:sway 5s ease-in-out infinite alternate}.s1{animation-delay:1.4s}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
@keyframes blink{50%{opacity:0}}
@keyframes pulse{50%{transform:scale(1.12);opacity:.88}}
@keyframes twinkle{50%{opacity:.25}}
@keyframes fly{from{transform:translateX(-140px)}to{transform:translateX(420px)}}
@keyframes flap{from{transform:scaleY(1)}to{transform:scaleY(-.55)}}
@keyframes drift{from{transform:translateX(-70px)}to{transform:translateX(110px)}}
@keyframes bob{0%,100%{transform:translate(176px,112px) rotate(-2deg)}50%{transform:translate(176px,114.5px) rotate(2deg)}}
@keyframes shimmer{50%{opacity:.08;transform:translateX(10px)}}
@keyframes sway{from{transform:rotate(-1.6deg)}to{transform:rotate(1.6deg)}}
@media(prefers-reduced-motion:reduce){*{animation:none!important}.tile{opacity:1}}
</style></head><body>
<div class="hero"><svg class="day" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 140" preserveAspectRatio="xMidYMid slice"><defs><radialGradient id="glowd"><stop offset="0" stop-color="#FFF3C4" stop-opacity=".95"/><stop offset="1" stop-color="#FFF3C4" stop-opacity="0"/></radialGradient><linearGradient id="skyd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE3A0"/><stop offset=".55" stop-color="#FFC98A"/><stop offset="1" stop-color="#CDE8B2"/></linearGradient><linearGradient id="wtd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F0C46E"/><stop offset="1" stop-color="#C98E3C"/></linearGradient></defs><rect width="360" height="140" fill="url(#skyd)"/><g class="sun"><circle cx="268" cy="64" r="46" fill="url(#glowd)"/><circle cx="268" cy="64" r="19" fill="#FFF6D2"/></g><g class="birds"><path class="wing" d="M102 34 Q106 28 110 34 Q114 28 118 34" fill="none" stroke="#FFFFFF" stroke-width="1.6" stroke-linecap="round"/><path class="wing" d="M121.6 28 Q124.8 23.2 128 28 Q131.2 23.2 134.4 28" fill="none" stroke="#FFFFFF" stroke-width="1.6" stroke-linecap="round"/><path class="wing" d="M92.4 24 Q95.2 19.8 98 24 Q100.8 19.8 103.6 24" fill="none" stroke="#FFFFFF" stroke-width="1.6" stroke-linecap="round"/></g><path d="M0 88 Q20 70 42 82 Q60 66 86 80 Q108 64 130 80 Q156 68 178 82 Q204 66 230 80 Q256 70 280 82 Q310 68 336 80 L360 78 L360 100 L0 100Z" fill="#4C9A66" fill-opacity=".75"/><rect y="92" width="360" height="48" fill="url(#wtd)"/><g class="rips"><path class="rip r0" d="M30 102 L110 102" stroke="#FFFFFF" stroke-opacity="0.28" stroke-width="1.6" stroke-linecap="round"/><path class="rip r1" d="M150 110 L260 110" stroke="#FFFFFF" stroke-opacity="0.28" stroke-width="1.6" stroke-linecap="round"/><path class="rip r2" d="M60 118 L140 118" stroke="#FFFFFF" stroke-opacity="0.28" stroke-width="1.6" stroke-linecap="round"/><path class="rip r3" d="M220 124 L320 124" stroke="#FFFFFF" stroke-opacity="0.28" stroke-width="1.6" stroke-linecap="round"/><path class="rip r4" d="M100 130 L190 130" stroke="#FFFFFF" stroke-opacity="0.28" stroke-width="1.6" stroke-linecap="round"/></g><g transform="translate(52 98) scale(1.0)"><g class="sway s0"><path d="M0 0 L0 -18" stroke="#5A3B1C" stroke-width="3.2" stroke-linecap="round"/><path d="M-3.3 -16 Q-19.8 -8 -22 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M-2.1 -16 Q-12.6 -8 -14 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M-0.8999999999999999 -16 Q-5.4 -8 -6 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M0.8999999999999999 -16 Q5.4 -8 6 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M2.1 -16 Q12.6 -8 14 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M3.3 -16 Q19.8 -8 22 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="0" cy="-30" rx="26" ry="15" fill="#135A31"/><ellipse cx="-16" cy="-24" rx="15" ry="10" fill="#135A31"/><ellipse cx="17" cy="-25" rx="15" ry="10" fill="#135A31"/><ellipse cx="2" cy="-40" rx="14" ry="9" fill="#135A31"/></g></g><g transform="translate(122 96) scale(0.78)"><g class="sway s1"><path d="M0 0 L0 -18" stroke="#5A3B1C" stroke-width="3.2" stroke-linecap="round"/><path d="M-3.3 -16 Q-19.8 -8 -22 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M-2.1 -16 Q-12.6 -8 -14 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M-0.8999999999999999 -16 Q-5.4 -8 -6 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M0.8999999999999999 -16 Q5.4 -8 6 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M2.1 -16 Q12.6 -8 14 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M3.3 -16 Q19.8 -8 22 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="0" cy="-30" rx="26" ry="15" fill="#1F7A45"/><ellipse cx="-16" cy="-24" rx="15" ry="10" fill="#1F7A45"/><ellipse cx="17" cy="-25" rx="15" ry="10" fill="#1F7A45"/><ellipse cx="2" cy="-40" rx="14" ry="9" fill="#1F7A45"/></g></g><g transform="translate(318 100) scale(1.05)"><g class="sway s1"><path d="M0 0 L0 -18" stroke="#5A3B1C" stroke-width="3.2" stroke-linecap="round"/><path d="M-3.3 -16 Q-19.8 -8 -22 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M-2.1 -16 Q-12.6 -8 -14 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M-0.8999999999999999 -16 Q-5.4 -8 -6 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M0.8999999999999999 -16 Q5.4 -8 6 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M2.1 -16 Q12.6 -8 14 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M3.3 -16 Q19.8 -8 22 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="0" cy="-30" rx="26" ry="15" fill="#135A31"/><ellipse cx="-16" cy="-24" rx="15" ry="10" fill="#135A31"/><ellipse cx="17" cy="-25" rx="15" ry="10" fill="#135A31"/><ellipse cx="2" cy="-40" rx="14" ry="9" fill="#135A31"/></g></g><g transform="translate(250 97) scale(0.7)"><g class="sway s0"><path d="M0 0 L0 -18" stroke="#5A3B1C" stroke-width="3.2" stroke-linecap="round"/><path d="M-3.3 -16 Q-19.8 -8 -22 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M-2.1 -16 Q-12.6 -8 -14 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M-0.8999999999999999 -16 Q-5.4 -8 -6 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M0.8999999999999999 -16 Q5.4 -8 6 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M2.1 -16 Q12.6 -8 14 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><path d="M3.3 -16 Q19.8 -8 22 8" fill="none" stroke="#5A3B1C" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="0" cy="-30" rx="26" ry="15" fill="#1F7A45"/><ellipse cx="-16" cy="-24" rx="15" ry="10" fill="#1F7A45"/><ellipse cx="17" cy="-25" rx="15" ry="10" fill="#1F7A45"/><ellipse cx="2" cy="-40" rx="14" ry="9" fill="#1F7A45"/></g></g><g class="boatwrap"><g class="boat" transform="translate(176 112)"><path d="M-34 0 Q0 12 34 0 L28 -5 L-28 -5Z" fill="#4A2E14"/><path d="M-6 -5 L-6 -19 Q0 -27 6 -19 L6 -5Z" fill="#4A2E14" fill-opacity=".92"/><path d="M-11 -23 L0 -34 L11 -23Z" fill="#F5E6B8"/><path d="M12 -4 L40 -14" stroke="#4A2E14" stroke-width="2" stroke-linecap="round"/></g></g></svg><svg class="night" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 140" preserveAspectRatio="xMidYMid slice"><defs><radialGradient id="glown"><stop offset="0" stop-color="#BFE9F2" stop-opacity=".55"/><stop offset="1" stop-color="#BFE9F2" stop-opacity="0"/></radialGradient><linearGradient id="skyn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0A1B2B"/><stop offset=".55" stop-color="#173B3A"/><stop offset="1" stop-color="#1F5A44"/></linearGradient><linearGradient id="wtn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1B5560"/><stop offset="1" stop-color="#0E3340"/></linearGradient></defs><rect width="360" height="140" fill="url(#skyn)"/><g class="sun"><circle cx="268" cy="58" r="40" fill="url(#glown)"/><circle cx="268" cy="58" r="15" fill="#F4F1D8"/><circle cx="274" cy="54" r="13" fill="#173B3A"/></g><g class="stars"><circle cx="40" cy="20" r="1.4" fill="#FFFFFF" fill-opacity=".85"/><circle cx="90" cy="34" r="1.1" fill="#FFFFFF" fill-opacity=".85"/><circle cx="150" cy="16" r="1.5" fill="#FFFFFF" fill-opacity=".85"/><circle cx="200" cy="40" r="1" fill="#FFFFFF" fill-opacity=".85"/><circle cx="320" cy="28" r="1.3" fill="#FFFFFF" fill-opacity=".85"/><circle cx="120" cy="52" r="1" fill="#FFFFFF" fill-opacity=".85"/></g><g class="birds"><path class="wing" d="M102 34 Q106 28 110 34 Q114 28 118 34" fill="none" stroke="#CFE8E0" stroke-width="1.6" stroke-linecap="round"/><path class="wing" d="M121.6 28 Q124.8 23.2 128 28 Q131.2 23.2 134.4 28" fill="none" stroke="#CFE8E0" stroke-width="1.6" stroke-linecap="round"/><path class="wing" d="M92.4 24 Q95.2 19.8 98 24 Q100.8 19.8 103.6 24" fill="none" stroke="#CFE8E0" stroke-width="1.6" stroke-linecap="round"/></g><path d="M0 88 Q20 70 42 82 Q60 66 86 80 Q108 64 130 80 Q156 68 178 82 Q204 66 230 80 Q256 70 280 82 Q310 68 336 80 L360 78 L360 100 L0 100Z" fill="#1D5A3F" fill-opacity=".75"/><rect y="92" width="360" height="48" fill="url(#wtn)"/><g class="rips"><path class="rip r0" d="M30 102 L110 102" stroke="#BFE9F2" stroke-opacity="0.18" stroke-width="1.6" stroke-linecap="round"/><path class="rip r1" d="M150 110 L260 110" stroke="#BFE9F2" stroke-opacity="0.18" stroke-width="1.6" stroke-linecap="round"/><path class="rip r2" d="M60 118 L140 118" stroke="#BFE9F2" stroke-opacity="0.18" stroke-width="1.6" stroke-linecap="round"/><path class="rip r3" d="M220 124 L320 124" stroke="#BFE9F2" stroke-opacity="0.18" stroke-width="1.6" stroke-linecap="round"/><path class="rip r4" d="M100 130 L190 130" stroke="#BFE9F2" stroke-opacity="0.18" stroke-width="1.6" stroke-linecap="round"/></g><g transform="translate(52 98) scale(1.0)"><g class="sway s0"><path d="M0 0 L0 -18" stroke="#2B1D10" stroke-width="3.2" stroke-linecap="round"/><path d="M-3.3 -16 Q-19.8 -8 -22 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M-2.1 -16 Q-12.6 -8 -14 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M-0.8999999999999999 -16 Q-5.4 -8 -6 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M0.8999999999999999 -16 Q5.4 -8 6 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M2.1 -16 Q12.6 -8 14 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M3.3 -16 Q19.8 -8 22 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="0" cy="-30" rx="26" ry="15" fill="#0A3320"/><ellipse cx="-16" cy="-24" rx="15" ry="10" fill="#0A3320"/><ellipse cx="17" cy="-25" rx="15" ry="10" fill="#0A3320"/><ellipse cx="2" cy="-40" rx="14" ry="9" fill="#0A3320"/></g></g><g transform="translate(122 96) scale(0.78)"><g class="sway s1"><path d="M0 0 L0 -18" stroke="#2B1D10" stroke-width="3.2" stroke-linecap="round"/><path d="M-3.3 -16 Q-19.8 -8 -22 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M-2.1 -16 Q-12.6 -8 -14 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M-0.8999999999999999 -16 Q-5.4 -8 -6 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M0.8999999999999999 -16 Q5.4 -8 6 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M2.1 -16 Q12.6 -8 14 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M3.3 -16 Q19.8 -8 22 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="0" cy="-30" rx="26" ry="15" fill="#0F4A2C"/><ellipse cx="-16" cy="-24" rx="15" ry="10" fill="#0F4A2C"/><ellipse cx="17" cy="-25" rx="15" ry="10" fill="#0F4A2C"/><ellipse cx="2" cy="-40" rx="14" ry="9" fill="#0F4A2C"/></g></g><g transform="translate(318 100) scale(1.05)"><g class="sway s1"><path d="M0 0 L0 -18" stroke="#2B1D10" stroke-width="3.2" stroke-linecap="round"/><path d="M-3.3 -16 Q-19.8 -8 -22 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M-2.1 -16 Q-12.6 -8 -14 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M-0.8999999999999999 -16 Q-5.4 -8 -6 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M0.8999999999999999 -16 Q5.4 -8 6 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M2.1 -16 Q12.6 -8 14 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M3.3 -16 Q19.8 -8 22 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="0" cy="-30" rx="26" ry="15" fill="#0A3320"/><ellipse cx="-16" cy="-24" rx="15" ry="10" fill="#0A3320"/><ellipse cx="17" cy="-25" rx="15" ry="10" fill="#0A3320"/><ellipse cx="2" cy="-40" rx="14" ry="9" fill="#0A3320"/></g></g><g transform="translate(250 97) scale(0.7)"><g class="sway s0"><path d="M0 0 L0 -18" stroke="#2B1D10" stroke-width="3.2" stroke-linecap="round"/><path d="M-3.3 -16 Q-19.8 -8 -22 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M-2.1 -16 Q-12.6 -8 -14 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M-0.8999999999999999 -16 Q-5.4 -8 -6 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M0.8999999999999999 -16 Q5.4 -8 6 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M2.1 -16 Q12.6 -8 14 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><path d="M3.3 -16 Q19.8 -8 22 8" fill="none" stroke="#2B1D10" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="0" cy="-30" rx="26" ry="15" fill="#0F4A2C"/><ellipse cx="-16" cy="-24" rx="15" ry="10" fill="#0F4A2C"/><ellipse cx="17" cy="-25" rx="15" ry="10" fill="#0F4A2C"/><ellipse cx="2" cy="-40" rx="14" ry="9" fill="#0F4A2C"/></g></g><g class="boatwrap"><g class="boat" transform="translate(176 112)"><path d="M-34 0 Q0 12 34 0 L28 -5 L-28 -5Z" fill="#120B05"/><path d="M-6 -5 L-6 -19 Q0 -27 6 -19 L6 -5Z" fill="#120B05" fill-opacity=".92"/><path d="M-11 -23 L0 -34 L11 -23Z" fill="#C9B27A"/><path d="M12 -4 L40 -14" stroke="#120B05" stroke-width="2" stroke-linecap="round"/><circle cx="20" cy="-6" r="2.2" fill="#FFD27A"/><circle class="lamp" cx="20" cy="-6" r="9" fill="url(#glown)"/></g></g></svg>
<div class="date" id="date"></div>
<div class="greet"><small id="sub">Chào bạn!</small><h1><span id="typed"></span><span class="caret"></span></h1></div></div>
<div class="wrap">
<form id="f" autocomplete="off"><input id="q" type="search" enterkeyhint="search" placeholder="Tìm kiếm hoặc nhập địa chỉ" autocapitalize="off" autocorrect="off">
<button type="submit" aria-label="Tìm"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg></button></form>
<h2>TRUY CẬP NHANH</h2>
<div class="grid">
<a class="tile" style="--i:0" href="https://www.google.com"><span class="ico">🔎</span>Google</a>
<a class="tile" style="--i:1" href="https://www.youtube.com"><span class="ico">▶️</span>YouTube</a>
<a class="tile" style="--i:2" href="https://www.facebook.com"><span class="ico">👥</span>Facebook</a>
<a class="tile" style="--i:3" href="https://baocamau.vn"><span class="ico">📰</span>Báo Cà Mau</a>
<a class="tile" style="--i:4" href="https://vi.wikipedia.org/wiki/C%C3%A0_Mau"><span class="ico">📖</span>Về Cà Mau</a>
<a class="tile" style="--i:5" href="https://www.google.com/search?q=th%E1%BB%9Di+ti%E1%BA%BFt+C%C3%A0+Mau"><span class="ico">⛅</span>Thời tiết</a>
</div>
__BOOKMARKS__
<p class="quote"><b>Cà Mau</b> – Đất Mũi, nơi rừng đước xanh, sông nước hữu tình.</p>
</div>
<script>
(function(){
var SEARCH="__SEARCH__";
var d=new Date(),h=d.getHours();
var g=h<5?"Khuya rồi, nghỉ ngơi nhé":h<11?"Chào buổi sáng":h<14?"Chào buổi trưa":h<18?"Chào buổi chiều":"Chào buổi tối";
document.getElementById("sub").textContent=g+" 🌿";
var T=["CN","Thứ 2","Thứ 3","Thứ 4","Thứ 5","Thứ 6","Thứ 7"];
document.getElementById("date").textContent=T[d.getDay()]+", "+d.getDate()+"/"+(d.getMonth()+1);
var txt="Cà Mau Browser xin chào!",i=0,el=document.getElementById("typed");
(function t(){el.textContent=txt.slice(0,i++);if(i<=txt.length)setTimeout(t,i===1?500:62)})();
document.getElementById("f").addEventListener("submit",function(e){
 e.preventDefault();var q=document.getElementById("q").value.trim();if(!q)return;
 var u;
 if(/^https?:\/\//i.test(q))u=q;
 else if(!/\s/.test(q)&&/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(q))u="https://"+q;
 else u=SEARCH+(SEARCH.indexOf("?")<0?"?":"&")+"q="+encodeURIComponent(q);
 location.href=u;});
})();
</script></body></html>
"""##
}
