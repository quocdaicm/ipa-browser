import SwiftUI

/// Hiệu ứng nền cho chủ đề Cà Mau.
/// Tối: đom đóm bập bùng bay quanh. Sáng: phấn hoa lấp lánh và lá đước rơi nhẹ.
/// Tự tắt khi bật "Giảm chuyển động" hoặc Chế độ nguồn điện thấp.
struct CaMauAmbient: View {
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var phase

    private struct P { let x, y, r, sp, ph, dr: Double; let leaf: Bool }

    private static func rnd(_ n: Double) -> Double {
        let v = sin(n * 12.9898 + 78.233) * 43758.5453
        return v - floor(v)
    }

    private static let items: [P] = (0..<28).map { i in
        let d = Double(i)
        return P(x: rnd(d + 1), y: rnd(d + 101), r: 1.2 + rnd(d + 201) * 2.2,
                 sp: 0.25 + rnd(d + 301) * 0.7, ph: rnd(d + 401) * 6.283,
                 dr: 6 + rnd(d + 501) * 10, leaf: rnd(d + 601) < 0.3)
    }

    var body: some View {
        // Tắt khi: giảm chuyển động, nguồn điện thấp, app không ở trước màn hình, hoặc máy đang nóng
        let thermal = ProcessInfo.processInfo.thermalState
        if reduceMotion || ProcessInfo.processInfo.isLowPowerModeEnabled
            || phase != .active || thermal == .serious || thermal == .critical {
            EmptyView()
        } else {
            TimelineView(.animation(minimumInterval: 1.0 / 20.0)) { tl in
                Canvas { ctx, size in
                    draw(&ctx, size, tl.date.timeIntervalSinceReferenceDate)
                }
            }
            .allowsHitTesting(false)
            .accessibilityHidden(true)
        }
    }

    private func draw(_ ctx: inout GraphicsContext, _ size: CGSize, _ t: Double) {
        let dark = scheme == .dark
        let w = Double(size.width), h = Double(size.height)
        for p in Self.items {
            if dark {
                // đom đóm: trôi chậm, nhấp nháy
                let x = (p.x * w + sin(t * p.sp + p.ph) * 34 + cos(t * p.sp * 0.6 + p.ph) * 18)
                let y = (p.y * h * 0.9 + cos(t * p.sp * 0.8 + p.ph) * 26 + sin(t * 0.15 + p.ph) * 12)
                let blink = pow(max(0, sin(t * (1.1 + p.sp) + p.ph)), 3)
                let a = 0.08 + 0.92 * blink
                let g = p.r * 5.5
                let rect = CGRect(x: x - g, y: y - g, width: g * 2, height: g * 2)
                ctx.fill(Path(ellipseIn: rect),
                         with: .radialGradient(Gradient(colors: [Color(red: 0.84, green: 1.0, blue: 0.40).opacity(0.55 * a), .clear]),
                                               center: CGPoint(x: x, y: y), startRadius: 0, endRadius: g))
                ctx.fill(Path(ellipseIn: CGRect(x: x - p.r * 0.5, y: y - p.r * 0.5, width: p.r, height: p.r)),
                         with: .color(Color(red: 0.96, green: 1.0, blue: 0.75).opacity(a)))
            } else if p.leaf {
                // lá đước rơi chéo
                let span = h + 40
                let y = (p.y * span + t * p.dr * 1.6).truncatingRemainder(dividingBy: span) - 20
                let x = p.x * w + sin(t * p.sp + p.ph) * 26 + (y * 0.12)
                var c = ctx
                c.translateBy(x: x.truncatingRemainder(dividingBy: w + 20), y: y)
                c.rotate(by: .radians(t * p.sp * 1.4 + p.ph))
                let leaf = Path(ellipseIn: CGRect(x: -p.r * 2.4, y: -p.r * 0.9, width: p.r * 4.8, height: p.r * 1.8))
                c.fill(leaf, with: .color(Color(red: 0.30, green: 0.62, blue: 0.30).opacity(0.5)))
                var rib = Path(); rib.move(to: CGPoint(x: -p.r * 2.2, y: 0)); rib.addLine(to: CGPoint(x: p.r * 2.2, y: 0))
                c.stroke(rib, with: .color(.white.opacity(0.35)), lineWidth: 0.5)
            } else {
                // phấn hoa nổi lên, lấp lánh
                let span = h + 20
                let y = h - (p.y * span + t * p.dr * 0.7).truncatingRemainder(dividingBy: span) + 10
                let x = p.x * w + sin(t * p.sp + p.ph) * 22
                let a = 0.15 + 0.35 * abs(sin(t * p.sp * 1.7 + p.ph))
                let g = p.r * 3.4
                ctx.fill(Path(ellipseIn: CGRect(x: x - g, y: y - g, width: g * 2, height: g * 2)),
                         with: .radialGradient(Gradient(colors: [Color(red: 0.86, green: 0.70, blue: 0.20).opacity(a), .clear]),
                                               center: CGPoint(x: x, y: y), startRadius: 0, endRadius: g))
            }
        }
    }
}

/// Dải rừng đước + sông vẽ sát đáy màn hình (Assets.xcassets/camau_bg, tự đổi sáng/tối).
struct CaMauFooterArt: View {
    var body: some View {
        Image("camau_bg")
            .resizable()
            .interpolation(.high)
            .antialiased(true)
            .scaledToFit()
            .frame(maxWidth: .infinity)
            .opacity(0.5)
            .mask(LinearGradient(stops: [.init(color: .clear, location: 0),
                                         .init(color: .black, location: 0.45)],
                                 startPoint: .top, endPoint: .bottom))
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}
