import SwiftUI

/// Hiệu ứng nền cho chủ đề Cà Mau.
/// Tối: đom đóm bập bùng bay quanh. Sáng: phấn hoa lấp lánh và lá đước rơi nhẹ.
/// Tự tắt khi bật "Giảm chuyển động" hoặc Chế độ nguồn điện thấp.
struct CaMauAmbient: View {
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var phase

    private struct P { let x, y, r, sp, ph, dr: Double; let leaf: Bool }

    private static func rnd(_ n: Double) -> Double {
        let v = sin(n * 12.9898 + 78.233) * 43758.5453
        return v - floor(v)
    }

    private static let items: [P] = (0..<28).map { i in
        let d = Double(i)
        return P(x: rnd(d + 1), y: rnd(d + 101), r: 1.2 + rnd(d + 201) * 2.2,
                 sp: 0.25 + rnd(d + 301) * 0.7, ph: rnd(d + 401) * 6.283,
                 dr: 6 + rnd(d + 501) * 10, leaf: rnd(d + 601) < 0.3)
    }

    var body: some View {
        // Tắt khi: giảm chuyển động, nguồn điện thấp, app không ở trước màn hình, hoặc máy đang nóng
        let thermal = ProcessInfo.processInfo.thermalState
        if reduceMotion || ProcessInfo.processInfo.isLowPowerModeEnabled
            || phase != .active || thermal == .serious || thermal == .critical {
            EmptyView()
        } else {
            TimelineView(.animation(minimumInterval: 1.0 / 20.0)) { tl in
                Canvas { ctx, size in
                    draw(&ctx, size, tl.date.timeIntervalSinceReferenceDate)
                }
            }
            .allowsHitTesting(false)
            .accessibilityHidden(true)
        }
    }

    private func draw(_ ctx: inout GraphicsContext, _ size: CGSize, _ t: Double) {
        let dark = scheme == .dark
        let w = Double(size.width), h = Double(size.height)
        for p in Self.items {
            if dark {
                // đom đóm: trôi chậm, nhấp nháy
                let x = (p.x * w + sin(t * p.sp + p.ph) * 34 + cos(t * p.sp * 0.6 + p.ph) * 18)
                let y = (p.y * h * 0.9 + cos(t * p.sp * 0.8 + p.ph) * 26 + sin(t * 0.15 + p.ph) * 12)
                let blink = pow(max(0, sin(t * (1.1 + p.sp) + p.ph)), 3)
                let a = 0.08 + 0.92 * blink
                let g = p.r * 5.5
                let rect = CGRect(x: x - g, y: y - g, width: g * 2, height: g * 2)
                ctx.fill(Path(ellipseIn: rect),
                         with: .radialGradient(Gradient(colors: [Color(red: 0.84, green: 1.0, blue: 0.40).opacity(0.55 * a), .clear]),
                                               center: CGPoint(x: x, y: y), startRadius: 0, endRadius: g))
                ctx.fill(Path(ellipseIn: CGRect(x: x - p.r * 0.5, y: y - p.r * 0.5, width: p.r, height: p.r)),
                         with: .color(Color(red: 0.96, green: 1.0, blue: 0.75).opacity(a)))
            } else if p.leaf {
                // lá đước rơi chéo
                let span = h + 40
                let y = (p.y * span + t * p.dr * 1.6).truncatingRemainder(dividingBy: span) - 20
                let x = p.x * w + sin(t * p.sp + p.ph) * 26 + (y * 0.12)
                var c = ctx
                c.translateBy(x: x.truncatingRemainder(dividingBy: w + 20), y: y)
                c.rotate(by: .radians(t * p.sp * 1.4 + p.ph))
                let leaf = Path(ellipseIn: CGRect(x: -p.r * 2.4, y: -p.r * 0.9, width: p.r * 4.8, height: p.r * 1.8))
                c.fill(leaf, with: .color(Color(red: 0.30, green: 0.62, blue: 0.30).opacity(0.5)))
                var rib = Path(); rib.move(to: CGPoint(x: -p.r * 2.2, y: 0)); rib.addLine(to: CGPoint(x: p.r * 2.2, y: 0))
                c.stroke(rib, with: .color(.white.opacity(0.35)), lineWidth: 0.5)
            } else {
                // phấn hoa nổi lên, lấp lánh
                let span = h + 20
                let y = h - (p.y * span + t * p.dr * 0.7).truncatingRemainder(dividingBy: span) + 10
                let x = p.x * w + sin(t * p.sp + p.ph) * 22
                let a = 0.15 + 0.35 * abs(sin(t * p.sp * 1.7 + p.ph))
                let g = p.r * 3.4
                ctx.fill(Path(ellipseIn: CGRect(x: x - g, y: y - g, width: g * 2, height: g * 2)),
                         with: .radialGradient(Gradient(colors: [Color(red: 0.86, green: 0.70, blue: 0.20).opacity(a), .clear]),
                                               center: CGPoint(x: x, y: y), startRadius: 0, endRadius: g))
            }
        }
    }
}

/// Dải rừng đước + sông vẽ sát đáy màn hình (Assets.xcassets/camau_bg, tự đổi sáng/tối).
struct CaMauFooterArt: View {
    var body: some View {
        Image("camau_bg")
            .resizable()
            .interpolation(.high)
            .antialiased(true)
            .scaledToFit()
            .frame(maxWidth: .infinity)
            .opacity(0.5)
            .mask(LinearGradient(stops: [.init(color: .clear, location: 0),
                                         .init(color: .black, location: 0.45)],
                                 startPoint: .top, endPoint: .bottom))
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}

// MARK: - Cá, tôm, cua ở dải sông dưới đáy

/// Vài con cá bơi, con tôm thỉnh thoảng búng, con cua bò ngang bờ — vẽ chồng đúng lên tranh `camau_bg`
/// (cùng khung 3:1, toạ độ 360×120). Tự tắt giống `CaMauAmbient`.
struct CaMauCritters: View {
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var phase

    var body: some View {
        let thermal = ProcessInfo.processInfo.thermalState
        if reduceMotion || ProcessInfo.processInfo.isLowPowerModeEnabled
            || phase != .active || thermal == .serious || thermal == .critical {
            EmptyView()
        } else {
            TimelineView(.animation(minimumInterval: 1.0 / 24.0)) { tl in
                Canvas { ctx, size in
                    ctx.scaleBy(x: size.width / 360, y: size.width / 360)
                    draw(&ctx, tl.date.timeIntervalSinceReferenceDate)
                }
            }
            .aspectRatio(3, contentMode: .fit)
            .frame(maxWidth: .infinity)
            .allowsHitTesting(false)
            .accessibilityHidden(true)
        }
    }

    private var dark: Bool { scheme == .dark }

    private func draw(_ ctx: inout GraphicsContext, _ t: Double) {
        // Cá: (độ cao, tốc độ, kích cỡ, pha, hướng)
        let fish: [(Double, Double, Double, Double, Double)] = [
            (84, 13, 1.0, 0.0, 1), (95, 9, 0.75, 2.1, -1), (89, 17, 0.6, 4.2, 1)
        ]
        for f in fish {
            let span = 360.0 + 80
            var x = (t * f.1 + f.3 * 60).truncatingRemainder(dividingBy: span)
            if f.4 < 0 { x = span - x }
            let y = f.0 + sin(t * 1.3 + f.3) * 1.8
            drawFish(&ctx, x: x - 40, y: y, s: f.2, dir: f.4, wag: sin(t * 8 + f.3))
        }
        drawShrimp(&ctx, t)
        drawCrab(&ctx, t)
        drawMudskipper(&ctx, t)
    }

    private func drawFish(_ ctx: inout GraphicsContext, x: Double, y: Double, s: Double, dir: Double, wag: Double) {
        var c = ctx
        c.translateBy(x: x, y: y)
        c.scaleBy(x: dir * s, y: s)
        let body = dark ? Color(hex: 0x9CC4D8) : Color(hex: 0xF2A65A)
        let fin = dark ? Color(hex: 0x6E9BB3) : Color(hex: 0xE76F51)
        let tail = wag * 3
        var t = Path()
        t.move(to: CGPoint(x: -9, y: 0))
        t.addLine(to: CGPoint(x: -16, y: -5 + tail))
        t.addLine(to: CGPoint(x: -16, y: 5 + tail))
        t.closeSubpath()
        c.fill(t, with: .color(fin.opacity(0.85)))
        c.fill(Path(ellipseIn: CGRect(x: -10, y: -4.5, width: 20, height: 9)), with: .color(body.opacity(0.88)))
        var d = Path()
        d.move(to: CGPoint(x: -3, y: -4)); d.addQuadCurve(to: CGPoint(x: 4, y: -4), control: CGPoint(x: 0, y: -8))
        c.fill(d, with: .color(fin.opacity(0.8)))
        c.fill(Path(ellipseIn: CGRect(x: 4.5, y: -1.8, width: 2, height: 2)), with: .color(.black.opacity(0.7)))
    }

    /// Tôm: nằm gần đáy, râu ngoe nguẩy, thỉnh thoảng búng lùi một đoạn rồi trôi lại.
    private func drawShrimp(_ ctx: inout GraphicsContext, _ t: Double) {
        let period = 7.0
        let local = (t + 2).truncatingRemainder(dividingBy: period)
        // 0–0.3 s: búng nhanh; 0.3–2.5 s: trôi lại từ từ
        let dart: Double = local < 0.3 ? local / 0.3 : max(0, 1 - (local - 0.3) / 2.2)
        let x = 232 - 30 * dart
        let y = 101 + sin(t * 2) * 0.8 - dart * 2
        var c = ctx
        c.translateBy(x: x, y: y)
        let col = dark ? Color(hex: 0xE59A8C) : Color(hex: 0xE76F51)
        var b = Path()
        b.move(to: CGPoint(x: 6, y: -4))
        b.addQuadCurve(to: CGPoint(x: -5, y: -1), control: CGPoint(x: 2, y: -8))
        b.addQuadCurve(to: CGPoint(x: -9, y: 5 - dart * 2), control: CGPoint(x: -10, y: 0))
        c.stroke(b, with: .color(col.opacity(0.95)), style: StrokeStyle(lineWidth: 3.4, lineCap: .round, lineJoin: .round))
        // đuôi xoè
        var tail = Path()
        tail.move(to: CGPoint(x: -9, y: 5 - dart * 2))
        tail.addLine(to: CGPoint(x: -13, y: 7)); tail.move(to: CGPoint(x: -9, y: 5 - dart * 2))
        tail.addLine(to: CGPoint(x: -7, y: 9))
        c.stroke(tail, with: .color(col.opacity(0.9)), style: StrokeStyle(lineWidth: 1.6, lineCap: .round))
        // râu
        let w = sin(t * 5) * 1.5
        var an = Path()
        an.move(to: CGPoint(x: 6, y: -4)); an.addQuadCurve(to: CGPoint(x: 15, y: -8 + w), control: CGPoint(x: 11, y: -8))
        c.stroke(an, with: .color(col.opacity(0.75)), style: StrokeStyle(lineWidth: 0.9, lineCap: .round))
        c.fill(Path(ellipseIn: CGRect(x: 4.6, y: -4.6, width: 1.6, height: 1.6)), with: .color(.black.opacity(0.75)))
    }

    /// Cua: bò ngang trên bờ cạn, chân bước lệch pha, hai càng giơ lên.
    private func drawCrab(_ ctx: inout GraphicsContext, _ t: Double) {
        let x = 150 + sin(t * 0.22) * 55
        let moving = cos(t * 0.22)           // dấu = hướng đi
        let step = t * 7
        var c = ctx
        c.translateBy(x: x, y: 113.5)
        let col = dark ? Color(hex: 0xC9705F) : Color(hex: 0xD64933)
        // chân
        for i in 0..<3 {
            let o = sin(step + Double(i) * 1.7) * 1.2 * (abs(moving) > 0.05 ? 1 : 0.2)
            for side in [-1.0, 1.0] {
                var l = Path()
                l.move(to: CGPoint(x: side * 3, y: 0.5 + Double(i) * 0.8))
                l.addLine(to: CGPoint(x: side * (7 + Double(i)), y: 2.5 + o))
                l.addLine(to: CGPoint(x: side * (9 + Double(i)), y: 5 + o))
                c.stroke(l, with: .color(col.opacity(0.9)), style: StrokeStyle(lineWidth: 1, lineCap: .round, lineJoin: .round))
            }
        }
        // càng
        let wave = sin(t * 3.1) * 1.5
        for side in [-1.0, 1.0] {
            var a = Path()
            a.move(to: CGPoint(x: side * 4, y: -1))
            a.addLine(to: CGPoint(x: side * 8, y: -5 - wave * side))
            c.stroke(a, with: .color(col), style: StrokeStyle(lineWidth: 1.3, lineCap: .round))
            c.fill(Path(ellipseIn: CGRect(x: side * 8 - 2.2, y: -8.4 - wave * side, width: 4.4, height: 4)), with: .color(col))
        }
        // thân + mắt
        c.fill(Path(ellipseIn: CGRect(x: -5.5, y: -3.5, width: 11, height: 7)), with: .color(col))
        for side in [-1.0, 1.0] {
            c.fill(Path(ellipseIn: CGRect(x: side * 2 - 0.9, y: -5.2, width: 1.8, height: 1.8)), with: .color(.black.opacity(0.8)))
        }
    }

    /// Cá thòi lòi: đậu trên bờ bùn, mắt lồi chớp chớp, vây lưng xoè ra rồi cụp lại, thỉnh thoảng bật nhảy sang chỗ khác.
    private func drawMudskipper(_ ctx: inout GraphicsContext, _ t: Double) {
        let stops: [Double] = [250, 276, 258, 292, 268, 240]
        let period = 5.5, hop = 0.55
        let k = Int(floor(t / period))
        let local = t - Double(k) * period
        let a = stops[((k % stops.count) + stops.count) % stops.count]
        let b = stops[(((k + 1) % stops.count) + stops.count) % stops.count]
        let u = min(1, max(0, (local - (period - hop)) / hop))     // chỉ nhảy ở cuối mỗi chu kỳ
        let x = a + (b - a) * u
        let lift = sin(u * .pi) * 8
        // hướng nhìn: về phía điểm sắp tới (đang nhảy) hoặc vừa đến
        let prev = stops[(((k - 1) % stops.count) + stops.count) % stops.count]
        let dir: Double = (u > 0 ? (b >= a ? 1 : -1) : (a >= prev ? 1 : -1))

        var c = ctx
        c.translateBy(x: x, y: 114 - lift)
        c.scaleBy(x: dir * 1.05, y: 1.05)
        let body = dark ? Color(hex: 0x8A8F6A) : Color(hex: 0x7C7A4E)
        let belly = dark ? Color(hex: 0xB5B28C) : Color(hex: 0xC9BF8A)
        let fin = dark ? Color(hex: 0xC98B5E) : Color(hex: 0xD9822B)

        // đuôi
        var tail = Path()
        tail.move(to: CGPoint(x: -6, y: 0))
        tail.addQuadCurve(to: CGPoint(x: -15, y: 2 + sin(t * 6) * (u > 0 ? 2 : 0.6)), control: CGPoint(x: -11, y: -1))
        tail.addQuadCurve(to: CGPoint(x: -6, y: 2.6), control: CGPoint(x: -11, y: 4.5))
        c.fill(tail, with: .color(body.opacity(0.92)))
        // vây lưng: xoè ra khi đậu, cụp khi nhảy
        let open = u > 0 ? 0.2 : 0.55 + 0.45 * max(0, sin(t * 0.9))
        var dorsal = Path()
        dorsal.move(to: CGPoint(x: -5, y: -2.4))
        dorsal.addQuadCurve(to: CGPoint(x: 3, y: -2.6), control: CGPoint(x: -1, y: -2.4 - 8 * open))
        c.fill(dorsal, with: .color(fin.opacity(0.9)))
        // thân
        c.fill(Path(ellipseIn: CGRect(x: -8, y: -3, width: 17, height: 6.4)), with: .color(body))
        c.fill(Path(ellipseIn: CGRect(x: -5, y: 0.2, width: 12, height: 3)), with: .color(belly.opacity(0.85)))
        // vây ngực như cánh tay chống xuống bùn
        var arm = Path()
        arm.move(to: CGPoint(x: 3, y: 2))
        arm.addLine(to: CGPoint(x: 5.5, y: 5))
        c.stroke(arm, with: .color(fin), style: StrokeStyle(lineWidth: 1.6, lineCap: .round))
        // đầu + hai mắt lồi trên đỉnh
        c.fill(Path(ellipseIn: CGRect(x: 4, y: -3.4, width: 7.5, height: 5.4)), with: .color(body))
        let blink = (t.truncatingRemainder(dividingBy: 3.1) < 0.12) ? 0.3 : 1.0
        for ex in [5.2, 8.0] {
            c.fill(Path(ellipseIn: CGRect(x: ex, y: -6.1, width: 2.6, height: 2.6 * blink)), with: .color(belly))
            c.fill(Path(ellipseIn: CGRect(x: ex + 0.8, y: -5.4, width: 1.1, height: 1.1 * blink)), with: .color(.black.opacity(0.85)))
        }
    }
}
