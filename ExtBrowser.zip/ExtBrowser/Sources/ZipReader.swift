import Foundation
import Compression

enum ZipError: Error { case invalid, unsupported }

struct ZipEntry {
    let name: String
    let method: Int
    let compSize: Int
    let size: Int
    let offset: Int
}

/// Đọc file ZIP tối thiểu (stored + deflate). Dùng cho .zip / .xpi / .crx
struct ZipArchive {
    private let b: [UInt8]
    let entries: [ZipEntry]

    private static func u16(_ b: [UInt8], _ i: Int) -> Int {
        Int(b[i]) | (Int(b[i + 1]) << 8)
    }
    private static func u32(_ b: [UInt8], _ i: Int) -> Int {
        u16(b, i) | (u16(b, i + 2) << 16)
    }

    init(data: Data) throws {
        let b = [UInt8](data)
        guard b.count >= 22 else { throw ZipError.invalid }
        var eocd = -1
        var i = b.count - 22
        let lowest = max(0, b.count - 22 - 65535)
        while i >= lowest {
            if b[i] == 0x50 && b[i + 1] == 0x4b && b[i + 2] == 5 && b[i + 3] == 6 {
                eocd = i
                break
            }
            i -= 1
        }
        guard eocd >= 0 else { throw ZipError.invalid }
        let count = Self.u16(b, eocd + 10)
        var p = Self.u32(b, eocd + 16)
        var list: [ZipEntry] = []
        for _ in 0..<count {
            guard p + 46 <= b.count, Self.u32(b, p) == 0x02014b50 else { throw ZipError.invalid }
            let method = Self.u16(b, p + 10)
            let cs = Self.u32(b, p + 20)
            let us = Self.u32(b, p + 24)
            let nl = Self.u16(b, p + 28)
            let el = Self.u16(b, p + 30)
            let cl = Self.u16(b, p + 32)
            let off = Self.u32(b, p + 42)
            guard p + 46 + nl <= b.count else { throw ZipError.invalid }
            let name = String(decoding: b[(p + 46)..<(p + 46 + nl)], as: UTF8.self)
            list.append(ZipEntry(name: name, method: method, compSize: cs, size: us, offset: off))
            p += 46 + nl + el + cl
        }
        self.b = b
        self.entries = list
    }

    func extract(_ e: ZipEntry) throws -> Data {
        let p = e.offset
        guard p + 30 <= b.count, Self.u32(b, p) == 0x04034b50 else { throw ZipError.invalid }
        let nl = Self.u16(b, p + 26)
        let el = Self.u16(b, p + 28)
        let start = p + 30 + nl + el
        guard start + e.compSize <= b.count else { throw ZipError.invalid }
        let comp = Array(b[start..<(start + e.compSize)])
        switch e.method {
        case 0:
            return Data(comp)
        case 8:
            if e.size == 0 { return Data() }
            var out = [UInt8](repeating: 0, count: e.size)
            let n = compression_decode_buffer(&out, e.size, comp, comp.count, nil, COMPRESSION_ZLIB)
            guard n > 0 else { throw ZipError.invalid }
            return Data(out[0..<n])
        default:
            throw ZipError.unsupported
        }
    }
}

/// File .crx = header "Cr24" + ZIP. Bỏ header để lấy phần ZIP.
enum CRX {
    static func zipData(from data: Data) -> Data {
        let b = [UInt8](data.prefix(16))
        guard b.count >= 12, b[0] == 0x43, b[1] == 0x72, b[2] == 0x32, b[3] == 0x34 else { return data }
        func u32(_ i: Int) -> Int {
            let a = Int(b[i]) | (Int(b[i + 1]) << 8)
            let c = (Int(b[i + 2]) << 16) | (Int(b[i + 3]) << 24)
            return a | c
        }
        let version = u32(4)
        let header: Int
        if version == 2 {
            guard b.count >= 16 else { return data }
            header = 16 + u32(8) + u32(12)
        } else if version == 3 {
            header = 12 + u32(8)
        } else {
            return data
        }
        guard header < data.count else { return data }
        return data.subdata(in: (data.startIndex + header)..<data.endIndex)
    }
}
