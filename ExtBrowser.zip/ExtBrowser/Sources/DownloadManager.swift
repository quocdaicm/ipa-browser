import Foundation
import WebKit

struct DownloadItem: Identifiable {
    enum State { case running, done, failed }
    let id = UUID()
    var name: String
    var fileURL: URL?
    var progress: Double = 0
    var state: State = .running
}

/// Quản lý tải file (WKDownload). File lưu ở Documents/Downloads, xem được trong app Tệp.
@MainActor
final class DownloadManager: NSObject, ObservableObject, WKDownloadDelegate {
    static let shared = DownloadManager()

    @Published private(set) var items: [DownloadItem] = []
    var notify: ((String) -> Void)?
    /// Thông báo gần nhất (để bảng Xem video tự hiện, vì thông báo chính nằm dưới bảng).
    @Published var lastMessage: String?
    /// Tăng 1 mỗi khi một file tải xong (nút Tải xuống trên thanh địa chỉ dùng để phát hiệu ứng).
    @Published private(set) var doneTick = 0

    private struct Active {
        let id: UUID
        let download: WKDownload
        let obs: NSKeyValueObservation
    }
    private var active: [ObjectIdentifier: Active] = [:]

    static var folder: URL {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    private override init() {
        super.init()
        loadExisting()
    }

    private func loadExisting() {
        let keys: [URLResourceKey] = [.contentModificationDateKey]
        guard let urls = try? FileManager.default.contentsOfDirectory(
            at: Self.folder, includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles]) else { return }
        let sorted = urls.sorted {
            let a = (try? $0.resourceValues(forKeys: Set(keys)).contentModificationDate) ?? .distantPast
            let b = (try? $1.resourceValues(forKeys: Set(keys)).contentModificationDate) ?? .distantPast
            return a > b
        }
        items = sorted.map {
            var it = DownloadItem(name: $0.lastPathComponent)
            it.fileURL = $0
            it.progress = 1
            it.state = .done
            return it
        }
    }

    // MARK: Bắt đầu / theo dõi

    func attach(_ d: WKDownload) {
        d.delegate = self
        let item = DownloadItem(name: d.originalRequest?.url?.lastPathComponent ?? "file")
        items.insert(item, at: 0)
        let id = item.id
        let obs = d.progress.observe(\.fractionCompleted) { [weak self] p, _ in
            let f = p.fractionCompleted
            Task { @MainActor in self?.update(id) { $0.progress = f } }
        }
        active[ObjectIdentifier(d)] = Active(id: id, download: d, obs: obs)
        notify?("Đang tải xuống…")
    }

    private func update(_ id: UUID, _ change: (inout DownloadItem) -> Void) {
        if let i = items.firstIndex(where: { $0.id == id }) { change(&items[i]) }
    }

    private func finish(_ d: WKDownload, ok: Bool) {
        let key = ObjectIdentifier(d)
        guard let a = active[key] else { return }
        active[key] = nil
        update(a.id) {
            $0.state = ok ? .done : .failed
            if ok { $0.progress = 1 }
        }
        let name = items.first(where: { $0.id == a.id })?.name ?? ""
        if ok { doneTick += 1 }
        notify?(ok ? "Đã tải xong: \(name)" : "Tải thất bại: \(name)")
    }

    // MARK: Tải ngoài WKDownload (trình tải video)

    private var cancels: [UUID: () -> Void] = [:]

    static func destination(for name: String) -> URL { uniqueURL(for: safeName(name)) }

    func addExternal(name: String) -> UUID {
        let it = DownloadItem(name: name)
        items.insert(it, at: 0)
        return it.id
    }

    func registerCancel(_ id: UUID, _ f: @escaping () -> Void) { cancels[id] = f }

    func setProgress(_ id: UUID, _ p: Double) { update(id) { $0.progress = p } }

    func complete(_ id: UUID, file: URL?, ok: Bool, message: String?) {
        cancels[id] = nil
        guard items.contains(where: { $0.id == id }) else { return }
        update(id) {
            $0.state = ok ? .done : .failed
            if ok {
                $0.progress = 1
                if let f = file { $0.fileURL = f; $0.name = f.lastPathComponent }
            }
        }
        let name = items.first(where: { $0.id == id })?.name ?? ""
        let text = ok ? "Đã tải xong: \(name)" : (message ?? "Tải thất bại: \(name)")
        if ok { doneTick += 1 }
        notify?(text)
        lastMessage = text
    }

    /// Xoá toàn bộ file đã tải (kể cả file trên đĩa) và huỷ các tải đang chạy.
    func removeAll() {
        for it in items { remove(it.id) }
    }

    func remove(_ id: UUID) {
        if let c = cancels[id] { c(); cancels[id] = nil }
        if let a = active.first(where: { $0.value.id == id }) {
            a.value.download.cancel { _ in }
            active[a.key] = nil
        }
        if let it = items.first(where: { $0.id == id }), let u = it.fileURL {
            try? FileManager.default.removeItem(at: u)
        }
        items.removeAll { $0.id == id }
    }

    // MARK: WKDownloadDelegate

    func download(_ download: WKDownload,
                  decideDestinationUsing response: URLResponse,
                  suggestedFilename: String,
                  completionHandler: @escaping (URL?) -> Void) {
        let dest = Self.uniqueURL(for: Self.safeName(suggestedFilename))
        if let a = active[ObjectIdentifier(download)] {
            update(a.id) {
                $0.name = dest.lastPathComponent
                $0.fileURL = dest
            }
        }
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) {
        finish(download, ok: true)
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        if let a = active[ObjectIdentifier(download)],
           let u = items.first(where: { $0.id == a.id })?.fileURL {
            try? FileManager.default.removeItem(at: u)
        }
        finish(download, ok: false)
    }

    // MARK: Tên file

    private static func safeName(_ s: String) -> String {
        var n = s.replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: ":", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if n.isEmpty || n == "." || n == ".." { n = "file" }
        return n
    }

    private static func uniqueURL(for name: String) -> URL {
        let fm = FileManager.default
        var url = folder.appendingPathComponent(name)
        if !fm.fileExists(atPath: url.path) { return url }
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var n = 1
        repeat {
            let candidate = ext.isEmpty ? "\(base) (\(n))" : "\(base) (\(n)).\(ext)"
            url = folder.appendingPathComponent(candidate)
            n += 1
        } while fm.fileExists(atPath: url.path)
        return url
    }
}
