import Foundation
import WebKit

struct DownloadItem: Identifiable {
    enum State { case running, done, failed }
    let id = UUID()
    var name: String
    var fileURL: URL?
    var progress: Double = 0
    var state: State = .running
}

/// Quản lý tải file (WKDownload). File lưu ở Documents/Downloads, xem được trong app Tệp.
@MainActor
final class DownloadManager: NSObject, ObservableObject, WKDownloadDelegate {
    static let shared = DownloadManager()

    @Published private(set) var items: [DownloadItem] = []
    var notify: ((String) -> Void)?

    private struct Active {
        let id: UUID
        let download: WKDownload
        let obs: NSKeyValueObservation
    }
    private var active: [ObjectIdentifier: Active] = [:]

    static var folder: URL {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    private override init() {
        super.init()
        loadExisting()
    }

    private func loadExisting() {
        let keys: [URLResourceKey] = [.contentModificationDateKey]
        guard let urls = try? FileManager.default.contentsOfDirectory(
            at: Self.folder, includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles]) else { return }
        let sorted = urls.sorted {
            let a = (try? $0.resourceValues(forKeys: Set(keys)).contentModificationDate) ?? .distantPast
            let b = (try? $1.resourceValues(forKeys: Set(keys)).contentModificationDate) ?? .distantPast
            return a > b
        }
        items = sorted.map {
            var it = DownloadItem(name: $0.lastPathComponent)
            it.fileURL = $0
            it.progress = 1
            it.state = .done
            return it
        }
    }

    // MARK: Bắt đầu / theo dõi

    func attach(_ d: WKDownload) {
        d.delegate = self
        let item = DownloadItem(name: d.originalRequest?.url?.lastPathComponent ?? "file")
        items.insert(item, at: 0)
        let id = item.id
        let obs = d.progress.observe(\.fractionCompleted) { [weak self] p, _ in
            let f = p.fractionCompleted
            Task { @MainActor in self?.update(id) { $0.progress = f } }
        }
        active[ObjectIdentifier(d)] = Active(id: id, download: d, obs: obs)
        notify?("Đang tải xuống…")
    }

    private func update(_ id: UUID, _ change: (inout DownloadItem) -> Void) {
        if let i = items.firstIndex(where: { $0.id == id }) { change(&items[i]) }
    }

    private func finish(_ d: WKDownload, ok: Bool) {
        let key = ObjectIdentifier(d)
        guard let a = active[key] else { return }
        active[key] = nil
        update(a.id) {
            $0.state = ok ? .done : .failed
            if ok { $0.progress = 1 }
        }
        let name = items.first(where: { $0.id == a.id })?.name ?? ""
        notify?(ok ? "Đã tải xong: \(name)" : "Tải thất bại: \(name)")
    }

    func remove(_ id: UUID) {
        if let a = active.first(where: { $0.value.id == id }) {
            a.value.download.cancel { _ in }
            active[a.key] = nil
        }
        if let it = items.first(where: { $0.id == id }), let u = it.fileURL {
            try? FileManager.default.removeItem(at: u)
        }
        items.removeAll { $0.id == id }
    }

    // MARK: WKDownloadDelegate

    func download(_ download: WKDownload,
                  decideDestinationUsing response: URLResponse,
                  suggestedFilename: String,
                  completionHandler: @escaping (URL?) -> Void) {
        let dest = Self.uniqueURL(for: Self.safeName(suggestedFilename))
        if let a = active[ObjectIdentifier(download)] {
            update(a.id) {
                $0.name = dest.lastPathComponent
                $0.fileURL = dest
            }
        }
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) {
        finish(download, ok: true)
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        if let a = active[ObjectIdentifier(download)],
           let u = items.first(where: { $0.id == a.id })?.fileURL {
            try? FileManager.default.removeItem(at: u)
        }
        finish(download, ok: false)
    }

    // MARK: Tên file

    private static func safeName(_ s: String) -> String {
        var n = s.replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: ":", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if n.isEmpty || n == "." || n == ".." { n = "file" }
        return n
    }

    private static func uniqueURL(for name: String) -> URL {
        let fm = FileManager.default
        var url = folder.appendingPathComponent(name)
        if !fm.fileExists(atPath: url.path) { return url }
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var n = 1
        repeat {
            let candidate = ext.isEmpty ? "\(base) (\(n))" : "\(base) (\(n)).\(ext)"
            url = folder.appendingPathComponent(candidate)
            n += 1
        } while fm.fileExists(atPath: url.path)
        return url
    }
}
