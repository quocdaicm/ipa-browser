import SwiftUI
import WebKit
import AVKit

// MARK: - Mô hình

struct DetectedVideo: Identifiable, Equatable {
    let id = UUID()
    let url: URL
    var kind: String          // hls, mp4, webm, file, blob
    var title: String
    var page: String
    var width = 0
    var height = 0
    var duration = 0.0

    var isBlob: Bool { kind == "blob" }

    var kindLabel: String {
        switch kind {
        case "hls": return "HLS"
        case "mp4": return "MP4"
        case "webm": return "WEBM"
        case "blob": return "STREAM"
        default: return (url.pathExtension.isEmpty ? "VIDEO" : String(url.pathExtension.uppercased().prefix(4)))
        }
    }

    var detail: String {
        var parts = [kindLabel]
        if width > 0 && height > 0 { parts.append("\(width)×\(height)") }
        if duration > 0 && duration.isFinite {
            let s = Int(duration)
            parts.append(s >= 3600 ? String(format: "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                                   : String(format: "%d:%02d", s / 60, s % 60))
        }
        return parts.joined(separator: " · ")
    }

    var displayName: String {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty { return t }
        let n = url.deletingPathExtension().lastPathComponent
        return n.isEmpty ? (url.host ?? "Video") : n
    }
}

// MARK: - Script dò video trong trang

enum VideoSniffer {
    static let source = #"""
(function(){
  if (window.__xbVid) return; window.__xbVid = true;
  var seen = {};
  function abs(u){ try { return new URL(u, location.href).href; } catch(e){ return null; } }
  function kind(u, ct){
    var l = (u || '').split('?')[0].split('#')[0].toLowerCase();
    ct = ct || '';
    if (/\.m3u8$/.test(l) || /mpegurl/i.test(ct)) return 'hls';
    if (/\.(mp4|m4v|mov)$/.test(l) || /^video\/mp4/i.test(ct)) return 'mp4';
    if (/\.webm$/.test(l) || /^video\/webm/i.test(ct)) return 'webm';
    if (/\.(mkv|flv|3gp|avi|ogv)$/.test(l) || /^video\//i.test(ct)) return 'file';
    return null;
  }
  function post(o){ try { window.webkit.messageHandlers.xbVideo.postMessage(o); } catch(e){} }
  function send(u, k, v){
    u = abs(u); if (!u) return;
    if (/^data:/i.test(u)) return;
    var o = {url:u, kind:k, title:document.title || '', page:location.href};
    if (v) {
      if (v.videoWidth) { o.w = v.videoWidth; o.h = v.videoHeight; }
      if (v.duration && isFinite(v.duration)) o.d = v.duration;
    }
    var key = u + '|' + (o.w || 0) + '|' + (o.d ? 1 : 0);
    if (seen[key]) return; seen[key] = 1;
    post(o);
  }
  function fromEl(v){
    if (!v || !v.tagName) return;
    var cands = [v.currentSrc, v.getAttribute && v.getAttribute('src')];
    var ss = v.querySelectorAll ? v.querySelectorAll('source') : [];
    for (var i = 0; i < ss.length; i++) cands.push(ss[i].src);
    cands.forEach(function(c){
      if (!c) return;
      if (/^blob:/i.test(c)) { send(c, 'blob', v); return; }
      var k = kind(abs(c) || c) || 'file';
      send(c, k, v);
    });
  }
  function scan(){
    var vs = document.querySelectorAll('video, audio');
    for (var i = 0; i < vs.length; i++) { if (vs[i].tagName === 'VIDEO') fromEl(vs[i]); }
  }
  ['loadstart','loadedmetadata','play','playing','durationchange','resize'].forEach(function(n){
    addEventListener(n, function(e){ if (e.target && e.target.tagName === 'VIDEO') fromEl(e.target); }, true);
  });
  try {
    new MutationObserver(function(){ scan(); }).observe(document.documentElement, {childList:true, subtree:true, attributes:true, attributeFilter:['src']});
  } catch(e){}
  setInterval(scan, 2500);

  // fetch / XHR
  try {
    var of = window.fetch;
    if (of) window.fetch = function(){
      var a = arguments, req = a[0], url = (req && req.url) ? req.url : String(req);
      return of.apply(this, a).then(function(r){
        try { var k = kind(r.url || url, r.headers && r.headers.get('content-type')); if (k) send(r.url || url, k); } catch(e){}
        return r;
      });
    };
    var oo = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(m, u){
      var self = this, url = u;
      this.addEventListener('readystatechange', function(){
        if (self.readyState === 2) {
          try { var k = kind(self.responseURL || url, self.getResponseHeader('content-type')); if (k) send(self.responseURL || url, k); } catch(e){}
        }
      });
      return oo.apply(this, arguments);
    };
  } catch(e){}

  // tài nguyên mạng mà trình phát đã tải
  try {
    var po = new PerformanceObserver(function(list){
      list.getEntries().forEach(function(en){ var k = kind(en.name); if (k) send(en.name, k); });
    });
    po.observe({entryTypes:['resource']});
    performance.getEntriesByType('resource').forEach(function(en){ var k = kind(en.name); if (k) send(en.name, k); });
  } catch(e){}
})();
"""#
}

// MARK: - Nhận tin nhắn từ trang

final class VideoBridge: NSObject, WKScriptMessageHandler {
    var onVideo: (@MainActor (WKWebView?, [String: Any]) -> Void)?

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any] else { return }
        let w = message.webView
        Task { @MainActor in self.onVideo?(w, body) }
    }
}

// MARK: - Tải file

struct VideoContext {
    var cookies: [HTTPCookie] = []
    var userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"

    /// profile 0: Referer + Origin · 1: chỉ Referer · 2: Referer gốc trang · 3: không gửi gì thêm.
    /// Một số máy chủ từ chối khi có Origin, số khác đòi Referer, nên thử lần lượt.
    func headers(for url: URL, page: String, profile: Int = 0) -> [String: String] {
        var h = ["User-Agent": userAgent, "Accept": "*/*"]
        if let p = URL(string: page), let s = p.scheme, let host = p.host {
            switch profile {
            case 0: h["Referer"] = page; h["Origin"] = "\(s)://\(host)"
            case 1: h["Referer"] = page
            case 2: h["Referer"] = "\(s)://\(host)/"
            default: break
            }
        }
        if let host = url.host {
            let m = cookies.filter { c in
                let d = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain
                return host == d || host.hasSuffix("." + d)
            }
            if !m.isEmpty, let ck = HTTPCookie.requestHeaderFields(with: m)["Cookie"] { h["Cookie"] = ck }
        }
        return h
    }

    static let profileCount = 4

    func request(_ url: URL, page: String, profile: Int = 0, rangeFrom: Int64? = nil) -> URLRequest {
        var r = URLRequest(url: url)
        r.timeoutInterval = 60
        for (k, v) in headers(for: url, page: page, profile: profile) { r.setValue(v, forHTTPHeaderField: k) }
        if let s = rangeFrom { r.setValue("bytes=\(s)-", forHTTPHeaderField: "Range") }
        return r
    }
}

enum VideoError: LocalizedError {
    case encrypted, empty, http(Int), notVideo, tooSmall(Int64)
    var errorDescription: String? {
        switch self {
        case .encrypted: return "Video được mã hoá (DRM), không tải được"
        case .empty: return "Không tìm thấy dữ liệu video"
        case .notVideo: return "Máy chủ trả về trang/tệp văn bản thay vì video (có thể cần mở lại video trong trang rồi tải lại)"
        case .tooSmall(let n): return "Chỉ nhận được \(ByteCountFormatter.string(fromByteCount: n, countStyle: .file)) — không phải video đầy đủ, đã bỏ"
        case .http(let c): return "Máy chủ từ chối (mã \(c)). Thử mở lại video trong trang rồi bấm tải lại"
        }
    }
}

/// Tải một file lớn có tiến độ, rồi trả về file tạm.
final class FileFetcher: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    var onProgress: ((Double) -> Void)?
    /// Phản hồi HTTP của lần tải gần nhất (để kiểm tra loại dữ liệu / Content-Range).
    private(set) var response: HTTPURLResponse?
    private var continuation: CheckedContinuation<URL, Error>?
    private var task: URLSessionDownloadTask?

    func fetch(_ req: URLRequest) async throws -> URL {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (c: CheckedContinuation<URL, Error>) in
                self.continuation = c
                let s = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
                let t = s.downloadTask(with: req)
                self.task = t
                t.resume()
            }
        } onCancel: {
            self.task?.cancel()
        }
    }

    private func finish(_ r: Result<URL, Error>) {
        guard let c = continuation else { return }
        continuation = nil
        c.resume(with: r)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        if totalBytesExpectedToWrite > 0 {
            onProgress?(Double(totalBytesWritten) / Double(totalBytesExpectedToWrite))
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        response = downloadTask.response as? HTTPURLResponse
        if let r = response, !(200..<300).contains(r.statusCode) {
            finish(.failure(VideoError.http(r.statusCode)))
            return
        }
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        do {
            try FileManager.default.moveItem(at: location, to: tmp)
            finish(.success(tmp))
        } catch {
            finish(.failure(error))
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let e = error { finish(.failure(e)) }
        session.finishTasksAndInvalidate()
    }
}

@MainActor
final class VideoDownloader {
    static let shared = VideoDownloader()
    private init() {}

    private func fileName(_ v: DetectedVideo, ext: String) -> String {
        var base = v.displayName
        let bad = CharacterSet(charactersIn: "/\\:*?\"<>|\n\r\t")
        base = base.components(separatedBy: bad).joined(separator: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if base.isEmpty { base = "video" }
        if base.count > 60 { base = String(base.prefix(60)) }
        if v.height > 0 { base += " \(v.height)p" }
        return base + "." + ext
    }

    private func ext(for v: DetectedVideo) -> String {
        switch v.kind {
        case "mp4": return "mp4"
        case "webm": return "webm"
        case "hls": return "mp4"
        default:
            let e = v.url.pathExtension.lowercased()
            return e.isEmpty || e.count > 4 ? "mp4" : e
        }
    }

    private var running = Set<URL>()

    func start(_ v: DetectedVideo, context: VideoContext) {
        guard !v.isBlob else { return }
        guard !running.contains(v.url) else {
            DownloadManager.shared.lastMessage = "Video này đang được tải rồi"
            return
        }
        running.insert(v.url)
        let dm = DownloadManager.shared
        let id = dm.addExternal(name: fileName(v, ext: ext(for: v)))
        var bg = UIBackgroundTaskIdentifier.invalid
        bg = UIApplication.shared.beginBackgroundTask(withName: "video-download") {
            UIApplication.shared.endBackgroundTask(bg)
            bg = .invalid
        }
        let task = Task { @MainActor in
            defer {
                self.running.remove(v.url)
                if bg != .invalid { UIApplication.shared.endBackgroundTask(bg) }
            }
            do {
                let result: (URL, String)
                if v.kind == "hls" {
                    result = try await self.downloadHLS(v, context: context) { p in
                        Task { @MainActor in dm.setProgress(id, p) }
                    }
                } else {
                    // (profile header, có Range?) — thử lần lượt tới khi máy chủ chấp nhận
                    let attempts: [(Int, Bool)] = [(0, true), (1, true), (1, false), (2, false), (3, false)]
                    var tmp: URL?
                    var firstResp: HTTPURLResponse?
                    var usedProfile = 0
                    var lastErr: Error = VideoError.empty
                    for (profile, range) in attempts {
                        try Task.checkCancellation()
                        let f = FileFetcher()
                        f.onProgress = { p in Task { @MainActor in dm.setProgress(id, p) } }
                        do {
                            tmp = try await f.fetch(context.request(v.url, page: v.page, profile: profile,
                                                                    rangeFrom: range ? 0 : nil))
                            firstResp = f.response
                            usedProfile = profile
                            break
                        } catch let e as VideoError {
                            lastErr = e
                            if case .http = e { continue }
                            throw e
                        }
                    }
                    guard let got = tmp else { throw lastErr }
                    try await self.finishDirect(got, resp: firstResp, v: v, ctx: context, profile: usedProfile) { p in
                        Task { @MainActor in dm.setProgress(id, p) }
                    }
                    result = (got, self.ext(for: v))
                }
                let dest = DownloadManager.destination(for: self.fileName(v, ext: result.1))
                try FileManager.default.moveItem(at: result.0, to: dest)
                dm.complete(id, file: dest, ok: true, message: nil)
            } catch is CancellationError {
                dm.complete(id, file: nil, ok: false, message: nil)
            } catch {
                let why = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                dm.complete(id, file: nil, ok: false, message: "Tải thất bại: \(why)")
            }
        }
        dm.registerCancel(id) { task.cancel() }
    }

    private func fileSize(_ u: URL) -> Int64 {
        Int64((try? u.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0)
    }

    /// Kiểm tra file vừa tải: loại bỏ trang văn bản, tải nối tiếp nếu máy chủ chỉ trả một phần (206),
    /// và từ chối file quá nhỏ so với video thật.
    private func finishDirect(_ file: URL, resp: HTTPURLResponse?, v: DetectedVideo, ctx: VideoContext,
                              profile: Int, progress: @escaping (Double) -> Void) async throws {
        func discard() { try? FileManager.default.removeItem(at: file) }

        if let m = resp?.mimeType?.lowercased(),
           m.hasPrefix("text/") || m.contains("html") || m.contains("json") || m.contains("xml") {
            discard(); throw VideoError.notVideo
        }
        // Content-Range: bytes 0-21000/123456789
        var total: Int64 = 0
        if resp?.statusCode == 206,
           let cr = resp?.value(forHTTPHeaderField: "Content-Range"),
           let slash = cr.lastIndex(of: "/"),
           let t = Int64(cr[cr.index(after: slash)...].trimmingCharacters(in: .whitespaces)) {
            total = t
        }
        var got = fileSize(file)
        var stalls = 0
        while total > 0, got < total {
            try Task.checkCancellation()
            let f = FileFetcher()
            let part: URL
            do {
                part = try await f.fetch(ctx.request(v.url, page: v.page, profile: profile, rangeFrom: got))
            } catch {
                discard(); throw error
            }
            let n = fileSize(part)
            if n == 0 || f.response?.statusCode != 206 {
                try? FileManager.default.removeItem(at: part)
                stalls += 1
                if stalls >= 2 { break }
                continue
            }
            // nối thêm vào file chính
            if let src = try? FileHandle(forReadingFrom: part), let dst = try? FileHandle(forWritingTo: file) {
                _ = try? dst.seekToEnd()
                while true {
                    let chunk = src.readData(ofLength: 1 << 20)
                    if chunk.isEmpty { break }
                    try dst.write(contentsOf: chunk)
                }
                try? src.close(); try? dst.close()
            }
            try? FileManager.default.removeItem(at: part)
            got = fileSize(file)
            progress(Double(got) / Double(total))
        }
        let size = fileSize(file)
        // Video thật hàng phút thì không thể dưới ~100 KB
        let minimum: Int64 = (v.duration > 30 || total > 1_000_000) ? 100 * 1024 : 1024
        if size < minimum || (total > 0 && size < total) {
            discard(); throw VideoError.tooSmall(size)
        }
    }

    // MARK: HLS (.m3u8): ghép các đoạn chưa mã hoá thành một file

    /// Hồ sơ header đã thành công (dùng chung cho mọi đoạn của một video).
    private final class ProfileBox { var value = 0 }
    private var profileBox = ProfileBox()

    private func fetchData(_ url: URL, _ v: DetectedVideo, _ c: VideoContext) async throws -> Data {
        var lastErr: Error = VideoError.empty
        var profile = profileBox.value
        var netRetries = 0
        while profile < VideoContext.profileCount {
            try Task.checkCancellation()
            do {
                let (d, r) = try await URLSession.shared.data(for: c.request(url, page: v.page, profile: profile))
                if let h = r as? HTTPURLResponse, !(200..<300).contains(h.statusCode) { throw VideoError.http(h.statusCode) }
                if profile > profileBox.value { profileBox.value = profile }
                return d
            } catch let e as VideoError {
                lastErr = e
                if case .http = e { profile += 1; continue }
                throw e
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                // lỗi mạng thoáng qua: thử lại tối đa 3 lần
                lastErr = error
                netRetries += 1
                if netRetries >= 3 { throw error }
                try await Task.sleep(nanoseconds: 600_000_000)
            }
        }
        throw lastErr
    }

    private func fetchText(_ url: URL, _ v: DetectedVideo, _ c: VideoContext) async throws -> String {
        let d = try await fetchData(url, v, c)
        return String(decoding: d, as: UTF8.self)
    }

    private func resolve(_ s: String, base: URL) -> URL? {
        URL(string: s, relativeTo: base)?.absoluteURL
    }

    private func downloadHLS(_ v: DetectedVideo, context c: VideoContext,
                             progress: @escaping (Double) -> Void) async throws -> (URL, String) {
        profileBox = ProfileBox()
        var listURL = v.url
        var text = try await fetchText(listURL, v, c)

        if text.contains("#EXT-X-STREAM-INF") {
            let lines = text.components(separatedBy: .newlines)
            var best: (bw: Int, uri: String)?
            var i = 0
            while i < lines.count {
                let l = lines[i]
                if l.hasPrefix("#EXT-X-STREAM-INF") {
                    var bw = 0
                    if let r = l.range(of: "BANDWIDTH=") {
                        let digits = l[r.upperBound...].prefix { $0.isNumber }
                        bw = Int(digits) ?? 0
                    }
                    var j = i + 1
                    while j < lines.count, lines[j].trimmingCharacters(in: .whitespaces).isEmpty || lines[j].hasPrefix("#") { j += 1 }
                    if j < lines.count, best == nil || bw > best!.bw {
                        best = (bw, lines[j].trimmingCharacters(in: .whitespaces))
                    }
                    i = j
                }
                i += 1
            }
            guard let b = best, let u = resolve(b.uri, base: listURL) else { throw VideoError.empty }
            listURL = u
            text = try await fetchText(listURL, v, c)
        }

        var segments: [URL] = []
        var initURL: URL?
        for raw in text.components(separatedBy: .newlines) {
            let l = raw.trimmingCharacters(in: .whitespaces)
            if l.isEmpty { continue }
            if l.hasPrefix("#EXT-X-KEY") {
                if !l.contains("METHOD=NONE") { throw VideoError.encrypted }
            } else if l.hasPrefix("#EXT-X-MAP") {
                if let r1 = l.range(of: "URI=\""), let r2 = l.range(of: "\"", range: r1.upperBound..<l.endIndex) {
                    initURL = resolve(String(l[r1.upperBound..<r2.lowerBound]), base: listURL)
                }
            } else if !l.hasPrefix("#") {
                if let u = resolve(l, base: listURL) { segments.append(u) }
            }
        }
        guard !segments.isEmpty else { throw VideoError.empty }

        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        FileManager.default.createFile(atPath: tmp.path, contents: nil)
        let fh = try FileHandle(forWritingTo: tmp)
        defer { try? fh.close() }

        if let i = initURL { try fh.write(contentsOf: try await fetchData(i, v, c)) }

        let batch = 6
        var done = 0
        var start = 0
        while start < segments.count {
            try Task.checkCancellation()
            let slice = Array(segments[start..<min(start + batch, segments.count)])
            let chunks = try await withThrowingTaskGroup(of: (Int, Data).self) { g -> [Data] in
                for (i, u) in slice.enumerated() {
                    g.addTask {
                        let d = try await self.fetchData(u, v, c)
                        return (i, d)
                    }
                }
                var out = [Data?](repeating: nil, count: slice.count)
                for try await (i, d) in g { out[i] = d }
                return out.compactMap { $0 }
            }
            for d in chunks { try fh.write(contentsOf: d) }
            done += slice.count
            start += batch
            progress(Double(done) / Double(segments.count))
        }
        return (tmp, initURL != nil ? "mp4" : "ts")
    }
}

// MARK: - Nút nổi & bảng “Xem video”

struct VideoFab: View {
    @ObservedObject var tab: Tab
    let action: () -> Void

    private var count: Int { tab.videos.filter { !$0.isBlob }.count }

    var body: some View {
        if count > 0 {
            Button(action: action) {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: "arrow.down.to.line")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 54, height: 54)
                        .background(Theme.gradient, in: Circle())
                        .overlay(Circle().strokeBorder(.white.opacity(0.3), lineWidth: 1))
                        .shadow(color: Theme.accent.opacity(0.55), radius: 12, y: 5)
                    Text("\(count)")
                        .font(.system(size: 11, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 5)
                        .frame(minWidth: 19, minHeight: 19)
                        .background(Theme.danger, in: Capsule())
                        .overlay(Capsule().strokeBorder(.white, lineWidth: 1.5))
                        .offset(x: 4, y: -4)
                }
            }
            .buttonStyle(PressStyle())
            .transition(.scale.combined(with: .opacity))
        }
    }
}

struct VideoSheet: View {
    @ObservedObject var tab: Tab
    @Environment(\.dismiss) private var dismiss
    @State private var playing: PlayerItem?
    @State private var busy = false
    @ObservedObject private var dm = DownloadManager.shared
    @State private var banner: String?

    struct PlayerItem: Identifiable {
        let id = UUID()
        let video: DetectedVideo
        let context: VideoContext
    }

    private func context() async -> VideoContext {
        var c = VideoContext()
        let store = tab.webView.configuration.websiteDataStore.httpCookieStore
        c.cookies = await store.allCookies()
        if let ua = try? await tab.webView.evaluateJavaScript("navigator.userAgent") as? String, !ua.isEmpty {
            c.userAgent = ua
        }
        return c
    }

    private func play(_ v: DetectedVideo) {
        busy = true
        Task { @MainActor in
            let c = await context()
            _ = try? await tab.webView.evaluateJavaScript("document.querySelectorAll('video,audio').forEach(function(m){try{m.pause()}catch(e){}})")
            playing = PlayerItem(video: v, context: c)
            busy = false
        }
    }

    private func download(_ v: DetectedVideo) {
        Task { @MainActor in
            let c = await context()
            VideoDownloader.shared.start(v, context: c)
            banner = "Đang tải: \(v.displayName) — xem tiến độ ở mục Tải xuống"
        }
    }

    var body: some View {
        SheetScaffold(title: "Xem video",
                      subtitle: tab.videos.isEmpty ? "Chưa phát hiện video" : "\(tab.videos.count) video trên trang",
                      onClose: { dismiss() }) {
            ScrollView {
                LazyVStack(spacing: 10) {
                    if tab.videos.isEmpty {
                        EmptyState(asset: "ic_download", title: "Chưa phát hiện video",
                                   message: "Mở trang có video và bấm phát, nút tải sẽ tự hiện ở góc màn hình.")
                    }
                    ForEach(tab.videos) { v in card(v) }
                    Text("Hỗ trợ video có đường dẫn trực tiếp (MP4, WEBM) và HLS (.m3u8) không mã hoá. Video DRM hoặc dạng luồng nội bộ (như YouTube, Netflix) không tải được. Chỉ tải nội dung bạn có quyền sử dụng.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .padding(.horizontal, 6).padding(.top, 6)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 30)
            }
        }
        .overlay(alignment: .bottom) {
            if let b = banner {
                Text(b)
                    .font(.footnote.weight(.semibold))
                    .multilineTextAlignment(.leading)
                    .padding(.horizontal, 16).padding(.vertical, 12)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(Theme.cardStroke))
                    .padding(.horizontal, 16).padding(.bottom, 20)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .onTapGesture { banner = nil }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: banner)
        .onChange(of: dm.lastMessage) { m in
            guard let m else { return }
            banner = m
        }
        .task(id: banner) {
            guard banner != nil else { return }
            try? await Task.sleep(nanoseconds: 6_000_000_000)
            banner = nil
        }
        .fullScreenCover(item: $playing) { p in
            ZStack(alignment: .topTrailing) {
                NativePlayer(video: p.video, context: p.context).ignoresSafeArea()
                Button { playing = nil } label: {
                    SVGIcon(name: "ic_close", size: 14)
                        .foregroundStyle(.white)
                        .frame(width: 38, height: 38)
                        .background(.black.opacity(0.55), in: Circle())
                }
                .padding(16)
            }
        }
    }

    private func card(_ v: DetectedVideo) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                IconChip(sf: v.isBlob ? "lock.fill" : "play.fill", color: v.isBlob ? Theme.warn : Theme.accent, size: 42)
                VStack(alignment: .leading, spacing: 3) {
                    Text(v.displayName).font(.subheadline.weight(.bold)).lineLimit(2)
                    Text(v.detail).font(.caption.weight(.semibold)).foregroundStyle(Theme.accent)
                    Text(v.url.host ?? v.url.absoluteString).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            if v.isBlob {
                Label("Video dùng luồng nội bộ hoặc DRM nên không thể tải trực tiếp.",
                      systemImage: "exclamationmark.triangle.fill")
                    .font(.caption).foregroundStyle(Theme.warn)
            } else {
                HStack(spacing: 8) {
                    Button { play(v) } label: {
                        Label("Xem", systemImage: "play.fill").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                    .disabled(busy)
                    Button { download(v) } label: {
                        Label("Tải về", systemImage: "arrow.down.circle.fill").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle(filled: true))
                    MiniIconButton(sf: "link") {
                        UIPasteboard.general.string = v.url.absoluteString
                        DownloadManager.shared.notify?("Đã chép liên kết video")
                    }
                }
            }
        }
        .padding(14)
        .card(radius: 20)
    }
}

struct NativePlayer: UIViewControllerRepresentable {
    let video: DetectedVideo
    let context: VideoContext

    func makeUIViewController(context ctx: Context) -> AVPlayerViewController {
        let h = context.headers(for: video.url, page: video.page)
        var opts: [String: Any] = ["AVURLAssetHTTPHeaderFieldsKey": h]
        if !context.cookies.isEmpty { opts["AVURLAssetHTTPCookiesKey"] = context.cookies }
        let asset = AVURLAsset(url: video.url, options: opts)
        let vc = AVPlayerViewController()
        vc.player = AVPlayer(playerItem: AVPlayerItem(asset: asset))
        vc.allowsPictureInPicturePlayback = true
        vc.player?.play()
        return vc
    }

    func updateUIViewController(_ vc: AVPlayerViewController, context: Context) {}
}
