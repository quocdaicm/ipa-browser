import SwiftUI
import WebKit
import AVKit
import Network
import Combine

// MARK: - Mô hình

struct DetectedVideo: Identifiable, Equatable {
    let id = UUID()
    let url: URL
    var kind: String          // hls, mp4, webm, file, blob
    var title: String
    var page: String
    var width = 0
    var height = 0
    var duration = 0.0
    var size: Int64 = 0

    var isBlob: Bool { kind == "blob" }

    var kindLabel: String {
        switch kind {
        case "hls": return "HLS"
        case "mp4": return "MP4"
        case "webm": return "WEBM"
        case "blob": return "STREAM"
        default: return (url.pathExtension.isEmpty ? "VIDEO" : String(url.pathExtension.uppercased().prefix(4)))
        }
    }

    var detail: String {
        var parts = [kindLabel]
        if width > 0 && height > 0 { parts.append("\(width)×\(height)") }
        if size > 0 { parts.append(ByteCountFormatter.string(fromByteCount: size, countStyle: .file)) }
        if duration > 0 && duration.isFinite {
            let s = Int(duration)
            parts.append(s >= 3600 ? String(format: "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                                   : String(format: "%d:%02d", s / 60, s % 60))
        }
        return parts.joined(separator: " · ")
    }

    var displayName: String {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty { return t }
        let n = url.deletingPathExtension().lastPathComponent
        return n.isEmpty ? (url.host ?? "Video") : n
    }
}

// MARK: - Script dò video trong trang

enum VideoSniffer {
    static let source = #"""
(function(){
  if (window.__xbVid) return; window.__xbVid = true;
  var seen = {}, sent = 0, MAX_SEND = 80;
  // Đoạn nhỏ của luồng (ts, m4s…), ảnh, script… không phải video để tải
  var SEG_EXT = /\.(ts|m4s|m4f|m4a|cmfv|cmfa|aac|mp3|vtt|srt|key|jpe?g|png|gif|webp|svg|js|css|json|woff2?)$/;
  var SEG_NAME = /(^|[\/_\-.])(seg|segment|chunk|frag|fragment|init)[\-_.]?\d*\.(mp4|m4s|ts)$/;
  var SEG_MIME = /^(video\/mp2t|video\/iso\.segment|audio\/|image\/|text\/vtt|application\/(javascript|json))/;
  var PLAYLIST_CT = /^(|text\/plain|application\/octet-stream|binary\/octet-stream|application\/x-mpegurl)$/;
  var MIN_BYTES = 150 * 1024;

  function abs(u){ try { return new URL(u, location.href).href; } catch(e){ return null; } }
  function mime(ct){ return String(ct || '').split(';')[0].trim().toLowerCase(); }
  // Khoá chống trùng: bỏ tham số range/byte (cùng một file nhưng tải từng khúc)
  function cleanKey(u){
    try {
      var x = new URL(u);
      ['range','bytestart','byteend','rn','rbuf'].forEach(function(k){ x.searchParams.delete(k); });
      x.hash = '';
      return x.href;
    } catch(e){ return u; }
  }
  function kind(u, ct){
    var p = String(u || '').split('#')[0];
    var l = p.split('?')[0].toLowerCase();
    var q = (p.split('?')[1] || '').toLowerCase();
    ct = mime(ct);
    if (SEG_EXT.test(l) || SEG_NAME.test(l) || SEG_MIME.test(ct)) return null;
    if (/\.m3u8$/.test(l) || /mpegurl/.test(ct)) return 'hls';
    if (/\.(mp4|m4v|mov)$/.test(l) || /^video\/mp4/.test(ct)) return 'mp4';
    if (/\.webm$/.test(l) || /^video\/webm/.test(ct)) return 'webm';
    if (/\.(mkv|flv|3gp|avi|ogv)$/.test(l) || /^video\//.test(ct)) return 'file';
    // link không có đuôi nhưng khai báo loại trong tham số (mime=video/mp4…)
    if (/(^|&)(mime|type|contenttype)=video(%2f|\/)(mp4|quicktime)/.test(q)) return 'mp4';
    return null;
  }
  function pageTitle(){
    try { return window.top.document.title || document.title || ''; } catch(e){ return document.title || ''; }
  }
  function post(o){ try { window.webkit.messageHandlers.xbVideo.postMessage(o); } catch(e){} }
  function send(u, k, v){
    u = abs(u); if (!u) return;
    if (/^(data|about|javascript):/i.test(u)) return;
    var o = {url:u, kind:k, title:pageTitle(), page:location.href};
    if (v) {
      if (v.videoWidth) { o.w = v.videoWidth; o.h = v.videoHeight; }
      if (v.duration && isFinite(v.duration)) o.d = v.duration;
    }
    var key = cleanKey(u) + '|' + (o.w || 0) + '|' + (o.d ? 1 : 0);
    if (seen[key]) return;
    if (sent >= MAX_SEND) return;
    seen[key] = 1; sent++;
    post(o);
  }
  function fromEl(v){
    if (!v || !v.tagName) return;
    var cands = [v.currentSrc, v.getAttribute && v.getAttribute('src')];
    var ss = v.querySelectorAll ? v.querySelectorAll('source') : [];
    for (var i = 0; i < ss.length; i++) cands.push(ss[i].src);
    cands.forEach(function(c){
      if (!c) return;
      if (/^blob:/i.test(c)) { send(c, 'blob', v); return; }
      var k = kind(abs(c) || c) || 'file';
      send(c, k, v);
    });
  }

  // Shadow DOM (trình phát dựng bằng web component): ghi lại các root khi được tạo
  var roots = [];
  try {
    var oa = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function(){
      var r = oa.apply(this, arguments);
      try { roots.push(r); } catch(e){}
      return r;
    };
  } catch(e){}
  function scan(){
    var vs = document.querySelectorAll('video');
    for (var i = 0; i < vs.length; i++) fromEl(vs[i]);
    roots = roots.filter(function(r){ return r.host && r.host.isConnected; });
    roots.forEach(function(r){
      try {
        var sv = r.querySelectorAll('video');
        for (var j = 0; j < sv.length; j++) fromEl(sv[j]);
      } catch(e){}
    });
  }
  ['loadstart','loadedmetadata','loadeddata','canplay','play','playing','durationchange','resize'].forEach(function(n){
    addEventListener(n, function(e){ if (e.target && e.target.tagName === 'VIDEO') fromEl(e.target); }, true);
  });
  try {
    new MutationObserver(function(){ scan(); }).observe(document.documentElement, {childList:true, subtree:true, attributes:true, attributeFilter:['src']});
  } catch(e){}
  setInterval(scan, 2500);

  // Playlist HLS không có đuôi .m3u8 / sai Content-Type: nhìn vào nội dung (#EXTM3U)
  function textIsM3U(t){ return typeof t === 'string' && /^\s*#EXTM3U/.test(t.slice(0, 32)); }
  function bufIsM3U(b){
    try {
      var a = new Uint8Array(b, 0, Math.min(7, b.byteLength));
      return String.fromCharCode.apply(null, a) === '#EXTM3U';
    } catch(e){ return false; }
  }
  // Phản hồi quá nhỏ (đoạn quảng cáo, mẩu thử…) thì bỏ
  function tooSmall(k, len){ return k !== 'hls' && len > 0 && len < MIN_BYTES; }

  // fetch / XHR
  try {
    var of = window.fetch;
    if (of) window.fetch = function(){
      var a = arguments, req = a[0], url = (req && req.url) ? req.url : String(req);
      return of.apply(this, a).then(function(r){
        try {
          var ru = r.url || url, ct = r.headers && r.headers.get('content-type');
          var cl = parseInt((r.headers && r.headers.get('content-length')) || '0', 10) || 0;
          var cr = r.headers && r.headers.get('content-range');
          var total = cr && /\/(\d+)\s*$/.exec(cr); if (total) cl = parseInt(total[1], 10);
          var k = kind(ru, ct);
          if (k) { if (!tooSmall(k, cl)) send(ru, k); }
          else if (PLAYLIST_CT.test(mime(ct)) && cl > 0 && cl < 1500000 && !SEG_EXT.test(String(ru).split('?')[0].toLowerCase())) {
            r.clone().text().then(function(t){ if (textIsM3U(t)) send(ru, 'hls'); }).catch(function(){});
          }
        } catch(e){}
        return r;
      });
    };
    var oo = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(m, u){
      var self = this, url = u;
      this.addEventListener('readystatechange', function(){
        try {
          if (self.readyState === 2) {
            var ru = self.responseURL || url, ct = self.getResponseHeader('content-type');
            var cl = parseInt(self.getResponseHeader('content-length') || '0', 10) || 0;
            var cr = self.getResponseHeader('content-range');
            var total = cr && /\/(\d+)\s*$/.exec(cr); if (total) cl = parseInt(total[1], 10);
            var k = kind(ru, ct);
            if (k && !tooSmall(k, cl)) send(ru, k);
          } else if (self.readyState === 4) {
            var ru2 = self.responseURL || url, ct2 = mime(self.getResponseHeader('content-type'));
            if (!kind(ru2, ct2) && PLAYLIST_CT.test(ct2) && !SEG_EXT.test(String(ru2).split('?')[0].toLowerCase())) {
              var rt = self.responseType;
              if ((rt === '' || rt === 'text') && textIsM3U(self.responseText)) send(ru2, 'hls');
              else if (rt === 'arraybuffer' && self.response && self.response.byteLength < 1500000 && bufIsM3U(self.response)) send(ru2, 'hls');
            }
          }
        } catch(e){}
      });
      return oo.apply(this, arguments);
    };
  } catch(e){}

  // Tài nguyên mạng mà trình phát đã tải (kể cả link không đuôi do thẻ <video> yêu cầu)
  function fromEntry(en){
    var k = kind(en.name);
    if (k) { send(en.name, k); return; }
    if (en.initiatorType === 'video' && !SEG_EXT.test(String(en.name).split('?')[0].toLowerCase()) && !SEG_NAME.test(String(en.name).split('?')[0].toLowerCase())) {
      send(en.name, 'file');
    }
  }
  try {
    var po = new PerformanceObserver(function(list){ list.getEntries().forEach(fromEntry); });
    po.observe({entryTypes:['resource']});
    performance.getEntriesByType('resource').forEach(fromEntry);
  } catch(e){}
})();
"""#
}

// MARK: - Nhận tin nhắn từ trang

final class VideoBridge: NSObject, WKScriptMessageHandler {
    var onVideo: (@MainActor (WKWebView?, [String: Any]) -> Void)?

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any] else { return }
        let w = message.webView
        Task { @MainActor in self.onVideo?(w, body) }
    }
}

// MARK: - Tải file

struct VideoContext {
    var cookies: [HTTPCookie] = []
    var userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"

    /// profile 0: Referer + Origin · 1: chỉ Referer · 2: Referer gốc trang · 3: không gửi gì thêm.
    /// Một số máy chủ từ chối khi có Origin, số khác đòi Referer, nên thử lần lượt.
    func headers(for url: URL, page: String, profile: Int = 0) -> [String: String] {
        var h = ["User-Agent": userAgent, "Accept": "*/*"]
        if let p = URL(string: page), let s = p.scheme, let host = p.host {
            switch profile {
            case 0: h["Referer"] = page; h["Origin"] = "\(s)://\(host)"
            case 1: h["Referer"] = page
            case 2: h["Referer"] = "\(s)://\(host)/"
            default: break
            }
        }
        if let host = url.host {
            let m = cookies.filter { c in
                let d = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain
                return host == d || host.hasSuffix("." + d)
            }
            if !m.isEmpty, let ck = HTTPCookie.requestHeaderFields(with: m)["Cookie"] { h["Cookie"] = ck }
        }
        return h
    }

    static let profileCount = 4

    func request(_ url: URL, page: String, profile: Int = 0, rangeFrom: Int64? = nil) -> URLRequest {
        var r = URLRequest(url: url)
        r.timeoutInterval = 60
        for (k, v) in headers(for: url, page: page, profile: profile) { r.setValue(v, forHTTPHeaderField: k) }
        if let s = rangeFrom { r.setValue("bytes=\(s)-", forHTTPHeaderField: "Range") }
        return r
    }
}

enum VideoError: LocalizedError {
    case encrypted, empty, http(Int), notVideo, tooSmall(Int64)
    var errorDescription: String? {
        switch self {
        case .encrypted: return "Video được mã hoá (DRM), không tải được"
        case .empty: return "Không tìm thấy dữ liệu video"
        case .notVideo: return "Máy chủ trả về trang/tệp văn bản thay vì video (có thể cần mở lại video trong trang rồi tải lại)"
        case .tooSmall(let n): return "Chỉ nhận được \(ByteCountFormatter.string(fromByteCount: n, countStyle: .file)) — không phải video đầy đủ, đã bỏ"
        case .http(let c): return "Máy chủ từ chối (mã \(c)). Thử mở lại video trong trang rồi bấm tải lại"
        }
    }
}

/// Tải một file lớn có tiến độ, rồi trả về file tạm.
final class FileFetcher: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    var onProgress: ((Double) -> Void)?
    /// Phản hồi HTTP của lần tải gần nhất (để kiểm tra loại dữ liệu / Content-Range).
    private(set) var response: HTTPURLResponse?
    private var continuation: CheckedContinuation<URL, Error>?
    private var task: URLSessionDownloadTask?

    func fetch(_ req: URLRequest) async throws -> URL {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (c: CheckedContinuation<URL, Error>) in
                self.continuation = c
                let s = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
                let t = s.downloadTask(with: req)
                self.task = t
                t.resume()
            }
        } onCancel: {
            self.task?.cancel()
        }
    }

    private func finish(_ r: Result<URL, Error>) {
        guard let c = continuation else { return }
        continuation = nil
        c.resume(with: r)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        if totalBytesExpectedToWrite > 0 {
            onProgress?(Double(totalBytesWritten) / Double(totalBytesExpectedToWrite))
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        response = downloadTask.response as? HTTPURLResponse
        if let r = response, !(200..<300).contains(r.statusCode) {
            finish(.failure(VideoError.http(r.statusCode)))
            return
        }
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        do {
            try FileManager.default.moveItem(at: location, to: tmp)
            finish(.success(tmp))
        } catch {
            finish(.failure(error))
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let e = error { finish(.failure(e)) }
        session.finishTasksAndInvalidate()
    }
}

@MainActor
final class VideoDownloader {
    static let shared = VideoDownloader()
    private init() {}

    private func fileName(_ v: DetectedVideo, ext: String) -> String {
        var base = v.displayName
        let bad = CharacterSet(charactersIn: "/\\:*?\"<>|\n\r\t")
        base = base.components(separatedBy: bad).joined(separator: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if base.isEmpty { base = "video" }
        if base.count > 60 { base = String(base.prefix(60)) }
        if v.height > 0 { base += " \(v.height)p" }
        return base + "." + ext
    }

    private func ext(for v: DetectedVideo) -> String {
        switch v.kind {
        case "mp4": return "mp4"
        case "webm": return "webm"
        case "hls": return "mp4"
        default:
            let e = v.url.pathExtension.lowercased()
            return e.isEmpty || e.count > 4 ? "mp4" : e
        }
    }

    private var running = Set<URL>()
    /// Video (theo link) → mục tải tương ứng, để bảng “Xem video” hiện tiến trình ngay trên thẻ.
    private(set) var jobs: [URL: UUID] = [:]

    func start(_ v: DetectedVideo, context: VideoContext, variant: URL? = nil, height: Int = 0) {
        guard !v.isBlob else { return }
        guard !running.contains(v.url) else {
            DownloadManager.shared.lastMessage = "Video này đang được tải rồi"
            return
        }
        running.insert(v.url)
        var named = v
        if height > 0 { named.height = height }
        let dm = DownloadManager.shared
        let id = dm.addExternal(name: fileName(named, ext: ext(for: v)))
        jobs[v.url] = id
        var bg = UIBackgroundTaskIdentifier.invalid
        bg = UIApplication.shared.beginBackgroundTask(withName: "video-download") {
            UIApplication.shared.endBackgroundTask(bg)
            bg = .invalid
        }
        let task = Task { @MainActor in
            defer {
                self.running.remove(v.url)
                if bg != .invalid { UIApplication.shared.endBackgroundTask(bg) }
            }
            do {
                let result: (URL, String)
                if v.kind == "hls" {
                    result = try await self.downloadHLS(v, context: context, variant: variant) { p in
                        Task { @MainActor in dm.setProgress(id, p) }
                    }
                } else {
                    // (profile header, có Range?) — thử lần lượt tới khi máy chủ chấp nhận
                    let attempts: [(Int, Bool)] = [(0, true), (1, true), (1, false), (2, false), (3, false)]
                    var tmp: URL?
                    var firstResp: HTTPURLResponse?
                    var usedProfile = 0
                    var lastErr: Error = VideoError.empty
                    for (profile, range) in attempts {
                        try Task.checkCancellation()
                        let f = FileFetcher()
                        f.onProgress = { p in Task { @MainActor in dm.setProgress(id, p) } }
                        do {
                            tmp = try await f.fetch(context.request(v.url, page: v.page, profile: profile,
                                                                    rangeFrom: range ? 0 : nil))
                            firstResp = f.response
                            usedProfile = profile
                            break
                        } catch let e as VideoError {
                            lastErr = e
                            if case .http = e { continue }
                            throw e
                        }
                    }
                    guard let got = tmp else { throw lastErr }
                    try await self.finishDirect(got, resp: firstResp, v: v, ctx: context, profile: usedProfile) { p in
                        Task { @MainActor in dm.setProgress(id, p) }
                    }
                    result = (got, self.ext(for: v))
                }
                let dest = DownloadManager.destination(for: self.fileName(named, ext: result.1))
                try FileManager.default.moveItem(at: result.0, to: dest)
                dm.complete(id, file: dest, ok: true, message: nil)
            } catch is CancellationError {
                dm.complete(id, file: nil, ok: false, message: nil)
            } catch {
                let why = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                dm.complete(id, file: nil, ok: false, message: "Tải thất bại: \(why)")
            }
        }
        dm.registerCancel(id) { task.cancel() }
    }

    private func fileSize(_ u: URL) -> Int64 {
        Int64((try? u.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0)
    }

    /// Kiểm tra file vừa tải: loại bỏ trang văn bản, tải nối tiếp nếu máy chủ chỉ trả một phần (206),
    /// và từ chối file quá nhỏ so với video thật.
    private func finishDirect(_ file: URL, resp: HTTPURLResponse?, v: DetectedVideo, ctx: VideoContext,
                              profile: Int, progress: @escaping (Double) -> Void) async throws {
        func discard() { try? FileManager.default.removeItem(at: file) }

        if let m = resp?.mimeType?.lowercased(),
           m.hasPrefix("text/") || m.contains("html") || m.contains("json") || m.contains("xml") {
            discard(); throw VideoError.notVideo
        }
        // Content-Range: bytes 0-21000/123456789
        var total: Int64 = 0
        if resp?.statusCode == 206,
           let cr = resp?.value(forHTTPHeaderField: "Content-Range"),
           let slash = cr.lastIndex(of: "/"),
           let t = Int64(cr[cr.index(after: slash)...].trimmingCharacters(in: .whitespaces)) {
            total = t
        }
        var got = fileSize(file)
        var stalls = 0
        while total > 0, got < total {
            try Task.checkCancellation()
            let f = FileFetcher()
            let part: URL
            do {
                part = try await f.fetch(ctx.request(v.url, page: v.page, profile: profile, rangeFrom: got))
            } catch {
                discard(); throw error
            }
            let n = fileSize(part)
            if n == 0 || f.response?.statusCode != 206 {
                try? FileManager.default.removeItem(at: part)
                stalls += 1
                if stalls >= 2 { break }
                continue
            }
            // nối thêm vào file chính
            if let src = try? FileHandle(forReadingFrom: part), let dst = try? FileHandle(forWritingTo: file) {
                _ = try? dst.seekToEnd()
                while true {
                    let chunk = src.readData(ofLength: 1 << 20)
                    if chunk.isEmpty { break }
                    try dst.write(contentsOf: chunk)
                }
                try? src.close(); try? dst.close()
            }
            try? FileManager.default.removeItem(at: part)
            got = fileSize(file)
            progress(Double(got) / Double(total))
        }
        let size = fileSize(file)
        // Video thật hàng phút thì không thể dưới ~100 KB
        let minimum: Int64 = (v.duration > 30 || total > 1_000_000) ? 100 * 1024 : 1024
        if size < minimum || (total > 0 && size < total) {
            discard(); throw VideoError.tooSmall(size)
        }
    }

    // MARK: HLS (.m3u8): ghép các đoạn chưa mã hoá thành một file

    /// Hồ sơ header đã thành công (dùng chung cho mọi đoạn của một video).
    private final class ProfileBox { var value = 0 }
    private var profileBox = ProfileBox()

    private func fetchData(_ url: URL, _ v: DetectedVideo, _ c: VideoContext) async throws -> Data {
        var lastErr: Error = VideoError.empty
        var profile = profileBox.value
        var netRetries = 0
        while profile < VideoContext.profileCount {
            try Task.checkCancellation()
            do {
                let (d, r) = try await URLSession.shared.data(for: c.request(url, page: v.page, profile: profile))
                if let h = r as? HTTPURLResponse, !(200..<300).contains(h.statusCode) { throw VideoError.http(h.statusCode) }
                if profile > profileBox.value { profileBox.value = profile }
                return d
            } catch let e as VideoError {
                lastErr = e
                if case .http = e { profile += 1; continue }
                throw e
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                // lỗi mạng thoáng qua: thử lại tối đa 3 lần
                lastErr = error
                netRetries += 1
                if netRetries >= 3 { throw error }
                try await Task.sleep(nanoseconds: 600_000_000)
            }
        }
        throw lastErr
    }

    private func fetchText(_ url: URL, _ v: DetectedVideo, _ c: VideoContext) async throws -> String {
        let d = try await fetchData(url, v, c)
        return String(decoding: d, as: UTF8.self)
    }

    private func resolve(_ s: String, base: URL) -> URL? {
        URL(string: s, relativeTo: base)?.absoluteURL
    }

    private func downloadHLS(_ v: DetectedVideo, context c: VideoContext, variant: URL? = nil,
                             progress: @escaping (Double) -> Void) async throws -> (URL, String) {
        profileBox = ProfileBox()
        var listURL = variant ?? v.url
        var text = try await fetchText(listURL, v, c)

        if text.contains("#EXT-X-STREAM-INF") {
            let lines = text.components(separatedBy: .newlines)
            var best: (bw: Int, uri: String)?
            var i = 0
            while i < lines.count {
                let l = lines[i]
                if l.hasPrefix("#EXT-X-STREAM-INF") {
                    var bw = 0
                    if let r = l.range(of: "BANDWIDTH=") {
                        let digits = l[r.upperBound...].prefix { $0.isNumber }
                        bw = Int(digits) ?? 0
                    }
                    var j = i + 1
                    while j < lines.count, lines[j].trimmingCharacters(in: .whitespaces).isEmpty || lines[j].hasPrefix("#") { j += 1 }
                    if j < lines.count, best == nil || bw > best!.bw {
                        best = (bw, lines[j].trimmingCharacters(in: .whitespaces))
                    }
                    i = j
                }
                i += 1
            }
            guard let b = best, let u = resolve(b.uri, base: listURL) else { throw VideoError.empty }
            listURL = u
            text = try await fetchText(listURL, v, c)
        }

        var segments: [URL] = []
        var initURL: URL?
        for raw in text.components(separatedBy: .newlines) {
            let l = raw.trimmingCharacters(in: .whitespaces)
            if l.isEmpty { continue }
            if l.hasPrefix("#EXT-X-KEY") {
                if !l.contains("METHOD=NONE") { throw VideoError.encrypted }
            } else if l.hasPrefix("#EXT-X-MAP") {
                if let r1 = l.range(of: "URI=\""), let r2 = l.range(of: "\"", range: r1.upperBound..<l.endIndex) {
                    initURL = resolve(String(l[r1.upperBound..<r2.lowerBound]), base: listURL)
                }
            } else if !l.hasPrefix("#") {
                if let u = resolve(l, base: listURL) { segments.append(u) }
            }
        }
        guard !segments.isEmpty else { throw VideoError.empty }

        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        FileManager.default.createFile(atPath: tmp.path, contents: nil)
        let fh = try FileHandle(forWritingTo: tmp)
        defer { try? fh.close() }

        if let i = initURL { try fh.write(contentsOf: try await fetchData(i, v, c)) }

        let batch = 6
        var done = 0
        var start = 0
        while start < segments.count {
            try Task.checkCancellation()
            let slice = Array(segments[start..<min(start + batch, segments.count)])
            let chunks = try await withThrowingTaskGroup(of: (Int, Data).self) { g -> [Data] in
                for (i, u) in slice.enumerated() {
                    g.addTask {
                        let d = try await self.fetchData(u, v, c)
                        return (i, d)
                    }
                }
                var out = [Data?](repeating: nil, count: slice.count)
                for try await (i, d) in g { out[i] = d }
                return out.compactMap { $0 }
            }
            for d in chunks { try fh.write(contentsOf: d) }
            done += slice.count
            start += batch
            progress(Double(done) / Double(segments.count))
        }
        return (tmp, initURL != nil ? "mp4" : "ts")
    }
}

// MARK: - Nút nổi & bảng “Xem video”

struct VideoFab: View {
    @ObservedObject var tab: Tab
    let action: () -> Void
    var onHideTab: () -> Void = {}
    var onHideAlways: () -> Void = {}

    private var count: Int { tab.videos.filter { !$0.isBlob }.count }

    var body: some View {
        if count > 0 {
            Button(action: action) {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: "arrow.down.to.line")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 54, height: 54)
                        .background(Theme.gradient, in: Circle())
                        .overlay(Circle().strokeBorder(.white.opacity(0.3), lineWidth: 1))
                        .shadow(color: Theme.accent.opacity(0.55), radius: 12, y: 5)
                    Text("\(count)")
                        .font(.system(size: 11, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 5)
                        .frame(minWidth: 19, minHeight: 19)
                        .background(Theme.danger, in: Capsule())
                        .overlay(Capsule().strokeBorder(.white, lineWidth: 1.5))
                        .offset(x: 4, y: -4)
                }
            }
            .buttonStyle(PressStyle())
            .contextMenu {
                Button { onHideTab() } label: { Label("Ẩn nút ở tab này", systemImage: "eye.slash") }
                Button(role: .destructive) { onHideAlways() } label: { Label("Tắt nút nổi (bật lại trong Cài đặt)", systemImage: "xmark.circle") }
            }
            .transition(.scale.combined(with: .opacity))
        }
    }
}

struct VideoSheet: View {
    @ObservedObject var tab: Tab
    @Environment(\.dismiss) private var dismiss
    @State private var playing: PlayerItem?
    @State private var busy = false
    @ObservedObject private var dm = DownloadManager.shared
    @State private var banner: String?
    @State private var picking: QualityPick?

    struct QualityPick: Identifiable {
        let id = UUID()
        let video: DetectedVideo
        let variants: [HLSVariant]
        let context: VideoContext
    }

    struct PlayerItem: Identifiable {
        let id = UUID()
        let video: DetectedVideo
        let context: VideoContext
        var start: Double = 0
    }

    private func context() async -> VideoContext {
        var c = VideoContext()
        let store = tab.webView.configuration.websiteDataStore.httpCookieStore
        c.cookies = await store.allCookies()
        if let ua = try? await tab.webView.evaluateJavaScript("navigator.userAgent") as? String, !ua.isEmpty {
            c.userAgent = ua
        }
        return c
    }

    private func play(_ v: DetectedVideo) {
        busy = true
        Task { @MainActor in
            let c = await context()
            _ = try? await tab.webView.evaluateJavaScript("document.querySelectorAll('video,audio').forEach(function(m){try{m.pause()}catch(e){}})")
            playing = PlayerItem(video: v, context: c)
            busy = false
        }
    }

    private func download(_ v: DetectedVideo) {
        Task { @MainActor in
            let c = await context()
            if v.kind == "hls" {
                // Video nhiều mức chất lượng: cho người dùng chọn (mỗi chiều cao một mục, mức bitrate cao nhất)
                let all = await HLSInfo.variants(url: v.url, page: v.page, context: c).filter { $0.url != nil }
                var best: [Int: HLSVariant] = [:]
                for x in all where x.bandwidth >= (best[x.short]?.bandwidth ?? -1) { best[x.short] = x }
                let list = best.values.sorted { $0.short > $1.short }
                if list.count > 1 {
                    picking = QualityPick(video: v, variants: list, context: c)
                    return
                }
            }
            VideoDownloader.shared.start(v, context: c)
            banner = "Bắt đầu tải: \(v.displayName)"
        }
    }

    private func download(_ p: QualityPick, _ x: HLSVariant?) {
        VideoDownloader.shared.start(p.video, context: p.context, variant: x?.url, height: x?.short ?? 0)
        banner = "Bắt đầu tải \(x.map { PlayerQuality.short($0.short) } ?? "chất lượng cao nhất"): \(p.video.displayName)"
    }

    var body: some View {
        SheetScaffold(title: "Xem video",
                      subtitle: tab.videos.isEmpty ? "Chưa phát hiện video" : "\(tab.videos.count) video trên trang",
                      onClose: { dismiss() }) {
            ScrollView {
                LazyVStack(spacing: 10) {
                    if tab.videos.isEmpty {
                        EmptyState(asset: "ic_download", title: "Chưa phát hiện video",
                                   message: "Mở trang có video và bấm phát, nút tải sẽ tự hiện ở góc màn hình.")
                    }
                    ForEach(tab.videos) { v in card(v) }
                    Text("Chỉ hiện video xem và tải được trên iPhone: đường dẫn trực tiếp (MP4, MOV) và HLS (.m3u8) không mã hoá. Video DRM hoặc dạng luồng nội bộ (như YouTube, Netflix) không tải được. Chỉ tải nội dung bạn có quyền sử dụng.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .padding(.horizontal, 6).padding(.top, 6)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 30)
            }
        }
        .overlay(alignment: .bottom) {
            if let b = banner {
                Text(b)
                    .font(.footnote.weight(.semibold))
                    .multilineTextAlignment(.leading)
                    .padding(.horizontal, 16).padding(.vertical, 12)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(Theme.cardStroke))
                    .padding(.horizontal, 16).padding(.bottom, 20)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .onTapGesture { banner = nil }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: banner)
        .onChange(of: dm.lastMessage) { m in
            guard let m else { return }
            banner = m
        }
        .task(id: banner) {
            guard banner != nil else { return }
            try? await Task.sleep(nanoseconds: 6_000_000_000)
            banner = nil
        }
        .fullScreenCover(item: $playing) { p in
            NativePlayerCover(item: p) { playing = nil }
        }
        .confirmationDialog("Chọn chất lượng để tải",
                            isPresented: Binding(get: { picking != nil }, set: { if !$0 { picking = nil } }),
                            titleVisibility: .visible,
                            presenting: picking) { p in
            ForEach(Array(p.variants.enumerated()), id: \.offset) { _, x in
                Button(PlayerQuality.label(x.short)) { download(p, x) }
            }
            Button("Huỷ", role: .cancel) {}
        }
    }

    private func item(for v: DetectedVideo) -> DownloadItem? {
        guard let id = VideoDownloader.shared.jobs[v.url] else { return nil }
        return dm.items.first(where: { $0.id == id })
    }

    private func isRunning(_ v: DetectedVideo) -> Bool { item(for: v)?.state == .running }

    private func etaText(_ s: Double?) -> String {
        guard let s, s.isFinite else { return "Đang tính thời gian…" }
        let t = Int(s.rounded(.up))
        if t < 60 { return "Còn khoảng \(max(t, 1)) giây" }
        if t < 3600 { return "Còn khoảng \(t / 60) phút \(t % 60) giây" }
        return "Còn khoảng \(t / 3600) giờ \((t % 3600) / 60) phút"
    }

    /// Tiến trình tải ngay trên thẻ video: thanh tiến độ, % và thời gian còn lại.
    @ViewBuilder
    private func progressBlock(_ v: DetectedVideo) -> some View {
        if let it = item(for: v) {
            switch it.state {
            case .running:
                VStack(alignment: .leading, spacing: 6) {
                    HStack(spacing: 10) {
                        ProgressView(value: min(max(it.progress, 0), 1)).tint(Theme.accent)
                        Button { dm.remove(it.id) } label: {
                            Image(systemName: "xmark.circle.fill").font(.title3).foregroundStyle(.secondary)
                        }
                        .buttonStyle(.plain)
                    }
                    HStack {
                        Text(it.progress > 0 ? "\(Int(it.progress * 100))%" : "Đang kết nối…")
                            .font(.caption.weight(.bold)).foregroundStyle(Theme.accent)
                        Spacer()
                        TimelineView(.periodic(from: .now, by: 1)) { _ in
                            Text(etaText(it.etaSeconds)).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            case .done:
                Label("Đã tải xong — xem ở mục Tải xuống", systemImage: "checkmark.circle.fill")
                    .font(.caption.weight(.semibold)).foregroundStyle(Theme.accent)
            case .failed:
                Label(it.error ?? "Tải thất bại", systemImage: "exclamationmark.triangle.fill")
                    .font(.caption).foregroundStyle(Theme.warn)
            }
        }
    }

    private func card(_ v: DetectedVideo) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                IconChip(sf: v.isBlob ? "lock.fill" : "play.fill", color: v.isBlob ? Theme.warn : Theme.accent, size: 42)
                VStack(alignment: .leading, spacing: 3) {
                    Text(v.displayName).font(.subheadline.weight(.bold)).lineLimit(2)
                    Text(v.detail).font(.caption.weight(.semibold)).foregroundStyle(Theme.accent)
                    Text(v.url.host ?? v.url.absoluteString).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            if v.isBlob {
                Label("Video dùng luồng nội bộ hoặc DRM nên không thể tải trực tiếp.",
                      systemImage: "exclamationmark.triangle.fill")
                    .font(.caption).foregroundStyle(Theme.warn)
            } else {
                HStack(spacing: 8) {
                    Button { play(v) } label: {
                        Label("Xem", systemImage: "play.fill").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle())
                    .disabled(busy)
                    Button { download(v) } label: {
                        Label(isRunning(v) ? "Đang tải…" : "Tải về",
                              systemImage: isRunning(v) ? "arrow.down.circle" : "arrow.down.circle.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle(filled: true))
                    .disabled(isRunning(v))
                    MiniIconButton(sf: "link") {
                        UIPasteboard.general.string = v.url.absoluteString
                        DownloadManager.shared.notify?("Đã chép liên kết video")
                    }
                }
                progressBlock(v)
            }
        }
        .padding(14)
        .card(radius: 20)
    }
}

/// Khung phát toàn màn hình: trình phát gốc iOS + nút chọn chất lượng (video HLS nhiều mức).
struct NativePlayerCover: View {
    let item: VideoSheet.PlayerItem
    let onClose: () -> Void
    @ObservedObject private var settings = BrowserSettings.shared
    @StateObject private var q = PlayerQuality()
    @State private var wake = 0
    @State private var dim = false

    private var chipText: String { q.selected == 0 ? "Auto" : PlayerQuality.short(q.selected) }

    private var qualityChip: some View {
        Menu {
            Picker("Chất lượng tối đa", selection: $q.selected) {
                Text("Tự động (theo mạng)").tag(0)
                ForEach(q.heights, id: \.self) { h in
                    Text(PlayerQuality.label(h)).tag(h)
                }
            }
            Text("Mạng hiện tại: \(q.network)")
        } label: {
            HStack(spacing: 5) {
                Image(systemName: "slider.horizontal.3").font(.system(size: 12, weight: .bold))
                Text(chipText).font(.system(size: 13, weight: .bold, design: .rounded))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 12)
            .frame(height: 34)
            .background(.black.opacity(0.55), in: Capsule())
        }
        .opacity(dim ? 0.35 : 1)
        .padding(.leading, 20)
    }

    var body: some View {
        ZStack(alignment: .leading) {
            Color.black.ignoresSafeArea()
            NativePlayer(video: item.video, context: item.context, start: item.start,
                         quality: q, initialQuality: settings.videoQuality, saver: settings.saverActive)
                .ignoresSafeArea()
                .simultaneousGesture(TapGesture().onEnded { wake += 1 })
            if q.isHLS && q.heights.count > 1 { qualityChip }
        }
        .onChange(of: q.selected) { v in settings.videoQuality = v }
        .task(id: wake) {
            dim = false
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            if !Task.isCancelled { dim = true }
        }
    }
}

/// Nhớ vị trí đang xem của từng video (theo link, bỏ phần token sau dấu ?).
enum PlaybackMemory {
    private static let key = "xb.playpos"

    static func id(_ url: URL) -> String {
        var c = URLComponents(url: url, resolvingAgainstBaseURL: false)
        c?.query = nil; c?.fragment = nil
        return c?.string ?? url.absoluteString
    }

    private static func all() -> [String: [Double]] {
        (UserDefaults.standard.dictionary(forKey: key) as? [String: [Double]]) ?? [:]
    }

    static func load(_ url: URL) -> Double {
        all()[id(url)]?.first ?? 0
    }

    /// Xem gần hết thì xoá (lần sau xem lại từ đầu).
    static func save(_ url: URL, time: Double, duration: Double) {
        var d = all()
        let k = id(url)
        if !time.isFinite || time < 3 || (duration > 0 && duration.isFinite && time > duration - 8) {
            d.removeValue(forKey: k)
        } else {
            d[k] = [time, Date().timeIntervalSince1970]
            if d.count > 200 {
                let old = d.sorted { ($0.value.last ?? 0) < ($1.value.last ?? 0) }.prefix(d.count - 200)
                for (kk, _) in old { d.removeValue(forKey: kk) }
            }
        }
        UserDefaults.standard.set(d, forKey: key)
    }
}

/// Chất lượng phát HLS: các mức có trong video + mức đang chọn (0 = tự động theo mạng).
final class PlayerQuality: ObservableObject {
    @Published var heights: [Int] = []     // chiều ngắn (p), giảm dần
    @Published var selected = 0
    @Published var network = ""
    @Published var isHLS = false

    static func short(_ h: Int) -> String { h >= 2160 ? "4K" : h >= 1440 ? "2K" : "\(h)p" }
    static func label(_ h: Int) -> String {
        h >= 2160 ? "4K · 2160p" : h >= 1440 ? "2K · 1440p" : "\(h)p"
    }
}

struct HLSVariant {
    let w: Int
    let h: Int
    let bandwidth: Int
    var url: URL? = nil
    var short: Int { min(w, h) }
}

enum HLSInfo {
    static func parse(_ text: String, base: URL? = nil) -> [HLSVariant] {
        guard text.contains("#EXT-X-STREAM-INF") else { return [] }
        let lines = text.components(separatedBy: .newlines)
        var out: [HLSVariant] = []
        for (i, raw) in lines.enumerated() where raw.hasPrefix("#EXT-X-STREAM-INF") {
            let l = raw.replacingOccurrences(of: "AVERAGE-BANDWIDTH", with: "AVG")
            var w = 0, h = 0, bw = 0
            if let r = l.range(of: "RESOLUTION=") {
                let parts = l[r.upperBound...].prefix { $0.isNumber || $0 == "x" }.split(separator: "x")
                if parts.count == 2 { w = Int(parts[0]) ?? 0; h = Int(parts[1]) ?? 0 }
            }
            if let r = l.range(of: "BANDWIDTH=") {
                bw = Int(l[r.upperBound...].prefix { $0.isNumber }) ?? 0
            }
            var uri: URL?
            var j = i + 1
            while j < lines.count, lines[j].trimmingCharacters(in: .whitespaces).isEmpty || lines[j].hasPrefix("#") { j += 1 }
            if j < lines.count, let b = base {
                uri = URL(string: lines[j].trimmingCharacters(in: .whitespaces), relativeTo: b)?.absoluteURL
            }
            if w > 0 && h > 0 { out.append(HLSVariant(w: w, h: h, bandwidth: bw, url: uri)) }
        }
        return out
    }

    /// Đọc master playlist để biết video có những mức chất lượng nào.
    static func variants(url: URL, page: String, context: VideoContext) async -> [HLSVariant] {
        for profile in 0..<VideoContext.profileCount {
            var req = context.request(url, page: page, profile: profile)
            req.timeoutInterval = 15
            guard let (data, resp) = try? await URLSession.shared.data(for: req) else { continue }
            if let http = resp as? HTTPURLResponse, !(200..<300).contains(http.statusCode) { continue }
            let text = String(decoding: data.prefix(400_000), as: UTF8.self)
            if text.contains("#EXTM3U") { return parse(text, base: url) }
        }
        return []
    }
}

struct NativePlayer: UIViewControllerRepresentable {
    let video: DetectedVideo
    let context: VideoContext
    var start: Double = 0
    var quality = PlayerQuality()
    var initialQuality = 0
    var saver = false

    /// Giữ trạng thái phát: lưu vị trí định kỳ, tự nối lại khi lỗi mạng.
    final class Coordinator {
        var player: AVPlayer?
        var url: URL?
        var makeItem: (() -> AVPlayerItem)?
        var last = 0.0
        var ticks = 0
        var retries = 0
        var online = true
        var needsRecover = false
        var timeToken: Any?
        var quality: PlayerQuality?
        var variants: [HLSVariant] = []
        var sel = 0
        var saver = false
        var cellular = false
        var constrained = false
        var qualityBag: AnyCancellable?
        var statusObs: NSKeyValueObservation?
        var stallObs: NSObjectProtocol?
        let monitor = NWPathMonitor()

        func begin() {
            monitor.pathUpdateHandler = { [weak self] path in
                DispatchQueue.main.async {
                    guard let self else { return }
                    let was = self.online
                    self.online = path.status == .satisfied
                    self.cellular = path.isExpensive || path.usesInterfaceType(.cellular)
                    self.constrained = path.isConstrained
                    self.refreshQuality()
                    if self.online && !was { self.retries = 0; self.recover() }
                }
            }
            monitor.start(queue: .global(qos: .utility))
            timeToken = player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 1),
                                                        queue: .main) { [weak self] t in
                guard let self else { return }
                let s = t.seconds
                guard s.isFinite, s > 0 else { return }
                self.last = s
                self.retries = 0
                self.ticks += 1
                if self.ticks % 5 == 0 { self.persist() }
            }
        }

        /// Đang bị giới hạn dữ liệu (chế độ dữ liệu thấp của iOS hoặc nút Tiết kiệm dữ liệu).
        private var lowData: Bool { constrained || saver }

        func refreshQuality() {
            quality?.network = lowData ? "Dữ liệu thấp" : (cellular ? "Mạng di động" : "Wi-Fi / mạng thường")
            applyQuality()
        }

        /// Đặt giới hạn độ phân giải: theo lựa chọn, hoặc (Tự động) theo mạng đang dùng.
        func applyQuality(to item: AVPlayerItem? = nil) {
            guard let it = item ?? player?.currentItem else { return }
            var target = sel          // chiều ngắn tối đa (p); 0 = không giới hạn
            var peak = 0.0
            if sel == 0 {
                if lowData { target = 360; peak = 800_000 }
                else if cellular { target = 720; peak = 3_000_000 }
            }
            if target > 0, !variants.isEmpty {
                let ok = variants.filter { $0.short <= target }
                if let v = ok.max(by: { $0.short < $1.short }) ?? variants.min(by: { $0.short < $1.short }) {
                    it.preferredMaximumResolution = CGSize(width: v.w, height: v.h)
                }
                it.preferredPeakBitRate = 0
            } else {
                it.preferredMaximumResolution = .zero
                // Không đọc được danh sách mức: chỉ giới hạn theo băng thông ở chế độ Tự động
                it.preferredPeakBitRate = (sel == 0 && variants.isEmpty) ? peak : 0
            }
        }

        func attach(_ item: AVPlayerItem) {
            applyQuality(to: item)
            statusObs = item.observe(\.status, options: [.new]) { [weak self] it, _ in
                guard it.status == .failed else { return }
                DispatchQueue.main.async { self?.failed() }
            }
            if let o = stallObs { NotificationCenter.default.removeObserver(o) }
            stallObs = NotificationCenter.default.addObserver(forName: .AVPlayerItemPlaybackStalled,
                                                              object: item, queue: .main) { [weak self] _ in
                // Đang offline thì đánh dấu để nối lại khi có mạng; online thì AVPlayer tự đệm.
                if self?.online == false { self?.needsRecover = true }
            }
        }

        private func failed() {
            needsRecover = true
            persist()
            guard online, retries < 5 else { return }
            retries += 1
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in self?.recover() }
        }

        func recover() {
            guard needsRecover, online, let p = player, let make = makeItem else { return }
            needsRecover = false
            let item = make()
            attach(item)
            p.replaceCurrentItem(with: item)
            if last > 1 {
                p.seek(to: CMTime(seconds: last, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
            }
            p.play()
        }

        func persist() {
            guard let u = url else { return }
            let d = player?.currentItem?.duration.seconds ?? 0
            PlaybackMemory.save(u, time: last, duration: d.isFinite ? d : 0)
        }

        func stop() {
            qualityBag = nil
            persist()
            if let t = timeToken { player?.removeTimeObserver(t); timeToken = nil }
            if let o = stallObs { NotificationCenter.default.removeObserver(o); stallObs = nil }
            statusObs = nil
            monitor.cancel()
            player?.pause()
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIViewController(context ctx: Context) -> AVPlayerViewController {
        let ctxInfo = context
        let url = video.url, page = video.page
        let make: () -> AVPlayerItem = {
            let h = ctxInfo.headers(for: url, page: page)
            var opts: [String: Any] = ["AVURLAssetHTTPHeaderFieldsKey": h]
            if !ctxInfo.cookies.isEmpty { opts["AVURLAssetHTTPCookiesKey"] = ctxInfo.cookies }
            return AVPlayerItem(asset: AVURLAsset(url: url, options: opts))
        }
        let item = make()
        let player = AVPlayer(playerItem: item)
        let vc = AVPlayerViewController()
        vc.player = player
        vc.allowsPictureInPicturePlayback = true

        // Vị trí bắt đầu: vị trí trang đang phát (nếu có), không thì vị trí đã lưu lần trước.
        let resume = start > 1 && start.isFinite ? start : PlaybackMemory.load(url)
        let c = ctx.coordinator
        c.player = player; c.url = url; c.makeItem = make; c.last = resume
        c.quality = quality; c.sel = initialQuality; c.saver = saver
        c.attach(item)
        c.begin()

        // Chất lượng: chỉ video HLS mới có nhiều mức để chọn
        let isHLS = video.kind == "hls" || url.pathExtension.lowercased() == "m3u8"
        let q = quality
        let initial = initialQuality
        DispatchQueue.main.async { q.isHLS = isHLS; q.selected = initial }
        c.qualityBag = q.$selected.receive(on: DispatchQueue.main).sink { [weak c] v in
            c?.sel = v
            c?.applyQuality()
        }
        if isHLS {
            Task {
                let vs = await HLSInfo.variants(url: url, page: page, context: ctxInfo)
                DispatchQueue.main.async { [weak c] in
                    guard let c = c else { return }
                    c.variants = vs
                    q.heights = Array(Set(vs.map { $0.short })).sorted(by: >)
                    c.applyQuality()
                }
            }
        }
        if resume > 1 {
            player.seek(to: CMTime(seconds: resume, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
        }
        player.play()
        return vc
    }

    func updateUIViewController(_ vc: AVPlayerViewController, context: Context) {}

    static func dismantleUIViewController(_ vc: AVPlayerViewController, coordinator: Coordinator) {
        coordinator.stop()
    }
}

// MARK: - Lọc video: chỉ giữ video vừa xem được vừa tải được trên iPhone

enum VideoProbe {
    /// Định dạng trình phát gốc iOS (AVPlayer) không phát được.
    private static let badExt: Set<String> = ["webm", "mkv", "flv", "f4v", "avi", "ogv", "ogg", "wmv", "mpd"]
    private static let badMime = ["video/webm", "video/x-matroska", "video/x-flv", "video/x-msvideo",
                                  "video/ogg", "video/x-ms-wmv", "application/dash+xml"]

    /// Lọc nhanh theo tên/đuôi file (không cần mạng).
    static func supportedByName(_ v: DetectedVideo) -> Bool {
        if v.isBlob || v.kind == "webm" { return false }
        return !badExt.contains(v.url.pathExtension.lowercased())
    }

    /// Thông tin đọc được khi dò một link video.
    struct Info {
        var size: Int64 = 0
        var width = 0
        var height = 0
        var duration = 0.0
        /// Với master playlist HLS: các link mức chất lượng con (để không liệt kê trùng).
        var children: [URL] = []
    }

    /// Kiểm tra thật qua mạng. Trả về nil khi chắc chắn không dùng được;
    /// lỗi mạng thoáng qua thì vẫn giữ video lại (Info rỗng).
    static func inspect(_ v: DetectedVideo, context c: VideoContext) async -> Info? {
        guard supportedByName(v) else { return nil }
        if v.kind == "hls" || v.url.pathExtension.lowercased() == "m3u8" {
            return await hlsInfo(v, c)
        }
        return await fileInfo(v, c)
    }

    static func isUsable(_ v: DetectedVideo, context c: VideoContext) async -> Bool {
        await inspect(v, context: c) != nil
    }

    // MARK: file trực tiếp (mp4, mov, …)

    private static func fileInfo(_ v: DetectedVideo, _ c: VideoContext) async -> Info? {
        var refused = false
        for profile in 0..<VideoContext.profileCount {
            var req = c.request(v.url, page: v.page, profile: profile, rangeFrom: 0)
            req.setValue("bytes=0-1023", forHTTPHeaderField: "Range")
            req.timeoutInterval = 15
            do {
                let (bytes, resp) = try await URLSession.shared.bytes(for: req)
                bytes.task.cancel()                 // chỉ cần header, không tải cả file
                guard let h = resp as? HTTPURLResponse else { return Info() }
                if !(200..<300).contains(h.statusCode) { refused = true; continue }
                let m = (h.mimeType ?? "").lowercased()
                if m.hasPrefix("text/") || m.contains("html") || m.contains("json") || m == "application/xml" {
                    refused = true; continue
                }
                if badMime.contains(m) { return nil }
                // Đoạn của luồng (ts / fMP4) hoặc âm thanh thuần: không phải video để tải
                if m == "video/mp2t" || m == "video/iso.segment" || m.hasPrefix("audio/") { return nil }
                var info = Info()
                if h.statusCode == 206,
                   let cr = h.value(forHTTPHeaderField: "Content-Range"),
                   let slash = cr.lastIndex(of: "/"),
                   let t = Int64(cr[cr.index(after: slash)...].trimmingCharacters(in: .whitespaces)) {
                    info.size = t
                } else if h.statusCode == 200, h.expectedContentLength > 0 {
                    info.size = h.expectedContentLength
                }
                // Dưới ~100 KB là mẩu quảng cáo / ảnh động, không phải video đáng tải
                if info.size > 0 && info.size < 100 * 1024 { return nil }
                return info
            } catch is CancellationError {
                return Info()
            } catch {
                return Info()                        // lỗi mạng: không loại
            }
        }
        return refused ? nil : Info()
    }

    // MARK: HLS (.m3u8)

    private enum Fetched { case ok(String), refused, unknown }

    private static func fetchText(_ url: URL, _ v: DetectedVideo, _ c: VideoContext) async -> Fetched {
        var refused = false
        for profile in 0..<VideoContext.profileCount {
            var req = c.request(url, page: v.page, profile: profile)
            req.timeoutInterval = 15
            do {
                let (data, resp) = try await URLSession.shared.data(for: req)
                if let h = resp as? HTTPURLResponse, !(200..<300).contains(h.statusCode) { refused = true; continue }
                let text = String(decoding: data.prefix(600_000), as: UTF8.self)
                if text.contains("#EXTM3U") { return .ok(text) }
                refused = true
            } catch {
                return .unknown
            }
        }
        return refused ? .refused : .unknown
    }

    private static func hasEncryption(_ text: String) -> Bool {
        for raw in text.components(separatedBy: .newlines) {
            let l = raw.trimmingCharacters(in: .whitespaces)
            if (l.hasPrefix("#EXT-X-KEY") || l.hasPrefix("#EXT-X-SESSION-KEY")), !l.contains("METHOD=NONE") {
                return true
            }
        }
        return false
    }

    private static func hlsInfo(_ v: DetectedVideo, _ c: VideoContext) async -> Info? {
        var info = Info()
        var text: String
        switch await fetchText(v.url, v, c) {
        case .ok(let t): text = t
        case .refused: return nil
        case .unknown: return Info()
        }
        if hasEncryption(text) { return nil }

        if text.contains("#EXT-X-STREAM-INF") {
            let lines = text.components(separatedBy: .newlines)
            var first: URL?
            var videoCodec = false, anyCodecs = false
            for (i, l) in lines.enumerated() where l.hasPrefix("#EXT-X-STREAM-INF") {
                if let r = l.range(of: "CODECS=\"") {
                    anyCodecs = true
                    let rest = l[r.upperBound...]
                    let codecs = rest.prefix { $0 != "\"" }.lowercased()
                    if ["avc1", "avc3", "hvc1", "hev1", "av01", "vp09", "vp9", "dvh1"].contains(where: { codecs.contains($0) }) {
                        videoCodec = true
                    }
                } else {
                    videoCodec = true               // không khai báo codec: coi như có hình
                }
                var j = i + 1
                while j < lines.count, lines[j].trimmingCharacters(in: .whitespaces).isEmpty || lines[j].hasPrefix("#") { j += 1 }
                if j < lines.count,
                   let u = URL(string: lines[j].trimmingCharacters(in: .whitespaces), relativeTo: v.url)?.absoluteURL {
                    info.children.append(u)
                    if first == nil { first = u }
                }
            }
            // Toàn bộ mức chỉ có âm thanh (radio, podcast) → bỏ
            if anyCodecs && !videoCodec { return nil }
            if let best = HLSInfo.parse(text).max(by: { $0.short < $1.short }) {
                info.width = best.w; info.height = best.h
            }
            guard let media = first else { return nil }
            switch await fetchText(media, v, c) {
            case .ok(let t): text = t
            case .refused: return nil
            case .unknown: return info
            }
            if hasEncryption(text) { return nil }
        }

        // Phải có ít nhất một đoạn; tính thời lượng nếu là video đã kết thúc (không phải phát trực tiếp)
        var segs = 0
        var dur = 0.0
        for raw in text.components(separatedBy: .newlines) {
            let l = raw.trimmingCharacters(in: .whitespaces)
            if l.hasPrefix("#EXTINF:") {
                dur += Double(l.dropFirst(8).prefix { $0.isNumber || $0 == "." }) ?? 0
            } else if !l.isEmpty && !l.hasPrefix("#") {
                segs += 1
            }
        }
        guard segs > 0 else { return nil }
        if text.contains("#EXT-X-ENDLIST") { info.duration = dur }
        return info
    }
}
