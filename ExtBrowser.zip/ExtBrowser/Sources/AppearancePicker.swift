import SwiftUI

/// Chọn giao diện Tự động / Sáng / Tối bằng 3 thẻ xem trước vẽ bằng SVG.
struct AppearancePicker: View {
    @Binding var selection: Int

    private let options: [(tag: Int, title: String, icon: String, preview: String)] = [
        (0, "Tự động", "ic_theme_auto", "pv_auto"),
        (1, "Sáng", "ic_sun", "pv_light"),
        (2, "Tối", "ic_moon", "pv_dark")
    ]

    var body: some View {
        HStack(spacing: 12) {
            ForEach(options, id: \.tag) { o in
                let on = selection == o.tag
                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { selection = o.tag }
                } label: {
                    VStack(spacing: 8) {
                        Image(o.preview)
                            .resizable()
                            .interpolation(.high)
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay {
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .strokeBorder(on ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Color.clear), lineWidth: 2.5)
                            }
                            .shadow(color: on ? Theme.accent.opacity(0.35) : .black.opacity(0.10), radius: on ? 8 : 4, y: 3)
                            .scaleEffect(on ? 1.0 : 0.96)
                        HStack(spacing: 5) {
                            SVGIcon(name: o.icon, size: 14)
                            Text(o.title).font(.system(size: 13, weight: on ? .bold : .medium, design: .rounded))
                        }
                        .foregroundStyle(on ? Theme.accent : Color.secondary)
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(PressStyle())
                .accessibilityLabel(o.title)
            }
        }
        .padding(14)
    }
}
