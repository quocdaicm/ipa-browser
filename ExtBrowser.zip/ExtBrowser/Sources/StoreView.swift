import SwiftUI

// MARK: - Gợi ý nhanh

struct SuggestedExt: Identifiable {
    let chromeID: String
    let name: String
    let note: String
    var id: String { chromeID }
    var url: String { "https://chromewebstore.google.com/detail/" + chromeID }
}

enum Suggested {
    static let all: [SuggestedExt] = [
        SuggestedExt(chromeID: "ddkjiahejlhfcafbddmgiahcphecmpfh", name: "uBlock Origin Lite", note: "Chặn quảng cáo (luật DNR)"),
        SuggestedExt(chromeID: "eimadpbcbfnmbkopoojfekhnkhdbieeh", name: "Dark Reader", note: "Chế độ tối cho mọi trang"),
        SuggestedExt(chromeID: "jinjaccalgkegednnccohejagnlnfdag", name: "Violentmonkey", note: "Quản lý userscript"),
        SuggestedExt(chromeID: "difoiogjjojoaoomphldepapgpbgkhkb", name: "Sider", note: "Trợ lý AI ở thanh bên")
    ]
}

// MARK: - Tách link từ văn bản dán vào

enum LinkParser {
    /// Lấy mọi link http(s) và ID extension Chrome (32 ký tự a–p) trong đoạn văn bản.
    static func parse(_ text: String) -> [String] {
        var out: [String] = []
        var seen = Set<String>()
        let ns = text as NSString
        let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
        detector?.enumerateMatches(in: text, range: NSRange(location: 0, length: ns.length)) { m, _, _ in
            guard let u = m?.url?.absoluteString, u.hasPrefix("http") else { return }
            if seen.insert(u).inserted { out.append(u) }
        }
        for w in text.split(whereSeparator: { !$0.isLetter }) {
            let s = String(w)
            guard s.count == 32, s.allSatisfy({ ("a"..."p").contains($0) }) else { continue }
            if out.contains(where: { $0.contains(s) }) { continue }
            let u = "https://chromewebstore.google.com/detail/" + s
            if seen.insert(u).inserted { out.append(u) }
        }
        return out
    }

    private static func pretty(_ slug: String) -> String {
        slug.replacingOccurrences(of: "-", with: " ").capitalized
    }

    /// Đoán tên từ đường dẫn (dùng tạm trong lúc chưa tải được tên thật).
    static func guessTitle(_ s: String) -> String {
        guard let u = URL(string: s) else { return s }
        let comps = u.pathComponents.filter { $0 != "/" }
        if let i = comps.firstIndex(of: "detail"), i + 1 < comps.count {
            let slug = comps[i + 1]
            if slug.count == 32 && i + 2 == comps.count { return "Extension Chrome (\(slug.prefix(8))…)" }
            return pretty(slug)
        }
        if let i = comps.firstIndex(of: "addon"), i + 1 < comps.count { return pretty(comps[i + 1]) }
        return comps.last ?? u.host ?? s
    }

    /// Tải tên thật từ thẻ <title> của trang store (không được thì trả nil).
    static func fetchTitle(_ s: String) async -> String? {
        guard let u = URL(string: s), u.path.contains("/detail/") || u.host == "addons.mozilla.org" else { return nil }
        var req = URLRequest(url: u)
        req.timeoutInterval = 8
        req.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148",
                     forHTTPHeaderField: "User-Agent")
        guard let (data, _) = try? await URLSession.shared.data(for: req) else { return nil }
        let html = String(decoding: data.prefix(80_000), as: UTF8.self)
        guard let r1 = html.range(of: "<title>"),
              let r2 = html.range(of: "</title>", range: r1.upperBound..<html.endIndex) else { return nil }
        var t = String(html[r1.upperBound..<r2.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
        if let r = t.range(of: " - Chrome Web Store") { t = String(t[..<r.lowerBound]) }
        if let r = t.range(of: " – ") { t = String(t[..<r.lowerBound]) }
        t = t.replacingOccurrences(of: "&amp;", with: "&").replacingOccurrences(of: "&#39;", with: "'")
        return t.isEmpty || t == "Chrome Web Store" ? nil : t
    }
}

// MARK: - Dán nhiều link → danh sách chọn để cài

struct LinkCandidate: Identifiable {
    enum State: Equatable { case idle, working, done(String), failed(String) }
    let id = UUID()
    let raw: String
    var title: String
    var selected = true
    var state: State = .idle
}

struct LinkImportView: View {
    @EnvironmentObject var manager: ExtensionManager
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var items: [LinkCandidate] = []
    @State private var installing = false

    private var selectedCount: Int {
        items.filter { $0.selected && !isDone($0) }.count
    }

    private func isDone(_ c: LinkCandidate) -> Bool {
        if case .done = c.state { return true }
        return false
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextEditor(text: $text)
                        .frame(minHeight: 100)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    HStack {
                        Button("Dán từ clipboard") {
                            if let s = UIPasteboard.general.string { text = s; build() }
                        }
                        Spacer()
                        Button("Tạo danh sách") { build() }
                            .buttonStyle(.borderedProminent)
                            .disabled(text.isEmpty || installing)
                    }
                    .buttonStyle(.borderless)
                } header: {
                    Text("Dán link hoặc ID (nhiều dòng)")
                } footer: {
                    Text("Nhận link Chrome Web Store, Firefox Add-ons, .user.js, .zip/.crx/.xpi hoặc ID extension Chrome (32 ký tự). Mỗi link thành một dòng để bạn chọn cài.")
                }

                if !items.isEmpty {
                    Section("Chọn extension để cài") {
                        ForEach($items) { $it in
                            Button {
                                if !installing { it.selected.toggle() }
                            } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: it.selected ? "checkmark.circle.fill" : "circle")
                                        .font(.title3)
                                        .foregroundStyle(it.selected ? Theme.accent : Color.secondary)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(it.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                                        Text(it.raw).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                                        switch it.state {
                                        case .done(let m):
                                            Text(m).font(.caption2).foregroundStyle(.green)
                                        case .failed(let m):
                                            Text(m).font(.caption2).foregroundStyle(.orange)
                                        default:
                                            EmptyView()
                                        }
                                    }
                                    Spacer()
                                    if it.state == .working { ProgressView() }
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .navigationTitle("Cài nhiều extension")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } }
            }
            .safeAreaInset(edge: .bottom) {
                if !items.isEmpty {
                    Button {
                        installSelected()
                    } label: {
                        Text(installing ? "Đang cài…" : "Cài \(selectedCount) extension đã chọn")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Theme.gradient, in: Capsule())
                            .foregroundStyle(.white)
                    }
                    .disabled(installing || selectedCount == 0)
                    .opacity(installing || selectedCount == 0 ? 0.5 : 1)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 8)
                    .background(.ultraThinMaterial)
                }
            }
        }
    }

    private func build() {
        let links = LinkParser.parse(text)
        items = links.map { LinkCandidate(raw: $0, title: LinkParser.guessTitle($0)) }
        // Tải tên thật ở nền
        for l in links {
            Task {
                if let t = await LinkParser.fetchTitle(l),
                   let i = items.firstIndex(where: { $0.raw == l }) {
                    items[i].title = t
                }
            }
        }
    }

    private func installSelected() {
        installing = true
        let ids = items.filter { $0.selected && !isDone($0) }.map { $0.id }
        Task {
            for id in ids {
                guard let i = items.firstIndex(where: { $0.id == id }) else { continue }
                items[i].state = .working
                let r = await manager.installReturning(items[i].raw)
                if let j = items.firstIndex(where: { $0.id == id }) {
                    items[j].state = r.ok ? .done(r.message) : .failed(r.message)
                    if r.ok { items[j].selected = false }
                }
            }
            installing = false
        }
    }
}
