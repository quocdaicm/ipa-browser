import SwiftUI
import CryptoKit
import LocalAuthentication
import Security

// MARK: - Mật khẩu riêng cho Dấu trang & Lịch sử (lưu băm có muối trong Keychain)

private enum LibKeychain {
    static let service = "com.example.extbrowser.librarylock"
    static let account = "pw"

    private static var base: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account]
    }

    static func read() -> Data? {
        var q = base
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess else { return nil }
        return out as? Data
    }

    static func write(_ data: Data) {
        delete()
        var q = base
        q[kSecValueData as String] = data
        q[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(q as CFDictionary, nil)
    }

    static func delete() { SecItemDelete(base as CFDictionary) }
}

/// Khoá riêng cho dấu trang và lịch sử: độc lập với khoá ứng dụng, tự khoá lại khi đóng bảng hoặc thoát app.
@MainActor
final class LibraryLock: ObservableObject {
    static let shared = LibraryLock()

    @Published private(set) var enabled: Bool
    @Published private(set) var unlocked = false
    @Published private(set) var lockoutUntil: Date?
    @Published var useBiometrics: Bool { didSet { UserDefaults.standard.set(useBiometrics, forKey: "liblock.bio") } }

    private var fails: Int { didSet { UserDefaults.standard.set(fails, forKey: "liblock.fails") } }

    private init() {
        let d = UserDefaults.standard
        // Cài mới thì xoá mật khẩu cũ còn sót trong Keychain
        if !d.bool(forKey: "liblock.installed") {
            LibKeychain.delete()
            d.set(true, forKey: "liblock.installed")
        }
        enabled = LibKeychain.read() != nil
        useBiometrics = d.object(forKey: "liblock.bio") as? Bool ?? true
        fails = d.integer(forKey: "liblock.fails")
        if let t = d.object(forKey: "liblock.until") as? Date, t > Date() { lockoutUntil = t }
    }

    /// Đang khoá: cần mật khẩu mới xem được dấu trang / lịch sử.
    var isLocked: Bool { enabled && !unlocked }

    private static func derive(_ pw: String, salt: Data) -> Data {
        var h = Data(SHA256.hash(data: salt + Data(pw.utf8)))
        for _ in 0..<20000 { h = Data(SHA256.hash(data: h + salt)) }
        return h
    }

    func verify(_ pw: String) -> Bool {
        guard let s = LibKeychain.read(), s.count == 48 else { return false }
        return Self.derive(pw, salt: Data(s.prefix(16))) == Data(s.suffix(32))
    }

    func setPassword(_ pw: String) {
        var salt = Data(count: 16)
        _ = salt.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 16, $0.baseAddress!) }
        LibKeychain.write(salt + Self.derive(pw, salt: salt))
        enabled = true
        unlocked = true
        fails = 0
        lockoutUntil = nil
        UserDefaults.standard.removeObject(forKey: "liblock.until")
    }

    func disable() {
        LibKeychain.delete()
        enabled = false
        unlocked = false
        fails = 0
        lockoutUntil = nil
        UserDefaults.standard.removeObject(forKey: "liblock.until")
    }

    func lock() { if unlocked { unlocked = false } }

    /// Trả về nil nếu đúng; ngược lại là thông báo lỗi.
    func unlock(with pw: String) -> String? {
        if let u = lockoutUntil, u > Date() { return "Thử lại sau ít phút." }
        if verify(pw) {
            fails = 0
            lockoutUntil = nil
            UserDefaults.standard.removeObject(forKey: "liblock.until")
            unlocked = true
            return nil
        }
        fails += 1
        if fails % 5 == 0 {
            let strikes = min(fails / 5, 6)
            let t = Date().addingTimeInterval(30 * pow(2, Double(strikes - 1)))
            lockoutUntil = t
            UserDefaults.standard.set(t, forKey: "liblock.until")
            return "Sai quá nhiều lần. Đã tạm khoá nhập mật khẩu."
        }
        return "Mật khẩu không đúng."
    }

    var biometryReady: Bool { useBiometrics && AppLock.shared.biometryAvailable }

    func authenticateBiometric() {
        guard isLocked, biometryReady else { return }
        LAContext().evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                                   localizedReason: "Mở khoá dấu trang và lịch sử") { ok, _ in
            guard ok else { return }
            Task { @MainActor in LibraryLock.shared.unlocked = true }
        }
    }

    func scenePhaseChanged(_ p: ScenePhase) {
        if p == .background { lock() }
    }
}

// MARK: - Màn nhập mật khẩu

/// Nội dung thay thế khi dấu trang / lịch sử đang khoá.
struct LibraryUnlockView: View {
    let title: String
    let onClose: () -> Void
    @ObservedObject private var lock = LibraryLock.shared
    @State private var password = ""
    @State private var error = ""
    @FocusState private var focused: Bool

    var body: some View {
        SheetScaffold(title: title, subtitle: "Đã khoá bằng mật khẩu", onClose: onClose) {
            TimelineView(.periodic(from: .now, by: 1)) { ctx in
                let remain = Int(max(0, (lock.lockoutUntil?.timeIntervalSince(ctx.date) ?? 0).rounded(.up)))
                VStack(spacing: 16) {
                    Spacer(minLength: 20)
                    SVGIcon(name: "ic_lock", size: 30)
                        .foregroundStyle(.white)
                        .frame(width: 68, height: 68)
                        .background(Theme.gradient, in: Circle())
                    Text("Nhập mật khẩu để xem")
                        .font(Theme.rounded(.headline, .bold))

                    SecureField("Mật khẩu 6 ký tự", text: $password)
                        .focused($focused)
                        .submitLabel(.go)
                        .onSubmit { submit() }
                        .onChange(of: password) { v in
                            if v.count > 6 { password = String(v.prefix(6)) }
                            else if v.count == 6 { submit() }
                        }
                        .multilineTextAlignment(.center)
                        .fieldStyle()
                        .padding(.horizontal, 40)
                        .disabled(remain > 0)

                    Text(remain > 0 ? "Thử lại sau \(remain) giây" : error)
                        .font(.footnote)
                        .foregroundStyle(Theme.danger)
                        .frame(height: 18)

                    Button("Mở khoá") { submit() }
                        .buttonStyle(PrimaryButtonStyle())
                        .padding(.horizontal, 40)
                        .disabled(remain > 0 || password.isEmpty)

                    if lock.biometryReady {
                        Button { lock.authenticateBiometric() } label: {
                            Label("Dùng \(AppLock.shared.biometryName)", systemImage: AppLock.shared.biometryIcon)
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(Theme.accent)
                        }
                    }
                    Spacer()
                    Spacer()
                }
                .frame(maxWidth: .infinity)
            }
        }
        .onAppear {
            if lock.biometryReady {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { lock.authenticateBiometric() }
            } else {
                focused = true
            }
        }
    }

    private func submit() {
        guard !password.isEmpty else { return }
        if let e = lock.unlock(with: password) {
            error = e
            password = ""
        }
    }
}
