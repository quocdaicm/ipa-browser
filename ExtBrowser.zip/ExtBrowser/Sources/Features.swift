import SwiftUI
import WebKit
import UIKit

// MARK: - Nhóm tab

struct TabGroup: Identifiable, Equatable {
    let id = UUID()
    var name: String
    var colorIndex: Int
}

enum GroupPalette {
    static let colors: [Color] = [
        Color(red: 0.25, green: 0.52, blue: 0.96),
        Color(red: 0.93, green: 0.30, blue: 0.30),
        Color(red: 0.98, green: 0.62, blue: 0.14),
        Color(red: 0.18, green: 0.78, blue: 0.50),
        Color(red: 0.62, green: 0.40, blue: 0.92),
        Color(red: 0.95, green: 0.40, blue: 0.70)
    ]
    static func color(_ i: Int) -> Color {
        colors[((i % colors.count) + colors.count) % colors.count]
    }
}

// MARK: - Chia sẻ file

struct ShareFile: Identifiable {
    let url: URL
    var id: URL { url }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

// MARK: - Chế độ đọc

/// Nhận nút Thoát / cỡ chữ / giao diện từ trang đọc.
final class ReaderBridge: NSObject, WKScriptMessageHandler {
    var onMessage: (@MainActor (WKWebView?, [String: Any]) -> Void)?

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard let b = message.body as? [String: Any] else { return }
        let w = message.webView
        Task { @MainActor in self.onMessage?(w, b) }
    }
}

enum ReaderMode {
    /// Tìm phần bài viết chính của trang, bỏ quảng cáo / menu / bình luận. Trả về chuỗi JSON hoặc null.
    static let extractJS = #"""
(function(){
try{
  var D=document; if(!D.body) return null;
  var BADTAG=/^(script|style|noscript|iframe|form|nav|aside|footer|header|button|input|select|textarea|svg|canvas|video|audio|object|embed|dialog|template|link|meta|label|source)$/i;
  var STRONG=/(^|[\s_-])(comments?|related|recommend\w*|newsletter|taboola|outbrain|sponsor\w*|advert\w*|advertisement|ads?|adv|popup|modal|cookie|breadcrumbs?)([\s_-]|$)/i;
  var WEAK=/(^|[\s_-])(share|sharing|social|tags?|toolbar|widget|print|toc|promo\w*|more|read-more|readmore)([\s_-]|$)/i;
  function txt(e){return (e.textContent||'').replace(/\s+/g,' ').trim();}
  function ld(e){
    var t=txt(e).length; if(!t) return 0; var l=0;
    e.querySelectorAll('a').forEach(function(a){l+=txt(a).length;});
    return l/t;
  }
  function meta(n){
    var m=D.querySelector('meta[property="'+n+'"],meta[name="'+n+'"]');
    return (m&&m.content)?m.content.trim():'';
  }
  var SEL='article,[itemprop=articleBody],[role=article],.article-body,.post-content,.entry-content,.article-content,.detail-content,.fck_detail,.singular-content,.content-detail,#article-body';
  var cand=null,best=null,bl=0;
  D.querySelectorAll(SEL).forEach(function(e){var l=txt(e).length; if(l>bl){bl=l;best=e;}});
  if(best&&bl>=500) cand=best;
  if(!cand){
    var sc=new Map();
    D.querySelectorAll('p,pre,td').forEach(function(p){
      var t=txt(p); if(t.length<50) return;
      var s=1+(t.split(',').length-1)+Math.min(Math.floor(t.length/100),3);
      var a=p.parentElement; if(!a) return;
      sc.set(a,(sc.get(a)||0)+s);
      var g=a.parentElement;
      if(g&&g!==D.documentElement) sc.set(g,(sc.get(g)||0)+s/2);
    });
    var ts=0;
    sc.forEach(function(v,k){
      v=v*(1-ld(k));
      if(v>ts){ts=v;cand=k;}
    });
  }
  if(!cand||txt(cand).length<250) return null;

  var c=cand.cloneNode(true);
  function clean(n){
    Array.prototype.slice.call(n.children).forEach(function(k){
      var tg=k.tagName;
      if(BADTAG.test(tg)){k.remove();return;}
      var cls=(k.getAttribute('class')||'')+' '+(k.id||'');
      if(!/^(img|picture|figure)$/i.test(tg)){
        if(STRONG.test(cls)){k.remove();return;}
        if(WEAK.test(cls)&&txt(k).length<400){k.remove();return;}
        if(k.getAttribute('aria-hidden')==='true'||k.hidden){k.remove();return;}
      }
      clean(k);
      if(/^(div|ul|ol|section|table|p|span)$/i.test(tg)&&!k.querySelector('img,picture')){
        var t=txt(k);
        if(!t){k.remove();return;}
        var th=/^p$/i.test(tg)?0.9:0.6;
        if(t.length<600&&ld(k)>th){k.remove();return;}
      }
    });
  }
  clean(c);

  c.querySelectorAll('picture').forEach(function(p){
    var im=p.querySelector('img'); if(im) p.replaceWith(im); else p.remove();
  });
  c.querySelectorAll('img').forEach(function(im){
    var s=im.getAttribute('data-src')||im.getAttribute('data-original')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||'';
    var cur=im.getAttribute('src')||'';
    if(/^data:/i.test(cur)&&(im.getAttribute('data-src')||im.getAttribute('data-original'))) s=im.getAttribute('data-src')||im.getAttribute('data-original');
    var w=parseInt(im.getAttribute('width')||'0',10);
    if(!s||/^data:/i.test(s)||(w&&w<48)){im.remove();return;}
    try{im.setAttribute('src',new URL(s,location.href).href);}catch(e){im.remove();}
  });
  c.querySelectorAll('a').forEach(function(a){
    var h=a.getAttribute('href')||'';
    if(!h||/^javascript:/i.test(h)){a.removeAttribute('href');return;}
    try{a.setAttribute('href',new URL(h,location.href).href);}catch(e){a.removeAttribute('href');}
  });

  var h1=D.querySelector('h1');
  var title=(h1&&txt(h1).length>5)?txt(h1):(meta('og:title')||D.title||'');
  var f=c.querySelector('h1'); if(f&&txt(f)===title) f.remove();

  c.querySelectorAll('*').forEach(function(e){
    Array.prototype.slice.call(e.attributes).forEach(function(a){
      if(!/^(href|src|alt|colspan|rowspan)$/i.test(a.name)) e.removeAttribute(a.name);
    });
  });

  var by=meta('author')||meta('article:author');
  if(!by){var be=D.querySelector('[rel=author],[itemprop=author],.author,.byline'); if(be) by=txt(be);}
  if(by.length>80) by='';
  var dt=meta('article:published_time')||meta('og:updated_time')||meta('date'),ds='';
  if(dt){var d=new Date(dt); if(!isNaN(d.getTime())) ds=d.toLocaleDateString();}

  var len=txt(c).length; if(len<250) return null;
  return JSON.stringify({title:title,byline:by,date:ds,site:location.hostname.replace(/^www\./,''),lang:D.documentElement.lang||'',html:c.innerHTML,len:len});
}catch(e){return null;}
})()
"""#

    static func esc(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }

    static func page(title: String, meta: String, body: String, lang: String, size: Int, theme: String) -> String {
        let th = ["light", "sepia", "dark"].contains(theme) ? theme : "light"
        let fs = min(max(size, 13), 30)
        let tpl = #"""
<!doctype html><html lang="__LANG__" data-theme="__THEME__"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="xb-nodark" content="1"><title>__TITLE__</title>
<style>
:root{--fs:__SIZE__px;--bg:#fff;--fg:#1d1d1f;--mut:#6b7280;--link:#0a8f8f;--bar:rgba(255,255,255,.92);--line:rgba(0,0,0,.12)}
[data-theme=sepia]{--bg:#f4ecd8;--fg:#3b2f20;--mut:#7a6a52;--link:#8a5a12;--bar:rgba(244,236,216,.92);--line:rgba(80,60,30,.22)}
[data-theme=dark]{--bg:#121416;--fg:#e6e6e6;--mut:#9aa0a6;--link:#4fd1c5;--bar:rgba(18,20,22,.92);--line:rgba(255,255,255,.16)}
html{-webkit-text-size-adjust:100%;background:var(--bg)}
body{margin:0;background:var(--bg);color:var(--fg);font-family:-apple-system,"Helvetica Neue",Georgia,serif;font-size:var(--fs);line-height:1.7;
 padding:max(20px,env(safe-area-inset-top)) max(18px,env(safe-area-inset-right)) calc(92px + env(safe-area-inset-bottom)) max(18px,env(safe-area-inset-left))}
article{max-width:680px;margin:0 auto;overflow-wrap:anywhere}
h1.t{font-size:1.5em;line-height:1.3;margin:.4em 0 .3em}
.m{color:var(--mut);font-size:.8em;margin-bottom:1.4em;padding-bottom:1em;border-bottom:1px solid var(--line)}
article img{max-width:100%;height:auto;border-radius:6px;display:block;margin:1em auto}
article a{color:var(--link)}
article h1,article h2,article h3,article h4{line-height:1.3;margin:1.4em 0 .5em}
article p{margin:0 0 1em}
article blockquote{margin:1em 0;padding:.2em 1em;border-left:3px solid var(--link);color:var(--mut)}
article pre{overflow:auto;background:var(--line);padding:12px;border-radius:8px;font-size:.85em}
article table{display:block;overflow:auto;border-collapse:collapse}
article td,article th{border:1px solid var(--line);padding:6px 8px}
figure{margin:1em 0}figcaption{color:var(--mut);font-size:.8em;text-align:center}
#bar{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(14px + env(safe-area-inset-bottom));display:flex;gap:2px;padding:6px;border-radius:999px;background:var(--bar);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);border:1px solid var(--line);box-shadow:0 6px 22px rgba(0,0,0,.2)}
#bar button{font:600 15px -apple-system,sans-serif;color:var(--fg);background:transparent;border:0;min-width:46px;height:40px;padding:0 12px;border-radius:999px}
#bar button:active{background:var(--line)}
</style></head><body>
<article><h1 class="t">__TITLE__</h1><div class="m">__META__</div>__BODY__</article>
<div id="bar"><button id="dn">A−</button><button id="up">A+</button><button id="th">Nền</button><button id="ex">✕ Thoát</button></div>
<script>
(function(){
 var root=document.documentElement,fs=__SIZE__,themes=['light','sepia','dark'],ti=Math.max(0,themes.indexOf('__THEME__'));
 function post(m){try{window.webkit.messageHandlers.xbReader.postMessage(m);}catch(e){}}
 function apply(){root.style.setProperty('--fs',fs+'px');root.setAttribute('data-theme',themes[ti]);post({a:'pref',size:fs,theme:themes[ti]});}
 document.getElementById('dn').onclick=function(){fs=Math.max(13,fs-2);apply();};
 document.getElementById('up').onclick=function(){fs=Math.min(30,fs+2);apply();};
 document.getElementById('th').onclick=function(){ti=(ti+1)%themes.length;apply();};
 document.getElementById('ex').onclick=function(){post({a:'exit'});};
})();
</script></body></html>
"""#
        return tpl
            .replacingOccurrences(of: "__LANG__", with: esc(lang))
            .replacingOccurrences(of: "__THEME__", with: th)
            .replacingOccurrences(of: "__SIZE__", with: String(fs))
            .replacingOccurrences(of: "__TITLE__", with: esc(title))
            .replacingOccurrences(of: "__META__", with: esc(meta))
            .replacingOccurrences(of: "__BODY__", with: body)
    }
}

// MARK: - Nền tối cho mọi trang

enum DarkScript {
    /// Đảo màu trang sáng (bỏ qua trang đã tối, giữ nguyên ảnh/video). Chỉ chạy ở khung chính.
    static let body = #"""
(function(){
  if (window.top !== window) return;
  if (window.__xbDarkInit) return; window.__xbDarkInit = true;
  var ID='__xb_dark_style', sheet=null;
  var CSS='html{filter:invert(1) hue-rotate(180deg)!important}'+
    'img,picture,video,canvas,svg image,iframe[src*="youtube"],iframe[src*="vimeo"],iframe[src*="player"],[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}';
  function put(){
    if (sheet || document.getElementById(ID)) return;
    try {
      sheet = new CSSStyleSheet(); sheet.replaceSync(CSS);
      document.adoptedStyleSheets = document.adoptedStyleSheets.concat([sheet]);
      return;
    } catch(e) { sheet = null; }
    var s = document.createElement('style'); s.id = ID; s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }
  function drop(){
    if (sheet) {
      var me = sheet;
      try { document.adoptedStyleSheets = document.adoptedStyleSheets.filter(function(x){ return x !== me; }); } catch(e){}
      sheet = null;
    }
    var s = document.getElementById(ID); if (s) s.remove();
  }
  function lum(c){
    var m = String(c).match(/rgba?\(([^)]+)\)/); if (!m) return null;
    var p = m[1].split(',').map(parseFloat);
    if (p.length > 3 && p[3] === 0) return null;
    return (0.2126*p[0] + 0.7152*p[1] + 0.0722*p[2]) / 255;
  }
  function pageIsDark(){
    try {
      var v = document.body ? lum(getComputedStyle(document.body).backgroundColor) : null;
      if (v === null) v = lum(getComputedStyle(document.documentElement).backgroundColor);
      return v !== null && v < 0.4;
    } catch(e){ return false; }
  }
  function check(){
    var X = window.__xb || {};
    if (!X.dark || document.querySelector('meta[name=xb-nodark]') || pageIsDark()) drop(); else put();
  }
  function apply(){
    var X = window.__xb || {};
    if (!X.dark) { drop(); return; }
    put();   // bật ngay để không bị chớp trắng, rồi kiểm tra lại khi trang đã dựng
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', check, {once:true});
    else check();
    window.addEventListener('load', check, {once:true});
  }
  window.__xbDarkApply = apply;
  apply();
})();
"""#
}

// MARK: - Dịch trang

enum PageTranslate {
    struct Lang: Identifiable {
        let code: String
        let name: String
        var id: String { code }
    }

    static let languages: [Lang] = [
        Lang(code: "vi", name: "Tiếng Việt"),
        Lang(code: "en", name: "English"),
        Lang(code: "zh-CN", name: "中文 (giản thể)"),
        Lang(code: "ja", name: "日本語"),
        Lang(code: "ko", name: "한국어"),
        Lang(code: "fr", name: "Français"),
        Lang(code: "de", name: "Deutsch"),
        Lang(code: "es", name: "Español"),
        Lang(code: "ru", name: "Русский"),
        Lang(code: "th", name: "ไทย")
    ]

    static func name(_ code: String) -> String {
        languages.first(where: { $0.code == code })?.name ?? code
    }

    /// Nạp bộ dịch của Google vào chính trang đang xem (giữ nguyên phiên đăng nhập).
    static func injectJS(_ tl: String) -> String {
        let safe = tl.filter { $0.isLetter || $0 == "-" }
        return #"""
(function(tl){
  try{
    var h=location.hostname, v='/auto/'+tl;
    document.cookie='googtrans='+v+';path=/';
    document.cookie='googtrans='+v+';path=/;domain='+h;
    if(!document.getElementById('xb_gt_box')){
      var box=document.createElement('div'); box.id='xb_gt_box';
      box.style.cssText='position:absolute;left:-9999px;top:0;width:1px;height:1px;overflow:hidden';
      (document.body||document.documentElement).appendChild(box);
    }
    window.googleTranslateElementInit=function(){
      try{ new google.translate.TranslateElement({pageLanguage:'auto',includedLanguages:tl,autoDisplay:false},'xb_gt_box'); }catch(e){}
    };
    var s=document.createElement('script');
    s.src='https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
    s.async=true; (document.head||document.documentElement).appendChild(s);
    try{
      var st=new CSSStyleSheet();
      st.replaceSync('.skiptranslate>iframe,.goog-te-banner-frame{display:none!important}body{top:0!important}#goog-gt-tt,.goog-tooltip{display:none!important}');
      document.adoptedStyleSheets=document.adoptedStyleSheets.concat([st]);
    }catch(e){}
    return 'ok';
  }catch(e){ return 'err'; }
})('
"""# + safe + "')"
    }

    static let revertJS = #"""
(function(){
  var h=location.hostname, x='=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/';
  document.cookie='googtrans'+x;
  document.cookie='googtrans'+x+';domain='+h;
  return 'ok';
})()
"""#

    /// Phương án dự phòng khi trang chặn script ngoài: mở qua Google Dịch (translate.goog).
    static func proxyURL(_ u: URL, target: String) -> URL? {
        guard var c = URLComponents(url: u, resolvingAgainstBaseURL: false), let host = c.host else { return nil }
        let h = host.replacingOccurrences(of: "-", with: "--").replacingOccurrences(of: ".", with: "-")
        c.scheme = "https"
        c.host = h + ".translate.goog"
        c.port = nil
        if c.path.isEmpty { c.path = "/" }
        var q = c.queryItems ?? []
        q.append(URLQueryItem(name: "_x_tr_sl", value: "auto"))
        q.append(URLQueryItem(name: "_x_tr_tl", value: target))
        q.append(URLQueryItem(name: "_x_tr_hl", value: target))
        q.append(URLQueryItem(name: "_x_tr_pto", value: "wapp"))
        c.queryItems = q
        return c.url
    }
}

// MARK: - Lưu trang thành PDF

enum PagePDF {
    /// PDF nhiều trang A4 (dùng bộ in của iOS); nếu không dựng được thì chụp cả trang thành một trang dài.
    @MainActor
    static func make(_ w: WKWebView) async -> Data? {
        let r = UIPrintPageRenderer()
        r.addPrintFormatter(w.viewPrintFormatter(), startingAtPageAt: 0)
        let paper = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)
        let printable = paper.insetBy(dx: 30, dy: 36)
        r.setValue(NSValue(cgRect: paper), forKey: "paperRect")
        r.setValue(NSValue(cgRect: printable), forKey: "printableRect")
        let n = r.numberOfPages
        if n > 0 {
            let data = NSMutableData()
            UIGraphicsBeginPDFContextToData(data, paper, nil)
            for i in 0..<n {
                UIGraphicsBeginPDFPage()
                r.drawPage(at: i, in: UIGraphicsGetPDFContextBounds())
            }
            UIGraphicsEndPDFContext()
            if data.length > 0 { return data as Data }
        }
        let cfg = WKPDFConfiguration()
        let size = w.scrollView.contentSize
        if size.width > 0, size.height > 0 { cfg.rect = CGRect(origin: .zero, size: size) }
        return try? await w.pdf(configuration: cfg)
    }
}


// MARK: - Chép văn bản tự do

enum CopyScript {
    /// Bỏ chặn chọn / sao chép / chuột phải / kéo của trang web (CSS user-select + chặn các trình xử lý của trang).
    static let body = #"""
(function(){
  if (window.__xbCopyInit) return; window.__xbCopyInit = true;
  var sheet = null, ID = '__xb_copy_style';
  var CSS = '*,*::before,*::after{-webkit-user-select:text!important;user-select:text!important}';
  function on(){ var X = window.__xb || {}; return !!X.copy && !window.__xbFSOn; }
  function put(){
    if (sheet || document.getElementById(ID)) return;
    try {
      sheet = new CSSStyleSheet(); sheet.replaceSync(CSS);
      document.adoptedStyleSheets = document.adoptedStyleSheets.concat([sheet]);
      return;
    } catch(e) { sheet = null; }
    var s = document.createElement('style'); s.id = ID; s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }
  function drop(){
    if (sheet) {
      var me = sheet;
      try { document.adoptedStyleSheets = document.adoptedStyleSheets.filter(function(x){ return x !== me; }); } catch(e){}
      sheet = null;
    }
    var s = document.getElementById(ID); if (s) s.remove();
  }
  // Chạy trước mọi trình xử lý của trang để chúng không gọi preventDefault / ghi đè clipboard
  ['copy','cut','selectstart','dragstart','contextmenu'].forEach(function(t){
    window.addEventListener(t, function(e){
      if (on()) e.stopImmediatePropagation();
    }, true);
  });
  function clearInline(){
    if (!on()) return;
    [document, document.documentElement, document.body].forEach(function(n){
      if (!n) return;
      try { n.oncopy = null; n.oncut = null; n.onselectstart = null; n.oncontextmenu = null; n.ondragstart = null; } catch(e){}
    });
  }
  function apply(){
    if (on()) { put(); clearInline(); } else drop();
  }
  window.__xbCopyApply = apply;
  apply();
  document.addEventListener('DOMContentLoaded', apply, {once:true});
  window.addEventListener('load', apply, {once:true});
})();
"""#
}

// MARK: - Chụp ảnh cả trang

enum PageShot {
    /// Cuộn qua cả trang để ảnh tải lười được nạp, rồi cuộn về chỗ cũ.
    @MainActor
    static func warmUp(_ w: WKWebView) async {
        let sv = w.scrollView
        let start = sv.contentOffset
        let step = max(w.bounds.height * 0.9, 300)
        var y: CGFloat = 0
        var n = 0
        while y < sv.contentSize.height - w.bounds.height, n < 40 {
            y += step
            sv.setContentOffset(CGPoint(x: 0, y: y), animated: false)
            try? await Task.sleep(nanoseconds: 120_000_000)
            n += 1
        }
        sv.setContentOffset(start, animated: false)
        try? await Task.sleep(nanoseconds: 150_000_000)
    }

    /// Chụp toàn bộ chiều dài trang: dựng PDF một trang rồi vẽ sang ảnh (tự giảm độ phân giải nếu trang quá dài).
    @MainActor
    static func capture(_ w: WKWebView) async -> UIImage? {
        await warmUp(w)
        let size = w.scrollView.contentSize
        guard size.width > 0, size.height > 0 else { return nil }
        let cfg = WKPDFConfiguration()
        cfg.rect = CGRect(origin: .zero, size: size)
        guard let data = try? await w.pdf(configuration: cfg),
              let doc = CGPDFDocument(CGDataProvider(data: data as CFData)!),
              let page = doc.page(at: 1) else { return nil }
        let box = page.getBoxRect(.mediaBox)
        guard box.width > 0, box.height > 0 else { return nil }
        // Giới hạn kích thước ảnh: cạnh dài ≤ 16000 px, tổng ≤ 60 triệu điểm ảnh
        var scale = UIScreen.main.scale
        scale = min(scale, 16000 / box.height, 16000 / box.width)
        scale = min(scale, (60_000_000 / (box.width * box.height)).squareRoot())
        scale = max(scale, 0.2)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = scale
        fmt.opaque = true
        let r = UIGraphicsImageRenderer(size: box.size, format: fmt)
        return r.image { ctx in
            UIColor.white.setFill()
            ctx.fill(CGRect(origin: .zero, size: box.size))
            let c = ctx.cgContext
            c.translateBy(x: 0, y: box.height)
            c.scaleBy(x: 1, y: -1)
            c.translateBy(x: -box.minX, y: -box.minY)
            c.drawPDFPage(page)
        }
    }
}
