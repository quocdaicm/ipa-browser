import SwiftUI
import WebKit

// Các tính năng kiểu Cốc Cốc: chế độ đọc, lưu PDF, dịch trang, nhóm tab, menu giữ lâu trên liên kết.

extension BrowserModel {

    // MARK: Hộp thoại / chia sẻ

    @discardableResult
    func presentController(_ vc: UIViewController) -> Bool {
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
        while let p = top?.presentedViewController { top = p }
        guard let host = top else { return false }
        if let pop = vc.popoverPresentationController {
            pop.sourceView = host.view
            pop.sourceRect = CGRect(x: host.view.bounds.midX, y: host.view.bounds.midY, width: 1, height: 1)
            pop.permittedArrowDirections = []
        }
        host.present(vc, animated: true)
        return true
    }

    func askText(title: String, message: String?, placeholder: String, initial: String,
                 ok: String = "Lưu", completion: @escaping (String) -> Void) {
        let a = UIAlertController(title: title, message: message, preferredStyle: .alert)
        a.addTextField {
            $0.placeholder = placeholder
            $0.text = initial
            $0.autocapitalizationType = .sentences
        }
        a.addAction(UIAlertAction(title: "Hủy", style: .cancel))
        a.addAction(UIAlertAction(title: ok, style: .default) { _ in
            completion((a.textFields?.first?.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines))
        })
        _ = present(a)
    }

    // MARK: Chế độ đọc

    func toggleReader() {
        let t = activeTab
        if t.reader { exitReader(t) } else { enterReader(t) }
    }

    func enterReader(_ t: Tab) {
        guard let url = t.webView.url,
              ["http", "https"].contains((url.scheme ?? "").lowercased()) else {
            onNotice?("Trang này không dùng được chế độ đọc")
            return
        }
        Task { @MainActor in
            let raw = try? await t.webView.evaluateJavaScript(ReaderMode.extractJS)
            guard let s = raw as? String,
                  let d = s.data(using: .utf8),
                  let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
                  let body = o["html"] as? String else {
                self.onNotice?("Không tìm thấy bài viết để đọc trong trang này")
                return
            }
            let title = (o["title"] as? String) ?? ""
            var parts: [String] = []
            for k in ["byline", "date", "site"] {
                if let v = o[k] as? String, !v.isEmpty { parts.append(v) }
            }
            let html = ReaderMode.page(title: title,
                                       meta: parts.joined(separator: " · "),
                                       body: body,
                                       lang: (o["lang"] as? String) ?? "",
                                       size: self.settings.readerSize,
                                       theme: self.settings.readerTheme)
            t.reader = true
            t.readerPending = true
            t.readerURL = url
            self.sync(t)
            t.webView.loadHTMLString(html, baseURL: url)
        }
    }

    func exitReader(_ t: Tab) {
        guard let u = t.readerURL else { return }
        t.reader = false
        t.readerPending = false
        sync(t)
        t.webView.load(URLRequest(url: u))
    }

    func readerMessage(_ w: WKWebView?, _ b: [String: Any]) {
        switch b["a"] as? String {
        case "exit":
            if let t = tabs.first(where: { $0.webView === w }) { exitReader(t) }
        case "pref":
            if let s = b["size"] as? Int { settings.readerSize = s }
            else if let d = b["size"] as? Double { settings.readerSize = Int(d) }
            if let th = b["theme"] as? String, ["light", "sepia", "dark"].contains(th) {
                settings.readerTheme = th
            }
        default:
            break
        }
    }

    // MARK: Lưu PDF

    func savePDF() async -> URL? {
        let w = webView
        guard w.url != nil else { return nil }
        onNotice?("Đang tạo PDF…")
        guard let data = await PagePDF.make(w) else {
            onNotice?("Không tạo được PDF")
            return nil
        }
        var name = pageTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = w.url?.host ?? "trang-web" }
        name = name.replacingOccurrences(of: "[\\\\/:*?\"<>|]", with: "_", options: .regularExpression)
        if name.count > 60 { name = String(name.prefix(60)) }
        let dest = DownloadManager.destination(for: name + ".pdf")
        do {
            try data.write(to: dest)
        } catch {
            onNotice?("Không lưu được PDF")
            return nil
        }
        let id = DownloadManager.shared.addExternal(name: dest.lastPathComponent)
        DownloadManager.shared.complete(id, file: dest, ok: true, message: nil)
        return dest
    }

    // MARK: Chụp ảnh cả trang

    func saveFullScreenshot() async -> URL? {
        let w = webView
        guard w.url != nil else { return nil }
        onNotice?("Đang chụp cả trang…")
        guard let img = await PageShot.capture(w), let png = img.pngData() else {
            onNotice?("Không chụp được trang này")
            return nil
        }
        var name = pageTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = w.url?.host ?? "trang-web" }
        name = name.replacingOccurrences(of: "[\\\\/:*?\"<>|]", with: "_", options: .regularExpression)
        if name.count > 60 { name = String(name.prefix(60)) }
        let dest = DownloadManager.destination(for: name + ".png")
        do {
            try png.write(to: dest)
        } catch {
            onNotice?("Không lưu được ảnh")
            return nil
        }
        let id = DownloadManager.shared.addExternal(name: dest.lastPathComponent)
        DownloadManager.shared.complete(id, file: dest, ok: true, message: nil)
        return dest
    }

    // MARK: Dịch trang

    func translatePage() {
        let t = activeTab
        let w = t.webView
        guard let url = w.url,
              ["http", "https"].contains((url.scheme ?? "").lowercased()) else {
            onNotice?("Trang này không dịch được")
            return
        }
        translateOffer = nil

        // Đang dịch -> trả về bản gốc
        if t.translated {
            if let origin = t.translateOrigin {
                t.translateOrigin = nil
                t.translated = false
                w.load(URLRequest(url: origin))
            } else {
                Task { @MainActor in
                    _ = try? await w.evaluateJavaScript(PageTranslate.revertJS)
                    t.translated = false
                    if t.reader { self.exitReader(t) } else { w.reload() }
                }
            }
            return
        }

        let target = settings.translateLang
        onNotice?("Đang dịch sang \(PageTranslate.name(target))…")
        Task { @MainActor in
            _ = try? await w.evaluateJavaScript(PageTranslate.injectJS(target))
            for _ in 0..<12 {
                try? await Task.sleep(nanoseconds: 500_000_000)
                if w.url != url { return }   // người dùng đã chuyển trang
                let cls = (try? await w.evaluateJavaScript("document.documentElement.className")) as? String ?? ""
                if cls.contains("translated-") {
                    t.translated = true
                    self.onNotice?("Đã dịch sang \(PageTranslate.name(target))")
                    return
                }
            }
            // Trang chặn script ngoài (CSP) -> mở qua Google Dịch
            guard !t.reader, let p = PageTranslate.proxyURL(url, target: target) else {
                self.onNotice?("Không dịch được trang này")
                return
            }
            t.translateOrigin = url
            w.load(URLRequest(url: p))
        }
    }

    /// Gợi ý dịch khi ngôn ngữ trang khác ngôn ngữ đích (mỗi tên miền chỉ hỏi một lần trong phiên).
    func checkTranslateOffer(_ w: WKWebView) {
        guard settings.translateOffer, w === webView,
              let u = w.url, ["http", "https"].contains((u.scheme ?? "").lowercased()),
              let host = u.host?.lowercased(),
              !host.hasSuffix(".translate.goog"),
              !offeredHosts.contains(host),
              !activeTab.translated, !activeTab.reader else { return }
        Task { @MainActor in
            guard let l = (try? await w.evaluateJavaScript("document.documentElement.lang||''")) as? String else { return }
            let src = String(l.lowercased().prefix(2))
            let tgt = String(self.settings.translateLang.lowercased().prefix(2))
            guard src.count == 2, src != tgt, w.url == u else { return }
            self.offeredHosts.insert(host)
            self.translateOffer = src
            try? await Task.sleep(nanoseconds: 9_000_000_000)
            if self.translateOffer == src { self.translateOffer = nil }
        }
    }

    // MARK: Nhóm tab

    @discardableResult
    func createGroup(name: String) -> TabGroup {
        let used = Set(groups.map { $0.colorIndex % GroupPalette.colors.count })
        let idx = (0..<GroupPalette.colors.count).first(where: { !used.contains($0) }) ?? groups.count
        let n = name.isEmpty ? "Nhóm \(groups.count + 1)" : name
        let g = TabGroup(name: n, colorIndex: idx)
        groups.append(g)
        return g
    }

    func renameGroup(_ id: UUID, to name: String) {
        guard !name.isEmpty, let i = groups.firstIndex(where: { $0.id == id }) else { return }
        groups[i].name = name
    }

    /// Giải tán nhóm: các thẻ vẫn còn, chỉ bỏ khỏi nhóm.
    func deleteGroup(_ id: UUID) {
        groups.removeAll { $0.id == id }
        for t in tabs where t.groupID == id { t.groupID = nil }
        objectWillChange.send()
    }

    func closeGroup(_ id: UUID) {
        let ids = tabs.filter { $0.groupID == id }.map { $0.id }
        for i in ids { close(i) }
        groups.removeAll { $0.id == id }
        objectWillChange.send()
    }

    func setGroup(_ gid: UUID?, for tabID: UUID) {
        guard let t = tabs.first(where: { $0.id == tabID }), !t.isPrivate else { return }
        t.groupID = gid
        objectWillChange.send()
    }

    func group(of tab: Tab) -> TabGroup? {
        guard let g = tab.groupID else { return nil }
        return groups.first(where: { $0.id == g })
    }

    // MARK: Menu giữ lâu trên liên kết

    func webView(_ webView: WKWebView,
                 contextMenuConfigurationForElement elementInfo: WKContextMenuElementInfo,
                 completionHandler: @escaping (UIContextMenuConfiguration?) -> Void) {
        guard let url = elementInfo.linkURL,
              ["http", "https"].contains((url.scheme ?? "").lowercased()) else {
            completionHandler(nil)   // ảnh, chữ... giữ menu mặc định của iOS
            return
        }
        let source = tabs.first(where: { $0.webView === webView })
        let isPriv = source?.isPrivate ?? false
        let gid = source?.groupID

        var actions: [UIMenuElement] = []
        actions.append(UIAction(title: "Mở", image: UIImage(systemName: "arrow.up.right.square")) { _ in
            webView.load(URLRequest(url: url))
        })
        actions.append(UIAction(title: "Mở trong thẻ mới", image: UIImage(systemName: "plus.square.on.square")) { [weak self] _ in
            self?.addTab(request: URLRequest(url: url), isPrivate: isPriv, group: gid)
        })
        actions.append(UIAction(title: "Mở ở thẻ nền", image: UIImage(systemName: "square.stack")) { [weak self] _ in
            self?.addTab(request: URLRequest(url: url), isPrivate: isPriv, activate: false, group: gid)
            self?.onNotice?("Đã mở ở thẻ nền")
        })
        if !isPriv {
            actions.append(UIAction(title: "Mở trong thẻ riêng tư", image: UIImage(systemName: "eye.slash")) { [weak self] _ in
                self?.addTab(request: URLRequest(url: url), isPrivate: true)
            })
        }
        actions.append(UIAction(title: "Sao chép liên kết", image: UIImage(systemName: "doc.on.doc")) { [weak self] _ in
            UIPasteboard.general.string = url.absoluteString
            self?.onNotice?("Đã sao chép liên kết")
        })
        actions.append(UIAction(title: "Chia sẻ…", image: UIImage(systemName: "square.and.arrow.up")) { [weak self] _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                self?.presentController(UIActivityViewController(activityItems: [url], applicationActivities: nil))
            }
        })
        actions.append(UIAction(title: "Tải liên kết về", image: UIImage(systemName: "arrow.down.circle")) { _ in
            webView.startDownload(using: URLRequest(url: url)) { d in
                Task { @MainActor in DownloadManager.shared.attach(d) }
            }
        })
        let title = url.host ?? url.absoluteString
        completionHandler(UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            UIMenu(title: title, children: actions)
        })
    }

    // MARK: Điều hướng: theo dõi chế độ đọc / dịch

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        guard let t = tabs.first(where: { $0.webView === webView }) else { return }
        releaseHome(t, after: 0.18)   // trang thật vừa commit: chờ nó kịp vẽ rồi mới gỡ trang chủ
        if t.readerPending {
            t.readerPending = false
        } else if t.reader {
            t.reader = false
            sync(t)
        }
        let viaProxy = webView.url?.host?.hasSuffix(".translate.goog") ?? false
        t.translated = viaProxy
        if !viaProxy { t.translateOrigin = nil }
    }
}
