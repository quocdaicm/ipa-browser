import Foundation

struct InstalledExtension: Identifiable, Codable, Equatable {
    var id: String
    var name: String
    var version: String
    var enabled: Bool
    var isUserScript: Bool
    var source: String
    var rev: Int? = nil
    /// Chức năng của extension mà app chưa hỗ trợ (cài được nhưng chạy một phần).
    var notes: [String]? = nil
}

/// Lưu file extension, danh sách đã cài và dữ liệu chrome.storage. Thread-safe.
final class ExtStore: @unchecked Sendable {
    static let shared = ExtStore()

    let root: URL
    let storageRoot: URL
    private let indexURL: URL
    private let lock = NSLock()
    private var session: [String: [String: Any]] = [:]

    private init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        root = base.appendingPathComponent("Extensions", isDirectory: true)
        storageRoot = base.appendingPathComponent("ExtStorage", isDirectory: true)
        indexURL = base.appendingPathComponent("ExtIndex.json")
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: storageRoot, withIntermediateDirectories: true)
    }

    // MARK: Index

    func loadIndex() -> [InstalledExtension] {
        guard let d = try? Data(contentsOf: indexURL),
              let a = try? JSONDecoder().decode([InstalledExtension].self, from: d) else { return [] }
        return a
    }

    func saveIndex(_ a: [InstalledExtension]) {
        if let d = try? JSONEncoder().encode(a) { try? d.write(to: indexURL, options: .atomic) }
    }

    // MARK: Files

    func extDir(_ id: String) -> URL { root.appendingPathComponent(id, isDirectory: true) }

    func write(files: [String: Data], id: String) throws {
        let dir = extDir(id)
        try? FileManager.default.removeItem(at: dir)
        try? FileManager.default.removeItem(at: storageRoot.appendingPathComponent(id + ".started"))
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        for (rel, data) in files {
            let u = dir.appendingPathComponent(rel)
            try FileManager.default.createDirectory(at: u.deletingLastPathComponent(), withIntermediateDirectories: true)
            try data.write(to: u)
        }
    }

    func deleteExtension(_ id: String) {
        try? FileManager.default.removeItem(at: extDir(id))
        try? FileManager.default.removeItem(at: sURL(id))
        try? FileManager.default.removeItem(at: storageRoot.appendingPathComponent(id + ".started"))
    }

    func readFile(id: String, path: String) -> Data? {
        guard !id.contains("/"), !id.contains("..") else { return nil }
        let comps = path.split(separator: "/").map(String.init).filter { $0 != "." && !$0.isEmpty }
        guard !comps.contains("..") else { return nil }
        var url = extDir(id)
        for c in comps { url.appendPathComponent(c) }
        return try? Data(contentsOf: url)
    }

    func readText(id: String, path: String) -> String? {
        guard let d = readFile(id: id, path: path) else { return nil }
        return String(decoding: d, as: UTF8.self)
    }

    func manifest(id: String) -> [String: Any] {
        guard var d = readFile(id: id, path: "manifest.json") else { return [:] }
        if d.starts(with: [0xEF, 0xBB, 0xBF]) { d = d.dropFirst(3) }
        let obj = try? JSONSerialization.jsonObject(with: d)
        return obj as? [String: Any] ?? [:]
    }

    func messages(id: String) -> [String: Any] {
        let m = manifest(id: id)
        var cands: [String] = []
        if let l = m["default_locale"] as? String { cands.append(l) }
        cands += ["en", "en_US"]
        for l in cands {
            if let d = readFile(id: id, path: "_locales/\(l)/messages.json"),
               let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] {
                return o
            }
        }
        return [:]
    }

    func popupPath(id: String) -> String? {
        let m = manifest(id: id)
        for key in ["action", "browser_action", "page_action"] {
            if let a = m[key] as? [String: Any], let p = a["default_popup"] as? String, !p.isEmpty { return p }
        }
        return nil
    }

    /// Trang thanh bên: Chrome `side_panel.default_path`, Firefox `sidebar_action.default_panel`.
    func sidePanelPath(id: String) -> String? {
        let m = manifest(id: id)
        if let sp = m["side_panel"] as? [String: Any], let p = sp["default_path"] as? String, !p.isEmpty { return p }
        if let sb = m["sidebar_action"] as? [String: Any], let p = sb["default_panel"] as? String, !p.isEmpty { return p }
        return nil
    }

    func optionsPath(id: String) -> String? {
        let m = manifest(id: id)
        if let o = m["options_ui"] as? [String: Any], let p = o["page"] as? String { return p }
        return m["options_page"] as? String
    }

    // MARK: Background page

    func backgroundEntry(id: String) -> String? {
        guard let bg = manifest(id: id)["background"] as? [String: Any] else { return nil }
        if let a = bg["scripts"] as? [String], !a.isEmpty { return "__bg__.html" }
        if let sw = bg["service_worker"] as? String, !sw.isEmpty { return "__bg__.html" }
        if let p = bg["page"] as? String, !p.isEmpty { return p }
        return nil
    }

    func backgroundHTML(id: String) -> Data? {
        guard let bg = manifest(id: id)["background"] as? [String: Any] else { return nil }
        func esc(_ s: String) -> String {
            s.replacingOccurrences(of: "&", with: "&amp;")
                .replacingOccurrences(of: "\"", with: "&quot;")
                .replacingOccurrences(of: "<", with: "&lt;")
        }
        let module = (bg["type"] as? String) == "module"
        let attr = module ? " type=\"module\"" : ""
        var tags = ""
        if let a = bg["scripts"] as? [String], !a.isEmpty {
            for s in a { tags += "<script\(attr) src=\"\(esc(s))\"></script>\n" }
        } else if let sw = bg["service_worker"] as? String, !sw.isEmpty {
            tags = "<script\(attr) src=\"\(esc(sw))\"></script>\n"
        } else {
            return nil
        }
        let html = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"></head><body>\n" + tags + "</body></html>"
        return Data(html.utf8)
    }

    /// true nếu đây là lần chạy đầu tiên của extension (để bắn onInstalled).
    func consumeFirstRun(_ id: String) -> Bool {
        let u = storageRoot.appendingPathComponent(id + ".started")
        if FileManager.default.fileExists(atPath: u.path) { return false }
        try? Data().write(to: u)
        return true
    }

    // MARK: declarativeNetRequest data

    func dnrRules(_ id: String, key: String) -> [[String: Any]] {
        (storageGet(id: id, area: "dnr", keys: key)[key] as? [[String: Any]]) ?? []
    }

    func dnrSetRules(_ id: String, key: String, rules: [[String: Any]]) {
        storageSet(id: id, area: "dnr", items: [key: rules, "ver": dnrVersion(id) + 1])
    }

    func dnrVersion(_ id: String) -> Int {
        (storageGet(id: id, area: "dnr", keys: "ver")["ver"] as? Int) ?? 0
    }

    func dnrEnabledOverride(_ id: String) -> [String]? {
        storageGet(id: id, area: "dnr", keys: "enabled")["enabled"] as? [String]
    }

    func dnrSetEnabled(_ id: String, _ list: [String]) {
        storageSet(id: id, area: "dnr", items: ["enabled": list, "ver": dnrVersion(id) + 1])
    }

    func hasDNR(_ id: String) -> Bool {
        let m = manifest(id: id)
        if m["declarative_net_request"] != nil { return true }
        return !dnrRules(id, key: "dynamic").isEmpty || !dnrRules(id, key: "session").isEmpty
    }

    // MARK: chrome.storage

    private func sURL(_ id: String) -> URL { storageRoot.appendingPathComponent(id + ".json") }

    private func load(_ id: String) -> [String: [String: Any]] {
        guard let d = try? Data(contentsOf: sURL(id)),
              let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: [String: Any]] else { return [:] }
        return o
    }

    private func save(_ id: String, _ o: [String: [String: Any]]) {
        guard JSONSerialization.isValidJSONObject(o),
              let d = try? JSONSerialization.data(withJSONObject: o) else { return }
        try? d.write(to: sURL(id), options: .atomic)
    }

    // Gọi khi đang giữ lock
    private func readArea(_ id: String, _ area: String) -> [String: Any] {
        if area == "session" { return session[id] ?? [:] }
        return load(id)[area] ?? [:]
    }

    private func writeArea(_ id: String, _ area: String, _ a: [String: Any]) {
        if area == "session" {
            session[id] = a
            return
        }
        var all = load(id)
        all[area] = a
        save(id, all)
    }

    func storageGet(id: String, area: String, keys: Any?) -> [String: Any] {
        lock.lock(); defer { lock.unlock() }
        let all = readArea(id, area)
        guard let keys = keys, !(keys is NSNull) else { return all }
        if let k = keys as? String {
            if let v = all[k] { return [k: v] }
            return [:]
        }
        if let arr = keys as? [String] {
            var o: [String: Any] = [:]
            for k in arr { if let v = all[k] { o[k] = v } }
            return o
        }
        if let d = keys as? [String: Any] {
            var o = d
            for k in d.keys { if let v = all[k] { o[k] = v } }
            return o
        }
        return [:]
    }

    @discardableResult
    func storageSet(id: String, area: String, items: [String: Any]) -> [String: [String: Any]] {
        lock.lock(); defer { lock.unlock() }
        var a = readArea(id, area)
        var changes: [String: [String: Any]] = [:]
        for (k, v) in items {
            var c: [String: Any] = ["newValue": v]
            if let old = a[k] { c["oldValue"] = old }
            changes[k] = c
            a[k] = v
        }
        writeArea(id, area, a)
        return changes
    }

    @discardableResult
    func storageRemove(id: String, area: String, keys: [String]) -> [String: [String: Any]] {
        lock.lock(); defer { lock.unlock() }
        var a = readArea(id, area)
        var changes: [String: [String: Any]] = [:]
        for k in keys {
            if let old = a[k] { changes[k] = ["oldValue": old] }
            a.removeValue(forKey: k)
        }
        writeArea(id, area, a)
        return changes
    }

    @discardableResult
    func storageClear(id: String, area: String) -> [String: [String: Any]] {
        lock.lock(); defer { lock.unlock() }
        let a = readArea(id, area)
        var changes: [String: [String: Any]] = [:]
        for (k, v) in a { changes[k] = ["oldValue": v] }
        writeArea(id, area, [:])
        return changes
    }
}
