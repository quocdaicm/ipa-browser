import SwiftUI
import CryptoKit
import LocalAuthentication
import Security

// MARK: - Lưu mật khẩu trong Keychain (chỉ lưu băm có muối, không lưu mật khẩu thật)

private enum LockKeychain {
    static let service = "com.example.extbrowser.applock"
    static let account = "pw"

    private static var base: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account]
    }

    static func read() -> Data? {
        var q = base
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess else { return nil }
        return out as? Data
    }

    static func write(_ data: Data) {
        delete()
        var q = base
        q[kSecValueData as String] = data
        q[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(q as CFDictionary, nil)
    }

    static func delete() { SecItemDelete(base as CFDictionary) }
}

// MARK: - Khoá ứng dụng

@MainActor
final class AppLock: ObservableObject {
    static let shared = AppLock()

    @Published private(set) var enabled: Bool
    @Published private(set) var isLocked: Bool
    @Published private(set) var covered = false
    @Published private(set) var lockoutUntil: Date?
    /// Mở khoá bằng Face ID / Touch ID.
    @Published var useBiometrics: Bool { didSet { UserDefaults.standard.set(useBiometrics, forKey: "lock.bio") } }
    /// Số giây ở nền trước khi khoá lại (0 = ngay lập tức).
    @Published var delay: Int { didSet { UserDefaults.standard.set(delay, forKey: "lock.delay") } }

    private var fails: Int { didSet { UserDefaults.standard.set(fails, forKey: "lock.fails") } }
    private var bgDate: Date?
    private var window: UIWindow?
    private weak var prevKey: UIWindow?

    private init() {
        let d = UserDefaults.standard
        // Cài mới thì xoá mật khẩu cũ còn sót trong Keychain (Keychain không tự xoá khi gỡ app).
        if !d.bool(forKey: "lock.installed") {
            LockKeychain.delete()
            d.set(true, forKey: "lock.installed")
        }
        let has = LockKeychain.read() != nil
        enabled = has
        isLocked = has
        useBiometrics = d.object(forKey: "lock.bio") as? Bool ?? true
        delay = d.object(forKey: "lock.delay") as? Int ?? 0
        fails = d.integer(forKey: "lock.fails")
        if let t = d.object(forKey: "lock.until") as? Date, t > Date() { lockoutUntil = t }
    }

    // MARK: Mật khẩu

    private static func derive(_ pw: String, salt: Data) -> Data {
        var h = Data(SHA256.hash(data: salt + Data(pw.utf8)))
        for _ in 0..<20000 { h = Data(SHA256.hash(data: h + salt)) }
        return h
    }

    func verify(_ pw: String) -> Bool {
        guard let s = LockKeychain.read(), s.count == 48 else { return false }
        let salt = s.prefix(16)
        let hash = s.suffix(32)
        return Self.derive(pw, salt: Data(salt)) == Data(hash)
    }

    /// Đặt hoặc đổi mật khẩu.
    func setPassword(_ pw: String) {
        var salt = Data(count: 16)
        _ = salt.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 16, $0.baseAddress!) }
        LockKeychain.write(salt + Self.derive(pw, salt: salt))
        enabled = true
        isLocked = false
        fails = 0
        lockoutUntil = nil
        UserDefaults.standard.removeObject(forKey: "lock.until")
        updateWindow()
    }

    func disable() {
        LockKeychain.delete()
        enabled = false
        isLocked = false
        covered = false
        fails = 0
        lockoutUntil = nil
        UserDefaults.standard.removeObject(forKey: "lock.until")
        updateWindow()
    }

    // MARK: Mở khoá

    /// Trả về nil nếu đúng; ngược lại là thông báo lỗi.
    func unlock(with pw: String) -> String? {
        if let u = lockoutUntil, u > Date() { return "Thử lại sau ít phút." }
        if verify(pw) {
            fails = 0
            lockoutUntil = nil
            UserDefaults.standard.removeObject(forKey: "lock.until")
            isLocked = false
            covered = false
            updateWindow()
            return nil
        }
        fails += 1
        if fails % 5 == 0 {
            let strikes = min(fails / 5, 6)
            let t = Date().addingTimeInterval(30 * pow(2, Double(strikes - 1)))
            lockoutUntil = t
            UserDefaults.standard.set(t, forKey: "lock.until")
            return "Sai quá nhiều lần. Đã tạm khoá nhập mật khẩu."
        }
        return "Mật khẩu không đúng."
    }

    var biometryAvailable: Bool {
        var e: NSError?
        return LAContext().canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &e)
    }

    var biometryIcon: String {
        let c = LAContext()
        _ = c.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
        return c.biometryType == .touchID ? "touchid" : "faceid"
    }

    var biometryName: String {
        let c = LAContext()
        _ = c.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
        return c.biometryType == .touchID ? "Touch ID" : "Face ID"
    }

    func authenticateBiometric() {
        guard isLocked, useBiometrics, biometryAvailable else { return }
        LAContext().evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                                   localizedReason: "Mở khoá ExtBrowser") { ok, _ in
            guard ok else { return }
            Task { @MainActor in
                AppLock.shared.isLocked = false
                AppLock.shared.covered = false
                AppLock.shared.updateWindow()
            }
        }
    }

    // MARK: Vòng đời app

    func attach() { updateWindow() }

    func scenePhaseChanged(_ p: ScenePhase) {
        guard enabled else { return }
        switch p {
        case .background:
            bgDate = Date()
            covered = true
        case .inactive:
            if !isLocked { covered = true }
        case .active:
            if let d = bgDate {
                if Date().timeIntervalSince(d) >= Double(delay) { isLocked = true }
                bgDate = nil
            }
            covered = false
        @unknown default: break
        }
        updateWindow()
    }

    // MARK: Cửa sổ phủ lên toàn bộ (kể cả các bảng đang mở)

    private func updateWindow() {
        let show = enabled && (isLocked || covered)
        if show, window == nil {
            guard let scene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first(where: { $0.activationState != .unattached }) else { return }
            prevKey = scene.windows.first(where: { $0.isKeyWindow })
            let w = UIWindow(windowScene: scene)
            w.windowLevel = .alert + 1
            let host = UIHostingController(rootView: LockRoot())
            host.view.backgroundColor = .clear
            w.rootViewController = host
            w.makeKeyAndVisible()
            window = w
        } else if !show, let w = window {
            w.isHidden = true
            window = nil
            prevKey?.makeKey()
        }
    }
}

// MARK: - Giao diện

struct LockRoot: View {
    @ObservedObject private var lock = AppLock.shared
    var body: some View {
        if lock.isLocked { LockScreen() } else { PrivacyCover() }
    }
}

private struct LockBackground: View {
    var body: some View { ScreenBackground() }
}

/// Che nội dung khi vào app đa nhiệm.
struct PrivacyCover: View {
    var body: some View {
        ZStack {
            LockBackground()
            SVGIcon(name: "ic_lock", size: 34)
                .foregroundStyle(.white)
                .frame(width: 84, height: 84)
                .background(Theme.gradient, in: Circle())
                .shadow(color: Theme.accent.opacity(0.5), radius: 20, y: 8)
        }
    }
}

struct LockScreen: View {
    @ObservedObject private var lock = AppLock.shared
    @State private var password = ""
    @State private var error = ""
    @FocusState private var focused: Bool

    private var bioReady: Bool { lock.useBiometrics && lock.biometryAvailable }

    var body: some View {
        ZStack {
            LockBackground()
            TimelineView(.periodic(from: .now, by: 1)) { ctx in
                let remain = Int(max(0, (lock.lockoutUntil?.timeIntervalSince(ctx.date) ?? 0).rounded(.up)))
                VStack(spacing: 18) {
                    Spacer()
                    SVGIcon(name: "ic_lock", size: 34)
                        .foregroundStyle(.white)
                        .frame(width: 76, height: 76)
                        .background(Theme.gradient, in: Circle())
                    Text("ExtBrowser đã khoá")
                        .font(Theme.rounded(.title2, .bold))
                        .foregroundStyle(.white)

                    SecureField("Nhập mật khẩu 6 ký tự", text: $password)
                        .focused($focused)
                        .textContentType(.password)
                        .submitLabel(.go)
                        .onSubmit { submit() }
                        .onChange(of: password) { v in
                            if v.count > 6 { password = String(v.prefix(6)) }
                            else if v.count == 6 { submit() }
                        }
                        .font(.system(.title3, design: .rounded))
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white)
                        .padding(.horizontal, 18)
                        .frame(height: 54)
                        .background(.white.opacity(0.10), in: Capsule())
                        .overlay(Capsule().strokeBorder(.white.opacity(0.16), lineWidth: 1))
                        .padding(.horizontal, 40)
                        .disabled(remain > 0)

                    Text(remain > 0 ? "Thử lại sau \(remain) giây" : error)
                        .font(.footnote)
                        .foregroundStyle(.red.opacity(0.9))
                        .frame(height: 18)

                    Button { submit() } label: { Text("Mở khoá") }
                        .buttonStyle(PrimaryButtonStyle())
                        .padding(.horizontal, 40)
                        .disabled(remain > 0 || password.isEmpty)

                    if bioReady {
                        Button { lock.authenticateBiometric() } label: {
                            Label("Dùng \(lock.biometryName)", systemImage: lock.biometryIcon)
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(.white.opacity(0.85))
                        }
                        .padding(.top, 4)
                    }
                    Spacer()
                    Spacer()
                }
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            if bioReady {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { lock.authenticateBiometric() }
            } else {
                focused = true
            }
        }
    }

    private func submit() {
        guard !password.isEmpty else { return }
        if let e = lock.unlock(with: password) {
            error = e
            password = ""
        }
    }
}

// MARK: - Đặt / đổi / tắt mật khẩu

enum PasswordFlow: String, Identifiable {
    case set, change, disable
    var id: String { rawValue }
}

struct PasswordFlowView: View {
    let flow: PasswordFlow
    @ObservedObject private var lock = AppLock.shared
    @Environment(\.dismiss) private var dismiss
    @State private var current = ""
    @State private var new1 = ""
    @State private var new2 = ""
    @State private var error = ""

    private var needsCurrent: Bool { flow != .set }
    private var needsNew: Bool { flow != .disable }

    private var title: String {
        switch flow {
        case .set: return "Đặt mật khẩu"
        case .change: return "Đổi mật khẩu"
        case .disable: return "Tắt khoá ứng dụng"
        }
    }

    var body: some View {
        SheetScaffold(title: title,
                      subtitle: flow == .disable ? "Xác nhận để tắt khoá" : "Mật khẩu gồm đúng 6 ký tự",
                      onClose: { dismiss() }) {
            ThemedScroll {
                if needsCurrent {
                    SectionCard(title: "Mật khẩu hiện tại") {
                        SecureField("Nhập mật khẩu hiện tại", text: $current)
                            .fieldStyle().padding(14)
                    }
                }
                if needsNew {
                    SectionCard(title: "Mật khẩu mới",
                                footer: "Mật khẩu chỉ lưu trên máy này. Nếu quên mật khẩu, bạn sẽ không khôi phục được — chỉ có cách gỡ và cài lại app (mất dữ liệu của app).") {
                        VStack(spacing: 10) {
                            SecureField("Mật khẩu mới (đúng 6 ký tự)", text: $new1).fieldStyle()
                            SecureField("Nhập lại mật khẩu mới", text: $new2).fieldStyle()
                        }
                        .padding(14)
                    }
                }
                if !error.isEmpty {
                    Label(error, systemImage: "exclamationmark.circle.fill")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(Theme.danger)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 6)
                }
                Button(flow == .disable ? "Tắt khoá ứng dụng" : "Lưu mật khẩu") { commit() }
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.top, 6)
            }
        }
        .onChange(of: current) { if $0.count > 6 { current = String($0.prefix(6)) } }
        .onChange(of: new1) { if $0.count > 6 { new1 = String($0.prefix(6)) } }
        .onChange(of: new2) { if $0.count > 6 { new2 = String($0.prefix(6)) } }
    }

    private func commit() {
        if needsCurrent, !lock.verify(current) {
            error = "Mật khẩu hiện tại không đúng."
            return
        }
        if needsNew {
            guard new1.count == 6 else { error = "Mật khẩu phải có đúng 6 ký tự."; return }
            guard new1 == new2 else { error = "Hai mật khẩu không khớp."; return }
            lock.setPassword(new1)
        } else {
            lock.disable()
        }
        dismiss()
    }
}
