import SwiftUI

/// Màu và thành phần giao diện dùng chung.
enum Theme {
    static let accent = Color(red: 0.36, green: 0.35, blue: 0.95)    // chàm
    static let accent2 = Color(red: 0.64, green: 0.33, blue: 0.97)   // tím
    static var gradient: LinearGradient {
        LinearGradient(colors: [accent, accent2], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

/// Biểu tượng SVG (Assets.xcassets/ic_*.imageset), tô màu theo foregroundStyle.
struct SVGIcon: View {
    let name: String
    var size: CGFloat = 22
    var body: some View {
        Image(name)
            .renderingMode(.template)
            .resizable()
            .scaledToFit()
            .frame(width: size, height: size)
    }
}

/// Hiệu ứng nhún khi bấm.
struct PressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.86 : 1)
            .opacity(configuration.isPressed ? 0.7 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

/// Nút biểu tượng SVG trên thanh công cụ.
struct IconButton: View {
    let icon: String
    var tint: Color = .primary
    var size: CGFloat = 22
    let action: () -> Void
    @Environment(\.isEnabled) private var enabled

    var body: some View {
        Button(action: action) {
            SVGIcon(name: icon, size: size)
                .foregroundStyle(tint)
                .opacity(enabled ? 1 : 0.28)
                .frame(maxWidth: .infinity, minHeight: 48)
                .contentShape(Rectangle())
        }
        .buttonStyle(PressStyle())
    }
}

enum MenuAction { case fullscreen, find, library, settings, downloads, newPrivate }

/// Bảng menu dạng lưới ô biểu tượng (thay cho menu khiên cũ).
struct MenuSheet: View {
    @EnvironmentObject var browser: BrowserModel
    @ObservedObject private var settings = BrowserSettings.shared
    @ObservedObject private var library = LibraryStore.shared
    let onAction: (MenuAction) -> Void

    private let cols = Array(repeating: GridItem(.flexible(), spacing: 10), count: 4)

    private func tile(_ icon: String, _ title: String, on: Bool = false) -> some View {
        VStack(spacing: 8) {
            SVGIcon(name: icon, size: 24)
                .foregroundStyle(on ? Color.white : Color.primary)
                .frame(width: 58, height: 58)
                .background {
                    if on { Theme.gradient } else { Color(.tertiarySystemFill) }
                }
                .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
            Text(title)
                .font(.caption2)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .foregroundStyle(.primary)
        }
        .frame(maxWidth: .infinity)
    }

    private func header(_ s: String) -> some View {
        Text(s).font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(browser.pageTitle.isEmpty ? "Menu" : browser.pageTitle)
                        .font(.headline).lineLimit(1)
                    if let h = browser.currentURL?.host {
                        Text(h).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                header("Bảo vệ & hiển thị")
                LazyVGrid(columns: cols, spacing: 16) {
                    Button { settings.adBlock.toggle() } label: {
                        tile(settings.adBlock ? "ic_shield" : "ic_shield_off", "Chặn quảng cáo", on: settings.adBlock)
                    }
                    Button { settings.popupBlock.toggle() } label: {
                        tile("ic_popup", "Chặn popup", on: settings.popupBlock)
                    }
                    Button { settings.dataSaver.toggle() } label: {
                        tile("ic_drop", "Tiết kiệm dữ liệu", on: settings.dataSaver)
                    }
                    Button { browser.toggleDesktop() } label: {
                        tile("ic_desktop", "Bản máy tính", on: browser.desktopMode)
                    }
                }
                .buttonStyle(PressStyle())

                header("Công cụ")
                LazyVGrid(columns: cols, spacing: 16) {
                    Button { onAction(.fullscreen) } label: { tile("ic_fullscreen", "Toàn màn hình") }
                    Button { onAction(.find) } label: { tile("ic_search", "Tìm trong trang") }
                    if let u = browser.currentURL {
                        ShareLink(item: u) { tile("ic_share", "Chia sẻ") }
                        Button {
                            library.toggleBookmark(url: u, title: browser.pageTitle)
                        } label: {
                            tile("ic_star", "Dấu trang", on: library.isBookmarked(u.absoluteString))
                        }
                    }
                    Button { onAction(.library) } label: { tile("ic_book", "Dấu trang & Lịch sử") }
                    Button { onAction(.downloads) } label: { tile("ic_download", "Tải xuống") }
                    Button { onAction(.newPrivate) } label: { tile("ic_private", "Tab riêng tư") }
                    Button { onAction(.settings) } label: { tile("ic_sliders", "Cài đặt") }
                }
                .buttonStyle(PressStyle())
            }
            .padding(20)
        }
    }
}
