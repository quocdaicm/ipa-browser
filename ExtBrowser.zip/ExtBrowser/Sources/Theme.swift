import SwiftUI

// MARK: - Màu & token thiết kế

extension Color {
    /// Màu thích ứng sáng / tối (hex 0xRRGGBB).
    init(light: UInt32, dark: UInt32, lightAlpha: Double = 1, darkAlpha: Double = 1) {
        self.init(UIColor { t in
            let isDark = t.userInterfaceStyle == .dark
            let v = isDark ? dark : light
            let a = isDark ? darkAlpha : lightAlpha
            return UIColor(red: CGFloat((v >> 16) & 0xFF) / 255,
                           green: CGFloat((v >> 8) & 0xFF) / 255,
                           blue: CGFloat(v & 0xFF) / 255,
                           alpha: CGFloat(a))
        })
    }
}

// MARK: - Chủ đề màu (Lagoon / Cà Mau)

enum ThemePalette {
    /// 0 = Lagoon, 1 = Cà Mau (mặc định). Được BrowserSettings cập nhật.
    static var current: Int = UserDefaults.standard.object(forKey: "set.palette") as? Int ?? 1
}

struct Swatch {
    let light: UInt32, dark: UInt32
    var la: Double = 1, da: Double = 1
}

extension Color {
    /// Màu đổi theo cả sáng/tối lẫn chủ đề đang chọn.
    init(lagoon: Swatch, camau: Swatch) {
        self.init(UIColor { t in
            let sw = ThemePalette.current == 1 ? camau : lagoon
            let isDark = t.userInterfaceStyle == .dark
            let v = isDark ? sw.dark : sw.light
            return UIColor(red: CGFloat((v >> 16) & 0xFF) / 255,
                           green: CGFloat((v >> 8) & 0xFF) / 255,
                           blue: CGFloat(v & 0xFF) / 255,
                           alpha: CGFloat(isDark ? sw.da : sw.la))
        })
    }
}

// MARK: - Chế độ riêng tư (tông đen)

private struct PrivateModeKey: EnvironmentKey { static let defaultValue = false }
extension EnvironmentValues {
    /// true khi đang ở tab riêng tư: nền đen + hình SVG, nhấn màu bạc.
    var privateMode: Bool {
        get { self[PrivateModeKey.self] }
        set { self[PrivateModeKey.self] = newValue }
    }
}

/// Hệ thống thiết kế “Lagoon”: nền gradient tối/sáng, thẻ kính mờ, nhấn xanh ngọc → lục.
enum Theme {
    static let privateAccent = Color(red: 0.78, green: 0.82, blue: 0.92)   // bạc xanh (tab riêng tư)
    static let privateGradient = LinearGradient(
        colors: [Color(red: 0.36, green: 0.38, blue: 0.46), Color(red: 0.14, green: 0.15, blue: 0.19)],
        startPoint: .topLeading, endPoint: .bottomTrailing)

    // Lagoon: cyan-teal → lục ngọc.  Cà Mau: xanh rừng đước → vàng phù sa.
    static let accent = Color(lagoon: Swatch(light: 0x0A8F9E, dark: 0x2DD4E0),
                              camau: Swatch(light: 0x0F8A4F, dark: 0x4ADE80))
    static let accent2 = Color(lagoon: Swatch(light: 0x12A06A, dark: 0x34D399),
                               camau: Swatch(light: 0xC8941F, dark: 0xFBBF24))
    static let pink = Color(lagoon: Swatch(light: 0xF2622E, dark: 0xFF8A57),
                            camau: Swatch(light: 0xD9480F, dark: 0xFF9A5C))      // cam tôm
    static let danger = Color(light: 0xE5384F, dark: 0xFF5A6E)
    static let success = Color(light: 0x16A34A, dark: 0x34D399)
    static let warn = Color(light: 0xF59E0B, dark: 0xFBBF24)

    static var gradient: LinearGradient {
        LinearGradient(colors: [accent, accent2], startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    static let bgTop = Color(lagoon: Swatch(light: 0xF5FAFB, dark: 0x05090F),
                             camau: Swatch(light: 0xF6FAF1, dark: 0x07120C))
    static let bgBottom = Color(lagoon: Swatch(light: 0xE2F0F3, dark: 0x0A1624),
                                camau: Swatch(light: 0xE2EEDA, dark: 0x0E1F15))
    static let card = Color(lagoon: Swatch(light: 0xFFFFFF, dark: 0x1B2A3D, la: 0.96, da: 0.74),
                            camau: Swatch(light: 0xFFFFFF, dark: 0x1A2B20, la: 0.96, da: 0.76))
    static let cardStroke = Color(lagoon: Swatch(light: 0x0A8F9E, dark: 0x7DD3FC, la: 0.28, da: 0.24),
                                  camau: Swatch(light: 0x0F8A4F, dark: 0x86EFAC, la: 0.28, da: 0.24))
    static let chip = Color(lagoon: Swatch(light: 0x0A8F9E, dark: 0x7DE3EE, la: 0.13, da: 0.15),
                            camau: Swatch(light: 0x0F8A4F, dark: 0x86EFAC, la: 0.13, da: 0.15))
    static let field = Color(lagoon: Swatch(light: 0x0A8F9E, dark: 0xFFFFFF, la: 0.08, da: 0.10),
                             camau: Swatch(light: 0x0F8A4F, dark: 0xFFFFFF, la: 0.08, da: 0.10))

    /// Nét viền mảnh nhưng tròn pixel: 1 px trên màn 2x, 2 px trên màn 3x (không bị nhoè).
    static func hairline(_ scale: CGFloat) -> CGFloat {
        let px = 1 / max(scale, 1)
        return scale >= 3 ? px * 2 : px
    }

    /// Nhãn đầu nhóm (VIẾT HOA, giãn chữ).
    static let sectionFont = Font.system(size: 12, weight: .bold, design: .rounded)

    /// Chữ tiêu đề bo tròn.
    static func rounded(_ style: Font.TextStyle, _ weight: Font.Weight = .semibold) -> Font {
        Font.system(style, design: .rounded).weight(weight)
    }
}

// MARK: - Nền & thẻ

/// Nền toàn màn hình: gradient + hai quầng sáng mờ.
struct ScreenBackground: View {
    @Environment(\.privateMode) private var isPrivate
    /// false: không vẽ hiệu ứng động (đom đóm / lá rơi) — dùng cho màn cuộn nhiều như Menu.
    var ambient = true
    var body: some View {
        if isPrivate { PrivateBackground() } else { normalBody }
    }

    /// Phần tĩnh (gradient, quầng sáng mờ, tranh SVG đáy) gom thành một ảnh đã vẽ sẵn:
    /// không phải vẽ lại SVG / làm mờ ở mỗi khung hình khi cuộn.
    private var staticLayer: some View {
        LinearGradient(colors: [Theme.bgTop, Theme.bgBottom], startPoint: .top, endPoint: .bottom)
            .overlay(alignment: .topLeading) {
                Circle().fill(Theme.accent.opacity(0.18)).frame(width: 320, height: 320)
                    .blur(radius: 80).offset(x: -150, y: -150)
            }
            .overlay(alignment: .bottomTrailing) {
                Circle().fill(Theme.accent2.opacity(0.13)).frame(width: 280, height: 280)
                    .blur(radius: 80).offset(x: 150, y: 150)
            }
            .overlay(alignment: .bottom) {
                if ThemePalette.current == 1 { CaMauFooterArt() }
            }
            .clipped()
            .drawingGroup()
    }

    private var normalBody: some View {
        ZStack {
            staticLayer
            if ambient && ThemePalette.current == 1 { CaMauAmbient() }
        }
        .clipped()
        .ignoresSafeArea()
    }
}

private struct FlatCardsKey: EnvironmentKey { static let defaultValue = false }
extension EnvironmentValues {
    /// true: thẻ dùng nền đặc nhẹ thay cho kính mờ + bóng lớn (màn cuộn dài, đỡ nặng GPU).
    var flatCards: Bool {
        get { self[FlatCardsKey.self] }
        set { self[FlatCardsKey.self] = newValue }
    }
}

/// Nền tab riêng tư: đen + hình SVG (Assets.xcassets/bg_private).
struct PrivateBackground: View {
    var body: some View {
        Color.black
            .overlay {
                Image("bg_private")
                    .resizable()
                    .scaledToFill()
            }
            .clipped()
            .ignoresSafeArea()
    }
}

struct CardStyle: ViewModifier {
    var radius: CGFloat = 22
    @Environment(\.displayScale) private var scale
    @Environment(\.flatCards) private var flat
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        content
            .background { ZStack { if !flat { shape.fill(.ultraThinMaterial) }; shape.fill(Theme.card) } }
            .overlay(shape.strokeBorder(Theme.cardStroke, lineWidth: Theme.hairline(scale)))
            .shadow(color: .black.opacity(0.10), radius: flat ? 6 : 14, y: flat ? 2 : 5)
    }
}

struct FieldStyle: ViewModifier {
    @Environment(\.displayScale) private var scale
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 14)
            .frame(minHeight: 48)
            .background(Theme.field, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(Theme.cardStroke, lineWidth: Theme.hairline(scale)))
    }
}

extension View {
    func card(radius: CGFloat = 22) -> some View { modifier(CardStyle(radius: radius)) }
    func fieldStyle() -> some View { modifier(FieldStyle()) }
}

// MARK: - Biểu tượng & nút

/// Biểu tượng SVG (Assets.xcassets/ic_*.imageset), tô màu theo foregroundStyle.
struct SVGIcon: View {
    let name: String
    var size: CGFloat = 22
    var body: some View {
        Image(name)
            .renderingMode(.template)
            .resizable()
            .interpolation(.high)
            .antialiased(true)
            .scaledToFit()
            .frame(width: size, height: size)
    }
}

/// Ô biểu tượng bo góc (đặc hoặc nhạt).
struct IconChip: View {
    var asset: String? = nil
    var sf: String? = nil
    var color: Color = Theme.accent
    var size: CGFloat = 34
    var filled = true

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.32, style: .continuous)
                .fill(filled
                      ? AnyShapeStyle(LinearGradient(colors: [color, color.opacity(0.68)],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                      : AnyShapeStyle(color.opacity(0.14)))
            if let a = asset {
                SVGIcon(name: a, size: size * 0.52).foregroundStyle(filled ? Color.white : color)
            } else if let s = sf {
                Image(systemName: s)
                    .font(.system(size: size * 0.46, weight: .semibold))
                    .foregroundStyle(filled ? Color.white : color)
            }
        }
        .frame(width: size, height: size)
    }
}

/// Hiệu ứng nhún khi bấm.
struct PressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.88 : 1)
            .opacity(configuration.isPressed ? 0.75 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.62), value: configuration.isPressed)
    }
}

/// Nút chính: capsule gradient, đổ bóng phát sáng.
struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View { PrimaryLabel(configuration: configuration) }

    private struct PrimaryLabel: View {
        let configuration: Configuration
        @Environment(\.isEnabled) private var enabled
        var body: some View {
            configuration.label
                .font(Theme.rounded(.headline, .bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, minHeight: 52)
                .background(Theme.gradient, in: Capsule())
                .overlay(Capsule().strokeBorder(.white.opacity(0.28), lineWidth: 1))
                .shadow(color: Theme.accent.opacity(enabled ? 0.45 : 0), radius: 14, y: 6)
                .scaleEffect(configuration.isPressed ? 0.97 : 1)
                .opacity(enabled ? 1 : 0.45)
                .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
        }
    }
}

/// Nút phụ dạng viên thuốc nhạt (hoặc đặc khi `filled`).
struct SoftButtonStyle: ButtonStyle {
    var tint: Color = Theme.accent
    var filled = false
    func makeBody(configuration: Configuration) -> some View { SoftLabel(configuration: configuration, tint: tint, filled: filled) }

    private struct SoftLabel: View {
        let configuration: Configuration
        let tint: Color
        let filled: Bool
        @Environment(\.isEnabled) private var enabled
        var body: some View {
            configuration.label
                .font(Theme.rounded(.subheadline, .semibold))
                .foregroundStyle(filled ? Color.white : tint)
                .padding(.horizontal, 16)
                .frame(minHeight: 38)
                .background(filled ? AnyShapeStyle(tint) : AnyShapeStyle(tint.opacity(0.13)), in: Capsule())
                .scaleEffect(configuration.isPressed ? 0.95 : 1)
                .opacity(enabled ? 1 : 0.4)
                .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
        }
    }
}

/// Nút tròn nhỏ có biểu tượng SF.
struct MiniIconButton: View {
    let sf: String
    var tint: Color = Theme.accent
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: sf)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(tint)
                .frame(width: 34, height: 34)
                .background(tint.opacity(0.13), in: Circle())
        }
        .buttonStyle(PressStyle())
    }
}

/// Nút biểu tượng SVG trên thanh công cụ.
struct IconButton: View {
    let icon: String
    var tint: Color = .primary
    var size: CGFloat = 22
    var badge = false
    let action: () -> Void
    @Environment(\.isEnabled) private var enabled

    var body: some View {
        Button(action: action) {
            SVGIcon(name: icon, size: size)
                .foregroundStyle(tint)
                .opacity(enabled ? 1 : 0.28)
                .overlay(alignment: .topTrailing) {
                    if badge {
                        Circle().fill(Theme.success).frame(width: 7, height: 7)
                            .overlay(Circle().strokeBorder(.background, lineWidth: 1.5))
                            .offset(x: 4, y: -3)
                    }
                }
                .frame(maxWidth: .infinity, minHeight: 52)
                .contentShape(Rectangle())
        }
        .buttonStyle(PressStyle())
    }
}

/// Thanh chọn dạng viên thuốc (2–3 mục).
struct SegmentedPill: View {
    let titles: [String]
    var icons: [String] = []
    @Binding var selection: Int

    var body: some View {
        HStack(spacing: 4) {
            ForEach(titles.indices, id: \.self) { i in
                Button {
                    withAnimation(.easeInOut(duration: 0.18)) { selection = i }
                } label: {
                    HStack(spacing: 6) {
                        if i < icons.count { SVGIcon(name: icons[i], size: 15) }
                        Text(titles[i]).font(Theme.rounded(.subheadline, .semibold))
                    }
                    .foregroundStyle(selection == i ? Color.white : Color.secondary)
                    .frame(maxWidth: .infinity, minHeight: 38)
                    .background {
                        if selection == i {
                            Capsule().fill(Theme.gradient)
                                .shadow(color: Theme.accent.opacity(0.4), radius: 8, y: 3)
                        }
                    }
                    .contentShape(Capsule())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(4)
        .background(Theme.chip, in: Capsule())
    }
}

// MARK: - Khung bảng (sheet) & nhóm cài đặt

/// Khung chuẩn cho các bảng: nền Lagoon + tiêu đề lớn + nút đóng.
struct SheetScaffold<Content: View, Trailing: View>: View {
    let title: String
    let subtitle: String?
    let onClose: () -> Void
    let trailing: Trailing
    let content: Content

    init(title: String, subtitle: String? = nil, onClose: @escaping () -> Void,
         @ViewBuilder trailing: () -> Trailing, @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.onClose = onClose
        self.trailing = trailing()
        self.content = content()
    }

    var body: some View {
        ZStack {
            ScreenBackground()
            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).font(Theme.rounded(.title2, .bold)).lineLimit(1)
                        if let s = subtitle {
                            Text(s).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                    Spacer(minLength: 8)
                    trailing
                    Button(action: onClose) {
                        SVGIcon(name: "ic_close", size: 14)
                            .foregroundStyle(.secondary)
                            .frame(width: 36, height: 36)
                            .background(Theme.chip, in: Circle())
                    }
                    .buttonStyle(PressStyle())
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 12)
                content
            }
        }
    }
}

extension SheetScaffold where Trailing == EmptyView {
    init(title: String, subtitle: String? = nil, onClose: @escaping () -> Void,
         @ViewBuilder content: () -> Content) {
        self.init(title: title, subtitle: subtitle, onClose: onClose, trailing: { EmptyView() }, content: content)
    }
}

/// Vùng cuộn có lề chuẩn.
struct ThemedScroll<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        ScrollView {
            VStack(spacing: 18) { content }
                .padding(.horizontal, 16)
                .padding(.top, 4)
                .padding(.bottom, 40)
        }
        .scrollDismissesKeyboard(.interactively)
    }
}

/// Nhóm cài đặt: tiêu đề nhỏ + thẻ kính + chú thích.
struct SectionCard<Content: View>: View {
    var title: String? = nil
    var footer: String? = nil
    let content: Content

    init(title: String? = nil, footer: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.footer = footer
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let t = title {
                Text(t.uppercased())
                    .font(Theme.sectionFont)
                    .tracking(0.8)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 6)
            }
            VStack(spacing: 0) { content }.card()
            if let f = footer {
                Text(f).font(.footnote).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 6)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct RowDivider: View {
    var inset: CGFloat = 60
    var body: some View {
        Rectangle().fill(Theme.cardStroke).frame(height: 1)
            .padding(.leading, inset)
    }
}

/// Một dòng cài đặt: ô biểu tượng + tiêu đề + phần điều khiển bên phải.
struct SettingRow<Trailing: View>: View {
    var asset: String? = nil
    var sf: String? = nil
    var color: Color = Theme.accent
    let title: String
    var subtitle: String? = nil
    let trailing: Trailing

    init(asset: String? = nil, sf: String? = nil, color: Color = Theme.accent,
         title: String, subtitle: String? = nil, @ViewBuilder trailing: () -> Trailing) {
        self.asset = asset
        self.sf = sf
        self.color = color
        self.title = title
        self.subtitle = subtitle
        self.trailing = trailing()
    }

    private var titleBlock: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                .fixedSize(horizontal: false, vertical: true)
            if let s = subtitle {
                Text(s).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    var body: some View {
        // Ưu tiên 1 hàng ngang; nếu phần bên phải quá dài (vd. “Tự động theo mạng”)
        // thì tự xuống dòng bên dưới, tránh bóp tiêu đề thành từng chữ một.
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 12) {
                IconChip(asset: asset, sf: sf, color: color)
                titleBlock
                    .frame(minWidth: 130, maxWidth: .infinity, alignment: .leading)
                    .layoutPriority(1)
                trailing.fixedSize()
            }
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 12) {
                    IconChip(asset: asset, sf: sf, color: color)
                    titleBlock.frame(maxWidth: .infinity, alignment: .leading)
                }
                trailing
                    .padding(.leading, 52)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .frame(minHeight: 58)
        .contentShape(Rectangle())
    }
}

extension SettingRow where Trailing == EmptyView {
    init(asset: String? = nil, sf: String? = nil, color: Color = Theme.accent,
         title: String, subtitle: String? = nil) {
        self.init(asset: asset, sf: sf, color: color, title: title, subtitle: subtitle, trailing: { EmptyView() })
    }
}

/// Dòng có công tắc.
struct ToggleRow: View {
    var asset: String? = nil
    var sf: String? = nil
    var color: Color = Theme.accent
    let title: String
    var subtitle: String? = nil
    @Binding var isOn: Bool

    var body: some View {
        SettingRow(asset: asset, sf: sf, color: color, title: title, subtitle: subtitle) {
            Toggle("", isOn: $isOn).labelsHidden().tint(Theme.accent)
        }
    }
}

struct Chevron: View {
    var body: some View {
        Image(systemName: "chevron.right").font(.footnote.weight(.bold)).foregroundStyle(.tertiary)
    }
}

struct EmptyState: View {
    let asset: String
    let title: String
    var message: String? = nil
    var body: some View {
        VStack(spacing: 12) {
            SVGIcon(name: asset, size: 30)
                .foregroundStyle(Theme.accent)
                .frame(width: 72, height: 72)
                .background(Theme.accent.opacity(0.12), in: Circle())
            Text(title).font(Theme.rounded(.headline, .bold))
            if let m = message {
                Text(m).font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 50)
        .padding(.horizontal, 24)
    }
}

// MARK: - Menu (bảng ô lưới)

enum MenuAction { case fullscreen, find, library, settings, downloads, newPrivate, videos, extensions, reader, translate, pdf, shot }

struct MenuSheet: View {
    @EnvironmentObject var browser: BrowserModel
    @ObservedObject private var settings = BrowserSettings.shared
    @ObservedObject private var library = LibraryStore.shared
    @State private var showBookmarkEdit = false
    @Environment(\.displayScale) private var scale
    let onAction: (MenuAction) -> Void

    // Lưới 4 cột đều nhau; mọi ô cùng chiều cao nên các hàng luôn thẳng hàng.
    private let cols = Array(repeating: GridItem(.flexible(), spacing: 8, alignment: .top), count: 4)
    private let tileBox: CGFloat = 56
    private let labelHeight: CGFloat = 30

    private func tile(_ icon: String, _ title: String, on: Bool = false) -> some View {
        let shape = RoundedRectangle(cornerRadius: 18, style: .continuous)
        return VStack(spacing: 8) {
            SVGIcon(name: icon, size: 24)
                .foregroundStyle(on ? Color.white : Color.primary.opacity(0.88))
                .frame(width: tileBox, height: tileBox)
                .background { shape.fill(on ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Theme.chip)) }
                .overlay { shape.strokeBorder(on ? Color.white.opacity(0.30) : Theme.cardStroke,
                                              lineWidth: Theme.hairline(scale)) }
                .shadow(color: on ? Theme.accent.opacity(0.32) : .clear, radius: 8, y: 4)
            Text(title)
                .font(.system(size: 12, weight: .medium, design: .rounded))
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .minimumScaleFactor(0.9)
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity, minHeight: labelHeight, maxHeight: labelHeight, alignment: .top)
        }
        .frame(maxWidth: .infinity, alignment: .top)
    }

    private func group<C: View>(_ title: String, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Capsule().fill(Theme.gradient).frame(width: 4, height: 14)
                Text(title).font(Theme.sectionFont).tracking(0.8).foregroundStyle(.secondary)
            }
            LazyVGrid(columns: cols, alignment: .center, spacing: 18) { content() }
                .buttonStyle(PressStyle())
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .card()
    }

    private var initial: String {
        let h = (browser.currentURL?.host ?? "").replacingOccurrences(of: "www.", with: "")
        return h.isEmpty ? "" : String(h.prefix(1)).uppercased()
    }

    var body: some View {
        ZStack {
            ScreenBackground(ambient: false)
            ScrollView {
                VStack(spacing: 16) {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle().fill(Theme.gradient)
                            if initial.isEmpty {
                                SVGIcon(name: "ic_grid", size: 20).foregroundStyle(.white)
                            } else {
                                Text(initial).font(Theme.rounded(.title3, .bold)).foregroundStyle(.white)
                            }
                        }
                        .frame(width: 46, height: 46)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(browser.pageTitle.isEmpty ? "Menu" : browser.pageTitle)
                                .font(Theme.rounded(.headline, .bold)).lineLimit(1)
                            if let h = browser.currentURL?.host {
                                Text(h).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(14)
                    .card()

                    // 1. Thao tác với trang đang xem
                    group("TRANG ĐANG XEM") {
                        if let u = browser.currentURL {
                            ShareLink(item: u) { tile("ic_share", "Chia sẻ") }
                            Button {
                                // Chưa có thì lưu ngay, rồi mở bảng chọn thư mục / xoá
                                if !LibraryLock.shared.isLocked, !library.isBookmarked(u.absoluteString) {
                                    library.saveBookmark(url: u, title: browser.pageTitle, folderID: nil)
                                }
                                showBookmarkEdit = true
                            } label: {
                                tile("ic_star", "Dấu trang", on: !LibraryLock.shared.enabled && library.isBookmarked(u.absoluteString))
                            }
                        }
                        Button { onAction(.find) } label: { tile("ic_search", "Tìm trong trang") }
                        Button { onAction(.fullscreen) } label: { tile("ic_fullscreen", "Toàn màn hình") }
                    }

                    // 2. Cách hiển thị & đọc nội dung
                    group("ĐỌC & HIỂN THỊ") {
                        Button { onAction(.reader) } label: { tile("ic_reader", "Chế độ đọc", on: browser.readerOn) }
                        Button { onAction(.translate) } label: { tile("ic_translate", "Dịch trang", on: browser.activeTab.translated) }
                        Button { settings.darkPages.toggle() } label: { tile("ic_moon", "Nền tối", on: settings.darkPages) }
                        Button { browser.toggleDesktop() } label: { tile("ic_desktop", "Bản máy tính", on: browser.desktopMode) }
                        Button { settings.freeCopy.toggle() } label: { tile("ic_copy", "Chép tự do", on: settings.freeCopy) }
                    }

                    // 3. Lưu / tải nội dung về máy
                    group("LƯU & TẢI VỀ") {
                        Button { onAction(.videos) } label: {
                            tile("ic_video", "Xem video", on: !browser.activeTab.videos.isEmpty)
                        }
                        Button { onAction(.downloads) } label: { tile("ic_download", "Tải xuống") }
                        Button { onAction(.pdf) } label: { tile("ic_pdf", "Lưu thành PDF") }
                        Button { onAction(.shot) } label: { tile("ic_shot", "Chụp cả trang") }
                    }

                    // 4. Chặn, tiết kiệm, riêng tư
                    group("BẢO VỆ & RIÊNG TƯ") {
                        Button { settings.adBlock.toggle() } label: {
                            tile(settings.adBlock ? "ic_shield" : "ic_shield_off", "Chặn quảng cáo", on: settings.adBlock)
                        }
                        Button { settings.popupBlock.toggle() } label: {
                            tile("ic_popup", "Chặn popup", on: settings.popupBlock)
                        }
                        Button { settings.dataSaver.toggle() } label: {
                            tile("ic_drop", "Tiết kiệm dữ liệu", on: settings.dataSaver)
                        }
                        Button { onAction(.newPrivate) } label: { tile("ic_private", "Tab riêng tư") }
                    }

                    // 5. Thư viện, tiện ích mở rộng, cài đặt
                    group("THƯ VIỆN & ỨNG DỤNG") {
                        Button { onAction(.library) } label: { tile("ic_book", "Dấu trang & Lịch sử") }
                        Button { onAction(.extensions) } label: { tile("ic_puzzle", "Extension") }
                        Button { onAction(.settings) } label: { tile("ic_sliders", "Cài đặt") }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 22)
                .padding(.bottom, 30)
            }
        }
        .environment(\.flatCards, true)
        .sheet(isPresented: $showBookmarkEdit) {
            if let u = browser.currentURL {
                BookmarkEditSheet(url: u, pageTitle: browser.pageTitle)
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
        }
    }
}


// MARK: - Hộp thoại hệ thống đồng bộ giao diện app

extension UIAlertController {
    /// Áp màu nhấn / chế độ sáng-tối của app lên hộp thoại UIKit.
    func applyAppStyle(isPrivate: Bool) {
        view.tintColor = UIColor(isPrivate ? Theme.privateAccent : Theme.accent)
        if isPrivate { overrideUserInterfaceStyle = .dark }
    }
}

enum AppAppearance {
    /// Gọi 1 lần khi mở app: màu nhấn cho cửa sổ UIKit (hộp thoại, menu giữ lâu, tay cầm chọn chữ…).
    static func install() {
        let accent = UIColor(Theme.accent)
        UIWindow.appearance().tintColor = accent
        UIView.appearance(whenContainedInInstancesOf: [UIAlertController.self]).tintColor = accent
    }
}
