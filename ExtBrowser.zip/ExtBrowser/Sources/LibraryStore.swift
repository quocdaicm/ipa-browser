import Foundation

struct SavedPage: Codable, Identifiable, Equatable {
    var id = UUID()
    var url: String
    var title: String
    var date: Date
}

/// Lịch sử duyệt web và dấu trang, lưu ở Application Support/library.json.
@MainActor
final class LibraryStore: ObservableObject {
    static let shared = LibraryStore()

    @Published private(set) var bookmarks: [SavedPage] = []
    @Published private(set) var history: [SavedPage] = []

    private let maxHistory = 2000
    private var saveTask: Task<Void, Never>?

    private struct Disk: Codable {
        var bookmarks: [SavedPage]
        var history: [SavedPage]
    }

    private let file: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent("library.json")
    }()

    private init() {
        if let data = try? Data(contentsOf: file),
           let d = try? JSONDecoder().decode(Disk.self, from: data) {
            bookmarks = d.bookmarks
            history = d.history
        }
    }

    // MARK: Lịch sử

    func recordVisit(url: URL, title: String) {
        let scheme = (url.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https" else { return }
        let s = url.absoluteString
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if let first = history.first, first.url == s {
            history[0].date = Date()
            if !t.isEmpty { history[0].title = t }
        } else {
            history.insert(SavedPage(url: s, title: t.isEmpty ? (url.host ?? s) : t, date: Date()), at: 0)
            if history.count > maxHistory { history.removeLast(history.count - maxHistory) }
        }
        save()
    }

    func removeHistory(_ id: UUID) {
        history.removeAll { $0.id == id }
        save()
    }

    func clearHistory() {
        history.removeAll()
        save()
    }

    // MARK: Dấu trang

    func isBookmarked(_ url: String) -> Bool {
        bookmarks.contains { $0.url == url }
    }

    func toggleBookmark(url: URL, title: String) {
        let s = url.absoluteString
        if let i = bookmarks.firstIndex(where: { $0.url == s }) {
            bookmarks.remove(at: i)
        } else {
            let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
            bookmarks.insert(SavedPage(url: s, title: t.isEmpty ? (url.host ?? s) : t, date: Date()), at: 0)
        }
        save()
    }

    func removeBookmark(_ id: UUID) {
        bookmarks.removeAll { $0.id == id }
        save()
    }

    // MARK: Lưu file (gộp, trễ ~1 giây)

    private func save() {
        saveTask?.cancel()
        let disk = Disk(bookmarks: bookmarks, history: history)
        let f = file
        saveTask = Task.detached {
            try? await Task.sleep(nanoseconds: 800_000_000)
            if Task.isCancelled { return }
            if let data = try? JSONEncoder().encode(disk) {
                try? data.write(to: f, options: .atomic)
            }
        }
    }
}
