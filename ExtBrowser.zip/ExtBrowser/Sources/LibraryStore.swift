import Foundation

struct SavedPage: Codable, Identifiable, Equatable {
    var id = UUID()
    var url: String
    var title: String
    var date: Date
    /// Thư mục chứa dấu trang (nil = ngoài cùng). Lịch sử không dùng trường này.
    var folderID: UUID? = nil
}

struct BookmarkFolder: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var date = Date()
}

/// Lịch sử duyệt web và dấu trang, lưu ở Application Support/library.json.
@MainActor
final class LibraryStore: ObservableObject {
    static let shared = LibraryStore()

    @Published private(set) var bookmarks: [SavedPage] = []
    @Published private(set) var history: [SavedPage] = []
    @Published private(set) var folders: [BookmarkFolder] = []

    private let maxHistory = 2000
    private var saveTask: Task<Void, Never>?

    private struct Disk: Codable {
        var bookmarks: [SavedPage]
        var history: [SavedPage]
        var folders: [BookmarkFolder]

        init(bookmarks: [SavedPage], history: [SavedPage], folders: [BookmarkFolder]) {
            self.bookmarks = bookmarks
            self.history = history
            self.folders = folders
        }

        // File cũ chưa có "folders" vẫn đọc được
        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            bookmarks = try c.decodeIfPresent([SavedPage].self, forKey: .bookmarks) ?? []
            history = try c.decodeIfPresent([SavedPage].self, forKey: .history) ?? []
            folders = try c.decodeIfPresent([BookmarkFolder].self, forKey: .folders) ?? []
        }
    }

    private let file: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent("library.json")
    }()

    private init() {
        if let data = try? Data(contentsOf: file),
           let d = try? JSONDecoder().decode(Disk.self, from: data) {
            bookmarks = d.bookmarks
            history = d.history
            folders = d.folders
        }
    }

    // MARK: Lịch sử

    func recordVisit(url: URL, title: String) {
        let scheme = (url.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https" else { return }
        let s = url.absoluteString
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if let first = history.first, first.url == s {
            history[0].date = Date()
            if !t.isEmpty { history[0].title = t }
        } else {
            history.insert(SavedPage(url: s, title: t.isEmpty ? (url.host ?? s) : t, date: Date()), at: 0)
            if history.count > maxHistory { history.removeLast(history.count - maxHistory) }
        }
        save()
    }

    func removeHistory(_ id: UUID) {
        history.removeAll { $0.id == id }
        save()
    }

    func clearHistory() {
        history.removeAll()
        save()
    }

    // MARK: Dấu trang

    func isBookmarked(_ url: String) -> Bool {
        bookmarks.contains { $0.url == url }
    }

    func toggleBookmark(url: URL, title: String) {
        let s = url.absoluteString
        if let i = bookmarks.firstIndex(where: { $0.url == s }) {
            bookmarks.remove(at: i)
        } else {
            let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
            bookmarks.insert(SavedPage(url: s, title: t.isEmpty ? (url.host ?? s) : t, date: Date()), at: 0)
        }
        save()
    }

    func removeBookmark(_ id: UUID) {
        bookmarks.removeAll { $0.id == id }
        save()
    }

    func bookmark(for url: String) -> SavedPage? {
        bookmarks.first { $0.url == url }
    }

    /// Thêm hoặc cập nhật dấu trang (tên + thư mục).
    func saveBookmark(url: URL, title: String, folderID: UUID?) {
        let s = url.absoluteString
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = t.isEmpty ? (url.host ?? s) : t
        if let i = bookmarks.firstIndex(where: { $0.url == s }) {
            bookmarks[i].title = name
            bookmarks[i].folderID = folderID
        } else {
            bookmarks.insert(SavedPage(url: s, title: name, date: Date(), folderID: folderID), at: 0)
        }
        save()
    }

    func moveBookmark(_ id: UUID, to folderID: UUID?) {
        guard let i = bookmarks.firstIndex(where: { $0.id == id }) else { return }
        bookmarks[i].folderID = folderID
        save()
    }

    // MARK: Thư mục dấu trang

    @discardableResult
    func createFolder(_ name: String) -> BookmarkFolder? {
        let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !n.isEmpty else { return nil }
        if let e = folders.first(where: { $0.name.caseInsensitiveCompare(n) == .orderedSame }) { return e }
        let f = BookmarkFolder(name: n)
        folders.append(f)
        save()
        return f
    }

    func renameFolder(_ id: UUID, to name: String) {
        let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !n.isEmpty, let i = folders.firstIndex(where: { $0.id == id }) else { return }
        folders[i].name = n
        save()
    }

    /// Xoá thư mục; dấu trang bên trong được đưa ra ngoài cùng (không bị mất).
    func deleteFolder(_ id: UUID) {
        for i in bookmarks.indices where bookmarks[i].folderID == id { bookmarks[i].folderID = nil }
        folders.removeAll { $0.id == id }
        save()
    }

    func folder(_ id: UUID?) -> BookmarkFolder? {
        guard let id = id else { return nil }
        return folders.first { $0.id == id }
    }

    func count(in folderID: UUID) -> Int {
        bookmarks.filter { $0.folderID == folderID }.count
    }

    // MARK: Lưu file (gộp, trễ ~1 giây)

    private func save() {
        saveTask?.cancel()
        let disk = Disk(bookmarks: bookmarks, history: history, folders: folders)
        let f = file
        saveTask = Task.detached {
            try? await Task.sleep(nanoseconds: 800_000_000)
            if Task.isCancelled { return }
            if let data = try? JSONEncoder().encode(disk) {
                try? data.write(to: f, options: .atomic)
            }
        }
    }
}
