import Foundation
import WebKit

struct ScriptSpec {
    let source: String
    let time: WKUserScriptInjectionTime
    let mainOnly: Bool
    var page: Bool = false
}

/// Đổi match pattern kiểu Chrome / glob userscript / /regex/ thành nguồn RegExp cho JS.
enum MatchPattern {
    static func regexSource(_ pattern: String) -> String? {
        let p = pattern.trimmingCharacters(in: .whitespaces)
        if p.isEmpty { return nil }
        if p == "<all_urls>" { return "^(https?|ftp)://.*$" }
        if p.count > 2, p.hasPrefix("/"), p.hasSuffix("/") { return String(p.dropFirst().dropLast()) }

        func esc(_ s: String) -> String {
            var o = ""
            for c in s {
                if "\\^$.|?+()[]{}/".contains(c) { o.append("\\") }
                o.append(c)
            }
            return o
        }
        func glob(_ s: String) -> String {
            s.split(separator: "*", omittingEmptySubsequences: false)
                .map { esc(String($0)) }
                .joined(separator: ".*")
        }

        guard let r = p.range(of: "://") else { return "^" + glob(p) + "$" }
        let scheme = String(p[..<r.lowerBound])
        var rest = String(p[r.upperBound...])
        let schemeRe = scheme == "*" ? "(https?|ftp)" : glob(scheme)
        var hostRe = ""
        if rest.hasPrefix("*.") {
            hostRe = "([^/]*\\.)?"
            rest.removeFirst(2)
        }
        return "^" + schemeRe + ":\\/\\/" + hostRe + glob(rest) + "$"
    }
}

enum ScriptBuilder {
    static func js(_ v: Any) -> String {
        if let d = try? JSONSerialization.data(withJSONObject: v, options: [.fragmentsAllowed]),
           let s = String(data: d, encoding: .utf8) {
            return s
        }
        return "null"
    }

    /// Đoạn JS khai báo __EXT + shim chrome.* cho một extension.
    static func context(id: String, store: ExtStore, tabURL: String?, role: String = "content") -> String {
        let m = store.manifest(id: id)
        var e: [String: Any] = [
            "id": id,
            "manifest": m,
            "messages": store.messages(id: id),
            "userscript": (m["x_userscript"] as? Bool) ?? false,
            "gm": store.storageGet(id: id, area: "gm", keys: nil),
            "role": role
        ]
        if let t = tabURL { e["tabURL"] = t }
        return "var __EXT = \(js(e));\n" + shim
    }

    /// Toàn bộ user script cần chèn vào trình duyệt cho extension này.
    static func scripts(for item: InstalledExtension, store: ExtStore) -> [ScriptSpec] {
        var out = [ScriptSpec(source: context(id: item.id, store: store, tabURL: nil),
                              time: .atDocumentStart, mainOnly: false)]
        let m = store.manifest(id: item.id)
        for cs in (m["content_scripts"] as? [[String: Any]]) ?? [] {
            let regs = ((cs["matches"] as? [String]) ?? []).compactMap(MatchPattern.regexSource)
            if regs.isEmpty { continue }
            let excl = ((cs["exclude_matches"] as? [String]) ?? []).compactMap(MatchPattern.regexSource)
            let isMain = ((cs["world"] as? String) ?? "").uppercased() == "MAIN"

            var body = (isMain && ((m["x_userscript"] as? Bool) ?? false)) ? "var unsafeWindow = window;\n" : ""
            for f in (cs["css"] as? [String]) ?? [] {
                if let t = store.readText(id: item.id, path: f) {
                    body += "__css(\(js(t)));\n"
                }
            }
            for f in (cs["js"] as? [String]) ?? [] {
                if let t = store.readText(id: item.id, path: f) {
                    body += t + "\n;\n"
                }
            }
            if body.isEmpty { continue }

            let src = "(function(){var __h=location.href;"
                + "function __t(a){return a.some(function(s){try{return new RegExp(s).test(__h)}catch(e){return false}})}"
                + "function __css(t){var f=function(){var s=document.createElement('style');s.textContent=t;(document.head||document.documentElement).appendChild(s)};if(document.documentElement)f();else document.addEventListener('DOMContentLoaded',f)}"
                + "if(!__t(\(js(regs)))||__t(\(js(excl))))return;\n"
                + body
                + "\n})();"
            let time: WKUserScriptInjectionTime = (cs["run_at"] as? String) == "document_start" ? .atDocumentStart : .atDocumentEnd
            let mainOnly = !((cs["all_frames"] as? Bool) ?? false)
            out.append(ScriptSpec(source: src, time: time, mainOnly: mainOnly, page: isMain))
        }
        return out
    }


    // MARK: chrome.* shim

    static let shim = #"""
(function () {
  var E = __EXT;
  var W = window;
  var ROLE = E.role || 'content';
  var EV = {};

  function bridge(type, payload) {
    return W.webkit.messageHandlers.extBridge.postMessage({ ext: E.id, type: type, role: ROLE, payload: payload || {} });
  }
  function quiet(p) { try { p.catch(function () {}); } catch (e) {} return p; }
  function done(p, cb) {
    if (typeof cb === 'function') {
      p.then(function (r) { cb(r); }, function () { try { cb(undefined); } catch (e) {} });
      return undefined;
    }
    return p;
  }
  function ev(name) {
    var l = [];
    var o = {
      addListener: function (f) { if (typeof f === 'function' && l.indexOf(f) < 0) l.push(f); },
      removeListener: function (f) { var i = l.indexOf(f); if (i >= 0) l.splice(i, 1); },
      hasListener: function (f) { return l.indexOf(f) >= 0; },
      hasListeners: function () { return l.length > 0; },
      _list: function () { return l.slice(); },
      _fire: function (args) {
        l.slice().forEach(function (f) { try { f.apply(null, args || []); } catch (e) { console.error(e); } });
      }
    };
    if (name) EV[name] = o;
    return o;
  }
  function fire(name, args) { if (EV[name]) EV[name]._fire(args); }
  function noop() {}
  function stubFn() {
    var cb = arguments[arguments.length - 1];
    if (typeof cb === 'function') { setTimeout(function () { try { cb(undefined); } catch (e) {} }, 0); }
    return Promise.resolve(undefined);
  }
  function loose(t) {
    return new Proxy(t, {
      get: function (o, k) {
        if (k in o) return o[k];
        if (typeof k !== 'string' || k === 'then' || k === 'catch' || k === 'toJSON') return undefined;
        if (/^on[A-Z]/.test(k)) { o[k] = ev(); return o[k]; }
        if (/^[A-Z][A-Z0-9_]*$/.test(k)) return undefined;
        o[k] = stubFn;
        return o[k];
      }
    });
  }

  // ---------- storage ----------
  function area(name) {
    return loose({
      get: function (keys, cb) {
        if (typeof keys === 'function') { cb = keys; keys = null; }
        return done(bridge('storage.get', { area: name, keys: keys === undefined ? null : keys }), cb);
      },
      set: function (items, cb) {
        return done(bridge('storage.set', { area: name, items: items }).then(function (ch) {
          if (ROLE === 'page' && ch) fire('storageChanged', [ch, name]);
        }), cb);
      },
      remove: function (keys, cb) {
        return done(bridge('storage.remove', { area: name, keys: [].concat(keys) }).then(function (ch) {
          if (ROLE === 'page' && ch) fire('storageChanged', [ch, name]);
        }), cb);
      },
      clear: function (cb) {
        return done(bridge('storage.clear', { area: name }).then(function (ch) {
          if (ROLE === 'page' && ch) fire('storageChanged', [ch, name]);
        }), cb);
      },
      getBytesInUse: function (k, cb) { return done(Promise.resolve(0), typeof k === 'function' ? k : cb); },
      setAccessLevel: function () { return Promise.resolve(); },
      onChanged: ev()
    });
  }

  function url(p) { return 'ext://' + E.id + '/' + String(p).replace(/^\/+/, ''); }
  function msg(key, subs) {
    var m = E.messages && E.messages[key];
    if (!m && E.messages) {
      var lk = String(key).toLowerCase();
      for (var k in E.messages) { if (k.toLowerCase() === lk) { m = E.messages[k]; break; } }
    }
    if (!m) return '';
    var s = m.message || '';
    if (subs !== undefined) {
      subs = [].concat(subs);
      s = s.replace(/\$(\d)/g, function (_, i) { return subs[i - 1] !== undefined ? subs[i - 1] : ''; });
    }
    return s;
  }

  // ---------- messaging ----------
  function senderInfo() {
    if (ROLE === 'content') {
      var top = (W === W.top);
      return {
        id: E.id, url: W.location.href, origin: W.location.origin, frameId: top ? 0 : 1,
        tab: { id: 1, index: 0, windowId: 1, active: true, url: top ? W.location.href : (document.referrer || W.location.href), title: document.title }
      };
    }
    return { id: E.id, url: W.location.href, origin: W.location.origin };
  }

  function dispatchMessage(p) {
    return new Promise(function (resolve) {
      var l = EV.message ? EV.message._list() : [];
      var answered = false, pending = 0;
      function finish(v) {
        if (answered) return;
        answered = true;
        var out;
        try { out = JSON.stringify({ ok: true, r: v === undefined ? null : v }); }
        catch (e) { out = JSON.stringify({ ok: true, r: null }); }
        resolve(out);
      }
      l.forEach(function (f) {
        if (answered) return;
        var keep;
        try { keep = f(p.message, p.sender, finish); } catch (e) { console.error(e); }
        if (keep === true) pending++;
        else if (keep && typeof keep.then === 'function') {
          pending++;
          keep.then(function (v) { if (v !== undefined) finish(v); }, function () {});
        }
      });
      if (!answered && pending === 0) { resolve(JSON.stringify({ ok: false })); }
      else if (!answered) {
        setTimeout(function () { if (!answered) { answered = true; resolve(JSON.stringify({ ok: false })); } }, 30000);
      }
    });
  }

  var ports = {};
  var portSeq = 0;
  function makePort(id, name, sender, to) {
    var port = {
      name: name || '', sender: sender,
      onMessage: ev(), onDisconnect: ev(),
      postMessage: function (m) { quiet(bridge('port.post', { portId: id, to: to, data: m })); },
      disconnect: function () {
        if (ports[id]) { delete ports[id]; quiet(bridge('port.disconnect', { portId: id, to: to })); }
      }
    };
    ports[id] = port;
    return port;
  }
  function newPortId() { return E.id + ':' + Date.now() + ':' + (++portSeq) + ':' + Math.random().toString(36).slice(2, 7); }

  W.__extRecv = function (kind, p) {
    p = p || {};
    switch (kind) {
      case 'message': return dispatchMessage(p);
      case 'installed': fire('installed', [p]); return;
      case 'startup': fire('startup', []); return;
      case 'storageChanged': fire('storageChanged', [p.changes, p.area]); return;
      case 'tabUpdated': fire('tabUpdated', [p.tabId, p.changeInfo, p.tab]); return;
      case 'navBefore': case 'navCommitted': case 'navCompleted': case 'navDOM': fire(kind, [p]); return;
      case 'portConnect':
        var np = makePort(p.portId, p.name, p.sender, ROLE === 'background' ? 'tab' : 'bg');
        fire('connect', [np]);
        return;
      case 'portMessage':
        var q = ports[p.portId];
        if (q) q.onMessage._fire([p.data, q]);
        return;
      case 'portDisconnect':
        var r = ports[p.portId];
        if (r) { delete ports[p.portId]; r.onDisconnect._fire([r]); }
        return;
    }
  };

  // ---------- alarms ----------
  var alarmMap = {}, alarmTimers = {};
  function persistAlarms() {
    quiet(bridge('storage.set', { area: 'alarms', items: { list: alarmMap } }));
  }
  function schedule(name, delay) {
    clearTimeout(alarmTimers[name]);
    alarmTimers[name] = setTimeout(function tick() {
      var a = alarmMap[name];
      if (!a) return;
      fire('alarm', [{ name: name, scheduledTime: Date.now(), periodInMinutes: a.periodInMinutes }]);
      if (a.periodInMinutes) {
        a.scheduledTime = Date.now() + a.periodInMinutes * 60000;
        alarmTimers[name] = setTimeout(tick, a.periodInMinutes * 60000);
      } else {
        delete alarmMap[name];
      }
      persistAlarms();
    }, Math.max(0, delay));
  }
  function alarmCreate(a, b) {
    var name = '', info = a;
    if (typeof a === 'string') { name = a; info = b; }
    info = info || {};
    var delay;
    if (info.when) delay = info.when - Date.now();
    else if (info.delayInMinutes !== undefined) delay = info.delayInMinutes * 60000;
    else delay = (info.periodInMinutes || 0) * 60000;
    alarmMap[name] = { name: name, scheduledTime: Date.now() + delay, periodInMinutes: info.periodInMinutes };
    schedule(name, delay);
    persistAlarms();
  }
  function alarmClear(name) {
    name = name || '';
    var had = !!alarmMap[name];
    clearTimeout(alarmTimers[name]);
    delete alarmMap[name];
    persistAlarms();
    return had;
  }

  function win() { return { id: 1, focused: true, type: 'normal', state: 'normal', incognito: false, left: 0, top: 0, width: W.innerWidth, height: W.innerHeight }; }
  var action = loose({
    setBadgeText: noop, setBadgeBackgroundColor: noop, setBadgeTextColor: noop, setIcon: noop, setTitle: noop, setPopup: noop,
    enable: noop, disable: noop,
    getBadgeText: function (d, cb) { return done(Promise.resolve(''), typeof d === 'function' ? d : cb); },
    onClicked: ev()
  });
  var dnrEnums = {
    ResourceType: { MAIN_FRAME: 'main_frame', SUB_FRAME: 'sub_frame', STYLESHEET: 'stylesheet', SCRIPT: 'script', IMAGE: 'image', FONT: 'font', OBJECT: 'object', XMLHTTPREQUEST: 'xmlhttprequest', PING: 'ping', CSP_REPORT: 'csp_report', MEDIA: 'media', WEBSOCKET: 'websocket', OTHER: 'other' },
    RuleActionType: { BLOCK: 'block', REDIRECT: 'redirect', ALLOW: 'allow', UPGRADE_SCHEME: 'upgradeScheme', MODIFY_HEADERS: 'modifyHeaders', ALLOW_ALL_REQUESTS: 'allowAllRequests' },
    HeaderOperation: { APPEND: 'append', SET: 'set', REMOVE: 'remove' },
    DomainType: { FIRST_PARTY: 'firstParty', THIRD_PARTY: 'thirdParty' },
    MAX_NUMBER_OF_DYNAMIC_RULES: 30000, MAX_NUMBER_OF_UNSAFE_DYNAMIC_RULES: 5000,
    MAX_NUMBER_OF_SESSION_RULES: 5000, MAX_NUMBER_OF_ENABLED_STATIC_RULESETS: 50,
    GUARANTEED_MINIMUM_STATIC_RULES: 30000
  };
  function dnrUpdate(key) {
    return function (o, cb) {
      o = o || {};
      return done(bridge('dnr.update', { key: key, add: o.addRules || [], remove: o.removeRuleIds || [] }).then(function () {}), cb);
    };
  }
  function dnrGet(key) {
    return function (a, cb) { return done(bridge('dnr.get', { key: key }), typeof a === 'function' ? a : cb); };
  }
  dnrEnums.updateDynamicRules = dnrUpdate('dynamic');
  dnrEnums.updateSessionRules = dnrUpdate('session');
  dnrEnums.getDynamicRules = dnrGet('dynamic');
  dnrEnums.getSessionRules = dnrGet('session');
  dnrEnums.updateEnabledRulesets = function (o, cb) {
    o = o || {};
    return done(bridge('dnr.rulesets', { enable: o.enableRulesetIds || [], disable: o.disableRulesetIds || [] }).then(function () {}), cb);
  };
  dnrEnums.getEnabledRulesets = function (cb) { return done(bridge('dnr.enabled', {}), cb); };
  dnrEnums.getAvailableStaticRuleCount = function (cb) { return done(Promise.resolve(300000), cb); };
  dnrEnums.isRegexSupported = function (o, cb) { return done(Promise.resolve({ isSupported: true }), cb); };
  dnrEnums.getMatchedRules = function (o, cb) { return done(Promise.resolve({ rulesMatchedInfo: [] }), typeof o === 'function' ? o : cb); };
  dnrEnums.setExtensionActionOptions = function () { return Promise.resolve(); };

  var api = {
    runtime: loose({
      id: E.id,
      getURL: url,
      getManifest: function () { return E.manifest; },
      getPlatformInfo: function (cb) { return done(Promise.resolve({ os: 'ios', arch: 'arm', nacl_arch: 'arm' }), cb); },
      getBrowserInfo: function (cb) { return done(Promise.resolve({ name: 'ExtBrowser', vendor: 'ExtBrowser', version: '1.0', buildID: '1' }), cb); },
      getBackgroundPage: function (cb) { return done(Promise.resolve(ROLE === 'background' ? W : null), cb); },
      openOptionsPage: function (cb) { return done(bridge('openOptions').then(function () {}), cb); },
      reload: noop,
      setUninstallURL: function (u, cb) { return done(Promise.resolve(), cb); },
      sendMessage: function () {
        var a = [].slice.call(arguments);
        var cb = typeof a[a.length - 1] === 'function' ? a.pop() : null;
        if (typeof a[0] === 'string' && a.length >= 2) a.shift();
        var p = bridge('runtime.sendMessage', { message: a[0], sender: senderInfo() })
          .then(function (r) { return (r && r.ok) ? r.r : undefined; });
        return done(p, cb);
      },
      connect: function () {
        var a = [].slice.call(arguments), info = {};
        if (typeof a[0] === 'string') a.shift();
        if (a[0] && typeof a[0] === 'object') info = a[0];
        var id = newPortId();
        var port = makePort(id, info.name, null, 'bg');
        quiet(bridge('port.connect', { portId: id, to: 'bg', name: info.name || '', sender: senderInfo() }));
        return port;
      },
      onMessage: ev('message'), onInstalled: ev('installed'), onConnect: ev('connect'), onStartup: ev('startup'),
      onMessageExternal: ev(), onConnectExternal: ev(), onSuspend: ev(), onUpdateAvailable: ev(),
      lastError: undefined
    }),
    extension: loose({
      getURL: url,
      getBackgroundPage: function () { return null; },
      getViews: function () { return []; },
      inIncognitoContext: false
    }),
    storage: loose({
      local: area('local'), sync: area('sync'), session: area('session'), managed: area('managed'),
      onChanged: ev('storageChanged')
    }),
    i18n: loose({
      getMessage: msg,
      getUILanguage: function () { return navigator.language; },
      getAcceptLanguages: function (cb) { return done(Promise.resolve([navigator.language]), cb); }
    }),
    tabs: loose({
      query: function (q, cb) {
        if (typeof q === 'function') { cb = q; q = {}; }
        return done(bridge('tabs.query', q || {}), cb);
      },
      get: function (id, cb) { return done(bridge('tabs.get', {}), cb); },
      getCurrent: function (cb) { return done(ROLE === 'content' ? bridge('tabs.get', {}) : Promise.resolve(undefined), cb); },
      create: function (o, cb) { return done(bridge('tabs.create', o || {}), cb); },
      update: function (a, b, c) {
        var o, cb;
        if (typeof a === 'number') { o = b; cb = c; } else { o = a; cb = b; }
        return done(bridge('tabs.update', o || {}), cb);
      },
      reload: function (a, b, c) {
        var cb = [a, b, c].filter(function (x) { return typeof x === 'function'; })[0];
        return done(bridge('tabs.reload', {}).then(function () {}), cb);
      },
      remove: function (ids, cb) { return done(Promise.resolve(), cb); },
      goBack: function (a, cb) { return done(bridge('tabs.goBack', {}).then(function () {}), typeof a === 'function' ? a : cb); },
      goForward: function (a, cb) { return done(bridge('tabs.goForward', {}).then(function () {}), typeof a === 'function' ? a : cb); },
      sendMessage: function (tabId, m, o, cb) {
        if (typeof o === 'function') cb = o;
        return done(bridge('tabs.sendMessage', { message: m }).then(function (r) { return (r && r.ok) ? r.r : undefined; }), cb);
      },
      connect: function (tabId, info) {
        info = info || {};
        var id = newPortId();
        var port = makePort(id, info.name, null, 'tab');
        quiet(bridge('port.connect', { portId: id, to: 'tab', name: info.name || '', sender: senderInfo() }));
        return port;
      },
      executeScript: function (a, b, c) {
        var d, cb;
        if (typeof a === 'number') { d = b; cb = c; } else { d = a; cb = b; }
        d = d || {};
        var pl = { world: 'ISOLATED' };
        if (d.code) pl.source = d.code; else if (d.file) pl.files = [d.file];
        return done(bridge('exec', pl).then(function (r) { return (r || []).map(function (x) { return x.result; }); }), cb);
      },
      insertCSS: function (a, b, c) {
        var d, cb;
        if (typeof a === 'number') { d = b; cb = c; } else { d = a; cb = b; }
        d = d || {};
        return done(bridge('css', { css: d.code || null, files: d.file ? [d.file] : null }).then(function () {}), cb);
      },
      captureVisibleTab: function (a, b, c) {
        var cb = [a, b, c].filter(function (x) { return typeof x === 'function'; })[0];
        return done(bridge('tabs.capture', {}), cb);
      },
      onUpdated: ev('tabUpdated'),
      TAB_ID_NONE: -1
    }),
    windows: loose({
      getCurrent: function (a, b) { return done(Promise.resolve(win()), typeof a === 'function' ? a : b); },
      getLastFocused: function (a, b) { return done(Promise.resolve(win()), typeof a === 'function' ? a : b); },
      getAll: function (a, b) { return done(Promise.resolve([win()]), typeof a === 'function' ? a : b); },
      get: function (id, a, b) { return done(Promise.resolve(win()), typeof a === 'function' ? a : b); },
      create: function (o, cb) {
        if (o && o.url) quiet(bridge('tabs.create', { url: [].concat(o.url)[0] }));
        return done(Promise.resolve(win()), cb);
      },
      update: function (id, o, cb) { return done(Promise.resolve(win()), cb); },
      WINDOW_ID_NONE: -1, WINDOW_ID_CURRENT: -2
    }),
    scripting: loose({
      executeScript: function (inj, cb) {
        inj = inj || {};
        var pl = { world: inj.world || 'ISOLATED' };
        if (typeof inj.func === 'function') pl.call = '(' + inj.func.toString() + ').apply(null, ' + JSON.stringify(inj.args || []) + ')';
        else if (inj.files) pl.files = inj.files;
        return done(bridge('exec', pl).then(function (r) { return r || []; }), cb);
      },
      insertCSS: function (inj, cb) {
        inj = inj || {};
        return done(bridge('css', { css: inj.css || null, files: inj.files || null }).then(function () {}), cb);
      },
      removeCSS: function (inj, cb) { return done(Promise.resolve(), cb); },
      registerContentScripts: function (s, cb) { return done(Promise.resolve(), cb); },
      unregisterContentScripts: function (s, cb) { return done(Promise.resolve(), typeof s === 'function' ? s : cb); },
      getRegisteredContentScripts: function (s, cb) { return done(Promise.resolve([]), typeof s === 'function' ? s : cb); },
      updateContentScripts: function (s, cb) { return done(Promise.resolve(), cb); }
    }),
    action: action,
    browserAction: action,
    pageAction: action,
    alarms: loose({
      create: function (a, b) { alarmCreate(a, b); return Promise.resolve(); },
      get: function (n, cb) {
        if (typeof n === 'function') { cb = n; n = ''; }
        return done(Promise.resolve(alarmMap[n || ''] || undefined), cb);
      },
      getAll: function (cb) { return done(Promise.resolve(Object.keys(alarmMap).map(function (k) { return alarmMap[k]; })), cb); },
      clear: function (n, cb) {
        if (typeof n === 'function') { cb = n; n = ''; }
        return done(Promise.resolve(alarmClear(n)), cb);
      },
      clearAll: function (cb) {
        Object.keys(alarmMap).forEach(alarmClear);
        return done(Promise.resolve(true), cb);
      },
      onAlarm: ev('alarm')
    }),
    contextMenus: loose({
      create: function (o, cb) { if (typeof cb === 'function') cb(); return (o && o.id) || 'menu'; },
      update: stubFn, remove: stubFn, removeAll: stubFn, onClicked: ev()
    }),
    permissions: loose({
      contains: function () { return Promise.resolve(true); },
      request: function () { return Promise.resolve(true); },
      getAll: function (cb) { return done(Promise.resolve({ permissions: E.manifest.permissions || [], origins: E.manifest.host_permissions || [] }), cb); },
      remove: function () { return Promise.resolve(true); }
    }),
    cookies: loose({
      getAll: function (d, cb) { return done(bridge('cookies.getAll', d || {}), cb); },
      get: function (d, cb) { return done(bridge('cookies.get', d || {}).then(function (r) { return r || null; }), cb); },
      set: function (d, cb) { return done(bridge('cookies.set', d || {}).then(function (r) { return r || null; }), cb); },
      remove: function (d, cb) { return done(bridge('cookies.remove', d || {}).then(function () { return d; }), cb); },
      getAllCookieStores: function (cb) { return done(Promise.resolve([{ id: '0', tabIds: [1] }]), cb); },
      onChanged: ev()
    }),
    downloads: loose({
      download: function (o, cb) { return done(bridge('downloads.download', o || {}), cb); },
      onChanged: ev(), onCreated: ev()
    }),
    webNavigation: loose({
      onBeforeNavigate: ev('navBefore'), onCommitted: ev('navCommitted'),
      onCompleted: ev('navCompleted'), onDOMContentLoaded: ev('navDOM')
    }),
    declarativeNetRequest: loose(dnrEnums),
    notifications: loose({
      create: function (a, b, c) {
        var cb = [a, b, c].filter(function (x) { return typeof x === 'function'; })[0];
        var id = typeof a === 'string' ? a : 'n' + Date.now();
        return done(Promise.resolve(id), cb);
      },
      clear: function (id, cb) { return done(Promise.resolve(true), cb); },
      onClicked: ev(), onClosed: ev()
    }),
    idle: loose({
      queryState: function (s, cb) { return done(Promise.resolve('active'), cb); },
      setDetectionInterval: noop, onStateChanged: ev()
    }),
    management: loose({
      getSelf: function (cb) {
        return done(Promise.resolve({ id: E.id, name: E.manifest.name, version: E.manifest.version, enabled: true, type: 'extension', installType: 'development' }), cb);
      },
      getAll: function (cb) { return done(Promise.resolve([]), cb); }
    })
  };
  var top = new Proxy(api, {
    get: function (o, k) {
      if (k in o) return o[k];
      if (typeof k !== 'string' || k === 'then' || k === 'catch' || k === 'toJSON') return undefined;
      o[k] = loose({});
      return o[k];
    }
  });
  W.chrome = top;
  W.browser = top;

  W.__extAddCSS = function (t) {
    var f = function () {
      var s = document.createElement('style');
      s.textContent = t;
      (document.head || document.documentElement).appendChild(s);
    };
    if (document.documentElement) f(); else document.addEventListener('DOMContentLoaded', f);
  };

  // ---------- background / extension pages ----------
  if (ROLE !== 'content') {
    var nativeFetch = W.fetch ? W.fetch.bind(W) : null;
    if (nativeFetch) {
      W.fetch = function (input, init) {
        try {
          var req = (typeof Request !== 'undefined' && input instanceof Request) ? input : null;
          var abs = new URL(req ? req.url : String(input), W.location.href);
          if (abs.protocol === 'http:' || abs.protocol === 'https:') {
            init = init || {};
            var method = String(init.method || (req && req.method) || 'GET').toUpperCase();
            var headers = {};
            var h = init.headers || (req && req.headers);
            if (h) new Headers(h).forEach(function (v, k) { headers[k] = v; });
            var body = init.body;
            if (body === undefined || body === null || typeof body === 'string' || (typeof URLSearchParams !== 'undefined' && body instanceof URLSearchParams)) {
              return bridge('fetch', { url: abs.href, method: method, headers: headers, body: (body === undefined || body === null) ? null : String(body) })
                .then(function (r) {
                  if (!r || r.error) throw new TypeError((r && r.error) || 'Failed to fetch');
                  var bin = atob(r.b64 || '');
                  var arr = new Uint8Array(bin.length);
                  for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
                  var st = r.status;
                  var nobody = (st === 204 || st === 205 || st === 304);
                  if (st < 200 || st > 599) st = 200;
                  var res = new Response(nobody ? null : arr, { status: st, statusText: r.statusText || '', headers: r.headers || {} });
                  try { Object.defineProperty(res, 'url', { value: r.url }); } catch (e) {}
                  return res;
                });
            }
          }
        } catch (e) {}
        return nativeFetch(input, init);
      };
    }
    W.importScripts = function () {
      for (var i = 0; i < arguments.length; i++) {
        var x = new XMLHttpRequest();
        x.open('GET', new URL(arguments[i], W.location.href).href, false);
        x.send();
        (0, eval)(x.responseText + '\n//# sourceURL=' + arguments[i]);
      }
    };
    W.skipWaiting = function () { return Promise.resolve(); };
    W.clients = { claim: function () { return Promise.resolve(); }, matchAll: function () { return Promise.resolve([]); } };
  }
  if (ROLE === 'background') {
    function fmt(a) {
      try { return typeof a === 'string' ? a : (a instanceof Error ? (a.stack || a.message) : JSON.stringify(a)); }
      catch (e) { return String(a); }
    }
    ['log', 'info', 'warn', 'error'].forEach(function (lv) {
      var o = console[lv];
      console[lv] = function () {
        try { quiet(bridge('log', { level: lv, text: [].map.call(arguments, fmt).join(' ') })); } catch (e) {}
        return o.apply(console, arguments);
      };
    });
    W.addEventListener('error', function (e) {
      quiet(bridge('log', { level: 'error', text: String(e.message) + ' @' + String(e.filename || '') + ':' + String(e.lineno || '') }));
    });
    W.addEventListener('unhandledrejection', function (e) {
      quiet(bridge('log', { level: 'error', text: 'unhandledrejection: ' + fmt(e.reason) }));
    });
    quiet(bridge('storage.get', { area: 'alarms', keys: 'list' }).then(function (r) {
      var l = (r && r.list) || {};
      Object.keys(l).forEach(function (k) {
        if (alarmMap[k]) return;
        var a = l[k];
        alarmMap[k] = a;
        schedule(k, Math.max(1000, (a.scheduledTime || 0) - Date.now()));
      });
    }));
  }

  // ---------- userscript GM_* ----------
  if (E.userscript) {
    var gm = E.gm || {};
    var info = { script: { name: E.manifest.name, version: E.manifest.version, namespace: '', description: '' }, scriptHandler: 'ExtBrowser', version: '1.0' };
    W.GM_getValue = function (k, d) { return (k in gm) ? gm[k] : d; };
    W.GM_setValue = function (k, v) {
      gm[k] = v;
      var o = {}; o[k] = v;
      quiet(bridge('storage.set', { area: 'gm', items: o }));
    };
    W.GM_deleteValue = function (k) {
      delete gm[k];
      quiet(bridge('storage.remove', { area: 'gm', keys: [k] }));
    };
    W.GM_listValues = function () { return Object.keys(gm); };
    W.GM_addStyle = function (css) {
      var s = document.createElement('style');
      s.textContent = css;
      (document.head || document.documentElement).appendChild(s);
      return s;
    };
    W.GM_log = function () { console.log.apply(console, arguments); };
    W.GM_info = info;
    W.GM_registerMenuCommand = function () { return 0; };
    W.GM_unregisterMenuCommand = noop;
    W.GM_openInTab = function (u) { W.open(u, '_blank'); return { close: noop }; };
    W.GM_setClipboard = function (t) { try { navigator.clipboard.writeText(String(t)); } catch (e) {} };
    W.GM_notification = noop;
    W.GM_download = function (a, b) {
      var u = typeof a === 'string' ? a : a.url, n = typeof a === 'string' ? b : a.name;
      quiet(bridge('downloads.download', { url: u, filename: n }));
    };
    W.GM_xmlhttpRequest = function (d) {
      quiet(bridge('xhr', { method: d.method || 'GET', url: d.url, headers: d.headers || {}, data: d.data || null })
        .then(function (r) {
          if (r.error) { r.finalUrl = d.url; if (d.onerror) d.onerror(r); }
          else {
            if (d.responseType === 'json') { try { r.response = JSON.parse(r.responseText); } catch (e) { r.response = null; } }
            if (d.onreadystatechange) d.onreadystatechange(r);
            if (d.onload) d.onload(r);
          }
          if (d.onloadend) d.onloadend(r);
        }));
      return { abort: noop };
    };
    W.GM = {
      info: info,
      getValue: function (k, d) { return Promise.resolve(W.GM_getValue(k, d)); },
      setValue: function (k, v) { W.GM_setValue(k, v); return Promise.resolve(); },
      deleteValue: function (k) { W.GM_deleteValue(k); return Promise.resolve(); },
      listValues: function () { return Promise.resolve(W.GM_listValues()); },
      addStyle: W.GM_addStyle,
      openInTab: W.GM_openInTab,
      setClipboard: W.GM_setClipboard,
      registerMenuCommand: W.GM_registerMenuCommand,
      xmlHttpRequest: function (d) {
        return new Promise(function (res, rej) {
          var o = Object.assign({}, d);
          o.onload = function (r) { res(r); };
          o.onerror = function (r) { rej(r); };
          W.GM_xmlhttpRequest(o);
        });
      }
    };
    W.unsafeWindow = W;
  }
})();

"""#
}
