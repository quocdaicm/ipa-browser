import SwiftUI

/// Khi một file tải xong, chiếc xuồng (hoặc con tôm, xen kẽ) chạy ngang màn hình Tải xuống.
struct SailOverlay: View {
    @ObservedObject private var dl = DownloadManager.shared
    @State private var x: CGFloat = -60
    @State private var visible = false
    @State private var shrimp = true
    @State private var bob = false

    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .topLeading) {
                if visible {
                    VStack(spacing: -2) {
                        SVGIcon(name: shrimp ? "ic_shrimp" : "ic_boat", size: 30)
                            .foregroundStyle(Theme.accent)
                            .rotationEffect(.degrees(bob ? 7 : -7))
                        // vệt sóng sau lái
                        Capsule().fill(Theme.accent2.opacity(0.55)).frame(width: 34, height: 3)
                    }
                    .offset(x: x, y: 4)
                }
            }
            .frame(width: g.size.width, height: 48, alignment: .topLeading)
            .onChange(of: dl.doneTick) { _ in sail(width: g.size.width) }
        }
        .frame(height: 48)
    }

    private func sail(width: CGFloat) {
        shrimp.toggle()
        var t = Transaction(); t.disablesAnimations = true
        withTransaction(t) { x = -50; bob = false; visible = true }
        DispatchQueue.main.async {
            withAnimation(.linear(duration: 2.6)) { x = width + 40 }
            withAnimation(.easeInOut(duration: 0.35).repeatForever(autoreverses: true)) { bob = true }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.7) {
            var t2 = Transaction(); t2.disablesAnimations = true
            withTransaction(t2) { visible = false; bob = false }
        }
    }
}
