import Foundation
import WebKit

/// Nhận message từ shim chrome.* (storage, xhr) và trả kết quả về JS.
final class ExtBridge: NSObject, WKScriptMessageHandlerWithReply {
    let store: ExtStore

    init(store: ExtStore) {
        self.store = store
    }

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage,
                               replyHandler: @escaping (Any?, String?) -> Void) {
        guard let body = message.body as? [String: Any],
              let id = body["ext"] as? String,
              let type = body["type"] as? String else {
            replyHandler(nil, "bad message")
            return
        }
        let p = body["payload"] as? [String: Any] ?? [:]
        let role = body["role"] as? String ?? "content"
        if type == "xhr" {
            xhr(p, replyHandler)
            return
        }
        Task { @MainActor in
            let r = await ExtRuntime.shared.handle(extId: id, type: type, payload: p, role: role)
            replyHandler(r, nil)
        }
    }

    /// GM_xmlhttpRequest: gọi mạng bằng URLSession nên không bị CORS của trang.
    private func xhr(_ p: [String: Any], _ reply: @escaping (Any?, String?) -> Void) {
        guard let s = p["url"] as? String, let url = URL(string: s) else {
            reply(["error": "bad url", "status": 0], nil)
            return
        }
        var req = URLRequest(url: url)
        req.httpMethod = (p["method"] as? String) ?? "GET"
        for (k, v) in (p["headers"] as? [String: Any] ?? [:]) {
            req.setValue("\(v)", forHTTPHeaderField: k)
        }
        if let d = p["data"] as? String { req.httpBody = Data(d.utf8) }

        URLSession.shared.dataTask(with: req) { data, resp, err in
            let out: [String: Any]
            if let err = err {
                out = ["error": err.localizedDescription, "status": 0, "readyState": 4]
            } else {
                let h = resp as? HTTPURLResponse
                let text = String(decoding: data ?? Data(), as: UTF8.self)
                let headers = (h?.allHeaderFields ?? [:])
                    .map { "\($0.key): \($0.value)" }
                    .joined(separator: "\r\n")
                out = [
                    "status": h?.statusCode ?? 0,
                    "statusText": "",
                    "responseText": text,
                    "response": text,
                    "responseHeaders": headers,
                    "finalUrl": resp?.url?.absoluteString ?? s,
                    "readyState": 4
                ]
            }
            DispatchQueue.main.async { reply(out, nil) }
        }.resume()
    }
}

/// Phục vụ file extension qua địa chỉ ext://<id>/<path> (popup, ảnh, getURL).
final class ExtSchemeHandler: NSObject, WKURLSchemeHandler {
    let store: ExtStore

    init(store: ExtStore) {
        self.store = store
    }

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url, let id = url.host else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }
        var path = url.path
        if path.hasPrefix("/") { path.removeFirst() }
        let generated: Data? = (path == "__bg__.html") ? store.backgroundHTML(id: id) : nil
        guard let data = generated ?? store.readFile(id: id, path: path) else {
            urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist))
            return
        }
        let headers = [
            "Content-Type": mime(path),
            "Content-Length": "\(data.count)",
            "Access-Control-Allow-Origin": "*"
        ]
        let resp = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: headers)!
        urlSchemeTask.didReceive(resp)
        urlSchemeTask.didReceive(data)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

    private func mime(_ path: String) -> String {
        switch (path as NSString).pathExtension.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json": return "application/json"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "gif": return "image/gif"
        case "svg": return "image/svg+xml"
        case "webp": return "image/webp"
        case "woff": return "font/woff"
        case "woff2": return "font/woff2"
        case "ttf": return "font/ttf"
        default: return "application/octet-stream"
        }
    }
}
