import SwiftUI
import WebKit
import Combine

@MainActor
final class Tab: ObservableObject, Identifiable {
    let id = UUID()
    let webView: WKWebView
    let isPrivate: Bool
    @Published var title = ""
    @Published var url: URL?
    @Published var thumb: UIImage?
    @Published var videos: [DetectedVideo] = []
    var desktop = false
    @Published var groupID: UUID?
    @Published var translated = false
    var translateOrigin: URL?
    var reader = false
    var readerPending = false
    var readerURL: URL?
    var observers: [NSKeyValueObservation] = []

    init(webView: WKWebView, isPrivate: Bool = false) {
        self.webView = webView
        self.isPrivate = isPrivate
    }
}

@MainActor
final class BrowserModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published var currentURL: URL?
    @Published var pageTitle = ""
    @Published var progress: Double = 0
    @Published var isLoading = false
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published private(set) var desktopMode = false
    @Published private(set) var isPrivate = false
    /// Ẩn thanh địa chỉ + thanh công cụ khi cuộn xuống.
    @Published private(set) var chromeHidden = false
    /// Chế độ toàn màn hình (chơi web game): ẩn thanh địa chỉ/công cụ, ẩn thanh trạng thái, xoay ngang.
    @Published private(set) var fullscreen = false
    /// Video đang mở bằng trình phát gốc của app (khi trang bấm toàn màn hình).
    @Published var nativePlay: VideoSheet.PlayerItem?

    @Published private(set) var tabs: [Tab] = []
    @Published private(set) var activeID: UUID?
    /// Nhóm tab (chỉ cho tab thường).
    @Published var groups: [TabGroup] = []
    /// Gợi ý dịch trang (mã ngôn ngữ trang) – nil khi không có.
    @Published var translateOffer: String?
    /// Tab đang xem đang ở chế độ đọc.
    @Published private(set) var readerOn = false

    let store: ExtStore
    let bridge: ExtBridge
    let scheme: ExtSchemeHandler

    /// Webview của tab đang xem (các phần khác của app dùng như trước).
    var webView: WKWebView { activeTab.webView }

    var activeTab: Tab {
        tabs.first(where: { $0.id == activeID }) ?? tabs[0]
    }

    /// Gọi khi người dùng bấm link .user.js (kiểu Greasy Fork) để cài thay vì mở trang.
    var onInstallLink: ((URL) -> Void)?
    /// Hiện thông báo nổi ngắn.
    var onNotice: ((String) -> Void)?
    let readerBridge = ReaderBridge()
    var offeredHosts = Set<String>()

    private let ucc = WKUserContentController()   // dùng chung cho mọi tab
    private let fsBridge = FullscreenBridge()      // nhận requestFullscreen() từ trang web
    private let videoBridge = VideoBridge()        // nhận video dò được từ trang
    private var worlds: [WKContentWorld] = []
    private var currentItems: [InstalledExtension] = []
    private var didLoadHome = false
    let settings = BrowserSettings.shared
    private var bag = Set<AnyCancellable>()
    private var privateStore: WKWebsiteDataStore?   // dùng chung cho các tab riêng tư, bỏ khi đóng hết
    private var lastNewTab = Date.distantPast      // chống mở tab dồn dập
    private var httpAllowed = Set<String>()   // host HTTP đã được người dùng cho phép trong phiên này
    private var homeURL: String { settings.homeURLString }
    private var lastY: CGFloat = 0
    private var suppressUntil = Date.distantPast

    override init() {
        let s = ExtStore.shared
        self.store = s
        self.scheme = ExtSchemeHandler(store: s)
        self.bridge = ExtBridge(store: s)
        super.init()
        ExtRuntime.shared.browser = self

        settings.objectWillChange
            .sink { [weak self] _ in
                Task { @MainActor in self?.settingsChanged() }
            }
            .store(in: &bag)

        let nc = NotificationCenter.default
        for (name, on) in [(UIApplication.willResignActiveNotification, true),
                           (UIApplication.didEnterBackgroundNotification, true),
                           (UIApplication.didBecomeActiveNotification, false)] {
            nc.publisher(for: name)
                .sink { [weak self] _ in Task { @MainActor in self?.backgroundMedia(on) } }
                .store(in: &bag)
        }

        fsBridge.onToggle = { [weak self] on in self?.setFullscreen(on) }
        ucc.add(fsBridge, name: "xbFS")
        videoBridge.onVideo = { [weak self] w, body in self?.videoFound(w, body) }
        ucc.add(videoBridge, name: "xbVideo")
        readerBridge.onMessage = { [weak self] w, b in self?.readerMessage(w, b) }
        ucc.add(readerBridge, name: "xbReader")

        addTab(request: nil, load: false)
    }

    // MARK: Tabs

    private func makeWebView(isPrivate: Bool) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        if isPrivate {
            if privateStore == nil { privateStore = WKWebsiteDataStore.nonPersistent() }
            cfg.websiteDataStore = privateStore!
        }
        cfg.userContentController = ucc
        cfg.setURLSchemeHandler(scheme, forURLScheme: "ext")
        cfg.allowsInlineMediaPlayback = true
        cfg.allowsPictureInPictureMediaPlayback = true
        cfg.preferences.javaScriptCanOpenWindowsAutomatically = !settings.popupBlock
        let w = WKWebView(frame: .zero, configuration: cfg)
        w.navigationDelegate = self
        w.uiDelegate = self
        w.allowsBackForwardNavigationGestures = true
        w.isFindInteractionEnabled = true
        w.underPageBackgroundColor = settings.darkPages ? .black : .systemBackground
        w.scrollView.refreshControl = makeRefresh()
        applyFullscreen(to: w)
        return w
    }

    private func makeRefresh() -> UIRefreshControl {
        let rc = UIRefreshControl()
        rc.addTarget(self, action: #selector(pullRefresh), for: .valueChanged)
        return rc
    }

    // MARK: Toàn màn hình

    /// Báo cho trang biết app vào/ra nền để bật lại nhạc/video bị hệ thống tạm dừng.
    private func backgroundMedia(_ on: Bool) {
        guard settings.bgPlay else { return }
        for t in tabs {
            t.webView.evaluateJavaScript("window.__xbBG&&window.__xbBG(\(on))", completionHandler: nil)
        }
    }

    func toggleFullscreen() { setFullscreen(!fullscreen) }

    func setFullscreen(_ on: Bool) {
        guard fullscreen != on else { return }
        fullscreen = on
        chromeHidden = false
        for t in tabs {
            applyFullscreen(to: t.webView)
            pushFullscreen(to: t.webView)
        }
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        let mask: UIInterfaceOrientationMask
        if settings.fsLandscape {
            mask = on ? .landscape : .portrait
        } else {
            mask = .allButUpsideDown
        }
        scene?.windows.first?.rootViewController?.setNeedsUpdateOfSupportedInterfaceOrientations()
        scene?.requestGeometryUpdate(.iOS(interfaceOrientations: mask)) { _ in }
    }

    /// Tắt các cử chỉ dễ vướng khi chơi game (vuốt cạnh = quay lại, kéo tải lại, nảy trang, pinch).
    private func applyFullscreen(to w: WKWebView) {
        let on = fullscreen
        let sv = w.scrollView
        w.allowsBackForwardNavigationGestures = !on
        if on { sv.refreshControl = nil } else if sv.refreshControl == nil { sv.refreshControl = makeRefresh() }
        sv.bounces = !on
        sv.showsVerticalScrollIndicator = !on
        sv.showsHorizontalScrollIndicator = !on
        sv.contentInsetAdjustmentBehavior = on ? .never : .automatic
        sv.pinchGestureRecognizer?.isEnabled = !(on && settings.gameHelper)
    }

    private func pushFullscreen(to w: WKWebView) {
        w.evaluateJavaScript("window.__xbFSState&&window.__xbFSState(\(fullscreen))", completionHandler: nil)
    }

    /// Mở tab mới. `request` nil = trang chủ. `load` false = chưa tải gì (dùng lúc khởi động).
    @discardableResult
    func addTab(request: URLRequest?, load: Bool = true, isPrivate: Bool = false,
                activate: Bool = true, group: UUID? = nil) -> Tab {
        let w = makeWebView(isPrivate: isPrivate)
        let tab = Tab(webView: w, isPrivate: isPrivate)
        tab.groupID = isPrivate ? nil : group
        tab.observers = [
            w.observe(\.url) { [weak self, weak tab] _, _ in Task { @MainActor in self?.sync(tab) } },
            w.observe(\.title) { [weak self, weak tab] _, _ in Task { @MainActor in self?.sync(tab) } },
            w.observe(\.estimatedProgress) { [weak self, weak tab] _, _ in Task { @MainActor in self?.sync(tab) } },
            w.observe(\.isLoading) { [weak self, weak tab] _, _ in Task { @MainActor in self?.sync(tab) } },
            w.observe(\.canGoBack) { [weak self, weak tab] _, _ in Task { @MainActor in self?.sync(tab) } },
            w.observe(\.canGoForward) { [weak self, weak tab] _, _ in Task { @MainActor in self?.sync(tab) } },
            w.scrollView.observe(\.contentOffset) { [weak self, weak tab] sv, _ in
                let y = sv.contentOffset.y
                Task { @MainActor in self?.scrolled(tab, y) }
            }
        ]
        if load && activate { captureActiveThumb() }
        tabs.append(tab)
        if activate { activeID = tab.id }
        sync(tab)
        if load {
            if let r = request {
                w.load(r)
            } else if let u = URL(string: homeURL) {
                w.load(URLRequest(url: u))
            }
        }
        return tab
    }

    /// Chụp ảnh xem trước của tab để hiện trong màn hình “Các thẻ”.
    func captureThumb(_ tab: Tab?, done: (() -> Void)? = nil) {
        guard let tab = tab else { done?(); return }
        let cfg = WKSnapshotConfiguration()
        cfg.snapshotWidth = 360
        tab.webView.takeSnapshot(with: cfg) { img, _ in
            Task { @MainActor in
                if let img = img { tab.thumb = img }
                done?()
            }
        }
    }

    func captureActiveThumb(done: (() -> Void)? = nil) {
        captureThumb(tabs.first(where: { $0.id == activeID }), done: done)
    }

    /// Nhận video do script dò được và gắn vào tab tương ứng.
    private func videoFound(_ w: WKWebView?, _ b: [String: Any]) {
        guard settings.videoTool, let w = w,
              let tab = tabs.first(where: { $0.webView === w }),
              let us = b["url"] as? String, let u = URL(string: us) else { return }
        let kind = (b["kind"] as? String) ?? "file"
        let width = (b["w"] as? Int) ?? Int((b["w"] as? Double) ?? 0)
        let height = (b["h"] as? Int) ?? Int((b["h"] as? Double) ?? 0)
        let dur = (b["d"] as? Double) ?? 0
        let wantsPlay = (b["play"] as? Bool) ?? false
        let start = (b["t"] as? Double) ?? 0
        if let i = tab.videos.firstIndex(where: { $0.url == u }) {
            var v = tab.videos[i]
            if width > 0 { v.width = width; v.height = height }
            if dur > 0 { v.duration = dur }
            if v != tab.videos[i] { tab.videos[i] = v }
            if wantsPlay { playNative(tab, v, start: start) }
            return
        }
        guard tab.videos.count < 30 || wantsPlay else { return }
        var v = DetectedVideo(url: u, kind: kind,
                              title: (b["title"] as? String) ?? "",
                              page: (b["page"] as? String) ?? "")
        v.width = width; v.height = height; v.duration = dur
        if tab.videos.count < 30 { tab.videos.append(v) }
        if wantsPlay { playNative(tab, v, start: start) }
    }

    /// Trang bấm toàn màn hình trên video có link trực tiếp → mở trình phát gốc của iOS.
    private func playNative(_ tab: Tab, _ v: DetectedVideo, start: Double) {
        Task { @MainActor in
            var c = VideoContext()
            c.cookies = await tab.webView.configuration.websiteDataStore.httpCookieStore.allCookies()
            if let ua = try? await tab.webView.evaluateJavaScript("navigator.userAgent") as? String, !ua.isEmpty {
                c.userAgent = ua
            }
            nativePlay = VideoSheet.PlayerItem(video: v, context: c, start: start)
        }
    }

    func newTab() { addTab(request: nil) }

    func newPrivateTab() { addTab(request: nil, isPrivate: true) }

    /// Mở thanh “Tìm trong trang” của iOS cho tab đang xem.
    func findInPage() {
        webView.findInteraction?.presentFindNavigator(showingReplace: false)
    }

    func select(_ id: UUID) {
        guard let t = tabs.first(where: { $0.id == id }) else { return }
        if id != activeID { captureActiveThumb() }
        activeID = id
        chromeHidden = false
        lastY = t.webView.scrollView.contentOffset.y
        applyFullscreen(to: t.webView)
        sync(t)
    }

    @objc private func pullRefresh() {
        webView.reload()
    }

    private func setChrome(hidden: Bool) {
        guard chromeHidden != hidden else { return }
        chromeHidden = hidden
        suppressUntil = Date().addingTimeInterval(0.6)   // bỏ qua cuộn giả do đổi kích thước
    }

    private func scrolled(_ tab: Tab?, _ y: CGFloat) {
        guard let tab = tab, tab.id == activeID else { return }
        let dy = y - lastY
        lastY = y
        if Date() < suppressUntil { return }
        if y <= 0 { setChrome(hidden: false); return }
        guard abs(dy) > 6 else { return }
        let sv = tab.webView.scrollView
        if y + sv.bounds.height > sv.contentSize.height { return }   // bỏ qua nảy ở đáy
        setChrome(hidden: dy > 0)
    }

    func close(_ id: UUID) {
        guard let idx = tabs.firstIndex(where: { $0.id == id }) else { return }
        let t = tabs[idx]
        t.webView.stopLoading()
        t.observers.removeAll()
        t.webView.navigationDelegate = nil
        t.webView.uiDelegate = nil
        tabs.remove(at: idx)
        if !tabs.contains(where: { $0.isPrivate }) { privateStore = nil }
        if tabs.isEmpty {
            addTab(request: nil)
        } else if activeID == id {
            select(tabs[min(idx, tabs.count - 1)].id)
        }
    }

    func sync(_ tab: Tab?) {
        guard let tab = tab else { return }
        let w = tab.webView
        tab.url = w.url
        tab.title = w.title ?? ""
        guard tab.id == activeID else { return }
        currentURL = w.url
        pageTitle = w.title ?? ""
        progress = w.estimatedProgress
        isLoading = w.isLoading
        canGoBack = w.canGoBack
        canGoForward = w.canGoForward
        desktopMode = tab.desktop
        isPrivate = tab.isPrivate
        readerOn = tab.reader
    }

    /// Bật/tắt xem bản máy tính cho tab đang xem rồi tải lại.
    func toggleDesktop() {
        let t = activeTab
        t.desktop.toggle()
        desktopMode = t.desktop
        t.webView.reload()
    }

    // MARK: Extensions

    /// Dựng lại toàn bộ script từ danh sách extension đang bật.
    func applyExtensions(_ items: [InstalledExtension]) {
        currentItems = items
        reinstallScripts()

        ExtRuntime.shared.sync(items)

        Task { @MainActor in
            await self.rebuildRules()
            if !self.didLoadHome {
                self.didLoadHome = true
                self.go(self.homeURL)
            } else {
                self.webView.reload()
            }
        }
    }

    /// Dựng lại user script: script dựng sẵn (chặn popup, video) + script của extension.
    private func reinstallScripts() {
        ucc.removeAllUserScripts()
        for w in worlds { ucc.removeAllScriptMessageHandlers(from: w) }
        worlds.removeAll()

        ucc.addUserScript(WKUserScript(source: BuiltinScript.source(settings),
                                       injectionTime: .atDocumentStart,
                                       forMainFrameOnly: false,
                                       in: .page))
        ucc.addUserScript(WKUserScript(source: VideoSniffer.source,
                                       injectionTime: .atDocumentStart,
                                       forMainFrameOnly: false,
                                       in: .page))

        for item in currentItems where item.enabled {
            let world = WKContentWorld.world(name: item.id)
            worlds.append(world)
            ucc.addScriptMessageHandler(bridge, contentWorld: world, name: "extBridge")
            for s in ScriptBuilder.scripts(for: item, store: store) {
                ucc.addUserScript(WKUserScript(source: s.source,
                                               injectionTime: s.time,
                                               forMainFrameOnly: s.mainOnly,
                                               in: s.page ? WKContentWorld.page : world))
            }
        }
    }

    private func settingsChanged() {
        reinstallScripts()
        for t in tabs {
            t.webView.configuration.preferences.javaScriptCanOpenWindowsAutomatically = !settings.popupBlock
            t.webView.evaluateJavaScript(BuiltinScript.flagsJS(settings), completionHandler: nil)
            t.webView.underPageBackgroundColor = settings.darkPages ? .black : .systemBackground
        }
        Task { @MainActor in await self.rebuildRules() }
    }

    /// Biên dịch luật chặn (declarativeNetRequest) của các extension đang bật.
    func rebuildRules() async {
        let lists = await DNR.lists(for: currentItems, store: store)
        ucc.removeAllContentRuleLists()
        if settings.adBlock, let ad = await AdBlock.list(allow: settings.adAllowSites) { ucc.add(ad) }
        for l in lists { ucc.add(l) }
    }

    // MARK: Navigation

    func go(_ text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        var url: URL?
        if t.contains("://"), let u = URL(string: t) {
            url = u
        } else if !t.contains(" "), t.contains("."), let u = URL(string: "https://" + t) {
            url = u
        } else {
            var c = URLComponents(string: settings.searchBase)!
            c.queryItems = [URLQueryItem(name: "q", value: t)]
            url = c.url
        }
        if let url = url { webView.load(URLRequest(url: url)) }
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 preferences: WKWebpagePreferences,
                 decisionHandler handler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
        let isDesktop = tabs.first(where: { $0.webView === webView })?.desktop ?? false
        preferences.preferredContentMode = isDesktop ? .desktop : .recommended
        let decisionHandler: (WKNavigationActionPolicy) -> Void = { handler($0, preferences) }
        if let u = navigationAction.request.url,
           u.path.hasSuffix(".user.js"),
           navigationAction.targetFrame?.isMainFrame ?? true {
            decisionHandler(.cancel)
            onInstallLink?(u)
            return
        }
        if navigationAction.shouldPerformDownload {
            decisionHandler(.download)
            return
        }
        if let u = navigationAction.request.url {
            let scheme = (u.scheme ?? "").lowercased()
            let userTap = navigationAction.navigationType == .linkActivated

            // Chặn điều hướng tới máy chủ quảng cáo khi không phải do người dùng bấm
            if settings.adBlockActive(for: webView.url?.host), !userTap, AdBlock.isAdHost(u.host) {
                decisionHandler(.cancel)
                return
            }
            // Quảng cáo nằm trong khung (iframe) tự đẩy cả trang sang chỗ khác
            if settings.popupBlock,
               navigationAction.targetFrame?.isMainFrame ?? false,
               navigationAction.navigationType != .reload,
               navigationAction.navigationType != .backForward,
               let src = navigationAction.value(forKey: "sourceFrame") as? WKFrameInfo,
               !src.isMainFrame,
               let cur = webView.url?.host,
               Self.siteKey(src.securityOrigin.host) != Self.siteKey(cur),
               Self.siteKey(u.host) != Self.siteKey(cur) {
                decisionHandler(.cancel)
                return
            }
            // Chặn tự nhảy sang app khác / scheme lạ (itms-apps, intent...)
            if settings.popupBlock,
               !["http", "https", "about", "data", "blob", "file", "ext", "javascript"].contains(scheme) {
                if userTap, ["tel", "mailto", "sms"].contains(scheme) {
                    UIApplication.shared.open(u)
                }
                decisionHandler(.cancel)
                return
            }
        }
        // Cảnh báo trang HTTP không mã hoá (bỏ qua mạng nội bộ)
        if let u = navigationAction.request.url,
           (u.scheme ?? "").lowercased() == "http",
           navigationAction.targetFrame?.isMainFrame ?? true,
           let host = u.host?.lowercased(),
           !Self.isLocalHost(host),
           !httpAllowed.contains(host) {
            let a = UIAlertController(
                title: "Trang không mã hoá",
                message: "\(host) dùng HTTP, thông tin bạn nhập có thể bị người khác đọc được. Vẫn tiếp tục?",
                preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in decisionHandler(.cancel) })
            a.addAction(UIAlertAction(title: "Tiếp tục", style: .default) { [weak self] _ in
                self?.httpAllowed.insert(host)
                decisionHandler(.allow)
            })
            if !present(a) { decisionHandler(.allow) }
            return
        }
        decisionHandler(.allow)
    }

    /// Tên miền gốc (xấp xỉ): a.b.example.com -> example.com, x.com.vn -> x.com.vn
    static func siteKey(_ host: String?) -> String {
        guard let h = host?.lowercased(), !h.isEmpty else { return "" }
        let p = h.split(separator: ".").map(String.init)
        if p.count <= 2 { return h }
        let sld: Set<String> = ["co", "com", "net", "org", "gov", "edu", "ac"]
        if sld.contains(p[p.count - 2]), p[p.count - 1].count == 2 {
            return p.suffix(3).joined(separator: ".")
        }
        return p.suffix(2).joined(separator: ".")
    }

    private static func isLocalHost(_ h: String) -> Bool {
        if h == "localhost" || h.hasSuffix(".local") { return true }
        if h.hasPrefix("127.") || h.hasPrefix("10.") || h.hasPrefix("192.168.") { return true }
        if h.hasPrefix("172."), let second = h.split(separator: ".").dropFirst().first,
           let n = Int(second), (16...31).contains(n) { return true }
        return false
    }

    // Tải file: Content-Disposition: attachment hoặc loại file trình duyệt không hiển thị được
    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        guard navigationResponse.isForMainFrame else {
            decisionHandler(.allow)
            return
        }
        if let http = navigationResponse.response as? HTTPURLResponse,
           let cd = http.value(forHTTPHeaderField: "Content-Disposition"),
           cd.lowercased().hasPrefix("attachment") {
            decisionHandler(.download)
            return
        }
        decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
    }

    func webView(_ webView: WKWebView,
                 navigationAction: WKNavigationAction,
                 didBecome download: WKDownload) {
        DownloadManager.shared.attach(download)
    }

    func webView(_ webView: WKWebView,
                 navigationResponse: WKNavigationResponse,
                 didBecome download: WKDownload) {
        DownloadManager.shared.attach(download)
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        tabs.first(where: { $0.webView === webView })?.videos = []
        if webView === self.webView { chromeHidden = false; translateOffer = nil }
        guard webView === self.webView else { return }
        ExtRuntime.shared.pageEvent(status: "loading", url: webView.url)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        webView.scrollView.refreshControl?.endRefreshing()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        webView.scrollView.refreshControl?.endRefreshing()
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        webView.scrollView.refreshControl?.endRefreshing()
        if let u = webView.url,
           !(tabs.first(where: { $0.webView === webView })?.isPrivate ?? false),
           !(tabs.first(where: { $0.webView === webView })?.reader ?? false) {
            LibraryStore.shared.recordVisit(url: u, title: webView.title ?? "")
        }
        if fullscreen { pushFullscreen(to: webView) }
        if let t = tabs.first(where: { $0.webView === webView }) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self, weak t] in self?.captureThumb(t) }
        }
        guard webView === self.webView else { return }
        ExtRuntime.shared.pageEvent(status: "complete", url: webView.url)
        checkTranslateOffer(webView)
    }

    // target=_blank / window.open do người dùng bấm -> mở tab mới
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        // Chỉ mở khi người dùng thật sự bấm link; popup/popunder do script tự gọi sẽ bị bỏ
        guard navigationAction.targetFrame == nil else { return nil }
        if settings.popupBlock {
            let userTap = navigationAction.navigationType == .linkActivated
            let host = navigationAction.request.url?.host
            if !userTap || (settings.adBlockActive(for: webView.url?.host) && AdBlock.isAdHost(host)) { return nil }
            // Link bấm trong khung quảng cáo của trang khác
            if let src = navigationAction.value(forKey: "sourceFrame") as? WKFrameInfo,
               !src.isMainFrame,
               let cur = webView.url?.host,
               Self.siteKey(src.securityOrigin.host) != Self.siteKey(cur) { return nil }
            // Tối đa 1 tab mới mỗi 1,2 giây
            let now = Date()
            if now.timeIntervalSince(lastNewTab) < 1.2 { return nil }
            lastNewTab = now
        }
        let source = tabs.first(where: { $0.webView === webView })
        addTab(request: navigationAction.request, isPrivate: source?.isPrivate ?? false, group: source?.groupID)
        return nil
    }

    // MARK: JS dialogs

    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        if !present(a) { completionHandler() }
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        if !present(a) { completionHandler(false) }
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        let a = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        a.addTextField { $0.text = defaultText }
        a.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(nil) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            completionHandler(a.textFields?.first?.text)
        })
        if !present(a) { completionHandler(nil) }
    }

    // Camera / micro cho trang web: để iOS hỏi người dùng
    func webView(_ webView: WKWebView,
                 requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo,
                 type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.prompt)
    }

    func present(_ alert: UIAlertController) -> Bool {
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
        while let p = top?.presentedViewController { top = p }
        guard let vc = top else { return false }
        vc.present(alert, animated: true)
        return true
    }
}

/// Nhận lời gọi `requestFullscreen()` / `exitFullscreen()` từ trang web (qua script dựng sẵn).
final class FullscreenBridge: NSObject, WKScriptMessageHandler {
    var onToggle: (@MainActor (Bool) -> Void)?

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        let on = (message.body as? Bool) ?? false
        Task { @MainActor in self.onToggle?(on) }
    }
}
