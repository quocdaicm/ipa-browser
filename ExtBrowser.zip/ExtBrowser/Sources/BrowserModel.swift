import SwiftUI
import WebKit

@MainActor
final class BrowserModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published var currentURL: URL?
    @Published var pageTitle = ""
    @Published var progress: Double = 0
    @Published var isLoading = false
    @Published var canGoBack = false
    @Published var canGoForward = false

    let store: ExtStore
    let bridge: ExtBridge
    let scheme: ExtSchemeHandler
    let webView: WKWebView

    /// Gọi khi người dùng bấm link .user.js (kiểu Greasy Fork) để cài thay vì mở trang.
    var onInstallLink: ((URL) -> Void)?

    private var worlds: [WKContentWorld] = []
    private var currentItems: [InstalledExtension] = []
    private var observers: [NSKeyValueObservation] = []
    private var didLoadHome = false

    override init() {
        let s = ExtStore.shared
        let sch = ExtSchemeHandler(store: s)
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(sch, forURLScheme: "ext")
        cfg.allowsInlineMediaPlayback = true
        cfg.preferences.javaScriptCanOpenWindowsAutomatically = true
        self.store = s
        self.scheme = sch
        self.bridge = ExtBridge(store: s)
        self.webView = WKWebView(frame: .zero, configuration: cfg)
        super.init()
        ExtRuntime.shared.browser = self
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true

        observers = [
            webView.observe(\.url) { [weak self] w, _ in
                let v = w.url
                Task { @MainActor in self?.currentURL = v }
            },
            webView.observe(\.title) { [weak self] w, _ in
                let v = w.title ?? ""
                Task { @MainActor in self?.pageTitle = v }
            },
            webView.observe(\.estimatedProgress) { [weak self] w, _ in
                let v = w.estimatedProgress
                Task { @MainActor in self?.progress = v }
            },
            webView.observe(\.isLoading) { [weak self] w, _ in
                let v = w.isLoading
                Task { @MainActor in self?.isLoading = v }
            },
            webView.observe(\.canGoBack) { [weak self] w, _ in
                let v = w.canGoBack
                Task { @MainActor in self?.canGoBack = v }
            },
            webView.observe(\.canGoForward) { [weak self] w, _ in
                let v = w.canGoForward
                Task { @MainActor in self?.canGoForward = v }
            }
        ]
    }

    // MARK: Extensions

    /// Dựng lại toàn bộ script từ danh sách extension đang bật.
    func applyExtensions(_ items: [InstalledExtension]) {
        currentItems = items
        let ucc = webView.configuration.userContentController
        ucc.removeAllUserScripts()
        for w in worlds { ucc.removeAllScriptMessageHandlers(from: w) }
        worlds.removeAll()

        for item in items where item.enabled {
            let world = WKContentWorld.world(name: item.id)
            worlds.append(world)
            ucc.addScriptMessageHandler(bridge, contentWorld: world, name: "extBridge")
            for s in ScriptBuilder.scripts(for: item, store: store) {
                ucc.addUserScript(WKUserScript(source: s.source,
                                               injectionTime: s.time,
                                               forMainFrameOnly: s.mainOnly,
                                               in: s.page ? WKContentWorld.page : world))
            }
        }

        ExtRuntime.shared.sync(items)

        Task { @MainActor in
            await self.rebuildRules()
            if !self.didLoadHome {
                self.didLoadHome = true
                self.go("https://www.google.com")
            } else {
                self.webView.reload()
            }
        }
    }

    /// Biên dịch luật chặn (declarativeNetRequest) của các extension đang bật.
    func rebuildRules() async {
        let lists = await DNR.lists(for: currentItems, store: store)
        let ucc = webView.configuration.userContentController
        ucc.removeAllContentRuleLists()
        for l in lists { ucc.add(l) }
    }

    // MARK: Navigation

    func go(_ text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        var url: URL?
        if t.contains("://"), let u = URL(string: t) {
            url = u
        } else if !t.contains(" "), t.contains("."), let u = URL(string: "https://" + t) {
            url = u
        } else {
            var c = URLComponents(string: "https://www.google.com/search")!
            c.queryItems = [URLQueryItem(name: "q", value: t)]
            url = c.url
        }
        if let url = url { webView.load(URLRequest(url: url)) }
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let u = navigationAction.request.url,
           u.path.hasSuffix(".user.js"),
           navigationAction.targetFrame?.isMainFrame ?? true {
            decisionHandler(.cancel)
            onInstallLink?(u)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        ExtRuntime.shared.pageEvent(status: "loading", url: webView.url)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        ExtRuntime.shared.pageEvent(status: "complete", url: webView.url)
    }

    // target=_blank -> mở ngay trong tab hiện tại
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }

    // MARK: JS dialogs

    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        if !present(a) { completionHandler() }
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        if !present(a) { completionHandler(false) }
    }

    private func present(_ alert: UIAlertController) -> Bool {
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        var top = scene?.windows.first(where: { $0.isKeyWindow })?.rootViewController
        while let p = top?.presentedViewController { top = p }
        guard let vc = top else { return false }
        vc.present(alert, animated: true)
        return true
    }
}
