import SwiftUI

/// Chọn chủ đề màu: Lagoon (mặc định) hoặc Cà Mau (rừng đước – đất mũi).
struct PalettePicker: View {
    @Binding var selection: Int

    var body: some View {
        VStack(spacing: 14) {
            HStack(spacing: 12) {
                card(tag: 0, title: "Lagoon", icon: "ic_drop") {
                    LinearGradient(colors: [Color(hex: 0x0A8F9E), Color(hex: 0x12A06A)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                        .overlay(SVGIcon(name: "ic_drop", size: 30).foregroundStyle(.white.opacity(0.95)))
                }
                card(tag: 1, title: "Cà Mau", icon: "ic_leaf") {
                    Image("camau_banner").resizable().scaledToFill()
                }
            }
            if selection == 1 { CaMauBanner() }
        }
        .padding(14)
    }

    private func card<P: View>(tag: Int, title: String, icon: String, @ViewBuilder preview: () -> P) -> some View {
        let on = selection == tag
        return Button {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { selection = tag }
        } label: {
            VStack(spacing: 8) {
                preview()
                    .frame(height: 84).frame(maxWidth: .infinity)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .strokeBorder(on ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Color.clear), lineWidth: 2.5)
                    }
                    .shadow(color: on ? Theme.accent.opacity(0.35) : .black.opacity(0.10), radius: on ? 8 : 4, y: 3)
                HStack(spacing: 5) {
                    SVGIcon(name: icon, size: 14)
                    Text(title).font(.system(size: 13, weight: on ? .bold : .medium, design: .rounded))
                }
                .foregroundStyle(on ? Theme.accent : Color.secondary)
            }
        }
        .buttonStyle(PressStyle())
        .accessibilityLabel(title)
    }
}

/// Dải tranh Cà Mau (rừng đước, xuồng trên sông) — đổi tranh ngày/đêm theo giao diện.
struct CaMauBanner: View {
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Image("camau_banner").resizable().scaledToFill()
                .frame(height: 140).frame(maxWidth: .infinity).clipped()
            LinearGradient(colors: [.clear, .black.opacity(0.55)], startPoint: .center, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 2) {
                Text("CÀ MAU").font(.system(size: 22, weight: .heavy, design: .rounded)).tracking(2)
                Text("Đất Mũi · Rừng đước · Đom đóm · Xuồng ba lá").font(.system(size: 12, weight: .medium, design: .rounded)).opacity(0.92)
            }
            .foregroundStyle(.white)
            .shadow(color: .black.opacity(0.4), radius: 3, y: 1)
            .padding(14)
        }
        .frame(height: 140)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .transition(.opacity.combined(with: .scale(scale: 0.96)))
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xFF) / 255, green: Double((hex >> 8) & 0xFF) / 255, blue: Double(hex & 0xFF) / 255)
    }
}
