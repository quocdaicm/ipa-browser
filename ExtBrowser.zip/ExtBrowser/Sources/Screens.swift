import SwiftUI
import AVFoundation
import WebKit
import UniformTypeIdentifiers

private func hostLetter(_ s: String) -> String {
    let h = (URL(string: s)?.host ?? s).replacingOccurrences(of: "www.", with: "")
    return h.isEmpty ? "•" : String(h.prefix(1)).uppercased()
}

// MARK: - Cài đặt

struct SettingsView: View {
    @ObservedObject private var settings = BrowserSettings.shared
    @ObservedObject private var lock = AppLock.shared
    @ObservedObject private var libLock = LibraryLock.shared
    @Environment(\.dismiss) private var dismiss
    @State private var pwFlow: PasswordFlow?
    @State private var message = ""

    var body: some View {
        SheetScaffold(title: "Cài đặt", subtitle: "Tuỳ chỉnh trình duyệt của bạn", onClose: { dismiss() }) {
            ThemedScroll {
                SectionCard(title: "Tìm kiếm & trang chủ") {
                    SettingRow(asset: "ic_search", title: "Công cụ tìm kiếm") {
                        Picker("", selection: $settings.searchEngine) {
                            Text("Google").tag("google")
                            Text("DuckDuckGo").tag("duckduckgo")
                            Text("Bing").tag("bing")
                        }
                        .pickerStyle(.menu)
                        .tint(Theme.accent)
                    }
                    RowDivider()
                    HStack(spacing: 12) {
                        IconChip(sf: "house.fill", color: Theme.accent2)
                        TextField("https://www.google.com", text: $settings.homepage)
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .lineLimit(1)
                            .frame(maxWidth: .infinity)
                            .fieldStyle()
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 11)
                }

                SectionCard(title: "Bảo mật",
                            footer: "Khi bật, app yêu cầu mật khẩu 6 ký tự mỗi lần mở và che nội dung trong màn hình đa nhiệm.") {
                    ToggleRow(asset: "ic_lock", color: Theme.success,
                              title: "Khoá ứng dụng bằng mật khẩu",
                              isOn: Binding(get: { lock.enabled },
                                            set: { pwFlow = $0 ? .set : .disable }))
                    if lock.enabled {
                        RowDivider()
                        Button { pwFlow = .change } label: {
                            SettingRow(sf: "key.fill", color: Theme.warn, title: "Đổi mật khẩu") { Chevron() }
                        }
                        .buttonStyle(PressStyle())
                        if lock.biometryAvailable {
                            RowDivider()
                            ToggleRow(sf: lock.biometryIcon, color: Theme.accent,
                                      title: "Mở khoá bằng \(lock.biometryName)",
                                      isOn: $lock.useBiometrics)
                        }
                        RowDivider()
                        SettingRow(sf: "timer", color: Theme.pink, title: "Tự khoá sau") {
                            Picker("", selection: $lock.delay) {
                                Text("Ngay lập tức").tag(0)
                                Text("1 phút").tag(60)
                                Text("5 phút").tag(300)
                                Text("15 phút").tag(900)
                            }
                            .pickerStyle(.menu)
                            .tint(Theme.accent)
                        }
                    }
                }

                SectionCard(title: "Plugin Xem video",
                            footer: "Tự dò video khi trang phát và hiện nút tải ở góc màn hình. Hỗ trợ MP4, WEBM và HLS không mã hoá; video DRM hoặc dạng luồng nội bộ (YouTube, Netflix…) không tải được. Chất lượng “Tự động”: Wi-Fi không giới hạn, mạng di động tối đa 720p, chế độ dữ liệu thấp hoặc Tiết kiệm dữ liệu tối đa 360p. Chỉ chọn được khi video HLS có nhiều mức chất lượng.") {
                    ToggleRow(sf: "play.rectangle.fill", color: Theme.pink,
                              title: "Xem & tải video",
                              subtitle: "Nút tải nổi khi có video",
                              isOn: $settings.videoTool)
                    ToggleRow(sf: "arrow.down.circle.fill", color: Theme.accent,
                              title: "Hiện nút tải nổi",
                              subtitle: "Tắt để ẩn nút; vẫn xem video ở Menu → Xem video",
                              isOn: $settings.videoFab)
                    RowDivider()
                    SettingRow(sf: "slider.horizontal.3", color: Theme.accent2, title: "Chất lượng tối đa",
                               subtitle: "Khi phát video HLS") {
                        Picker("", selection: $settings.videoQuality) {
                            Text("Tự động theo mạng").tag(0)
                            Text("360p").tag(360)
                            Text("480p").tag(480)
                            Text("720p").tag(720)
                            Text("1080p").tag(1080)
                            Text("2K").tag(1440)
                            Text("4K").tag(2160)
                        }
                        .pickerStyle(.menu)
                        .tint(Theme.accent)
                    }
                }

                SectionCard(title: "Hiển thị trang",
                            footer: "Nền tối đảo màu các trang sáng (trang đã tối thì giữ nguyên, ảnh và video không bị đảo). Bật/tắt nhanh ở Menu → Nền tối.") {
                    ToggleRow(asset: "ic_moon", color: Theme.accent2,
                              title: "Nền tối cho mọi trang",
                              isOn: $settings.darkPages)
                    RowDivider()
                    ToggleRow(asset: "ic_copy", color: Theme.accent,
                              title: "Chép văn bản tự do",
                              subtitle: "Bỏ chặn chọn / sao chép / giữ lâu của trang web",
                              isOn: $settings.freeCopy)
                }

                SectionCard(title: "Dịch trang",
                            footer: "Dùng Google Dịch: nội dung trang được gửi tới Google khi bạn dịch. Menu → Dịch trang để dịch, bấm lại để về bản gốc.") {
                    SettingRow(asset: "ic_translate", color: Theme.accent, title: "Dịch sang") {
                        Picker("", selection: $settings.translateLang) {
                            ForEach(PageTranslate.languages) { l in
                                Text(l.name).tag(l.code)
                            }
                        }
                        .pickerStyle(.menu)
                        .tint(Theme.accent)
                    }
                    RowDivider()
                    ToggleRow(asset: "ic_translate", color: Theme.accent2,
                              title: "Gợi ý dịch khi trang khác ngôn ngữ",
                              isOn: $settings.translateOffer)
                }

                SectionCard(title: "Phát nền",
                            footer: "Nhạc và âm thanh video vẫn phát khi tắt màn hình hoặc sang app khác, có nút điều khiển ở màn hình khoá. Muốn giữ hình video khi ra ngoài, dùng nút Hình trong hình (PiP) của trình phát.") {
                    ToggleRow(sf: "speaker.wave.2.fill", color: Theme.accent2,
                              title: "Tiếp tục phát khi thoát app",
                              subtitle: "Cả khi khoá màn hình",
                              isOn: $settings.bgPlay)
                }

                SectionCard(title: "Chơi game",
                            footer: "Hỗ trợ game: chặn phóng to bằng 2 ngón / chạm đúp, chặn chọn chữ, menu giữ lâu và kéo trang; thêm Fullscreen API cho game gọi requestFullscreen().") {
                    ToggleRow(sf: "gamecontroller.fill", color: Theme.accent,
                              title: "Hỗ trợ game khi toàn màn hình",
                              isOn: $settings.gameHelper)
                    RowDivider()
                    ToggleRow(sf: "rotate.right.fill", color: Theme.accent2,
                              title: "Tự xoay ngang khi toàn màn hình",
                              isOn: $settings.fsLandscape)
                    RowDivider()
                    SettingRow(sf: "sparkles", color: Theme.pink, title: "Làm nét game") {
                        Picker("", selection: $settings.sharp) {
                            Text("Tắt").tag(0)
                            Text("Nét pixel").tag(1)
                            Text("Tối đa").tag(2)
                        }
                        .pickerStyle(.menu)
                        .tint(Theme.accent)
                    }
                }

                SectionCard(title: "Khoá dấu trang & lịch sử",
                            footer: "Mật khẩu riêng 6 ký tự, độc lập với khoá ứng dụng. Khi bật, xem Dấu trang, Lịch sử và lưu dấu trang đều phải mở khoá; gợi ý trên thanh địa chỉ cũng bị ẩn. Tự khoá lại khi đóng bảng hoặc thoát app. Quên mật khẩu thì không khôi phục được.") {
                    ToggleRow(sf: "lock.doc.fill", color: Theme.accent,
                              title: "Đặt mật khẩu dấu trang & lịch sử",
                              isOn: Binding(get: { libLock.enabled },
                                            set: { pwFlow = $0 ? .libSet : .libDisable }))
                    if libLock.enabled {
                        RowDivider()
                        Button { pwFlow = .libChange } label: {
                            SettingRow(sf: "key.fill", color: Theme.warn, title: "Đổi mật khẩu") { Chevron() }
                        }
                        .buttonStyle(PressStyle())
                        if lock.biometryAvailable {
                            RowDivider()
                            ToggleRow(sf: lock.biometryIcon, color: Theme.accent,
                                      title: "Mở khoá bằng \(lock.biometryName)",
                                      isOn: $libLock.useBiometrics)
                        }
                    }
                }

                SectionCard(title: "Dữ liệu duyệt web", footer: message.isEmpty ? nil : message) {
                    Button {
                        LibraryStore.shared.clearHistory()
                        message = "Đã xoá lịch sử"
                    } label: {
                        SettingRow(sf: "clock.arrow.circlepath", color: Theme.danger, title: "Xoá lịch sử") { Chevron() }
                    }
                    .buttonStyle(PressStyle())
                    RowDivider()
                    Button {
                        Task {
                            await WKWebsiteDataStore.default().removeData(
                                ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                                modifiedSince: .distantPast)
                            message = "Đã xoá cookie và bộ nhớ đệm (bạn sẽ bị đăng xuất khỏi các trang)"
                        }
                    } label: {
                        SettingRow(sf: "trash.fill", color: Theme.danger, title: "Xoá cookie và bộ nhớ đệm") { Chevron() }
                    }
                    .buttonStyle(PressStyle())
                }
            }
        }
        .sheet(item: $pwFlow) { PasswordFlowView(flow: $0) }
    }
}

// MARK: - Dấu trang & Lịch sử

struct LibraryView: View {
    @ObservedObject private var lib = LibraryStore.shared
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var tab = 0
    @State private var query = ""
    @State private var confirmClear = false
    @State private var openFolder: UUID?
    @State private var showNewFolder = false
    @State private var newFolderName = ""
    @State private var renamingID: UUID?
    @State private var renameText = ""
    @State private var deletingFolder: BookmarkFolder?
    @ObservedObject private var gate = LibraryLock.shared

    private var searching: Bool { !query.isEmpty }

    private var shown: [SavedPage] {
        let src: [SavedPage]
        if tab == 0 {
            // Đang tìm: tìm trong mọi thư mục; không thì chỉ xem thư mục hiện tại
            src = searching ? lib.bookmarks : lib.bookmarks.filter { $0.folderID == openFolder }
        } else {
            src = lib.history
        }
        if query.isEmpty { return src }
        return src.filter {
            $0.title.localizedCaseInsensitiveContains(query) ||
            $0.url.localizedCaseInsensitiveContains(query)
        }
    }

    private var showFolders: Bool { tab == 0 && !searching && openFolder == nil && !lib.folders.isEmpty }

    private var titleText: String {
        if tab == 1 { return "Lịch sử" }
        return lib.folder(openFolder)?.name ?? "Dấu trang"
    }

    private func folderRow(_ f: BookmarkFolder) -> some View {
        HStack(spacing: 12) {
            Button { openFolder = f.id } label: {
                HStack(spacing: 12) {
                    Image(systemName: "folder.fill")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 38, height: 38)
                        .background(Theme.gradient, in: Circle())
                    VStack(alignment: .leading, spacing: 2) {
                        Text(f.name).font(.subheadline.weight(.semibold)).lineLimit(1).foregroundStyle(.primary)
                        Text("\(lib.count(in: f.id)) dấu trang").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            Menu {
                Button {
                    renameText = f.name
                    renamingID = f.id
                } label: { Label("Đổi tên", systemImage: "pencil") }
                Button(role: .destructive) { deletingFolder = f } label: { Label("Xoá thư mục", systemImage: "trash") }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.secondary)
                    .frame(width: 34, height: 34)
                    .background(Theme.chip, in: Circle())
            }
        }
        .padding(12)
        .card(radius: 18)
    }

    private func pageRow(_ p: SavedPage) -> some View {
        HStack(spacing: 12) {
            Button {
                browser.go(p.url)
                dismiss()
            } label: {
                HStack(spacing: 12) {
                    Text(hostLetter(p.url))
                        .font(Theme.rounded(.subheadline, .bold))
                        .foregroundStyle(.white)
                        .frame(width: 38, height: 38)
                        .background(Theme.gradient, in: Circle())
                    VStack(alignment: .leading, spacing: 2) {
                        Text(p.title.isEmpty ? p.url : p.title)
                            .font(.subheadline.weight(.semibold)).lineLimit(1)
                            .foregroundStyle(.primary)
                        Text(p.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        if tab == 1 {
                            Text(p.date.formatted(date: .abbreviated, time: .shortened))
                                .font(.caption2).foregroundStyle(.tertiary)
                        } else if searching, let f = lib.folder(p.folderID) {
                            Label(f.name, systemImage: "folder")
                                .font(.caption2).foregroundStyle(.tertiary)
                        }
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if tab == 0 {
                Menu {
                    Menu {
                        Button { lib.moveBookmark(p.id, to: nil) } label: {
                            Label("Ngoài cùng", systemImage: p.folderID == nil ? "checkmark" : "tray")
                        }
                        ForEach(lib.folders) { f in
                            Button { lib.moveBookmark(p.id, to: f.id) } label: {
                                Label(f.name, systemImage: p.folderID == f.id ? "checkmark" : "folder")
                            }
                        }
                    } label: { Label("Chuyển vào thư mục", systemImage: "folder") }
                    Button(role: .destructive) { lib.removeBookmark(p.id) } label: {
                        Label("Xoá dấu trang", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(.secondary)
                        .frame(width: 34, height: 34)
                        .background(Theme.chip, in: Circle())
                }
            } else {
                MiniIconButton(sf: "trash", tint: Theme.danger) { lib.removeHistory(p.id) }
            }
        }
        .padding(12)
        .card(radius: 18)
    }

    var body: some View {
        Group {
            if gate.isLocked {
                LibraryUnlockView(title: "Dấu trang & Lịch sử") { dismiss() }
            } else {
                content
            }
        }
        .onDisappear { gate.lock() }
    }

    private var content: some View {
        SheetScaffold(title: titleText,
                      subtitle: "\(shown.count) mục",
                      onClose: { dismiss() },
                      trailing: {
            if tab == 1 && !lib.history.isEmpty {
                Button("Xoá hết") { confirmClear = true }
                    .buttonStyle(SoftButtonStyle(tint: Theme.danger))
            } else if tab == 0 && openFolder == nil {
                Button {
                    newFolderName = ""
                    showNewFolder = true
                } label: {
                    Label("Thư mục", systemImage: "folder.badge.plus")
                }
                .buttonStyle(SoftButtonStyle(tint: Theme.accent))
            }
        }, content: {
            VStack(spacing: 12) {
                SegmentedPill(titles: ["Dấu trang", "Lịch sử"], icons: ["ic_star", "ic_book"], selection: $tab)
                    .padding(.horizontal, 16)

                HStack(spacing: 10) {
                    SVGIcon(name: "ic_search", size: 16).foregroundStyle(.secondary)
                    TextField("Tìm trong danh sách", text: $query)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    if !query.isEmpty {
                        Button { query = "" } label: {
                            SVGIcon(name: "ic_close", size: 13).foregroundStyle(.secondary)
                        }
                    }
                }
                .fieldStyle()
                .padding(.horizontal, 16)

                ScrollView {
                    LazyVStack(spacing: 10) {
                        if tab == 0, openFolder != nil, !searching {
                            Button { openFolder = nil } label: {
                                HStack(spacing: 8) {
                                    Image(systemName: "chevron.left").font(.caption.weight(.bold))
                                    Text("Tất cả dấu trang").font(.subheadline.weight(.semibold))
                                    Spacer(minLength: 0)
                                }
                                .foregroundStyle(Theme.accent)
                                .padding(.vertical, 4)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                        if showFolders {
                            ForEach(lib.folders) { folderRow($0) }
                        }
                        if shown.isEmpty && !showFolders {
                            EmptyState(asset: tab == 0 ? "ic_star" : "ic_book",
                                       title: tab == 0 ? (openFolder == nil ? "Chưa có dấu trang" : "Thư mục trống") : "Chưa có lịch sử",
                                       message: tab == 0 ? "Mở menu và bấm Dấu trang để lưu trang yêu thích, rồi chọn thư mục để phân loại." : "Các trang bạn đã xem sẽ hiện ở đây.")
                        }
                        ForEach(shown) { pageRow($0) }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 30)
                }
            }
        })
        .onChange(of: tab) { _ in openFolder = nil }
        .onChange(of: lib.folders) { f in
            if let o = openFolder, !f.contains(where: { $0.id == o }) { openFolder = nil }
        }
        .confirmationDialog("Xoá toàn bộ lịch sử?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xoá hết", role: .destructive) { lib.clearHistory() }
        }
        .confirmationDialog(deletingFolder.map { "Xoá thư mục “\($0.name)”?" } ?? "",
                            isPresented: Binding(get: { deletingFolder != nil }, set: { if !$0 { deletingFolder = nil } }),
                            titleVisibility: .visible) {
            Button("Xoá thư mục", role: .destructive) {
                if let f = deletingFolder { lib.deleteFolder(f.id) }
                deletingFolder = nil
            }
        } message: {
            Text("Các dấu trang bên trong không bị xoá, chúng được đưa ra ngoài cùng.")
        }
        .alert("Thư mục mới", isPresented: $showNewFolder) {
            TextField("Tên thư mục", text: $newFolderName)
            Button("Tạo") { lib.createFolder(newFolderName) }
            Button("Huỷ", role: .cancel) {}
        }
        .alert("Đổi tên thư mục", isPresented: Binding(get: { renamingID != nil }, set: { if !$0 { renamingID = nil } })) {
            TextField("Tên thư mục", text: $renameText)
            Button("Lưu") {
                if let id = renamingID { lib.renameFolder(id, to: renameText) }
                renamingID = nil
            }
            Button("Huỷ", role: .cancel) { renamingID = nil }
        }
    }
}

/// Bảng chọn thư mục / sửa tên cho dấu trang của trang đang xem.
struct BookmarkEditSheet: View {
    let url: URL
    var pageTitle = ""
    @ObservedObject private var lib = LibraryStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var showNewFolder = false
    @State private var newFolderName = ""
    @ObservedObject private var gate = LibraryLock.shared

    private var current: SavedPage? { lib.bookmark(for: url.absoluteString) }

    private func choose(_ id: UUID?) {
        guard let c = current else { return }
        lib.moveBookmark(c.id, to: id)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    private func folderChoice(_ title: String, icon: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon).font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(Theme.accent).frame(width: 26)
                Text(title).font(Theme.rounded(.subheadline, .semibold)).foregroundStyle(.primary).lineLimit(1)
                Spacer(minLength: 0)
                if selected {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(Theme.success)
                }
            }
            .padding(.vertical, 10)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    var body: some View {
        Group {
            if gate.isLocked {
                LibraryUnlockView(title: "Dấu trang") { dismiss() }
            } else {
                editor
            }
        }
        .onDisappear { gate.lock() }
    }

    private var editor: some View {
        SheetScaffold(title: "Dấu trang", subtitle: url.host, onClose: { commit(); dismiss() }, trailing: { EmptyView() }, content: {
            ScrollView {
                VStack(spacing: 14) {
                    TextField("Tên dấu trang", text: $name)
                        .fieldStyle()

                    VStack(alignment: .leading, spacing: 4) {
                        Text("THƯ MỤC").font(Theme.sectionFont).tracking(0.8).foregroundStyle(.secondary)
                            .padding(.bottom, 4)
                        folderChoice("Ngoài cùng", icon: "tray", selected: current?.folderID == nil) { choose(nil) }
                        ForEach(lib.folders) { f in
                            Divider()
                            folderChoice(f.name, icon: "folder", selected: current?.folderID == f.id) { choose(f.id) }
                        }
                        Divider()
                        folderChoice("Thư mục mới…", icon: "folder.badge.plus", selected: false) {
                            newFolderName = ""
                            showNewFolder = true
                        }
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .card()

                    Button(role: .destructive) {
                        if let c = current { lib.removeBookmark(c.id) }
                        dismiss()
                    } label: {
                        Text("Xoá dấu trang").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(SoftButtonStyle(tint: Theme.danger))
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 30)
            }
        })
        .onAppear {
            // Đang khoá lúc bấm Dấu trang thì chưa lưu; lưu ngay khi đã mở khoá
            if current == nil { lib.saveBookmark(url: url, title: pageTitle, folderID: nil) }
            name = current?.title ?? ""
        }
        .onDisappear { commit() }
        .alert("Thư mục mới", isPresented: $showNewFolder) {
            TextField("Tên thư mục", text: $newFolderName)
            Button("Tạo") {
                if let f = lib.createFolder(newFolderName) { choose(f.id) }
            }
            Button("Huỷ", role: .cancel) {}
        }
    }

    private func commit() {
        guard let c = current else { return }
        let t = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty, t != c.title { lib.saveBookmark(url: url, title: t, folderID: c.folderID) }
    }
}

// MARK: - Tải xuống

struct DownloadsView: View {
    @ObservedObject private var dl = DownloadManager.shared
    @EnvironmentObject var manager: ExtensionManager
    @Environment(\.dismiss) private var dismiss
    @State private var confirmClear = false
    @State private var playing: VideoSheet.PlayerItem?

    /// Định dạng trình phát gốc iOS phát được.
    private func playable(_ u: URL) -> Bool {
        ["mp4", "m4v", "mov", "qt", "3gp"].contains(u.pathExtension.lowercased())
    }

    private func play(_ item: DownloadItem, _ u: URL) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        let v = DetectedVideo(url: u, kind: "file", title: item.name, page: "")
        playing = VideoSheet.PlayerItem(video: v, context: VideoContext())
    }

    private func installable(_ u: URL) -> Bool {
        ["crx", "xpi", "zip", "js"].contains(u.pathExtension.lowercased())
    }

    private func sizeText(_ u: URL?) -> String {
        guard let u = u,
              let n = (try? u.resourceValues(forKeys: [.fileSizeKey]))?.fileSize else { return "" }
        return ByteCountFormatter.string(fromByteCount: Int64(n), countStyle: .file)
    }

    private func ext(_ name: String) -> String {
        let e = (name as NSString).pathExtension.uppercased()
        return e.isEmpty ? "FILE" : String(e.prefix(4))
    }

    var body: some View {
        SheetScaffold(title: "Tải xuống", subtitle: "\(dl.items.count) file", onClose: { dismiss() },
                      trailing: {
            if !dl.items.isEmpty {
                Button("Xoá hết") { confirmClear = true }
                    .buttonStyle(SoftButtonStyle(tint: Theme.danger))
            }
        }, content: {
            ScrollView {
                LazyVStack(spacing: 10) {
                    if dl.items.isEmpty {
                        EmptyState(asset: "ic_download", title: "Chưa có file nào",
                                   message: "File bạn tải về sẽ nằm ở đây.")
                    }
                    ForEach(dl.items) { item in
                        HStack(spacing: 12) {
                            if item.state == .done, let u = item.fileURL, playable(u) {
                                Button { play(item, u) } label: { VideoThumb(url: u, label: ext(item.name)) }
                                    .buttonStyle(PressStyle())
                            } else {
                                Text(ext(item.name))
                                    .font(.system(size: 11, weight: .heavy, design: .rounded))
                                    .foregroundStyle(.white)
                                    .frame(width: 44, height: 44)
                                    .background(Theme.gradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            }
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.name).font(.subheadline.weight(.semibold)).lineLimit(2)
                                if item.state == .running {
                                    GeometryReader { g in
                                        ZStack(alignment: .leading) {
                                            Capsule().fill(Theme.chip)
                                            Capsule().fill(Theme.gradient)
                                                .frame(width: max(6, g.size.width * CGFloat(item.progress)))
                                        }
                                    }
                                    .frame(height: 6)
                                } else if item.state == .failed {
                                    Text("Tải thất bại").font(.caption).foregroundStyle(Theme.danger)
                                } else {
                                    Text(sizeText(item.fileURL)).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            Spacer(minLength: 0)
                            if item.state == .done, let u = item.fileURL {
                                if playable(u) {
                                    Button { play(item, u) } label: {
                                        Image(systemName: "play.fill")
                                            .font(.system(size: 13, weight: .bold))
                                            .foregroundStyle(.white)
                                            .frame(width: 34, height: 34)
                                            .background(Theme.gradient, in: Circle())
                                    }
                                    .buttonStyle(PressStyle())
                                }
                                if installable(u) {
                                    Button("Cài") { manager.importFile(u) }
                                        .buttonStyle(SoftButtonStyle(filled: true))
                                }
                                ShareLink(item: u) {
                                    Image(systemName: "square.and.arrow.up")
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundStyle(Theme.accent)
                                        .frame(width: 34, height: 34)
                                        .background(Theme.accent.opacity(0.13), in: Circle())
                                }
                            }
                            MiniIconButton(sf: "trash", tint: Theme.danger) { dl.remove(item.id) }
                        }
                        .padding(12)
                        .card(radius: 18)
                        .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .onTapGesture {
                            if item.state == .done, let u = item.fileURL, playable(u) { play(item, u) }
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 30)
            }
        })
        .fullScreenCover(item: $playing) { p in
            NativePlayerCover(item: p) { playing = nil }
        }
        .confirmationDialog("Xoá tất cả \(dl.items.count) file đã tải?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xoá hết", role: .destructive) { dl.removeAll() }
            Button("Hủy", role: .cancel) {}
        }
    }
}

/// Ảnh xem trước (khung hình đầu) của video đã tải, kèm biểu tượng phát.
struct VideoThumb: View {
    let url: URL
    let label: String
    @State private var image: UIImage?

    private static let cache = NSCache<NSURL, UIImage>()

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: 14, style: .continuous)
        ZStack {
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                shape.fill(Theme.gradient)
            }
            Circle().fill(.black.opacity(0.45)).frame(width: 24, height: 24)
            Image(systemName: "play.fill")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(.white)
                .offset(x: 1)
        }
        .frame(width: 44, height: 44)
        .clipShape(shape)
        .task(id: url) {
            if let c = Self.cache.object(forKey: url as NSURL) { image = c; return }
            let u = url
            let img: UIImage? = await Task.detached(priority: .utility) {
                let gen = AVAssetImageGenerator(asset: AVURLAsset(url: u))
                gen.appliesPreferredTrackTransform = true
                gen.maximumSize = CGSize(width: 240, height: 240)
                guard let cg = try? gen.copyCGImage(at: CMTime(seconds: 1, preferredTimescale: 600), actualTime: nil)
                else { return nil }
                return UIImage(cgImage: cg)
            }.value
            if let img { Self.cache.setObject(img, forKey: u as NSURL); image = img }
        }
    }
}

// MARK: - Extension

struct ExtensionsView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var link = ""
    @State private var importing = false
    @State private var page: ExtPage?
    @State private var logFor: InstalledExtension?
    @State private var showLinks = false

    private func openStore(_ url: String) {
        browser.go(url)
        dismiss()
    }

    private func storeTile(_ sf: String, _ title: String, _ color: Color, _ url: String) -> some View {
        Button { openStore(url) } label: {
            VStack(alignment: .leading, spacing: 10) {
                IconChip(sf: sf, color: color, size: 40)
                Text(title).font(Theme.rounded(.subheadline, .bold)).foregroundStyle(.primary)
                    .multilineTextAlignment(.leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .card(radius: 20)
        }
        .buttonStyle(PressStyle())
    }

    var body: some View {
        SheetScaffold(title: "Extension", subtitle: "\(manager.items.count) đã cài", onClose: { dismiss() }) {
            ThemedScroll {
                VStack(alignment: .leading, spacing: 8) {
                    Text("CỬA HÀNG").font(Theme.sectionFont).tracking(0.8).foregroundStyle(.secondary).padding(.horizontal, 6)
                    HStack(spacing: 12) {
                        storeTile("bag.fill", "Chrome Web Store", Theme.accent, "https://chromewebstore.google.com")
                        storeTile("flame.fill", "Firefox Add-ons", Theme.warn, "https://addons.mozilla.org/vi/firefox/extensions/")
                    }
                    Button { showLinks = true } label: {
                        SettingRow(sf: "list.bullet.rectangle.fill", color: Theme.accent2,
                                   title: "Dán nhiều link → chọn để cài") { Chevron() }
                            .card(radius: 18)
                    }
                    .buttonStyle(PressStyle())
                }

                SectionCard(title: "Gợi ý nhanh") {
                    ForEach(Array(Suggested.all.enumerated()), id: \.element.id) { idx, s in
                        if idx > 0 { RowDivider(inset: 14) }
                        Button {
                            Task { await manager.installFromLink(s.url) }
                        } label: {
                            HStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(s.name).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                                    Text(s.note).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "arrow.down.circle.fill")
                                    .font(.title2).foregroundStyle(Theme.accent)
                            }
                            .padding(.horizontal, 14).padding(.vertical, 11)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(PressStyle())
                        .disabled(manager.busy)
                    }
                }

                SectionCard(title: "Thêm extension",
                            footer: "Hoặc mở trang extension trên Chrome Web Store / Firefox Add-ons rồi bấm nút “Thêm vào app”.") {
                    VStack(spacing: 12) {
                        HStack(spacing: 10) {
                            TextField("Dán link store, .user.js hoặc .zip", text: $link)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .keyboardType(.URL)
                                .fieldStyle()
                            Button("Cài") {
                                let l = link
                                link = ""
                                Task { await manager.installFromLink(l) }
                            }
                            .buttonStyle(SoftButtonStyle(filled: true))
                            .disabled(link.isEmpty || manager.busy)
                        }
                        Button { importing = true } label: {
                            Label("Chọn file (.zip .crx .xpi .js)", systemImage: "doc.badge.plus")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(SoftButtonStyle())
                    }
                    .padding(14)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("ĐÃ CÀI (\(manager.items.count))").font(Theme.sectionFont).tracking(0.8)
                        .foregroundStyle(.secondary).padding(.horizontal, 6)
                    if manager.items.isEmpty {
                        EmptyState(asset: "ic_puzzle", title: "Chưa có extension nào",
                                   message: "Cài extension từ cửa hàng hoặc dán link ở trên.")
                            .card()
                    }
                    ForEach(manager.items) { item in
                        row(item)
                    }
                }
            }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.item]) { result in
            if case .success(let u) = result { manager.importFile(u) }
        }
        .sheet(isPresented: $showLinks) { LinkImportView() }
        .sheet(item: $logFor) { it in
            ExtLogView(extId: it.id, title: it.name)
        }
        .sheet(item: $page) { p in
            NavigationStack {
                ExtPageView(page: p)
                    .navigationTitle(p.title)
                    .navigationBarTitleDisplayMode(.inline)
            }
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
    }

    private func pill(_ sf: String, _ title: String, tint: Color = Theme.accent, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: sf).font(.caption.weight(.semibold))
        }
        .buttonStyle(SoftButtonStyle(tint: tint))
    }

    @ViewBuilder
    private func row(_ item: InstalledExtension) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Text(String(item.name.prefix(1)).uppercased())
                    .font(Theme.rounded(.headline, .bold))
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(Theme.gradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.name).font(.subheadline.weight(.bold)).lineLimit(1)
                    Text("v\(item.version) · \(item.source)")
                        .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                Toggle("", isOn: Binding(
                    get: { item.enabled },
                    set: { manager.setEnabled(item.id, $0) }
                ))
                .labelsHidden()
                .tint(Theme.accent)
            }
            if let n = item.notes, !n.isEmpty {
                Label("Chưa chạy: " + n.joined(separator: ", "), systemImage: "exclamationmark.triangle.fill")
                    .font(.caption2).foregroundStyle(Theme.warn)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    if manager.store.backgroundEntry(id: item.id) != nil {
                        pill("doc.text", "Nhật ký") { logFor = item }
                    }
                    if let p = manager.store.popupPath(id: item.id) {
                        pill("rectangle.on.rectangle", "Popup") {
                            page = ExtPage(extId: item.id, path: p,
                                           tabURL: browser.currentURL?.absoluteString ?? "", title: item.name)
                        }
                    }
                    if let sp = manager.store.sidePanelPath(id: item.id) {
                        pill("sidebar.right", "Panel") {
                            page = ExtPage(extId: item.id, path: sp,
                                           tabURL: browser.currentURL?.absoluteString ?? "", title: item.name)
                        }
                    }
                    if let o = manager.store.optionsPath(id: item.id) {
                        pill("gearshape", "Tuỳ chọn") {
                            page = ExtPage(extId: item.id, path: o,
                                           tabURL: browser.currentURL?.absoluteString ?? "", title: item.name)
                        }
                    }
                    pill("trash", "Gỡ", tint: Theme.danger) { manager.remove(item.id) }
                }
            }
        }
        .padding(14)
        .card(radius: 20)
    }
}
