import SwiftUI
import WebKit
import UniformTypeIdentifiers

private func hostLetter(_ s: String) -> String {
    let h = (URL(string: s)?.host ?? s).replacingOccurrences(of: "www.", with: "")
    return h.isEmpty ? "•" : String(h.prefix(1)).uppercased()
}

// MARK: - Cài đặt

struct SettingsView: View {
    @ObservedObject private var settings = BrowserSettings.shared
    @ObservedObject private var lock = AppLock.shared
    @Environment(\.dismiss) private var dismiss
    @State private var pwFlow: PasswordFlow?
    @State private var message = ""

    var body: some View {
        SheetScaffold(title: "Cài đặt", subtitle: "Tuỳ chỉnh trình duyệt của bạn", onClose: { dismiss() }) {
            ThemedScroll {
                SectionCard(title: "Tìm kiếm & trang chủ") {
                    SettingRow(asset: "ic_search", title: "Công cụ tìm kiếm") {
                        Picker("", selection: $settings.searchEngine) {
                            Text("Google").tag("google")
                            Text("DuckDuckGo").tag("duckduckgo")
                            Text("Bing").tag("bing")
                        }
                        .pickerStyle(.menu)
                        .tint(Theme.accent)
                    }
                    RowDivider()
                    HStack(spacing: 12) {
                        IconChip(sf: "house.fill", color: Theme.accent2)
                        TextField("https://www.google.com", text: $settings.homepage)
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .lineLimit(1)
                            .frame(maxWidth: .infinity)
                            .fieldStyle()
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 11)
                }

                SectionCard(title: "Bảo mật",
                            footer: "Khi bật, app yêu cầu mật khẩu 6 ký tự mỗi lần mở và che nội dung trong màn hình đa nhiệm.") {
                    ToggleRow(asset: "ic_lock", color: Theme.success,
                              title: "Khoá ứng dụng bằng mật khẩu",
                              isOn: Binding(get: { lock.enabled },
                                            set: { pwFlow = $0 ? .set : .disable }))
                    if lock.enabled {
                        RowDivider()
                        Button { pwFlow = .change } label: {
                            SettingRow(sf: "key.fill", color: Theme.warn, title: "Đổi mật khẩu") { Chevron() }
                        }
                        .buttonStyle(PressStyle())
                        if lock.biometryAvailable {
                            RowDivider()
                            ToggleRow(sf: lock.biometryIcon, color: Theme.accent,
                                      title: "Mở khoá bằng \(lock.biometryName)",
                                      isOn: $lock.useBiometrics)
                        }
                        RowDivider()
                        SettingRow(sf: "timer", color: Theme.pink, title: "Tự khoá sau") {
                            Picker("", selection: $lock.delay) {
                                Text("Ngay lập tức").tag(0)
                                Text("1 phút").tag(60)
                                Text("5 phút").tag(300)
                                Text("15 phút").tag(900)
                            }
                            .pickerStyle(.menu)
                            .tint(Theme.accent)
                        }
                    }
                }

                SectionCard(title: "Plugin Xem video",
                            footer: "Tự dò video khi trang phát và hiện nút tải ở góc màn hình. Hỗ trợ MP4, WEBM và HLS không mã hoá; video DRM hoặc dạng luồng nội bộ (YouTube, Netflix…) không tải được.") {
                    ToggleRow(sf: "play.rectangle.fill", color: Theme.pink,
                              title: "Xem & tải video",
                              subtitle: "Nút tải nổi khi có video",
                              isOn: $settings.videoTool)
                    ToggleRow(sf: "arrow.down.circle.fill", color: Theme.accent,
                              title: "Hiện nút tải nổi",
                              subtitle: "Tắt để ẩn nút; vẫn xem video ở Menu → Xem video",
                              isOn: $settings.videoFab)
                }

                SectionCard(title: "Phát nền",
                            footer: "Nhạc và âm thanh video vẫn phát khi tắt màn hình hoặc sang app khác, có nút điều khiển ở màn hình khoá. Muốn giữ hình video khi ra ngoài, dùng nút Hình trong hình (PiP) của trình phát.") {
                    ToggleRow(sf: "speaker.wave.2.fill", color: Theme.accent2,
                              title: "Tiếp tục phát khi thoát app",
                              subtitle: "Cả khi khoá màn hình",
                              isOn: $settings.bgPlay)
                }

                SectionCard(title: "Chơi game",
                            footer: "Hỗ trợ game: chặn phóng to bằng 2 ngón / chạm đúp, chặn chọn chữ, menu giữ lâu và kéo trang; thêm Fullscreen API cho game gọi requestFullscreen().") {
                    ToggleRow(sf: "gamecontroller.fill", color: Theme.accent,
                              title: "Hỗ trợ game khi toàn màn hình",
                              isOn: $settings.gameHelper)
                    RowDivider()
                    ToggleRow(sf: "rotate.right.fill", color: Theme.accent2,
                              title: "Tự xoay ngang khi toàn màn hình",
                              isOn: $settings.fsLandscape)
                    RowDivider()
                    SettingRow(sf: "sparkles", color: Theme.pink, title: "Làm nét game") {
                        Picker("", selection: $settings.sharp) {
                            Text("Tắt").tag(0)
                            Text("Nét pixel").tag(1)
                            Text("Tối đa").tag(2)
                        }
                        .pickerStyle(.menu)
                        .tint(Theme.accent)
                    }
                }

                SectionCard(title: "Dữ liệu duyệt web", footer: message.isEmpty ? nil : message) {
                    Button {
                        LibraryStore.shared.clearHistory()
                        message = "Đã xoá lịch sử"
                    } label: {
                        SettingRow(sf: "clock.arrow.circlepath", color: Theme.danger, title: "Xoá lịch sử") { Chevron() }
                    }
                    .buttonStyle(PressStyle())
                    RowDivider()
                    Button {
                        Task {
                            await WKWebsiteDataStore.default().removeData(
                                ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                                modifiedSince: .distantPast)
                            message = "Đã xoá cookie và bộ nhớ đệm (bạn sẽ bị đăng xuất khỏi các trang)"
                        }
                    } label: {
                        SettingRow(sf: "trash.fill", color: Theme.danger, title: "Xoá cookie và bộ nhớ đệm") { Chevron() }
                    }
                    .buttonStyle(PressStyle())
                }
            }
        }
        .sheet(item: $pwFlow) { PasswordFlowView(flow: $0) }
    }
}

// MARK: - Dấu trang & Lịch sử

struct LibraryView: View {
    @ObservedObject private var lib = LibraryStore.shared
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var tab = 0
    @State private var query = ""
    @State private var confirmClear = false

    private var shown: [SavedPage] {
        let src = tab == 0 ? lib.bookmarks : lib.history
        if query.isEmpty { return src }
        return src.filter {
            $0.title.localizedCaseInsensitiveContains(query) ||
            $0.url.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        SheetScaffold(title: tab == 0 ? "Dấu trang" : "Lịch sử",
                      subtitle: "\(shown.count) mục",
                      onClose: { dismiss() },
                      trailing: {
            if tab == 1 && !lib.history.isEmpty {
                Button("Xoá hết") { confirmClear = true }
                    .buttonStyle(SoftButtonStyle(tint: Theme.danger))
            }
        }, content: {
            VStack(spacing: 12) {
                SegmentedPill(titles: ["Dấu trang", "Lịch sử"], icons: ["ic_star", "ic_book"], selection: $tab)
                    .padding(.horizontal, 16)

                HStack(spacing: 10) {
                    SVGIcon(name: "ic_search", size: 16).foregroundStyle(.secondary)
                    TextField("Tìm trong danh sách", text: $query)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    if !query.isEmpty {
                        Button { query = "" } label: {
                            SVGIcon(name: "ic_close", size: 13).foregroundStyle(.secondary)
                        }
                    }
                }
                .fieldStyle()
                .padding(.horizontal, 16)

                ScrollView {
                    LazyVStack(spacing: 10) {
                        if shown.isEmpty {
                            EmptyState(asset: tab == 0 ? "ic_star" : "ic_book",
                                       title: tab == 0 ? "Chưa có dấu trang" : "Chưa có lịch sử",
                                       message: tab == 0 ? "Mở menu và bấm Dấu trang để lưu trang yêu thích." : "Các trang bạn đã xem sẽ hiện ở đây.")
                        }
                        ForEach(shown) { p in
                            HStack(spacing: 12) {
                                Button {
                                    browser.go(p.url)
                                    dismiss()
                                } label: {
                                    HStack(spacing: 12) {
                                        Text(hostLetter(p.url))
                                            .font(Theme.rounded(.subheadline, .bold))
                                            .foregroundStyle(.white)
                                            .frame(width: 38, height: 38)
                                            .background(Theme.gradient, in: Circle())
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(p.title.isEmpty ? p.url : p.title)
                                                .font(.subheadline.weight(.semibold)).lineLimit(1)
                                                .foregroundStyle(.primary)
                                            Text(p.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                            if tab == 1 {
                                                Text(p.date.formatted(date: .abbreviated, time: .shortened))
                                                    .font(.caption2).foregroundStyle(.tertiary)
                                            }
                                        }
                                        Spacer(minLength: 0)
                                    }
                                    .contentShape(Rectangle())
                                }
                                .buttonStyle(.plain)
                                MiniIconButton(sf: "trash", tint: Theme.danger) {
                                    if tab == 0 { lib.removeBookmark(p.id) } else { lib.removeHistory(p.id) }
                                }
                            }
                            .padding(12)
                            .card(radius: 18)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 30)
                }
            }
        })
        .confirmationDialog("Xoá toàn bộ lịch sử?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xoá hết", role: .destructive) { lib.clearHistory() }
        }
    }
}

// MARK: - Tải xuống

struct DownloadsView: View {
    @ObservedObject private var dl = DownloadManager.shared
    @EnvironmentObject var manager: ExtensionManager
    @Environment(\.dismiss) private var dismiss
    @State private var confirmClear = false

    private func installable(_ u: URL) -> Bool {
        ["crx", "xpi", "zip", "js"].contains(u.pathExtension.lowercased())
    }

    private func sizeText(_ u: URL?) -> String {
        guard let u = u,
              let n = (try? u.resourceValues(forKeys: [.fileSizeKey]))?.fileSize else { return "" }
        return ByteCountFormatter.string(fromByteCount: Int64(n), countStyle: .file)
    }

    private func ext(_ name: String) -> String {
        let e = (name as NSString).pathExtension.uppercased()
        return e.isEmpty ? "FILE" : String(e.prefix(4))
    }

    var body: some View {
        SheetScaffold(title: "Tải xuống", subtitle: "\(dl.items.count) file", onClose: { dismiss() },
                      trailing: {
            if !dl.items.isEmpty {
                Button("Xoá hết") { confirmClear = true }
                    .buttonStyle(SoftButtonStyle(tint: Theme.danger))
            }
        }, content: {
            ScrollView {
                LazyVStack(spacing: 10) {
                    if dl.items.isEmpty {
                        EmptyState(asset: "ic_download", title: "Chưa có file nào",
                                   message: "File bạn tải về sẽ nằm ở đây.")
                    }
                    ForEach(dl.items) { item in
                        HStack(spacing: 12) {
                            Text(ext(item.name))
                                .font(.system(size: 11, weight: .heavy, design: .rounded))
                                .foregroundStyle(.white)
                                .frame(width: 44, height: 44)
                                .background(Theme.gradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.name).font(.subheadline.weight(.semibold)).lineLimit(2)
                                if item.state == .running {
                                    GeometryReader { g in
                                        ZStack(alignment: .leading) {
                                            Capsule().fill(Theme.chip)
                                            Capsule().fill(Theme.gradient)
                                                .frame(width: max(6, g.size.width * CGFloat(item.progress)))
                                        }
                                    }
                                    .frame(height: 6)
                                } else if item.state == .failed {
                                    Text("Tải thất bại").font(.caption).foregroundStyle(Theme.danger)
                                } else {
                                    Text(sizeText(item.fileURL)).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            Spacer(minLength: 0)
                            if item.state == .done, let u = item.fileURL {
                                if installable(u) {
                                    Button("Cài") { manager.importFile(u) }
                                        .buttonStyle(SoftButtonStyle(filled: true))
                                }
                                ShareLink(item: u) {
                                    Image(systemName: "square.and.arrow.up")
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundStyle(Theme.accent)
                                        .frame(width: 34, height: 34)
                                        .background(Theme.accent.opacity(0.13), in: Circle())
                                }
                            }
                            MiniIconButton(sf: "trash", tint: Theme.danger) { dl.remove(item.id) }
                        }
                        .padding(12)
                        .card(radius: 18)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 30)
            }
        })
        .confirmationDialog("Xoá tất cả \(dl.items.count) file đã tải?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xoá hết", role: .destructive) { dl.removeAll() }
            Button("Hủy", role: .cancel) {}
        }
    }
}

// MARK: - Extension

struct ExtensionsView: View {
    @EnvironmentObject var manager: ExtensionManager
    @EnvironmentObject var browser: BrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var link = ""
    @State private var importing = false
    @State private var page: ExtPage?
    @State private var logFor: InstalledExtension?
    @State private var showLinks = false

    private func openStore(_ url: String) {
        browser.go(url)
        dismiss()
    }

    private func storeTile(_ sf: String, _ title: String, _ color: Color, _ url: String) -> some View {
        Button { openStore(url) } label: {
            VStack(alignment: .leading, spacing: 10) {
                IconChip(sf: sf, color: color, size: 40)
                Text(title).font(Theme.rounded(.subheadline, .bold)).foregroundStyle(.primary)
                    .multilineTextAlignment(.leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .card(radius: 20)
        }
        .buttonStyle(PressStyle())
    }

    var body: some View {
        SheetScaffold(title: "Extension", subtitle: "\(manager.items.count) đã cài", onClose: { dismiss() }) {
            ThemedScroll {
                VStack(alignment: .leading, spacing: 8) {
                    Text("CỬA HÀNG").font(.caption.weight(.bold)).tracking(0.8).foregroundStyle(.secondary).padding(.horizontal, 6)
                    HStack(spacing: 12) {
                        storeTile("bag.fill", "Chrome Web Store", Theme.accent, "https://chromewebstore.google.com")
                        storeTile("flame.fill", "Firefox Add-ons", Theme.warn, "https://addons.mozilla.org/vi/firefox/extensions/")
                    }
                    Button { showLinks = true } label: {
                        SettingRow(sf: "list.bullet.rectangle.fill", color: Theme.accent2,
                                   title: "Dán nhiều link → chọn để cài") { Chevron() }
                            .card(radius: 18)
                    }
                    .buttonStyle(PressStyle())
                }

                SectionCard(title: "Gợi ý nhanh") {
                    ForEach(Array(Suggested.all.enumerated()), id: \.element.id) { idx, s in
                        if idx > 0 { RowDivider(inset: 14) }
                        Button {
                            Task { await manager.installFromLink(s.url) }
                        } label: {
                            HStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(s.name).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                                    Text(s.note).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "arrow.down.circle.fill")
                                    .font(.title2).foregroundStyle(Theme.accent)
                            }
                            .padding(.horizontal, 14).padding(.vertical, 11)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(PressStyle())
                        .disabled(manager.busy)
                    }
                }

                SectionCard(title: "Thêm extension",
                            footer: "Hoặc mở trang extension trên Chrome Web Store / Firefox Add-ons rồi bấm nút “Thêm vào app”.") {
                    VStack(spacing: 12) {
                        HStack(spacing: 10) {
                            TextField("Dán link store, .user.js hoặc .zip", text: $link)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .keyboardType(.URL)
                                .fieldStyle()
                            Button("Cài") {
                                let l = link
                                link = ""
                                Task { await manager.installFromLink(l) }
                            }
                            .buttonStyle(SoftButtonStyle(filled: true))
                            .disabled(link.isEmpty || manager.busy)
                        }
                        Button { importing = true } label: {
                            Label("Chọn file (.zip .crx .xpi .js)", systemImage: "doc.badge.plus")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(SoftButtonStyle())
                    }
                    .padding(14)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("ĐÃ CÀI (\(manager.items.count))").font(.caption.weight(.bold)).tracking(0.8)
                        .foregroundStyle(.secondary).padding(.horizontal, 6)
                    if manager.items.isEmpty {
                        EmptyState(asset: "ic_puzzle", title: "Chưa có extension nào",
                                   message: "Cài extension từ cửa hàng hoặc dán link ở trên.")
                            .card()
                    }
                    ForEach(manager.items) { item in
                        row(item)
                    }
                }
            }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.item]) { result in
            if case .success(let u) = result { manager.importFile(u) }
        }
        .sheet(isPresented: $showLinks) { LinkImportView() }
        .sheet(item: $logFor) { it in
            ExtLogView(extId: it.id, title: it.name)
        }
        .sheet(item: $page) { p in
            NavigationStack {
                ExtPageView(page: p)
                    .navigationTitle(p.title)
                    .navigationBarTitleDisplayMode(.inline)
            }
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
    }

    private func pill(_ sf: String, _ title: String, tint: Color = Theme.accent, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: sf).font(.caption.weight(.semibold))
        }
        .buttonStyle(SoftButtonStyle(tint: tint))
    }

    @ViewBuilder
    private func row(_ item: InstalledExtension) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Text(String(item.name.prefix(1)).uppercased())
                    .font(Theme.rounded(.headline, .bold))
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(Theme.gradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.name).font(.subheadline.weight(.bold)).lineLimit(1)
                    Text("v\(item.version) · \(item.source)")
                        .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                Toggle("", isOn: Binding(
                    get: { item.enabled },
                    set: { manager.setEnabled(item.id, $0) }
                ))
                .labelsHidden()
                .tint(Theme.accent)
            }
            if let n = item.notes, !n.isEmpty {
                Label("Chưa chạy: " + n.joined(separator: ", "), systemImage: "exclamationmark.triangle.fill")
                    .font(.caption2).foregroundStyle(Theme.warn)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    if manager.store.backgroundEntry(id: item.id) != nil {
                        pill("doc.text", "Nhật ký") { logFor = item }
                    }
                    if let p = manager.store.popupPath(id: item.id) {
                        pill("rectangle.on.rectangle", "Popup") {
                            page = ExtPage(extId: item.id, path: p,
                                           tabURL: browser.currentURL?.absoluteString ?? "", title: item.name)
                        }
                    }
                    if let sp = manager.store.sidePanelPath(id: item.id) {
                        pill("sidebar.right", "Panel") {
                            page = ExtPage(extId: item.id, path: sp,
                                           tabURL: browser.currentURL?.absoluteString ?? "", title: item.name)
                        }
                    }
                    if let o = manager.store.optionsPath(id: item.id) {
                        pill("gearshape", "Tuỳ chọn") {
                            page = ExtPage(extId: item.id, path: o,
                                           tabURL: browser.currentURL?.absoluteString ?? "", title: item.name)
                        }
                    }
                    pill("trash", "Gỡ", tint: Theme.danger) { manager.remove(item.id) }
                }
            }
        }
        .padding(14)
        .card(radius: 20)
    }
}
