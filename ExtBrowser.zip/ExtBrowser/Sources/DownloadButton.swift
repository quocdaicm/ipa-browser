import SwiftUI

/// Nút “Tải xuống” trên thanh địa chỉ: vòng tiến trình khi đang tải,
/// hiệu ứng toả sóng + dấu tích + rung nhẹ khi tải xong một file.
struct DownloadBarButton: View {
    @ObservedObject private var dl = DownloadManager.shared
    @Environment(\.privateMode) private var isPrivate
    var action: () -> Void

    @State private var wave = false
    @State private var showDone = false
    @State private var hideTask: DispatchWorkItem?
    @State private var useShrimp = false
    @State private var rock = false

    private var running: [DownloadItem] { dl.items.filter { $0.state == .running } }
    private var progress: Double {
        guard !running.isEmpty else { return 0 }
        return running.map(\.progress).reduce(0, +) / Double(running.count)
    }
    private var tint: Color { isPrivate ? Theme.privateAccent : Theme.accent }

    var body: some View {
        Button {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            action()
        } label: {
            ZStack {
                // Sóng lan ra khi tải xong
                Circle().stroke(Theme.success, lineWidth: 2.5)
                    .frame(width: 30, height: 30)
                    .scaleEffect(wave ? 2.5 : 1)
                    .opacity(wave ? 0 : 0.85)
                    .animation(.easeOut(duration: 0.85), value: wave)
                Circle().stroke(tint, lineWidth: 1.8)
                    .frame(width: 30, height: 30)
                    .scaleEffect(wave ? 2.0 : 1)
                    .opacity(wave ? 0 : 0.7)
                    .animation(.easeOut(duration: 0.85).delay(0.14), value: wave)

                Circle()
                    .fill(showDone ? AnyShapeStyle(Theme.success) : AnyShapeStyle(Theme.chip))
                    .frame(width: 30, height: 30)

                // Vòng tiến trình
                if !running.isEmpty && !showDone {
                    Circle().trim(from: 0, to: max(0.06, progress))
                        .stroke(tint, style: StrokeStyle(lineWidth: 2.2, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .frame(width: 30, height: 30)
                        .animation(.easeOut(duration: 0.25), value: progress)
                }

                if showDone {
                    // Xuồng (nón lá) hoặc con tôm, lắc nhẹ như đang đi trên sóng
                    SVGIcon(name: useShrimp ? "ic_shrimp" : "ic_boat", size: 19)
                        .foregroundStyle(.white)
                        .rotationEffect(.degrees(rock ? 9 : -9))
                        .offset(y: rock ? -1.5 : 1.5)
                        .animation(.easeInOut(duration: 0.34).repeatForever(autoreverses: true), value: rock)
                        .transition(.scale(scale: 0.3).combined(with: .opacity))
                } else {
                    SVGIcon(name: "ic_download", size: 15)
                        .foregroundStyle(running.isEmpty ? Color.secondary : tint)
                        .transition(.scale(scale: 0.3).combined(with: .opacity))
                }
            }
            .frame(width: 30, height: 30)
            .tapArea()
            .scaleEffect(showDone ? 1.12 : 1)
            .animation(.spring(response: 0.35, dampingFraction: 0.55), value: showDone)
        }
        .buttonStyle(PressStyle())
        .onChange(of: dl.doneTick) { _ in celebrate() }
        .accessibilityLabel("Tải xuống")
    }

    private func celebrate() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        var t = Transaction(); t.disablesAnimations = true
        withTransaction(t) { wave = false }
        DispatchQueue.main.async {
            wave = true
            withAnimation { showDone = true }
        }
        useShrimp.toggle()          // lần này xuồng, lần sau tôm, xen kẽ
        rock = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { rock = true }
        hideTask?.cancel()
        let w = DispatchWorkItem { withAnimation { showDone = false }; rock = false }
        hideTask = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2, execute: w)
    }
}
