import SwiftUI
import UIKit

extension Notification.Name {
    static let xbPinchOpenTabs = Notification.Name("xb.pinchOpenTabs")
}

/// Cử chỉ: hai ngón cái đặt ở hai mép trái/phải màn hình rồi chụm vào giữa → mở màn hình “Các thẻ”.
/// Gắn vào cả cửa sổ nên dùng được ở mọi nơi (trang chủ, trang web), không cản các thao tác khác.
@MainActor
final class EdgePinchTabs: NSObject, UIGestureRecognizerDelegate {
    static let shared = EdgePinchTabs()

    private weak var window: UIWindow?
    private var recognizer: UIPinchGestureRecognizer?
    private var armed = false
    private var fired = false

    /// Vùng mép: mỗi ngón phải bắt đầu trong 30% chiều rộng ở mỗi bên.
    private let edgeZone: CGFloat = 0.30
    /// Khoảng cách hai ngón phải thu lại còn dưới mức này (so với lúc đầu) thì mở thẻ.
    private let triggerScale: CGFloat = 0.80

    func install(on w: UIWindow) {
        guard window !== w else { return }
        if let r = recognizer { r.view?.removeGestureRecognizer(r) }
        let r = UIPinchGestureRecognizer(target: self, action: #selector(handle(_:)))
        r.delegate = self
        r.cancelsTouchesInView = false
        r.delaysTouchesBegan = false
        r.delaysTouchesEnded = false
        w.addGestureRecognizer(r)
        window = w
        recognizer = r
    }

    @objc private func handle(_ g: UIPinchGestureRecognizer) {
        guard let w = window else { return }
        switch g.state {
        case .began:
            fired = false
            armed = false
            guard g.numberOfTouches == 2 else { return }
            let a = g.location(ofTouch: 0, in: w)
            let b = g.location(ofTouch: 1, in: w)
            let width = w.bounds.width
            armed = min(a.x, b.x) < width * edgeZone && max(a.x, b.x) > width * (1 - edgeZone)
        case .changed:
            guard armed, !fired, g.scale < triggerScale else { return }
            fired = true
            // Đang mở bảng/cửa sổ khác (cài đặt, thẻ, trình phát…) thì bỏ qua
            if w.rootViewController?.presentedViewController != nil { return }
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            NotificationCenter.default.post(name: .xbPinchOpenTabs, object: nil)
        default:
            armed = false
            fired = false
        }
    }

    // Cho phép chạy song song với cử chỉ của trang web (phóng to/thu nhỏ…)
    nonisolated func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                                       shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool {
        true
    }
}

/// View ẩn, chỉ để lấy cửa sổ hiện tại rồi gắn cử chỉ vào đó.
struct EdgePinchInstaller: UIViewRepresentable {
    func makeUIView(context: Context) -> InstallerView { InstallerView() }
    func updateUIView(_ uiView: InstallerView, context: Context) {}

    final class InstallerView: UIView {
        override init(frame: CGRect) {
            super.init(frame: frame)
            isUserInteractionEnabled = false
            backgroundColor = .clear
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

        override func didMoveToWindow() {
            super.didMoveToWindow()
            guard let w = window else { return }
            Task { @MainActor in EdgePinchTabs.shared.install(on: w) }
        }
    }
}
