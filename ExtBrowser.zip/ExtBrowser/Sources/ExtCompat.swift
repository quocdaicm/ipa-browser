import Foundation

/// Kết quả kiểm tra extension có chạy được trên app này hay không.
struct CompatReport {
    /// Lý do không dùng được (có lý do nào thì từ chối cài).
    var blockers: [String] = []
    /// Cài được nhưng một số chức năng sẽ không chạy.
    var warnings: [String] = []
}

enum ExtCompat {
    static func check(manifest m: [String: Any], files: [String: Data]) -> CompatReport {
        var r = CompatReport()

        func norm(_ p: String) -> String {
            var s = p
            while s.hasPrefix("./") { s.removeFirst(2) }
            while s.hasPrefix("/") { s.removeFirst() }
            if let q = s.firstIndex(where: { $0 == "?" || $0 == "#" }) { s = String(s[..<q]) }
            return s
        }
        func has(_ p: String) -> Bool { files[norm(p)] != nil }
        func strings(_ v: Any?) -> [String] { (v as? [Any])?.compactMap { $0 as? String } ?? [] }

        // 1) Loại extension không phải dạng chạy được
        let mv = (m["manifest_version"] as? NSNumber)?.intValue ?? 0
        if mv != 2 && mv != 3 {
            r.blockers.append("manifest_version không hợp lệ (cần 2 hoặc 3)")
            return r
        }
        if m["theme"] != nil {
            r.blockers.append("đây là giao diện (theme), không phải extension")
            return r
        }
        if m["dictionaries"] != nil || m["langpack_id"] != nil {
            r.blockers.append("đây là từ điển / gói ngôn ngữ, không phải extension")
            return r
        }

        let perms = Set(strings(m["permissions"]))

        // 2) Các thành phần chạy được
        var missing: [String] = []

        var hasContent = false
        for cs in (m["content_scripts"] as? [[String: Any]]) ?? [] {
            for f in strings(cs["js"]) + strings(cs["css"]) {
                if has(f) { hasContent = true } else { missing.append(f) }
            }
        }

        var hasBackground = false
        if let bg = m["background"] as? [String: Any] {
            var list = strings(bg["scripts"])
            if let sw = bg["service_worker"] as? String { list.append(sw) }
            if let pg = bg["page"] as? String { list.append(pg) }
            for f in list {
                if has(f) { hasBackground = true } else { missing.append(f) }
            }
        }

        var hasUI = false
        for key in ["action", "browser_action", "page_action"] {
            if let a = m[key] as? [String: Any], let p = a["default_popup"] as? String, !p.isEmpty {
                if has(p) { hasUI = true } else { missing.append(p) }
            }
        }
        if let o = m["options_ui"] as? [String: Any], let p = o["page"] as? String, has(p) { hasUI = true }
        if let p = m["options_page"] as? String, has(p) { hasUI = true }

        var dnrOK = 0, dnrBad = 0
        if let d = m["declarative_net_request"] as? [String: Any] {
            for res in (d["rule_resources"] as? [[String: Any]]) ?? [] {
                guard let path = res["path"] as? String,
                      let data = files[norm(path)],
                      let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else { continue }
                for rule in arr {
                    let t = ((rule["action"] as? [String: Any])?["type"] as? String) ?? ""
                    if ["block", "allow", "allowAllRequests"].contains(t) { dnrOK += 1 } else { dnrBad += 1 }
                }
            }
        }
        let hasDNR = dnrOK > 0

        var hasSide = false
        if let sp = m["side_panel"] as? [String: Any], let p = sp["default_path"] as? String, has(p) { hasSide = true }
        if let sb = m["sidebar_action"] as? [String: Any], let p = sb["default_panel"] as? String, has(p) { hasSide = true }
        if hasSide { hasUI = true }

        var other: [String] = []
        if (m["side_panel"] != nil || m["sidebar_action"] != nil) && !hasSide { other.append("side panel") }
        if m["devtools_page"] != nil { other.append("công cụ nhà phát triển (devtools)") }
        if m["chrome_url_overrides"] != nil { other.append("thay trang tab mới") }
        if m["omnibox"] != nil { other.append("omnibox") }

        let working = hasContent || hasDNR

        // 3) Lý do không dùng được
        if perms.contains("nativeMessaging") && !working {
            r.blockers.append("cần ứng dụng cài kèm trên máy (native messaging), iOS không hỗ trợ")
        }
        if perms.contains("proxy") && !working {
            r.blockers.append("extension proxy/VPN, iOS không cho extension đổi proxy")
        }
        if perms.contains("webRequestBlocking") && !working {
            r.blockers.append("dựa vào chặn request động (webRequestBlocking), app chỉ hỗ trợ declarativeNetRequest")
        }
        if r.blockers.isEmpty, perms.contains("webRequest"), !working, !hasUI {
            r.blockers.append("chỉ chạy nền và dựa vào webRequest, app không hỗ trợ")
        }
        if r.blockers.isEmpty && !(hasContent || hasDNR || hasBackground || hasUI) {
            if !other.isEmpty {
                r.blockers.append("chỉ có " + other.joined(separator: ", ") + ", app không hỗ trợ")
            } else if dnrBad > 0 {
                r.blockers.append("chỉ có luật chuyển hướng / sửa header (redirect, modifyHeaders), app không hỗ trợ")
            } else {
                r.blockers.append("không có thành phần nào chạy được (content script, trang nền, luật chặn, popup)")
            }
        }
        if !r.blockers.isEmpty { return r }

        // 4) Cài được nhưng chạy một phần
        let partial: [(String, String)] = [
            ("webRequestBlocking", "không chặn được request động"),
            ("webRequest", "webRequest không chặn/sửa được request"),
            ("nativeMessaging", "native messaging"),
            ("proxy", "proxy"),
            ("identity", "đăng nhập tài khoản (identity)"),
            ("offscreen", "offscreen"),
            ("debugger", "debugger"),
            ("tabCapture", "chụp/ghi tab"),
            ("desktopCapture", "ghi màn hình"),
            ("pageCapture", "lưu trang MHTML"),
            ("bookmarks", "dấu trang của extension"),
            ("history", "lịch sử của extension"),
            ("sessions", "sessions"),
            ("topSites", "topSites"),
            ("tts", "đọc văn bản (tts)"),
            ("contextMenus", "menu chuột phải"),
            ("notifications", "thông báo")
        ]
        for (perm, text) in partial where perms.contains(perm) {
            r.warnings.append(text)
        }
        for o in other { r.warnings.append(o) }
        if dnrBad > 0 { r.warnings.append("\(dnrBad) luật redirect/sửa header bị bỏ qua") }
        if !missing.isEmpty {
            r.warnings.append("thiếu file: " + missing.prefix(3).joined(separator: ", "))
        }
        var seen = Set<String>()
        r.warnings = r.warnings.filter { seen.insert($0).inserted }
        return r
    }
}
