import Foundation

enum ExtError: LocalizedError {
    case download, noManifest, badFile
    case incompatible([String])
    var errorDescription: String? {
        switch self {
        case .download: return "Không tải được extension"
        case .noManifest: return "Không tìm thấy manifest.json"
        case .badFile: return "File không hợp lệ"
        case .incompatible(let r): return "Không cài được: " + r.joined(separator: "; ")
        }
    }
}

struct UserScriptMeta {
    var name = "Userscript"
    var version = "1.0"
    var matches: [String] = []
    var excludes: [String] = []
    var runAt = "document_idle"
    var grants: [String] = []
    var noframes = false
    var injectInto = ""

    init(_ text: String) {
        var inside = false
        for raw in text.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.hasPrefix("// ==UserScript==") { inside = true; continue }
            if line.hasPrefix("// ==/UserScript==") { break }
            guard inside, line.hasPrefix("//") else { continue }
            let body = String(line.dropFirst(2)).trimmingCharacters(in: .whitespaces)
            guard body.hasPrefix("@") else { continue }
            let parts = body.dropFirst().split(maxSplits: 1, whereSeparator: { $0 == " " || $0 == "\t" })
            guard let key = parts.first.map(String.init) else { continue }
            let val = parts.count > 1 ? parts[1].trimmingCharacters(in: .whitespaces) : ""
            switch key {
            case "name": name = val
            case "version": version = val
            case "match", "include": matches.append(val)
            case "exclude", "exclude-match": excludes.append(val)
            case "run-at": runAt = val.replacingOccurrences(of: "-", with: "_")
            case "grant": grants.append(val)
            case "noframes": noframes = true
            case "inject-into": injectInto = val
            default: break
            }
        }
        if matches.isEmpty { matches = ["<all_urls>"] }
    }
}

@MainActor
final class ExtensionManager: ObservableObject {
    enum StoreTarget {
        case chrome(String)
        case firefox(String)
    }

    @Published var items: [InstalledExtension] = []
    @Published var busy = false
    @Published var notice: String?

    let store = ExtStore.shared

    init() {
        items = store.loadIndex()
    }

    // MARK: Store detection

    static func storeTarget(for url: URL?) -> StoreTarget? {
        guard let url = url, let host = url.host?.lowercased() else { return nil }
        let comps = url.pathComponents
        if host == "chromewebstore.google.com" || (host == "chrome.google.com" && url.path.contains("/webstore")) {
            let isID: (String) -> Bool = { s in
                s.count == 32 && s.allSatisfy { ("a"..."p").contains($0) }
            }
            if let id = comps.last(where: isID) { return .chrome(id) }
        }
        if host == "addons.mozilla.org", let i = comps.firstIndex(of: "addon"), i + 1 < comps.count {
            return .firefox(comps[i + 1])
        }
        return nil
    }

    // MARK: Install

    func flash(_ s: String) {
        notice = s
        Task {
            try? await Task.sleep(nanoseconds: UInt64(max(3.5, Double(s.count) / 10) * 1_000_000_000))
            if self.notice == s { self.notice = nil }
        }
    }

    /// Thông báo sau khi cài: kèm phần chức năng không chạy (nếu có).
    private func installedNote(_ item: InstalledExtension) -> String {
        guard let n = item.notes, !n.isEmpty else { return "Đã cài: \(item.name)" }
        return "Đã cài: \(item.name). Chưa chạy được: " + n.joined(separator: ", ")
    }

    private static func errorText(_ e: Error) -> String {
        if case ExtError.incompatible = e { return e.localizedDescription }
        return "Lỗi: \(e.localizedDescription)"
    }

    private func installStore(_ t: StoreTarget) async throws -> InstalledExtension {
        switch t {
        case .chrome(let id):
            let u = URL(string: "https://clients2.google.com/service/update2/crx?response=redirect&prodversion=120.0.0.0&acceptformat=crx2,crx3&x=id%3D\(id)%26uc")!
            let (data, resp) = try await URLSession.shared.data(from: u)
            guard (resp as? HTTPURLResponse)?.statusCode == 200, data.count > 100 else { throw ExtError.download }
            return try install(archive: data, preferredId: id, source: "chrome")
        case .firefox(let slug):
            let api = URL(string: "https://addons.mozilla.org/api/v5/addons/addon/\(slug)/")!
            let (jd, _) = try await URLSession.shared.data(from: api)
            guard let j = try JSONSerialization.jsonObject(with: jd) as? [String: Any],
                  let cv = j["current_version"] as? [String: Any],
                  let f = cv["file"] as? [String: Any],
                  let s = f["url"] as? String,
                  let fu = URL(string: s) else { throw ExtError.download }
            let (data, _) = try await URLSession.shared.data(from: fu)
            return try install(archive: data, preferredId: slug, source: "firefox")
        }
    }

    func installFromStore(_ t: StoreTarget) async {
        busy = true
        defer { busy = false }
        do {
            let item = try await installStore(t)
            flash(installedNote(item))
        } catch {
            flash(Self.errorText(error))
        }
    }

    /// Cài một link và trả kết quả (dùng cho danh sách chọn nhiều extension, không bật thông báo nổi).
    func installReturning(_ text: String) async -> (ok: Bool, message: String) {
        let s = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: s), url.scheme?.hasPrefix("http") == true else {
            return (false, "Link không hợp lệ")
        }
        busy = true
        defer { busy = false }
        do {
            if let t = Self.storeTarget(for: url) {
                let item = try await installStore(t)
                return (true, installedNote(item))
            }
            let (data, _) = try await URLSession.shared.data(from: url)
            let head = String(decoding: data.prefix(3000), as: UTF8.self)
            let item: InstalledExtension
            if url.path.hasSuffix(".user.js") || head.contains("==UserScript==") {
                item = try installUserScript(String(decoding: data, as: UTF8.self),
                                             fileName: url.deletingPathExtension().lastPathComponent)
            } else {
                item = try install(archive: data, preferredId: nil, source: "link")
            }
            return (true, installedNote(item))
        } catch {
            return (false, Self.errorText(error))
        }
    }

    func installFromLink(_ text: String) async {
        let s = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: s), url.scheme?.hasPrefix("http") == true else {
            flash("Link không hợp lệ")
            return
        }
        if let t = Self.storeTarget(for: url) {
            await installFromStore(t)
            return
        }
        busy = true
        defer { busy = false }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let head = String(decoding: data.prefix(3000), as: UTF8.self)
            if url.path.hasSuffix(".user.js") || head.contains("==UserScript==") {
                let item = try installUserScript(String(decoding: data, as: UTF8.self),
                                                 fileName: url.deletingPathExtension().lastPathComponent)
                flash(installedNote(item))
            } else {
                let item = try install(archive: data, preferredId: nil, source: "link")
                flash(installedNote(item))
            }
        } catch {
            flash(Self.errorText(error))
        }
    }

    func importFile(_ url: URL) {
        let ok = url.startAccessingSecurityScopedResource()
        defer { if ok { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try Data(contentsOf: url)
            let head = String(decoding: data.prefix(3000), as: UTF8.self)
            if url.pathExtension.lowercased() == "js" || head.contains("==UserScript==") {
                let item = try installUserScript(String(decoding: data, as: UTF8.self),
                                                 fileName: url.deletingPathExtension().lastPathComponent)
                flash(installedNote(item))
            } else {
                let item = try install(archive: data, preferredId: nil, source: "file")
                flash(installedNote(item))
            }
        } catch {
            flash(Self.errorText(error))
        }
    }

    @discardableResult
    func install(archive raw: Data, preferredId: String?, source: String) throws -> InstalledExtension {
        let zip = try ZipArchive(data: CRX.zipData(from: raw))
        guard let mf = zip.entries
            .filter({ $0.name == "manifest.json" || $0.name.hasSuffix("/manifest.json") })
            .min(by: { $0.name.count < $1.name.count }) else { throw ExtError.noManifest }
        let prefix = String(mf.name.dropLast("manifest.json".count))
        var files: [String: Data] = [:]
        for e in zip.entries where e.name.hasPrefix(prefix) && !e.name.hasSuffix("/") {
            let rel = String(e.name.dropFirst(prefix.count))
            if rel.contains("..") || rel.hasPrefix("/") { continue }
            files[rel] = try zip.extract(e)
        }
        guard var mdata = files["manifest.json"] else { throw ExtError.noManifest }
        if mdata.starts(with: [0xEF, 0xBB, 0xBF]) {
            mdata = mdata.dropFirst(3)
            files["manifest.json"] = mdata
        }
        guard let manifest = (try? JSONSerialization.jsonObject(with: mdata)) as? [String: Any] else {
            throw ExtError.noManifest
        }
        let name = resolve(manifest["name"] as? String ?? "Extension", manifest, files)
        let version = manifest["version"] as? String ?? ""

        // Kiểm tra extension có chạy được không trước khi ghi xuống máy
        let report = ExtCompat.check(manifest: manifest, files: files)
        if !report.blockers.isEmpty {
            throw ExtError.incompatible(["\(name): " + report.blockers.joined(separator: "; ")])
        }

        let id = Self.slug(preferredId ?? name)
        try store.write(files: files, id: id)
        return register(InstalledExtension(id: id, name: name, version: version,
                                           enabled: true, isUserScript: false, source: source,
                                           notes: report.warnings.isEmpty ? nil : report.warnings))
    }

    @discardableResult
    func installUserScript(_ text: String, fileName: String) throws -> InstalledExtension {
        let meta = UserScriptMeta(text)
        let name = meta.name == "Userscript" ? fileName : meta.name
        let id = "us-" + Self.slug(name)
        let manifest: [String: Any] = [
            "name": name,
            "version": meta.version,
            "manifest_version": 2,
            "x_userscript": true,
            "content_scripts": [[
                "matches": meta.matches,
                "exclude_matches": meta.excludes,
                "js": ["script.user.js"],
                "run_at": meta.runAt
            ]]
        ]
        // Không khai @grant (hoặc @grant none) -> chạy ở world của trang để thấy biến của trang.
        let noGrant = meta.grants.isEmpty || meta.grants.allSatisfy { $0 == "none" }
        let wantPage = meta.injectInto == "page" || (noGrant && meta.injectInto != "content")
        var manifest2 = manifest
        if var cs = manifest2["content_scripts"] as? [[String: Any]], !cs.isEmpty {
            cs[0]["all_frames"] = !meta.noframes
            if wantPage { cs[0]["world"] = "MAIN" }
            manifest2["content_scripts"] = cs
        }
        let mdata = try JSONSerialization.data(withJSONObject: manifest2)
        try store.write(files: ["manifest.json": mdata, "script.user.js": Data(text.utf8)], id: id)
        return register(InstalledExtension(id: id, name: name, version: meta.version,
                                           enabled: true, isUserScript: true, source: "userscript"))
    }

    // MARK: Manage

    func setEnabled(_ id: String, _ on: Bool) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        items[i].enabled = on
        store.saveIndex(items)
    }

    func remove(_ id: String) {
        store.deleteExtension(id)
        items.removeAll { $0.id == id }
        store.saveIndex(items)
    }

    private func register(_ item: InstalledExtension) -> InstalledExtension {
        var it = item
        if let i = items.firstIndex(where: { $0.id == item.id }) {
            it.rev = (items[i].rev ?? 0) + 1
            items[i] = it
        } else {
            it.rev = 1
            items.append(it)
        }
        store.saveIndex(items)
        return it
    }

    // MARK: Helpers

    static func slug(_ s: String) -> String {
        let allowed = Set("abcdefghijklmnopqrstuvwxyz0123456789-")
        let t = String(s.lowercased().map { allowed.contains($0) ? $0 : Character("-") })
        let trimmed = t.trimmingCharacters(in: CharacterSet(charactersIn: "-"))
        return trimmed.isEmpty ? "ext" : trimmed
    }

    private func resolve(_ s: String, _ manifest: [String: Any], _ files: [String: Data]) -> String {
        guard s.hasPrefix("__MSG_"), s.hasSuffix("__"), s.count > 8 else { return s }
        let key = String(s.dropFirst(6).dropLast(2))
        let loc = manifest["default_locale"] as? String ?? "en"
        for l in [loc, "en", "en_US"] {
            if let d = files["_locales/\(l)/messages.json"],
               let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any],
               let entry = o.first(where: { $0.key.lowercased() == key.lowercased() })?.value as? [String: Any],
               let m = entry["message"] as? String {
                return m
            }
        }
        return key
    }
}
